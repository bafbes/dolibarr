<?php
/* Copyright (C) 2007 		Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2008-2011	Jean Heimburger	   	<jean@tiaris.fr> http://www.tiaris.fr
 * Copyright (C) 2011-2013  Philippe Grand      <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013	Juanjo Menent	   	<jmenent@sbyte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       ecommerce/site_index.php
 *        \ingroup    ecommerce
 *        \brief      Index page for an e-commerce site
 *        \author        Jean Heimburger
 */

require("./pre.inc.php");
dol_include_once("/ecommerce/core/lib/ecommerce.lib.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/ecom_order.class.php");
dol_include_once("/ecommerce/class/E_product.class.php");
dol_include_once("/ecommerce/class/E_order.class.php");
dol_include_once("/ecommerce/class/ecom_log.class.php");
require_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");
//compatibilité
dol_include_once("/ecommerce/includes/orders.inc.php");

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("other");
$langs->load("ecommerce@ecommerce");


// Protection if external user
$socid = GETPOST('socid', 'int');
if ($user->societe_id) $socid = $user->societe_id;
$result = restrictedArea($user, 'societe', $socid);


/*
 * Actions
 */


// Get parameters
$siteid = GETPOST('siteid', 'int');
$limit = GETPOST("limit", 'int')?GETPOST("limit", 'int'):$conf->liste_limit;
$offset = GETPOST("offset", 'int')?GETPOST("offset", 'int'):0;
$action=GETPOST("action");
if ($siteid) {
// get site_parameters
	$site_params = new Ecom_site($db);
	if ($site_params->fetch($siteid, $user) < 0) {
		setEventMessage($langs->trans("ReadSiteError"), 'errors');
	}
	else {

	}
}
else setEventMessage($langs->trans("ErrorNoSite"), 'errors');


if ($action== 'import') {
    //Bouton IMPORTER NOUVELLES COMMANDES
	// updating data
	$res = get_orders($siteid, $db, $user);
	if ($res) setEventMessage($langs->trans("Ok"));
	else setEventMessage($langs->trans("ImportError1"), 'errors');
/*	$res = import_orders($siteid, $db, $user);
	if ($res < 0) setEventMessage($langs->trans("ImportError2"), 'errors');
	elseif ($res == 0) setEventMessage($langs->trans("ImportNoOrders"));
	else  setEventMessage($langs->trans("ImportedOrders"));*/
}
elseif ($action== 'importOrder') {
	$now = dol_now();
	$ecomlog = new Ecom_log($db);
    $ecom_order = GETPOST("ecom_order", 'int');
    $e_order = new E_order($db, $siteid, $user);
    $result=$e_order->import_order($ecom_order);
    if ( $result< 0) {
        dol_syslog("ws_import::import_orders Commande " . $ecom_order . " ECHEC de l'import\n", LOG_ERR);
        //trace dans log
        $ecomlog->site_id = $siteid;
        $ecomlog->log_date = $now;
        $ecomlog->log_fct = 'COM';
        $ecomlog->log_type = "ERR";
        $ecomlog->log_fonction = "Import commande " . $ecom_order;
        $ecomlog->log_message = $e_order->error;
        $ecomlog->create($user);
        // si on échoue dans l'import on passe le doli_order à -1
        if ($e_order->findInSite($ecom_order, $siteid) > 0) {
            $e_order->doli_order = -1;
            $e_order->datem = $now;

            dol_syslog("orders.inc::import commandes update ecom_order " . $e_order->id, LOG_ERR);
            if ($e_order->update($user) < 0) {
                dol_syslog("orders.inc::import commandes update ecom_order échoué " . $e_order->error, LOG_ERR);
            }
        }
    }
    else {
        // traitements d'après création de commande
        dol_syslog("ws_import::import_orders Commande " . $ecom_order . " importée numéro " . $obj->doli_order . "\n", LOG_DEBUG);

        $commande = new Commande($db);
        if ($commande->fetch($e_order->doli_order) < 0) {
            dol_syslog("ws_import::import_orders erreur lecture commande" . $commande->error, LOG_ERR);
            return -1;
        }
        dol_syslog("ws_import::import_orders test date commande à date de début de traitement " . $commande->date_commande . " site " . $e_order->site->site_startdate, LOG_DEBUG);
        if ($commande->date_commande >= $e_order->site->site_startdate) // TODO test
        {

            if (!empty($conf->global->ECOM_CREATE_FACTURE)) {
                $commande = new Commande($db);
                if ($commande->fetch($e_order->doli_order) < 0) {
                    dol_syslog("ws_import::import_orders erreur lecture commande" . $commande->error, LOG_ERR);
                    return -1;
                }
                $facture_ok = 0;
                //TODO tester si défini
                // on ne créé une facture que pour une commande validée ou clôturée
                if (($commande->statut == -1) || ($commande->statut == 0)) {
                    $facture_ok++;
                    dol_syslog("ws_import::import_orders facturation statut commande " . $commande->statut . " non validable ", LOG_DEBUG);
                }
                // on ne créé une facture que pour payement CB
                if (($commande->mode_reglement_id != $conf->global->ECOM_CB_PAYE)
                    && ($commande->mode_reglement_id != $conf->global->ECOM_PAYPAL)
                    && ($commande->mode_reglement_id != $conf->global->ECOM_PAYBOX)) {
                    $facture_ok++;
                    dol_syslog("ws_import::import_orders facturation règlement " . $commande->mode_reglement_id . " non validable ", LOG_DEBUG);
                }

                if ($facture_ok == 0) {
                    $facid = create_facture($db, $user, $commande, $siteid);

                    if ($facid > 0) {
                        // si CB ou ECOM_PAYPAL on créé le paiement
                        // si ECOM_PAYPAL, ECOM_PAYBOX on créé un enreg pour la commission
                        if ($commande->mode_reglement_id == $conf->global->ECOM_PAYPAL) $payaccount = $conf->global->ECOM_PAYPAL_ACCOUNT;
                        elseif ($commande->mode_reglement_id == $conf->global->ECOM_PAYBOX) $payaccount = $conf->global->ECOM_PAYBOX_ACCOUNT;
                        else  $payaccount = $conf->global->ECOM_CB_ACCOUNT;

                        create_paiement($db, $user, $facid, $commande->mode_reglement_id, $payaccount);
                    }
                }
                else dol_syslog("ws_import::import_orders facturation commande impossible " . $e_order->doli_order . " facture_ok =" . $facture_ok . "rgt " . $commande->mode_reglement_id . " statut " . $commande->statut, LOG_DEBUG);
            }//creation facture
        }
        else {
            // traitement commande archive
            dol_syslog("ws_import::import_orders commande antérieure à date de début de traitement " . $commande->date_commande . " site " . $e_order->site->site_startdate, LOG_DEBUG);

            $e_params = new E_params($db, $siteid, $user);
            $newstatus = $e_params->ecom2dolibarr($obj->site_order_status, 'ordstat');

            switch ($newstatus) {
                case 1:
                    $commande->valid($user);
                    break;
                case 2:
                    $commande->valid($user);// pas de mouvement de stock même si mode gestion validation de commande
                    //TODO statut 2
                    break;
                case 3:
                    $commande->valid($user);
                    $commande->cloture($user);
                    $commande->classer_facturee(); // TODO complètement traitée sur site
                    break;
                case -1 :
                    $commande->cancel($user);
                    break;
            }
            /*	if ( $newstatus > 0)
                {
                    dol_syslog("ws_import::import_orders commande antérieure nouveau statut ".$newstatus, LOG_DEBUG);
                //	$e_order->change_local_status($e_order->ecom_order, $newstatus);
                    $sql = $sql = 'UPDATE '.MAIN_DB_PREFIX.'commande';
                    $sql.= ' SET fk_statut = '.$newstatus.',';
                    $sql.= ' fk_user_cloture = '.$user->id.',';
                    $sql.= ' date_cloture = date_commande ';
                    $sql.= ', date_valid = date_commande ';
                    $sql.= ', fk_user_valid = '.$user->id;
                    $sql.= ' WHERE rowid = '.$e_order->doli_order;

                    $resql=$db->query($sql);
                    if (! $resql)
                    {
                        dol_syslog("maj Commande::update() Echec update - 10 - sql=".$sql, LOG_ERR);
                        return -1;
                        //		dol_print_error($this->db);

                    }
                }*/

        }
    } //else
    unset($e_order);

}
/*
 * Model
 */

llxHeader();

$form = new Form($db);

$text = $langs->trans("SiteArea");

print_fiche_titre($text, '', 'ecommerce@ecommerce');
print '<br>';
$h = 0;
$head = array();

$head[$h][0] = dol_buildpath("/ecommerce/site_index.php?siteid=" . $siteid, 1);
$head[$h][1] = $site_params->site_name;
$head[$h][2] = 'ecommerce';
$h++;

dol_fiche_head($head, 'ecommerce', $langs->trans("ECommerce"));


print '<table class="liste" width="100%">';
print '<tr><td colspan="2">';
print '<table class="notopnoleftnoright" width="100%">';
print '<tr>';
if (!$user->rights->Ecommerce->import) print '<td></td>';
else {
    print '<td width="20%" align="left"><left><form action="' . $_SERVER['PHP_SELF'] . '?siteid=' . $siteid . '" method="POST">';
    print '<input type="hidden" name="siteid" value="' . $siteid . '">';
    print '<input type="hidden" name="action" value="import">';
    print '<input type="submit" class="button" value="' . ($langs->trans("SiteImportOrders")) . '">';
    print '</form></left></td>';
}
print '</tr></table>';
print '</td>';
print '<tr>';
print '<td colspan="11" align="left">';
print '<form action="' . $_SERVER['PHP_SELF'] . '?siteid=' . $siteid . '" method="POST">';
print '<input type="hidden" name="siteid" value="' . $siteid . '">';
print '<input type="hidden" name="action" value="resetlimitoffset">';
print 'Nombre d\'enregistrements : ';
print '<input type="text" id="limit" name="limit" value="'.$limit.'">';
print 'Décalage depuis la fin : ';
print '<input type="text" id="offset" name="offset" value="'.$offset.'">';
print '<input class="button" type="submit" value="' . $langs->trans("Update") . '">';
print '</form>';
print '</td>';
print "</tr>\n";
print '<tr>';
// last orders from site
if (1) {
    print '<th align="left">' . $langs->trans("SiteLastOrders") . '</th><th align="left">' . $langs->trans("SiteCA") . '</th>';
    print '</tr>' . "\n";
    print '<tr>';

    $sql = "SELECT ec.rowid, ec.ecom_order, ec.site_client_name, ec.site_order_date, ec.datem, ec.site_order_total_ht, ep.ecom_lib, ec.site_order_status, ec.doli_order ";
    $sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order AS ec ";
    $sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "ecom_params AS ep ON ep.ecom_id = ec.site_order_status AND ep.partype = 'ordstat' AND ep.siteid = '" . $siteid . "' ";
    $sql .= " WHERE ec.siteid = '" . $siteid . "' ";
    $sql .= " ORDER BY ec.ecom_order DESC ";
    $sql .= " LIMIT $offset,$limit";

    $resql = $db->query($sql);
    $taborders = array();
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {
            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {
                    $taborders[$i]["ecom_order"] = $obj->ecom_order;
                    $taborders[$i]["site_client_name"] = $obj->site_client_name;
                    $taborders[$i]["site_order_date"] = $obj->site_order_date;
                    $taborders[$i]["datem"] = $obj->datem;
                    $taborders[$i]["site_order_total_ht"] = $obj->site_order_total_ht;
                    $taborders[$i]["ecom_lib"] = $obj->ecom_lib;
                    $taborders[$i]["site_order_status"] = $obj->site_order_status;
                    $taborders[$i]["doli_order"] = $obj->doli_order;
                    $taborders[$i]["rowid"] = $obj->rowid;
                }
                $i++;
            }
        }
    }
    print '<td valign="top" align="left">';
    if (count($taborders) > 0) {
        print '<table class="notopnoleftnoright"  width="95%">';
        print '<tr>';
        print '<th align="left">' . $langs->trans("SiteOrderId") . '</th>';
        print '<th align="left">' . $langs->trans("SiteCustName") . '</th>';
        print '<th align="left">' . $langs->trans("SiteOrderDate") . '</th>';
//        print '<th align="left">' . $langs->trans("SiteModifOrderDate") . '</th>';
        print '<th align="left">' . $langs->trans("ImportDate") . '</th>';
        print '<th align="right">' . $langs->trans("SiteOrderTotal") . '</th>';
        print '<th align="left">' . $langs->trans("SiteOrderStatus") . '</th>';
        print '<th align="left">' . $langs->trans("DoliOrder") . '</th>';
        print '<th align="left">' . $langs->trans("Action") . '</th>';
//        print '<th>' . $langs->trans("SiteName") . '</th>';
        print "</tr>\n";
        $var = True;
        $soc=new Societe($db);
        $com=new Commande($db);
        foreach ($taborders as $elt) {
            print '<tr ' . $bc[$var] . ' ><td>';
            print $elt["ecom_order"];
            print '</td><td >';
            $com->fetch($elt["doli_order"]);
            $soc->fetch($com->socid);
            print $soc->getNomUrl(1);
//            print $elt["site_client_name"];
            print '</td><td>';
            print dol_print_date($db->jdate($elt["site_order_date"]), "day");
            print '</td><td>';
            print dol_print_date($db->jdate($elt["datem"]), "dayhour");
            print '</td><td align="right">';
            print price($elt["site_order_total_ht"]);
            print '</td><td >';
            if ($elt["ecom_lib"]) $lib = $elt["ecom_lib"];
            else $lib = $langs->trans("OrderNoStatus") . ' ' . $elt["site_order_status"];
            print $lib;
            print '</td><td nowrap>';
            if ($elt["doli_order"] <= 0) print ' ';
            else {
//                print '<a href="' . DOL_URL_ROOT . '/commande/card.php?id=' . $elt["doli_order"] . '">' . $elt["doli_order"] . '</a>';
                print $com->getNomUrl(1);

            }
//            print '</td><td><a href="' . dol_buildpath('/ecommerce/site_orders.php', 1) . '?siteid=' . $siteid . '">' . $siteid . '</a></td>';'
            print '</td><td>';
            print '<form action="' . $_SERVER['PHP_SELF'] . '?siteid=' . $siteid . '" method="POST">';
            print '<input type="hidden" name="siteid" value="' . $siteid . '">';
            print '<input type="hidden" name="limit" value="' . $limit . '">';
            print '<input type="hidden" name="offset" value="' . $offset . '">';
            print '<input type="hidden" name="action" value="importOrder">';
            print '<input type="hidden" name="ecom_order" value="'.$elt["ecom_order"].'">';
            print '<input type="hidden" name="rowid" value="'.$elt["rowid"].'">';
            print '<input class="button" type="submit" value="' . (($elt["doli_order"]>0)?$langs->trans("ImportWeb") :$langs->trans("Import") ). '">';
            print '</form></td>';
            print '</tr>';

            $var = !$var;
        }
        print '</table>';
    }
    print '</td>';
}

// CA from site
if(2) {
    $sql = "SELECT sum(eo.site_order_total_HT) AS CA, MONTH(eo.site_order_date) AS mois , YEAR(eo.site_order_date) AS an, count(*) AS nb_com ";
    $sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order AS eo";
    $sql .= " JOIN " . MAIN_DB_PREFIX . "commande AS c ON eo.doli_order = c.rowid ";
    $sql .= " WHERE c.fk_statut > 0 "; // on ne compte que les commandes validées pour le CA
    $sql .= " AND siteid = '" . $siteid . "' ";
    $sql .= " GROUP BY an, mois ";
    $sql .= " ORDER BY an desc, mois desc ";
    $sql .= " limit 12";

    dol_syslog("site_index CA sql=" . $sql, LOG_DEBUG);
    $tabCA = array();
    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {
            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {
                    $tabCA[$i]["an"] = $obj->an;
                    $tabCA[$i]["mois"] = $obj->mois;
                    $tabCA[$i]["CA"] = $obj->CA;
                }
                $i++;
            }
        }
    }


    print '<td valign="top" align="left">';
    if (count($tabCA) > 0) {
        print '<table class="notopnoleftnoright" width="95%">';
        print '<tr>';
        print '<th align="left" >' . $langs->trans("e-year") . '</th>';
        print '<th align="left">' . $langs->trans("e-month") . '</th>';
        print '<th align="right" >' . $langs->trans("e-CA") . '</th>';
        print '</tr>';
        $var = True;
        foreach ($tabCA as $elt) {
            print '<tr ' . $bc[$var] . '><td>';
            print $elt["an"] . '</td>';
            print '<td >' . $elt["mois"] . '</td>';
            print '<td align="right">' . price($elt["CA"]) . '</td>';
            print'</td></tr>';
            $var = !$var;
        }
        print '</table>';
    }
    print '</td>';
}
print '</tr><tr><td colspan="2">&nbsp;</td></tr>';


// Client Prospects import
/*
$sql = "SELECT ec.doli_soc, p.label ";
$sql .= ", s.nom, s.town as ville ";
$sql .= " FROM " . MAIN_DB_PREFIX . "societe AS s ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_customer AS ec ON ec.doli_soc = s.rowid ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "c_country AS p ON p.rowid = s.fk_pays ";
$sql .= " WHERE ec.siteid = '" . $siteid . "'";
$sql .= " ORDER BY ec.rowid DESC LIMIT 5 ";

dol_syslog("site_index clients sql=" . $sql, LOG_DEBUG);

$tabcustomer = array();
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;
	$var = True;
	if ($num) {
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				$tabcustomer[$i]["nom"] = $obj->nom;
				$tabcustomer[$i]["ville"] = $obj->ville;
				$tabcustomer[$i]["libelle"] = $obj->libelle;
				$tabcustomer[$i]["doli_soc"] = $obj->doli_soc;
			}
			$i++;
			$var = !$var;
		}
	}
}*/
/*
 * View
 */
/*
//stadistics
include_once DOL_DOCUMENT_ROOT . '/core/class/dolgraph.class.php';
include_once './class/ecom_stadistics.class.php';

$WIDTH = DolGraph::getDefaultGraphSizeForStats('width');//ancho de la grafica
$HEIGHT = DolGraph::getDefaultGraphSizeForStats('height');//alto de la grafica

$endyear = strftime("%Y", dol_now());//años en los que se aplicara la grafica
$startyear = $endyear - 1;

//carpeta temporal
$dir = getcwd() . '/temp';
dol_mkdir($dir);
$filenamenb = $dir . '/ordersnbinyear-' . $year . '.png';

$stats = new ecom_stadistics($db);

print '<tr >';
print '<td align="left">' . $langs->trans("NumberOfOrdersByMonth") . '</td>' . "\n";//grafica 1
print '<td align="left">' . $langs->trans("AmountOfOrdersByMonthHT") . '</td>' . "\n";//grafica 2
print '</tr>';

//grafica 1
$data = $stats->getNbByMonthWithPrevYear($endyear, $startyear, 0, $siteid);

$px1 = new DolGraph();
$mesg = $px1->isGraphKo();

if (!$mesg) {
	$px1->SetData($data);
	$px1->SetPrecisionY(0);
	$i = $startyear;
	$legend = array();
	while ($i <= $endyear) {
		$legend[] = $i;
		$i++;
	}
	$px1->SetLegend($legend);
	$px1->SetMaxValue($px1->GetCeilMaxValue());
	$px1->SetMinValue(min(0, $px1->GetFloorMinValue()));
	$px1->SetWidth($WIDTH);
	$px1->SetHeight($HEIGHT);
	$px1->SetYLabel($langs->trans("NbOfOrder"));
	$px1->SetShading(3);
	$px1->SetHorizTickIncrement(1);
	$px1->SetPrecisionY(0);
	$px1->mode = 'depth';
	//$px1->SetTitle($langs->trans("NumberOfOrdersByMonth"));

	$px1->draw($filenamenb, '');
}

//grafica 2
// Build graphic number of object
$data = $stats->getAmountByMonthWithPrevYear($endyear, $startyear, 0, $siteid);

$filenameamount = $dir . '/ordersamountinyear-' . $year . '.png';

$px2 = new DolGraph();
$mesg2 = $px2->isGraphKo();

if (!$mesg2) {
	$px2->SetData($data);
	$px2->SetPrecisionY(0);
	$i = $startyear;
	$legend = array();
	while ($i <= $endyear) {
		$legend[] = $i;
		$i++;
	}
	$px2->SetLegend($legend);
	$px2->SetMaxValue($px2->GetCeilMaxValue());
	$px2->SetMinValue(min(0, $px2->GetFloorMinValue()));
	$px2->SetWidth($WIDTH);
	$px2->SetHeight($HEIGHT);
	$px2->SetYLabel($langs->trans("AmountOfOrders"));
	$px2->SetShading(3);
	$px2->SetHorizTickIncrement(1);
	$px2->SetPrecisionY(0);
	$px2->mode = 'depth';
	//$px2->SetTitle($langs->trans("AmountOfOrdersByMonthHT"));

	$px2->draw($filenameamount, '');
}

//show graph
print '<tr valign="top"><td align="left">';

if ($mesg) {
	print $mesg;
}
else {
	print $px1->show();
}
print '</td><td align="left">';

if ($mesg2) {
	print $mesg2;
}
else {
	print $px2->show();
}
print '</tr>';
*/
// customer and log
if(0) {
    print '<tr >';
    print '<td align="left"><h4>' . $langs->trans("SiteClients") . '</td><td align="left"><h4>' . $langs->trans("SiteImportLog") . '</td>';
    print '</tr>';
    print '<tr><td valign="top" align="left">';
    if (count($tabcustomer) > 0) {
        print '<table class="notopnoleftnoright" width="95%">';
        print '<tr >';
        print '<th  align="left"><h4>' . $langs->trans("SiteCustName") . '</th>';
        print '<th  align="left"><h4>' . $langs->trans("SiteCustTown") . '</th>';
        print '<th  align="left"><h4>' . $langs->trans("SiteCustCountry") . '</th>';
        print '<th  align="left"><h4>' . $langs->trans("DoliOrder") . '</th></tr>';
        $var = True;
        foreach ($tabcustomer as $elt) {
            print '<tr ' . $bc[$var] . '>';
            print '<td>' . $elt["nom"] . '</td>';
            print '<td>' . $elt["ville"] . '</td>';
            print '<td>' . $elt["libelle"] . '</td>';
            print '<td ><a href="' . dol_buildpath('/societe/soc.php', 1) . '?socid=' . $elt["doli_soc"] . '">' . $elt["doli_soc"] . '</a></td>';
            print '</tr>';
            $var = !$var;
        }
        print '<tr><td>&nbsp;</td></tr>';
//	print '<tr><td>'.$langs->trans("OtherFunctionsImport").'</td></tr>';
        print '</table>';
    }

// log for site

    $sql = "SELECT l.log_date, l.site_id, l.log_message ";
    $sql .= " FROM " . MAIN_DB_PREFIX . "ecom_log AS l ";
    $sql .= " WHERE l.site_id = '" . $siteid . "' AND l.log_type = 'EXP'";
    $sql .= " ORDER BY l.log_date DESC ";
    $sql .= " LIMIT 10";

    dol_syslog("site_index log sql=" . $sql, LOG_DEBUG);
    $tablog = array();
    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {
            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {
                    $tablog[$i]["log_date"] = $obj->log_date;
                    $tablog[$i]["site_id"] = $obj->site_id;
                    $tablog[$i]["log_message"] = $obj->log_message;
                }
                $i++;
            }
        }
    }
    print '</td>';
    print '<td valign="top" align="left">';
    if (count($tablog) > 0) {
        print '<table class="notopnoleftnoright" width="95%">';
        print '<tr >';
        print '<th align="left">' . $langs->trans("LogDate") . '</th>';
        print '<th align="left">' . $langs->trans("LogSite") . '</th>';
        print '<th align="left">' . $langs->trans("LogMessage") . '</th>';
        print '</tr>';
        $var = True;
        foreach ($tablog as $elt) {
            print '<tr ' . $bc[$var] . ' ><td>';
            print $elt["log_date"];
            print '</td><td >';
            print $elt["site_id"];
            print '</td><td >';
            print $elt["log_message"];
            print '</td></tr>';
            $var = !$var;
        }
        print '</table>';
    }
    print '</td></tr>';
    print '</table>';
    print '<tr><td colspan="2">&nbsp;</td></tr>';
}
// End of page
if ($mesg) dol_htmloutput_mesg($mesg);

llxFooter();

$db->close();
