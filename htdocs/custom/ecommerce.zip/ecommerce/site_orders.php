<?php
/* Copyright (C) 2007 		Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2008-2013	Jean Heimburger	   	<jean@tiaris.fr> http://www.tiaris.fr
 * Copyright (C) 2011-2013 	Philippe Grand      <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013 	Juanjo Menent		<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       ecommerce/site_orders.php
 *        \ingroup    ecommerce
 *        \brief      Order management from e-commerce site
 *        \author        Jean Heimburger
 */

require("./pre.inc.php");

dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/E_order.class.php");
dol_include_once("/ecommerce/class/ecom_log.class.php");

require_once(DOL_DOCUMENT_ROOT . "/compta/facture/class/facture.class.php");
require_once(DOL_DOCUMENT_ROOT . "/commande/class/commande.class.php");

// Load traductions files required by by page
$langs->load("ecommerce@ecommerce");
$langs->load("companies");
$langs->load("other");

//constantes a mettre ailleurs
define('ECOM_VALID', 1); // commande en attente
define('ECOM_ANNUL', -1); // commande annulee
define('ECOM_CLOTURE', 3);// commande cloturee
define('ECOM_TRAITE', 2); // commande en traitement
// fin def constantes


// Protection if external user
$socid = GETPOST('socid', 'int');
if ($user->societe_id) $socid = $user->societe_id;
$result = restrictedArea($user, 'societe', $socid);

// Get parameters
$siteid = GETPOST('siteid');
$typeliste = GETPOST('state', 'alpha');
if (empty($typeliste)) $typeliste = 'Waiting';

if ($siteid) {
// get site_parameters
	$site_params = new Ecom_site($db);
	if ($site_params->fetch($siteid, $user) < 0) {
		setEventMessage($langs->trans("ReadSiteError"), 'errors');
	}
	else {
	}
}
// Pagination
$action = GETPOST("action", 'alpha');
$sortfield = GETPOST("sortfield", 'alpha');
$sortorder = GETPOST("sortorder", 'alpha');
if (!$sortfield) $sortfield = "ec.ecom_order";
if (!$sortorder) $sortorder = "DESC";

$page = GETPOST("page", 'int');
$limit = GETPOST("limit", 'int') ? GETPOST("limit", 'int') : $conf->liste_limit;
$offset = GETPOST("offset", 'int') ? GETPOST("offset", 'int') : 0;

// recherche
$secomid = GETPOST("secomid", 'int');
$sdoliid = GETPOST("sdoliid", 'int');
$sclient = GETPOST("sclient", 'alpha');
$sdatec = GETPOST("sdatec");
$sdateimp = GETPOST("sdateimp");

$secomid = trim($secomid);
$sdoliid = trim($sdoliid);
$sclient = trim($sclient);
$sdatec = trim($sdatec);
$sdateimp = trim($sdateimp);

/*
* ACTIONS
*
*/

if (isset($_POST["button_removefilter_x"])) {
	$secomid = "";
	$sdoliid = "";
	$sclient = "";
	$sdatec = "";
	$sdateimp = "";
}

if (isset($action) && $action == 'import') {
// import order
	$e_order = new E_order($db, $siteid, $user);
    $result=$e_order->import_order($_POST['ecomid']);
	if ( $result< 0) setEventMessage($langs->trans("ErrImport", $_POST['ecomid']), 'errors');
}

if (isset($action) && $action == 'modif') {
// Modify order
	setEventMessage($langs->trans("NoDispo", $_POST['ecomid']), 'warnings');
}

if (isset($action) && $action == 'valider') {
// Modify order
	$e_com = new E_order($db, $siteid, $user);
	if ($e_com->change_local_status($_GET['ecomid'], ECOM_VALID) > 0) $mesg = '';
	else {
		$mesg = $langs->trans("Weborder") . $_GET['ecomid'] . '  ' . $_GET['ordid'] . $langs->trans("ErrOrderNonMaj") . $e_prod->error;
		setEventMessage($mesg, 'errors');
	}
}

if (isset($action) && $action == 'annuler') {
// Modify order
	$e_com = new E_order($db, $siteid, $user);
	if ($e_com->change_local_status($_GET['ecomid'], ECOM_ANNUL) > 0) $mesg = '';
	else {
		$mesg = $langs->trans("Weborder") . $_GET['ecomid'] . '  ' . $_GET['ordid'] . $langs->trans("ErrOrderNonMaj") . $e_prod->error;
		setEventMessage($mesg, 'errors');
	}
}
if (isset($action) && $action == 'cloturer') {
// Modify order
	$e_com = new E_order($db, $siteid, $user);
	if ($e_com->change_local_status($_GET['ecomid'], ECOM_CLOTURE) > 0) $mesg = '';
	else {
		$mesg = $langs->trans("Weborder") . $_GET['ecomid'] . '  ' . $_GET['ordid'] . $langs->trans("ErrOrderNonMaj") . $e_prod->error;
		setEventMessage($mesg, 'errors');
	}
}
// delete a log item
if (isset($action) && $action == 'logdelete') {
	if (isset($_POST["logrowid"])) {
		$elog = new Ecom_log($db);
		$elog->id = $_POST["logrowid"];
		$elog->delete($_POST["logrowid"], 1);
	}
}

/*
 * View
 */

llxHeader();

$form = new Form($db);

$text = $langs->trans("SiteArea");

print_fiche_titre($text, '', 'ecommerce@ecommerce');

print '<form action="' . $_SERVER['PHP_SELF'] . '?siteid=' . $siteid . '" method="POST">';
print '<input type="hidden" name="siteid" value="' . $siteid . '">';
print '<input type="hidden" name="action" value="resetlimitoffset">';
print 'Nombre d\'enregistrements : ';
print '<input type="text" id="limit" name="limit" value="'.$limit.'">';
print 'Décalage depuis la fin : ';
print '<input type="text" id="offset" name="offset" value="'.$offset.'">';
print '<input type="hidden" id="offset" name="state" value="'.$typeliste.'">';
print '<input class="button" type="submit" value="' . $langs->trans("Update") . '">';
print '</form>';
print '<br/>';


$h = 0;
$head = array();

$head[$h][0] = dol_buildpath("/ecommerce/site_index.php?siteid=$siteid&limit=$limit&offset=$offset", 1);
$head[$h][1] = $site_params->site_name;
$head[$h][2] = 'ecommerce';
$h++;

// Onglets
$head = ecom_prepare_head_order($siteid,$limit,$offset);
$ongletdefault = (empty($typeliste) ? 'Waiting' : $typeliste);
dol_fiche_head($head, $ongletdefault, $langs->trans("OrderManagement"), 0, 'order');

$sql = "SELECT ec.ecom_order, ec.doli_order, ec.site_client_name, ec.site_order_total_ht, ec.site_order_date, ";
$sql .= " ec.site_order_status, ec.site_total_vat, ec.site_total_port, ec.datem ";
$sql .= ", c.fk_soc, c.fk_statut, c.ref as refcom, ep.ecom_lib, lcp.libelle methpay, ec.exp_meth ";
$sql .= " , el.fk_target, f.ref ";
// TODO traiter le cas des factures d'expéditions
$sql .= "FROM " . MAIN_DB_PREFIX . "ecom_order ec ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "ecom_params ep ON ec.site_order_status = ep.ecom_id AND ec.siteid = ep.siteid AND ep.partype='ordstat' ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "commande c ON c.rowid = ec.doli_order ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "c_paiement lcp ON lcp.id = c.fk_mode_reglement ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "element_element el ON ec.doli_order = el.fk_source AND el.sourcetype = 'commande' and el.targettype = 'facture' ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "facture f ON el.fk_target = f.rowid ";
$sql .= " WHERE ec.siteid = '" . $siteid . "'";

// liste
switch ($typeliste) {
	case 'Waiting' :
		$sql .= ' AND c.fk_statut =1 ';
		break;
	case 'Process' :
		$sql .= ' AND c.fk_statut = 2 ';
		break;
	case 'ToBill' :
		$sql .= ' AND c.fk_statut =3 AND c.facture = 0 ';
		break;
	case 'All' :
		break;
	default :
		break;
}
//fonction de recherche
if ($sclient) $sql .= " AND ec.site_client_name LIKE '%" . $sclient . "%'";
if ($secomid) $sql .= " AND ec.ecom_order = '" . $secomid . "'";
if ($sdoliid) $sql .= " AND ec.doli_order = '" . $sdoliid . "'";
if ($sdatec) $sql .= " AND ec.site_order_date = '" . $sdatec . "'";
if ($sdateimp) $sql .= " AND ec.datem = '" . $sdateimp . "'";

$sql .= " ORDER BY $sortfield $sortorder ";

$nbtotalofrecords = 0;
if (empty($conf->global->MAIN_DISABLE_FULL_SCANLIST)) {
	$result = $db->query($sql);
	$nbtotalofrecords = $db->num_rows($result);
}

$sql .= $db->plimit($limit + 1, $offset);

dol_syslog("site_orders sql=" . $sql, LOG_DEBUG);
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	// entete
	$param = '&siteid=' . $siteid;
	$param .= '&state=' . $typeliste;
	$texte = '';
	print_barre_liste($texte, $page, "site_orders.php", $param, $sortfield, $sortorder, '', $num, $nbtotalofrecords);
	print '<table class="liste" width="100%">';

	//print '<tr><td>&nbsp;</td></tr>';
	/*		print '<tr class="liste_titre">';
			print '<td colspan="2" align="left"><strong>'.$langs->trans("SiteOrderAdmin").'</strong></td>';
			print '<td colspan="4" align="center"><a href="site_index.php?siteid='.$siteid.'">'.$site_params->site_name.'</a></td>';
			print '<td colspan="6" align="center"><a href="'.$site_params->site_url.'">'.$site_params->site_url.'</a></td>';
			print '<td colspan="2">&nbsp;</td>';
			print "</tr>\n";
	*/
	print '<tr class="liste_titre">';
	print '<td colspan="14" align="center">' . $langs->trans("SiteOrderAdmin") . '</td>';
	print '</tr>';
	print '<tr><td>&nbsp;</td></tr>';

	print '<tr class="liste_titre">';
	print_liste_field_titre($langs->trans("SiteOrderId"), "site_orders.php", "ec.ecom_order", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("SiteClientName"), "site_orders.php", "ec.site_client_name", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("SiteOrderStatus"), "site_orders.php", "ec.site_order_status", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("SiteOrderDate"), "site_orders.php", "ec.site_order_date", $param, "", "", $sortfield, $sortorder);
	print '<td align="right" class="liste_titre">' . $langs->trans("SiteOrderTotal_TTC") . '</td><td align="right" class="liste_titre">' . $langs->trans("SiteOrderVat") . '</td><td align="right" class="liste_titre">' . $langs->trans("SiteOrderPort") . '</td>';
	print_liste_field_titre($langs->trans("MethPaye"), "site_orders.php", "methpay", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("MethShip"), "site_orders.php", "methship", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("SiteOrder"), "site_orders.php", "ec.doli_order", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("DoliStatus"), "site_orders.php", "c.fk_statut", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("Invoice"), "", "", $param, "", "", $sortfield, $sortorder);
	print '<td class="liste_titre">' . $langs->trans("ImportModify") . '</td><td class="liste_titre">' . $langs->trans("ImportDate") . '</td>';
	print "</tr>\n";

	//recherche
	print '<form action="site_orders.php" method="post" name="formulaire">';
	print '<input type="hidden" name="siteid" value=' . $siteid . ' >';
	print '<tr class="liste_titre">';
	print '<td class="liste_titre" align="left">';
	print '<input class="flat" type="text" name="secomid" size="8" value="' . $secomid . '">';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '<input class="flat" type="text" name="sclient" size="20" value="' . $sclient . '">';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" colspan="2" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '<input class="flat" type="text" name="sdoliid" size="8" value="' . $sdoliid . '">';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="right">';

	print '<input type="image" class="liste_titre" name="button_search" src="' . DOL_URL_ROOT . '/theme/' . $conf->theme . '/img/search.png" alt="' . $langs->trans("Search") . '">';
	print '<input type="image" class="liste_titre" name="button_removefilter" src="' . DOL_URL_ROOT . '/theme/' . $conf->theme . '/img/searchclear.png" alt="' . $langs->trans("RemoveFilter") . '">';
	print '</td>';

	print '</tr>';
	print '</form>';
	print "\n";

	$facture_static = new Facture($db);
	$commande_static = new Commande($db);

	$i = 0;
	if ($num) {
		$var = True;
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				print '<tr ' . $bc[$var] . '>';
				print '<td>' . $obj->ecom_order . '</td>';
				if ($obj->fk_soc > 0) {
					print '<td><a href="' . DOL_URL_ROOT . '/societe/soc.php?socid=' . $obj->fk_soc . '">' . $obj->site_client_name . '</a></td>'; //client
				}
				else print '<td>' . $obj->site_client_name . '</td>';
				print '<td>';
				print $obj->ecom_lib;
				print '</td>';
				//print '<td>'.$obj->doli_order.'</td>';
				//print '<td>'.dol_print_date($obj->site_order_date, "%d %b %Y").'</td>';
				print '<td>' . dol_print_date($db->jdate($obj->site_order_date), "day") . '</td>';
				//$x = mktime();
				//print '<td>'.dol_print_date($x ).'</td>';
				print '<td align="right">' . price($obj->site_order_total_ht) . '</td>'; // total HT
				print '<td align="right">' . price($obj->site_total_vat) . '</td>'; //total TVA
				print '<td align="right">' . price($obj->site_total_port) . '</td>'; //total port
				print '<td align="center">' . $obj->methpay . '</td>';
				print '<td>' . $obj->exp_meth . '</td>';
				if ($obj->doli_order > 0) {
					//print '<td><a href="'.DOL_URL_ROOT.'/commande/fiche.php?id='.$obj->doli_order.'">'.$obj->doli_order.'</a></td>';
					$commande_static->id = $obj->doli_order;
					$commande_static->ref = $obj->refcom;
					$commande_static->type = 1;
					print '<td>' . $commande_static->getNomUrl(1) . '</td>';

					switch ($obj->fk_statut) {
						case 0:
							$lib = $langs->trans("OrderStatusDraft");
							break;
						case 1:
							$lib = $langs->trans("OrderStatusValid");
							break;
						case 2:
							$lib = $langs->trans("OrderStatusTrait");
							break;
						case 3:
							$lib = $langs->trans("OrderStatusCloture");
							break;
						case -1:
							$lib = $langs->trans("OrderStatusNull");
							break;
						default:
							$lib = $obj->fk_statut;
					}
					print '<td>' . $lib . '</td>';

					$facture_static->id = $obj->fk_target;
					$facture_static->ref = $obj->facnumber;
					$facture_static->type = 1;
					$flib = isset($obj->facnumber) ? $facture_static->getNomUrl(1) : '';
					print '<td>' . $flib . '</td>';
				}
				else print '<td>' . ' ' . '</td>' . '<td>' . ' ' . '</td>' . '<td>' . ' ' . '</td>';

				//les actions
				print '<td align="center"><form action="site_orders.php?siteid=' . $siteid;
				if (isset($_GET["state"])) {
					print '&state=' . $_GET["state"];
				}
				print '"method="POST">';
				if ($obj->doli_order > 0) {

					switch ($obj->fk_statut) {
						case 0:
							$lib = ' <a href="site_orders.php?siteid=' . $siteid . '&action=valider&ordid=' . $obj->doli_order . '&ecomid=' . $obj->ecom_order . '">' . $langs->trans("OrderValid") . '</a>&nbsp;&nbsp;';
							$lib .= '<a href="site_orders.php?siteid=' . $siteid . '&action=annuler&ordid=' . $obj->doli_order . '&ecomid=' . $obj->ecom_order . '">' . $langs->trans("OrderAnnul") . '</a>';
							print $lib;
							break;
						case 1:
							$lib = '<a href="' . DOL_URL_ROOT . '/commande/card.php?id=' . $obj->doli_order . '">' . $langs->trans("OrderTrait") . '</a>';
							$lib .= ' / <a href="site_orders.php?siteid=' . $siteid . '&action=annuler&ordid=' . $obj->doli_order . '&ecomid=' . $obj->ecom_order . '">' . $langs->trans("OrderAnnul") . '</a>';
							print $lib;
							break;
						case 2:
							$lib = '<a href="site_orders.php?siteid=' . $siteid . '&action=cloturer&ordid=' . $obj->doli_order . '&ecomid=' . $obj->ecom_order . '">' . $langs->trans("OrderCloture") . '</a>';
							print $lib;
							break;
						case 3:
							break;

						default:
							/*	$lib=	$langs->trans("Modify")	;
								print '<input type="hidden" name="action" value="modif">';
								print '<input type="hidden" name="ecomid" value="'.$obj->ecom_order.'">'	;
								print '<input class="button" type="submit" value="'.$lib.'">';
							*/
							break;
					}
				}
				else {
					$lib = $langs->trans("Import");
					print '<input type="hidden" name="action" value="import">';
					print '<input type="hidden" name="ecomid" value="' . $obj->ecom_order . '">';
					print '<input class="button" type="submit" value="' . $lib . '">';
				}

				print '</form></td>'; //bouton import

				print '<td>' . dol_print_date($db->jdate($obj->datem), "day") . '</td>';
				print '</tr>' . "\n";
			}
			$i++;
			$var = !$var;
		}
		print "</table>" . "\n";

		print '<input type="hidden" name="siteid" value="' . $siteid . '" />';
		print_barre_liste($texte, $page, "site_orders.php", $param, $sortfield, $sortorder, '', $num, $nbtotalofrecords);

	}

}

/*// affichage des logs
print '<br/>';

$sql = "SELECT rowid, log_date, log_fonction, log_message ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_log l";
$sql .= " WHERE site_id = '" . $siteid . "' AND log_fct = 'COM' AND log_type = 'ERR' ";
$sql .= " ORDER BY l.log_date DESC ";
$sql .= " LIMIT 10";

$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;
	if ($num) {
		print '<table class="liste" width="100%"><tr class="liste_titre"><td colspan="13" align="center">' . $langs->trans("LogAdmin") . '</td></tr>';
		print '<tr class="liste_titre">';
		print '<td colspan="2">' . $langs->trans("LogDate") . '</td>';
		print '<td colspan="2">' . $langs->trans("LogFonc") . '</td>';
		print '<td colspan="8">' . $langs->trans("LogMessage") . '</td>';
		print '<td colspan="1">' . $langs->trans("LogAction") . '</td>';
		print '</tr>';
		$var = True;

		print '<form action="' . $url . '" name="deletelog" method="POST">';
		print '<input type="hidden" name="action" value="logdelete"/>';

		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				print '<tr ' . $bc[$var] . '><td colspan="2">' . $obj->log_date . '</td>';
				print '<td colspan="2">' . $obj->log_fonction . '</td>';
				print '<td colspan="8" align="justify">' . $obj->log_message . '</td>';
				print '<form action="' . $url . '" name="deletelog" method="POST">';
				print '<input type="hidden" name="action" value="logdelete"/>';
				print '<input type="hidden" name="logrowid" value="' . $obj->rowid . '"/>';
				print '<td colspan="1"><input type="submit" class="button" value="' . $langs->trans("Delete") . '" /></td></form></tr>';

			}
			$i++;
			$var = !$var;
		}
		print '</table>';
	}
}
print '</table>';
print '<tr><td>&nbsp;</td></tr>';
*/
// End of page

llxFooter();

$db->close();

