<?php
/* Copyright (C) 2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010 Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013 Philippe Grand  <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2014 	Juanjo Menent  <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *  \file       htdocs/ecommerce/pre.inc.php
 *  \brief      File to manage left menu by default
 *  \version    $Id: pre.inc.php,v 1.2.4.5 2012-02-08 17:54:26 tiaris Exp $
 */

$res = @include("../main.inc.php");                        // For root directory
if (!$res) $res = @include("../../main.inc.php");
if (!$res) $res = @include("../../../main.inc.php");        // For "custom" directory
if (!$res) die;

include_once DOL_DOCUMENT_ROOT.'/core/class/menu.class.php';
dol_include_once("/ecommerce/core/lib/ecommerce.lib.php");

/**
 *    \brief        Function called by page to show menus (top and left)
 */
function llxHeader($head = '', $title = '', $help_url = '', $target = '', $disablejs = 0, $disablehead = 0, $arrayofjs = '', $arrayofcss = '', $morequerystring = '', $morecssonbody = '', $replacemainareaby = '', $disablenofollow = 0, $disablenoindex = 0)
{
	global $db, $user, $conf, $langs, $menumanager,$hookmanager;
	$menu = new Menu();

	$parameters = array(
		'head' => & $head,
		'title' => & $title,
		'help_url' => & $help_url,
		'target' => & $target,
		'disablejs' => & $disablejs,
		'disablehead' => & $disablehead,
		'arrayofjs' => & $arrayofjs,
		'arrayofcss' => & $arrayofcss,
		'morequerystring' => & $morequerystring,
		'morecssonbody' => & $morecssonbody,
		'replacemainareaby' => & $replacemainareaby,
		'disablenofollow' => & $disablenofollow,
		'disablenoindex' => & $disablenoindex

	);
	$reshook = $hookmanager->executeHooks('llxHeader', $parameters);
	if ($reshook > 0) {
		print $hookmanager->resPrint;
		return;
	}

	// html header
	top_htmlhead($head, $title, $disablejs, $disablehead, $arrayofjs, $arrayofcss, 0, $disablenofollow, $disablenoindex);

	$tmpcsstouse = 'sidebar-collapse' . ($morecssonbody ? ' ' . $morecssonbody : '');
	// If theme MD and classic layer, we open the menulayer by default.
	if ($conf->theme == 'md' && !in_array($conf->browser->layout, array('phone', 'tablet')) && !getDolGlobalString('MAIN_OPTIMIZEFORTEXTBROWSER')) {
		global $mainmenu;
		if ($mainmenu != 'website') {
			$tmpcsstouse = $morecssonbody; // We do not use sidebar-collpase by default to have menuhider open by default.
		}
	}

	if (getDolGlobalString('MAIN_OPTIMIZEFORCOLORBLIND')) {
		$tmpcsstouse .= ' colorblind-' . strip_tags(getDolGlobalString('MAIN_OPTIMIZEFORCOLORBLIND'));
	}

	print '<body id="mainbody" class="' . $tmpcsstouse . '">' . "\n";
////////////////
	if ($menumanager->name == 'abbes') {
		if ((empty($conf->dol_hide_topmenu) || GETPOSTINT('dol_invisible_topmenu')) && !GETPOSTINT('dol_openinpopup')) {
			top_menu($head, $title, $target, $disablejs, $disablehead, $arrayofjs, $arrayofcss, $morequerystring, $help_url);
		}
		if (empty($conf->dol_hide_leftmenu) && !GETPOST('dol_openinpopup', 'aZ09')) {
			left_menu(array(), $help_url, '', '', 1, $title, 1); // $menumanager is retrieved with a global $menumanager inside this function
		}
	} elseif ($menumanager->name == 'oblyon') {
		require_once(DOL_DOCUMENT_ROOT . "/core/class/menu.class.php");

		$sql = "SELECT m.rowid";
		$sql .= " FROM " . MAIN_DB_PREFIX . "menu as m WHERE module = 'ecommerce'";
		$sql .= " ORDER BY rowid DESC LIMIT 1";
		$resql = $db->query($sql);
		$objr = $db->fetch_object($resql);
		$menu_ecommerce_id = $objr->rowid;

		$sql = "SELECT m.rowid";
		$sql .= " FROM " . MAIN_DB_PREFIX . "menu as m";
		$sql .= " ORDER BY rowid DESC LIMIT 1";
		$resql = $db->query($sql);
		$obji = $db->fetch_object($resql);
		$start_id = $obji->rowid;
		$start_id++;

		$cont = count($menumanager->tabMenu);

		// afficher tous les sites
		$sql = "SELECT rowid, site_name FROM " . MAIN_DB_PREFIX . "ecom_site";
		$sql .= " WHERE entity = " . $conf->entity;
		$resql = $db->query($sql);
		if ($resql) {
			$numr = $db->num_rows($resql);
			$i = 0;
			while ($i < $numr) {
				$objp = $db->fetch_object($resql);
				//$menu->add($rootmenu."/ecommerce/site_index.php?siteid=".$objp->rowid, $objp->site_name);
				// We complete tabMenu
				$menumanager->tabMenu[$cont]['rowid'] = $start_id;
				$menumanager->tabMenu[$cont]['module'] = 'ecommerce';
				$menumanager->tabMenu[$cont]['fk_menu'] = $menu_ecommerce_id;
				$menumanager->tabMenu[$cont]['url'] = '/ecommerce/site_index.php?siteid=' . $objp->rowid;
				$menumanager->tabMenu[$cont]['titre'] = $objp->site_name;
				$menumanager->tabMenu[$cont]['target'] = '';
				$menumanager->tabMenu[$cont]['mainmenu'] = 'ecommerce';
				$menumanager->tabMenu[$cont]['leftmenu'] = '';
				$menumanager->tabMenu[$cont]['perms'] = $user->rights->Ecommerce->user;
				$menumanager->tabMenu[$cont]['enabled'] = $conf->ecommerce->enabled;
				$menumanager->tabMenu[$cont]['type'] = 'left';
				$menumanager->tabMenu[$cont]['fk_mainmenu'] = '';
				$menumanager->tabMenu[$cont]['fk_leftmenu'] = '';
				$menumanager->tabMenu[$cont]['position'] = 100;
				$rowid_group = $start_id;
				$cont++;
				$start_id++;
				{
					//menu pour un site
					//$menu->add($rootmenu."/ecommerce/site_index.php?siteid=".$_GET["siteid"], $langs->trans("EcomBoutique"));
					// We complete tabMenu
					$menumanager->tabMenu[$cont]['rowid'] = $start_id;
					$menumanager->tabMenu[$cont]['module'] = 'ecommerce';
					$menumanager->tabMenu[$cont]['fk_menu'] = $rowid_group;
					$menumanager->tabMenu[$cont]['url'] = '/ecommerce/site_orders.php?siteid=' . $_GET["siteid"];
					$menumanager->tabMenu[$cont]['titre'] = $langs->trans("Orders");
					$menumanager->tabMenu[$cont]['target'] = '';
					$menumanager->tabMenu[$cont]['mainmenu'] = 'ecommerce';
					$menumanager->tabMenu[$cont]['leftmenu'] = '';
					$menumanager->tabMenu[$cont]['perms'] = $user->rights->Ecommerce->user;
					$menumanager->tabMenu[$cont]['enabled'] = $conf->ecommerce->enabled;
					$menumanager->tabMenu[$cont]['type'] = 'left';
					$menumanager->tabMenu[$cont]['fk_mainmenu'] = '';
					$menumanager->tabMenu[$cont]['fk_leftmenu'] = '';
					$menumanager->tabMenu[$cont]['position'] = 100;
					$cont++;
					$start_id++;
					// We complete tabMenu
					$menumanager->tabMenu[$cont]['rowid'] = $start_id;
					$menumanager->tabMenu[$cont]['module'] = 'ecommerce';
					$menumanager->tabMenu[$cont]['fk_menu'] = $rowid_group;
					$menumanager->tabMenu[$cont]['url'] = '/ecommerce/site_products.php?siteid=' . $_GET["siteid"];
					$menumanager->tabMenu[$cont]['titre'] = $langs->trans("Products");
					$menumanager->tabMenu[$cont]['target'] = '';
					$menumanager->tabMenu[$cont]['mainmenu'] = 'ecommerce';
					$menumanager->tabMenu[$cont]['leftmenu'] = '';
					$menumanager->tabMenu[$cont]['perms'] = $user->rights->Ecommerce->user;
					$menumanager->tabMenu[$cont]['enabled'] = $conf->ecommerce->enabled;
					$menumanager->tabMenu[$cont]['type'] = 'left';
					$menumanager->tabMenu[$cont]['fk_mainmenu'] = '';
					$menumanager->tabMenu[$cont]['fk_leftmenu'] = '';
					$menumanager->tabMenu[$cont]['position'] = 100;
					$cont++;
					$start_id++;
					// We complete tabMenu
					$menumanager->tabMenu[$cont]['rowid'] = $start_id;
					$menumanager->tabMenu[$cont]['module'] = 'ecommerce';
					$menumanager->tabMenu[$cont]['fk_menu'] = $rowid_group;
					$menumanager->tabMenu[$cont]['url'] = '/ecommerce/site_customers.php?siteid=' . $_GET["siteid"];
					$menumanager->tabMenu[$cont]['titre'] = $langs->trans("Clients");
					$menumanager->tabMenu[$cont]['target'] = '';
					$menumanager->tabMenu[$cont]['mainmenu'] = 'ecommerce';
					$menumanager->tabMenu[$cont]['leftmenu'] = '';
					$menumanager->tabMenu[$cont]['perms'] = $user->rights->Ecommerce->user;
					$menumanager->tabMenu[$cont]['enabled'] = $conf->ecommerce->enabled;
					$menumanager->tabMenu[$cont]['type'] = 'left';
					$menumanager->tabMenu[$cont]['fk_mainmenu'] = '';
					$menumanager->tabMenu[$cont]['fk_leftmenu'] = '';
					$menumanager->tabMenu[$cont]['position'] = 100;
					$cont++;
					$start_id++;
					if ($conf->global->ECOM_IMP_PRODIMPORT > 0) {
						// We complete tabMenu
						$menumanager->tabMenu[$cont]['rowid'] = $start_id;
						$menumanager->tabMenu[$cont]['module'] = 'ecommerce';
						$menumanager->tabMenu[$cont]['fk_menu'] = $rowid_group;
						$menumanager->tabMenu[$cont]['url'] = '/ecommerce/site_prodimport.php?siteid=' . $_GET["siteid"];
						$menumanager->tabMenu[$cont]['titre'] = $langs->trans("SiteProdImport");
						$menumanager->tabMenu[$cont]['target'] = '';
						$menumanager->tabMenu[$cont]['mainmenu'] = 'ecommerce';
						$menumanager->tabMenu[$cont]['leftmenu'] = '';
						$menumanager->tabMenu[$cont]['perms'] = $user->rights->Ecommerce->user;
						$menumanager->tabMenu[$cont]['enabled'] = $conf->ecommerce->enabled;
						$menumanager->tabMenu[$cont]['type'] = 'left';
						$menumanager->tabMenu[$cont]['fk_mainmenu'] = '';
						$menumanager->tabMenu[$cont]['fk_leftmenu'] = '';
						$menumanager->tabMenu[$cont]['position'] = 100;
						$cont++;
						$start_id++;
					}
					if ($conf->global->ECOM_IMP_CATPROD > 0) {
						// We complete tabMenu
						$menumanager->tabMenu[$cont]['rowid'] = $start_id;
						$menumanager->tabMenu[$cont]['module'] = 'ecommerce';
						$menumanager->tabMenu[$cont]['fk_menu'] = $rowid_group;
						$menumanager->tabMenu[$cont]['url'] = '/ecommerce/site_categories.php?siteid=' . $_GET["siteid"];
						$menumanager->tabMenu[$cont]['titre'] = $langs->trans("Categories");
						$menumanager->tabMenu[$cont]['target'] = '';
						$menumanager->tabMenu[$cont]['mainmenu'] = 'ecommerce';
						$menumanager->tabMenu[$cont]['leftmenu'] = '';
						$menumanager->tabMenu[$cont]['perms'] = $user->rights->Ecommerce->user;
						$menumanager->tabMenu[$cont]['enabled'] = $conf->ecommerce->enabled;
						$menumanager->tabMenu[$cont]['type'] = 'left';
						$menumanager->tabMenu[$cont]['fk_mainmenu'] = '';
						$menumanager->tabMenu[$cont]['fk_leftmenu'] = '';
						$menumanager->tabMenu[$cont]['position'] = 100;
						$cont++;
						$start_id++;
					}
					//$menu->add($rootmenu."/ecommerce/site_orders.php?siteid=".$_GET["siteid"], $langs->trans("Orders"),1);
					//$menu->add($rootmenu."/ecommerce/site_products.php?siteid=".$_GET["siteid"], $langs->trans("Products"),1);
					//$menu->add($rootmenu."/ecommerce/site_customers.php?siteid=".$_GET["siteid"], $langs->trans("Clients"),1);
					//if (ECOM_IMP_PRODIMPORT > 0) $menu->add($rootmenu."/ecommerce/site_prodimport.php?siteid=".$_GET["siteid"],$langs->trans("SiteProdImport"),1);
					//if (ECOM_IMP_CATPROD > 0)$menu->add($rootmenu."/ecommerce/site_categories.php?siteid=".$_GET["siteid"], $langs->trans("Categories"),1);
					//$menu->add($rootmenu."/ecommerce/admin/site_admin.php?siteid=".$_GET["siteid"],$langs->trans("Administration"));
				}
				$i++;
			}
		}
		if ((empty($conf->dol_hide_topmenu) || GETPOSTINT('dol_invisible_topmenu')) && !GETPOSTINT('dol_openinpopup')) {
			top_menu($head, $title, $target, $disablejs, $disablehead, $arrayofjs, $arrayofcss, $morequerystring, $help_url);
		}
		if (empty($conf->dol_hide_leftmenu) && !GETPOST('dol_openinpopup', 'aZ09')) {
			left_menu($menu->liste, $help_url, '', '', 1, $title, 1); // $menumanager is retrieved with a global $menumanager inside this function
		}
	} else {
		if ((empty($conf->dol_hide_topmenu) || GETPOSTINT('dol_invisible_topmenu')) && !GETPOSTINT('dol_openinpopup')) {
			top_menu($head, $title, $target, $disablejs, $disablehead, $arrayofjs, $arrayofcss, $morequerystring, $help_url);
		}


		//$last_version = defined(MAIN_VERSION_LAST_UPGRADE) ? MAIN_VERSION_LAST_UPGRADE : MAIN_VERSION_LAST_INSTALL;
		$last_version = DOL_VERSION;

		$rootmenu = '';
		//$menu->add($rootmenu."/ecommerce/index.php", $langs->trans("OSCommerceShop"));

		// afficher tous les sites
		$sql = "SELECT rowid, site_name FROM " . MAIN_DB_PREFIX . "ecom_site";
		$sql .= " WHERE entity = " . $conf->entity;
		$resql = $db->query($sql);
		if ($resql) {
			$numr = $db->num_rows($resql);
			$i = 0;
			while ($i < $numr) {
				$objp = $db->fetch_object($resql);
				$menu->add($rootmenu . "/ecommerce/site_index.php?siteid=" . $objp->rowid, $objp->site_name);
				if (isset($_GET["siteid"]) && $objp->rowid == $_GET["siteid"]) {
					//menu pour un site
					//$menu->add($rootmenu."/ecommerce/site_index.php?siteid=".$_GET["siteid"], $langs->trans("EcomBoutique"));
					$menu->add($rootmenu . "/ecommerce/site_orders.php?siteid=" . $_GET["siteid"], $langs->trans("Orders"), 1);
					$menu->add($rootmenu . "/ecommerce/site_products.php?siteid=" . $_GET["siteid"], $langs->trans("Products"), 1);
					$menu->add($rootmenu . "/ecommerce/site_customers.php?siteid=" . $_GET["siteid"], $langs->trans("Clients"), 1);
					if ($conf->global->ECOM_IMP_PRODIMPORT > 0) $menu->add($rootmenu . "/ecommerce/site_prodimport.php?siteid=" . $_GET["siteid"], $langs->trans("SiteProdImport"), 1);
					if ($conf->global->ECOM_IMP_CATPROD > 0) $menu->add($rootmenu . "/ecommerce/site_categories.php?siteid=" . $_GET["siteid"], $langs->trans("Categories"), 1);
					//$menu->add($rootmenu."/ecommerce/admin/site_admin.php?siteid=".$_GET["siteid"],$langs->trans("Administration"));
				}
				$i++;
			}
		}

		if (empty($conf->dol_hide_leftmenu) && !GETPOST('dol_openinpopup', 'aZ09')) {
			left_menu($menu->liste, $help_url, '', '', 1, $title, 1); // $menumanager is retrieved with a global $menumanager inside this function
		}
	}
///////////
 	// main area
	if ($replacemainareaby) {
		print $replacemainareaby;
		return;
	}
	main_area($title);
}


