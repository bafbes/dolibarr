<?php
/* Copyright (C) 2007 		Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2008 		Jean Heimburger	   	<jean@tiaris.fr>
 * Copyright (C) 2011-2013 	Philippe Grand      <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013 	Juanjo Menent       <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       ecommerce/site_categories.php
 *        \ingroup    ecommerce
 *        \brief      Categories Management for e-commerce site
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */

require("./pre.inc.php");

dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/E_categorie.class.php");
require_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/class/html.form.class.php';

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("other");
$langs->load("ecommerce@ecommerce");

// Protection if external user
if ($user->societe_id > 0) {
	//accessforbidden();
}

// Get parameters
$siteid = GETPOST('siteid');
$confirm = GETPOST('confirm');

if ($siteid) {
// get site_parameters
	$site_params = new Ecom_site($db);
	if ($site_params->fetch($siteid, $user) < 0) {
		setEventMessage($langs->trans("ErrLecSite"), 'errors');
	}
	else {
	}
}

$action = GETPOST('action', 'alpha');

$sortfield = GETPOST("sortfield", 'alpha');
$sortorder = GETPOST("sortorder", 'alpha');
$slabel = GETPOST("slabel", 'alpha');
$sdolilabel = GETPOST("sdolilabel", 'alpha');
// Pagination
$page = GETPOST("page", 'int');
if ($page == -1) {
	$page = 0;
}
$offset = $conf->liste_limit * $page;
$pageprev = $page - 1;
$pagenext = $page + 1;
if (!$sortfield) $sortfield = "ec.ecom_catid";
if (!$sortorder) $sortorder = "DESC";

$limit = $conf->liste_limit;

$sai_cat = false;


/*
* Actions
*/

if (isset($_POST["button_removefilter_x"])) {
	$slabel = "";
	$sdolilabel = "";
}

if ($action == 'import') {
	if (is_array($_POST['toCreate']) && count($_POST['toCreate'])) {
		foreach ($_POST['toCreate'] as $catToDoli) {
			$ecat = new E_categorie($db, $siteid, $user);
			if ($ecat->import_categorie($catToDoli, GETPOST('rowid')) < 0) setEventMessage($langs->trans("ErrImport", $ecat->error), 'errors');
		}
	}
}
elseif ($action == 'import_new') {
	$ecatlimit = $site_params->site_maxcategory;
	$ecat = new E_categorie($db, $siteid, $user);
	if ($ecat->import_new_cats($ecatlimit) < 0) {
		$mesg = $langs->trans("ErrorImportNewCat") . ": " . $ecat->error;
		setEventMessage($mesg, 'errors');
	}
}
elseif ($action == 'modif') {
// Saisie de la catégorie dolibarr
	$sai_cat = true;
	$saicat_id = GETPOST('ecomid');
}
elseif ($action == 'SelectDoliCat') {
// Mise à jour de la catégorie dolibarr

    $ecat = new E_categorie($db, $siteid, $user);
    if ($ecat->fetch(GETPOST('rowid')) < 0) {
        $mesg = $langs->trans("Erreur") . ": " . $ecat->error;
        setEventMessage($mesg, 'errors');
    } else {
        if (GETPOST("catMere")) {
            $ecat->doli_catid = GETPOST("catMere");
        } else {
            $ecat->doli_catid = GETPOST("parent");
        }
        if ($ecat->update($user) < 0) setEventMessage($langs->trans("Erreur", $ecat->error), 'errors');
    }
}
elseif ($action == 'confirm_recreateondolibarr' && $confirm == 'yes') {
    $cat = new Categorie($db);
    $categories = [];
    $existing=[];

    if ($cat->rechercher($conf->global->ECOM_IMP_CATPROD, '', 0) > 0) {
        // 1. Sélectionner toutes les catégories
        $sql = "SELECT rowid, doli_catid, ecom_catid, ecom_parentid, ecom_catname FROM " . MAIN_DB_PREFIX."ecom_categories";
        $sql.= " WHERE siteid = " . ((int) $siteid);
        $resql = $db->query($sql);

        if ($resql && ($num = $db->num_rows($resql)) > 0) {
            include_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';

            // 2. Création des catégories sans lien parent
            while ($obj = $db->fetch_object($resql)) {
                if (empty($obj->doli_catid)) {
                    $cat->label = $obj->ecom_catname;
                    if(in_array($obj->ecom_catname,$existing)) $cat->label.='.';
                    $cat->description = $obj->ecom_catname;
                    $cat->visible = 1;
                    $cat->type = 0;
                    $cat->entity = $conf->entity;
                    $cat->fk_user_creat = $user->id;

                    // On stocke temporairement un parent neutre (sera mis à jour ensuite)
                    $cat->fk_parent = null;
                    $existing[]=$obj->ecom_catname;

                    $result = $cat->create($user);
                    if ($result > 0) {
                        // Stocker l'ID Dolibarr nouvellement créé
                        $categories[$obj->ecom_catid] = [
                            'rowid' => $obj->rowid,
                            'doli_catid' => $result,
                            'ecom_parentid' => $obj->ecom_parentid
                        ];

                        // Mettre à jour la table avec l'ID Dolibarr
                        $update_sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_categories 
                                       SET doli_catid = " . ((int) $result) . " 
                                       WHERE rowid = " . ((int) $obj->rowid);
                        $db->query($update_sql);
                    } else {
                        setEventMessage("Erreur lors de la création de la catégorie Dolibarr : " . $cat->error, 'errors');
                    }
                }
            }

            // 3. Mise à jour des relations parent/enfant
            foreach ($categories as $ecom_catid => $cat_data) {
                if (!empty($cat_data['ecom_parentid']) && isset($categories[$cat_data['ecom_parentid']])) {
                    $parent_doli_catid = $categories[$cat_data['ecom_parentid']]['doli_catid'];
                } else {
                    // Si pas de parent défini, utiliser une catégorie mère par défaut (ex: première catégorie créée ?)
                    $parent_doli_catid = $conf->global->ECOM_IMP_CATPROD; // Peut être modifié
                }

                // Mise à jour du parent dans Dolibarr
                $update_sql = "UPDATE " . MAIN_DB_PREFIX . "categorie 
                               SET fk_parent = " . ((int) $parent_doli_catid) . " 
                               WHERE rowid = " . ((int) $cat_data['doli_catid']);
                if (!$db->query($update_sql)) {
                    setEventMessage("Erreur de mise à jour du parent pour la catégorie ID " . $cat_data['doli_catid'], 'errors');
                }
            }
        } else {
            setEventMessage("Erreur : Aucune catégorie trouvée pour le site $siteid", 'errors');
        }
    } else {
        setEventMessage("Erreur : Catégorie racine non trouvée dans Dolibarr", 'errors');
    }
}

/*. Les
 * View
 */

llxHeader();

if ($action == 'recreateondolibarr') {
// Saisie de la catégorie dolibarr
	$html = new Form($db);
	$html->form_confirm($_SERVER['PHP_SELF'] . "?siteid=$siteid", "", $langs->trans('RecreateOnDolibarrConfirm'), 'confirm_recreateondolibarr', '', 0, 2);
}

$form = new Form($db);

$text = $langs->trans("SiteArea");

print_fiche_titre($text, '', 'ecommerce@ecommerce');
print '<br>';
$h = 0;
/*$head = array();

$head[$h][0] = dol_buildpath("/ecommerce/site_index.php?siteid=" . $siteid, 1);
$head[$h][1] = $site_params->site_name;
$head[$h][2] = 'ecommerce';
$h++;
dol_fiche_head($head, 'ecommerce', $langs->trans("SiteCategorieAdmin"));
*/

$sql = "SELECT count(*) num FROM " . MAIN_DB_PREFIX . "ecom_categories";
$resql = $db->query($sql);
if ($resql) $nenregistrements = $db->fetch_object($resql)->num;

$param = "&amp;siteid=" . $siteid;

$sql = "SELECT ec.rowid as id, ec.ecom_catid,  ec.ecom_catname, c.rowid, c.label ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_categories ec ";
$sql .= " LEFT OUTER JOIN " . MAIN_DB_PREFIX . "categorie c ON c.rowid = ec.doli_catid ";
$sql .= " WHERE ec.siteid = '" . $siteid . "'";
if ($slabel) $sql .= " AND ec.ecom_catname like '%" . $slabel . "%'";
$sql .= " ORDER BY $sortfield $sortorder ";
$sql .= $db->plimit($limit + 1, $offset);

dol_syslog("site_categories sql " . $sql, LOG_DEBUG);

$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);

	$texte = '';
	$url = 'site_categories.php?siteid=' . $siteid ;
//	print_barre_liste($texte, $page, "site_categories.php", $param, $sortfield, $sortorder, '', $num);
    print "$nenregistrements enregistrements";
    print '<table class="liste" width="100%">';
	print '<tr class="liste_titre">';
	print '<td colspan="2" align="left"><a href="' . $site_params->site_url . '">' . $site_params->site_url . '</a></td>';
	print '<td colspan="3" align="left"><h3><a href="' . $url. '&action=import_new' . '">' . $langs->trans("SiteImport") . '</a></td>';
	print '<td colspan="2" align="left"><a href="' . $url. '&action=recreateondolibarr' . '">' . $langs->trans("RecreateOnDolibarr") . '</a></td>';
	print '</tr>';
	print "</tr>\n";
	print '<tr><td>&nbsp;</td></tr>';
	print '<tr class="liste_titre">';
	print '<td colspan="7" align="center"><h3>' . $langs->trans("SiteCategorieAdmin") . '</td>';

	if ($page > 0) $url .= '&page=' . $page;

	print '<tr class="liste_titre">';
	print_liste_field_titre($langs->trans("SiteCatId"), "site_categories.php", "ec.ecom_catid", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("SiteCattName"), "site_categories.php", "ec.ecom_catname", $param, "", "", $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("DoliCatLabel"), "site_categories.php", "c.label", $param, "", 'colspan="2"', $sortfield, $sortorder);
	print_liste_field_titre($langs->trans("DoliCatId"), "site_categories.php", "c.rowid", $param, "", "", $sortfield, $sortorder);
	if($user->admin) print '<td class="liste_titre" colspan="2" align="center">' . $langs->trans("ImportModify") . '</td></tr>';

	// Lignes des champs de filtre
	print '<form action="site_categories.php" method="post" name="formulaire">';
	print '<input type="hidden" name="siteid" value=' . $siteid . ' >';
	print '<input type="hidden" name="sortfield" value="' . $sortfield . '">';
	print '<input type="hidden" name="sortorder" value="' . $sortorder . '">';
	print '<tr class="liste_titre">';
	print '<td class="liste_titre">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '<input class="flat" type="text" name="slabel" size="20" value="' . $slabel . '">';
	print '</td>';
	print '</td>';
	print '<td class="liste_titre" align="left">';
	print '<input class="flat" type="text" name="sdolilabel" size="20" value="' . $sdolilabel . '">';
	print '</td>';
	print '<td class="liste_titre">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre">';
	print '&nbsp;';
	print '</td>';
	print '<td class="liste_titre" align="right">';
	print "\n";
	print '<input type="image" class="liste_titre" name="button_search" src="' . DOL_URL_ROOT . '/theme/' . $conf->theme . '/img/search.png" alt="' . $langs->trans("Search") . '">';
	print '<input type="image" class="liste_titre" name="button_removefilter" src="' . DOL_URL_ROOT . '/theme/' . $conf->theme . '/img/searchclear.png" alt="' . $langs->trans("RemoveFilter") . '">';

	print '</td>';
	print '</tr>';

	print "\n";
	print '</form>';
	$url1 = 'site_categories.php?siteid=' . $siteid;
	if ($page > 0) $url1 .= '&page=' . $page;

	$i = 0;
	if ($num) {
		$var = True;
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				print '<tr ' . $bc[$var] . '>';
				print '<td>' . $obj->ecom_catid . '</td>';
				print '<td>' . $obj->ecom_catname . '</td>';
				if ($obj->rowid) {
					print '<td>' . $obj->label . '</td>';
					print '<td colspan="2"><a href="' . DOL_URL_ROOT . '/categories/viewcat.php?id=' . $obj->rowid . '">' . $obj->rowid . '</a></td>';
				}
				else print '<td>&nbsp</td><td colspan="2">&nbsp</td>';

				// actions
				print '<td align="center"><form action="' . $url1 . '" method="POST">';
				print '<input type="hidden" name="ecomid" value="' . $obj->ecom_catid . '">';
				print '<input type="hidden" name="rowid" value="' . $obj->id . '">';
				print '<input type="hidden" name="sortfield" value="' . $sortfield . '">';
				print '<input type="hidden" name="sortorder" value="' . $sortorder . '">';
				print '<input type="hidden" name="slabel" value="' . $slabel . '">';
				print '<input type="hidden" name="sdolilabel" value="' . $sdolilabel . '">';
				$lib = $langs->trans("Modify");
				print '<input type="hidden" name="action" value="modif">';
				if($user->admin) print '<input class="button" type="submit" value="' . $lib . '">';
				print '</form></td>'; //bouton modifier

				if (($sai_cat) && ($saicat_id == $obj->ecom_catid)) {
					$var = !$var;
					// saisie de la catégorie
					$html = new Form($db);
					print '<td>&nbsp;</td>';
					print '</tr><tr ' . $bc[$var] . '>';
					print '<td></td>';
					print '<td>' . $langs->trans("ChoixCatDolibarr") . '</td>';
					print '<td><form action="' . $url1 . '"method="POST">';
					print '<input type="hidden" name="ecomid" value="' . $obj->ecom_catid . '">';
					print '<input type="hidden" name="action" value="SelectDoliCat">';
					print '<input type="hidden" name="rowid" value="' . $obj->id . '">';
					print '<input type="hidden" name="sortfield" value="' . $sortfield . '">';
					print '<input type="hidden" name="sortorder" value="' . $sortorder . '">';
					print '<input type="hidden" name="slabel" value="' . $slabel . '">';
					print '<input type="hidden" name="sdolilabel" value="' . $sdolilabel . '">';
					print $html->select_all_categories('product',$obj->rowid) . ' <input type="submit" class="button" value="' . $langs->trans("Classify") . '"></td>';
					print '</form>';
					print'<td></td>';
				}


				print '</tr>';
			}
			$i++;
			$var = !$var;
		}
		print '<tr class="liste_titre" >';
		print '<td colspan="5">&nbsp;</td>';
		print '<td align="center">';
		print '</form>';

		print '</td>';
		print '</tr>';
		if ($num > $conf->liste_limit) {
			print '<input type="hidden" name="siteid" value="' . $siteid . '" />';
			print_barre_liste($texte, $page, "site_categories.php", '&siteid=' . $siteid, '', '', '', $num);
		}

	}
}
print '</table>';


// End of page

llxFooter();

$db->close();

