<?php
/* Copyright (C) 2007 		Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2008-2011	Jean Heimburger	   	<jean@tiaris.fr> http://www.tiaris.fr
 * Copyright (C) 2011-2013  Philippe Grand      <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013	Juanjo Menent	   	<jmenent@sbyte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       ecommerce/site_index.php
 *        \ingroup    ecommerce
 *        \brief      Index page for an e-commerce site
 *        \author        Jean Heimburger
 */

require("./pre.inc.php");
dol_include_once("/ecommerce/core/lib/ecommerce.lib.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/ecom_order.class.php");
dol_include_once("/ecommerce/class/E_product.class.php");
dol_include_once("/ecommerce/class/E_order.class.php");
dol_include_once("/ecommerce/class/ecom_log.class.php");
require_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");
//compatibilité
dol_include_once("/ecommerce/includes/orders.inc.php");

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("other");
$langs->load("ecommerce@ecommerce");


// Protection if external user
$socid = GETPOST('socid', 'int');
if ($user->societe_id) $socid = $user->societe_id;
$result = restrictedArea($user, 'societe', $socid);


/*
 * Actions
 */


// Get parameters
$siteid = GETPOST('siteid', 'int');
$limit = GETPOST("limit", 'int') ? GETPOST("limit", 'int') : $conf->liste_limit;
$offset = GETPOST("offset", 'int') ? GETPOST("offset", 'int') : 0;

if ($siteid) {
// get site_parameters
    $site_params = new Ecom_site($db);
    if ($site_params->fetch($siteid, $user) < 0) {
        setEventMessage($langs->trans("ReadSiteError"), 'errors');
    }
    else {

    }
}
else setEventMessage($langs->trans("ErrorNoSite"), 'errors');

if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'logdelete') {
	if (isset($_POST["logrowid"])) {
		$elog = new Ecom_log($db);
		$elog->id = $_POST["logrowid"];
		$elog->delete($_POST["logrowid"], 1);
	}
}

/*
 * Model
 */

llxHeader();


// customer and log
// log for site
// affichage des logs
print '<br/>';
print '<form action="' . $_SERVER['PHP_SELF'] . '?siteid=' . $siteid . '" method="POST">';
print '<input type="hidden" name="siteid" value="' . $siteid . '">';
print '<input type="hidden" name="action" value="resetlimitoffset">';
print 'Nombre d\'enregistrements : ';
print '<input type="text" id="limit" name="limit" value="'.$limit.'">';
print 'Décalage depuis la fin : ';
print '<input type="text" id="offset" name="offset" value="'.$offset.'">';
print '<input class="button" type="submit" value="' . $langs->trans("Update") . '">';
print '</form>';
print '<br/>';

$sql = "SELECT rowid, log_date, log_fonction, log_message ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_log";
$sql .= " WHERE site_id = '" . $siteid . "'";
//$sql .= " AND log_fct = 'COM' AND log_type = 'ERR' ";
$sql .= " ORDER BY rowid DESC";
$sql .= " LIMIT $offset,$limit";

$resql = $db->query($sql);
if ($resql) {
    $num = $db->num_rows($resql);
    $i = 0;
    if ($num) {
        print '<table class="liste" width="100%"><tr class="liste_titre"><td colspan="15" align="center"><h3>' . $langs->trans("LogAdmin") . '</td></tr>';
        print '<tr class="liste_titre">';
        print '<th colspan="2"><b>' . $langs->trans("Id") . '</th>';
        print '<th colspan="2"><b>' . $langs->trans("LogDate") . '</th>';
        print '<th colspan="2"><b>' . $langs->trans("LogFonc") . '</th>';
        print '<th colspan="8"><b>' . $langs->trans("LogMessage") . '</th>';
//        print '<th colspan="1"><b>' . $langs->trans("LogAction") . '</th>';
        print '</tr>';
        $var = True;

        print '<form action="' .  $_SERVER['PHP_SELF'] . '" name="deletelog" method="POST">';
        print '<input type="hidden" name="action" value="logdelete"/>';

        while ($i < $num) {
            $obj = $db->fetch_object($resql);
            if ($obj) {
                print '<tr ' . $bc[$var] . '>';
                print '<td colspan="2">' . $obj->rowid . '</td>';
                print '<td colspan="2" nowrap>' . $obj->log_date . '</td>';
                print '<td colspan="2">' . $obj->log_fonction . '</td>';
                print '<td colspan="8" align="justify">' . $obj->log_message . '</td>';
                print '<form action="' .  $_SERVER['PHP_SELF'] . '" name="deletelog" method="POST">';
                print '<input type="hidden" name="action" value="logdelete"/>';
                print '<input type="hidden" name="logrowid" value="' . $obj->rowid . '"/>';
                print '<input type="hidden" name="siteid" value="' . $siteid. '"/>';
//                print '<td colspan="1">';
//                print '<input type="submit" class="button" value="' . $langs->trans("Delete") . '" />';
//                print '</td>';
                print '</form></tr>';

            }
            $i++;
            $var = !$var;
        }
        print '</table>';
    }
}
// End of page
if ($mesg) dol_htmloutput_mesg($mesg);

llxFooter();

$db->close();
