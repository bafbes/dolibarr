<?php
//Non utilisé

/* Copyright (C) 2007 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2008 Jean Heimburger	   <jean@tiaris.fr>
 * Copyright (C) 2011-2013 Philippe Grand  <philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       ecommerce/site_prodimport.php
 *    \ingroup    ecommerce
 *    \brief      Actuellement non utilisée - Importation de produits dans un fichier CSV
 *    \author     Jean Heimburger www.tiaris.fr
 */

require("./pre.inc.php");

require_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");
require_once(DOL_DOCUMENT_ROOT . "/core/class/html.formfile.class.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/E_product.class.php");
dol_include_once("/ecommerce/class/ecom_html.class.php");
dol_include_once("/ecommerce/class/E_import.class.php");
//compatibilité
dol_include_once(DOL_DOCUMENT_ROOT . "/ecommerce/includes/products.inc.php");

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("other");
$langs->load("ecommerce@ecommerce");


// Protection if external user
$socid = GETPOST('socid', 'int');
if ($user->societe_id) $socid = $user->societe_id;
$result = restrictedArea($user, 'societe', $socid);

// Get parameters
$siteid = isset($_GET["siteid"]) ? $_GET["siteid"] : $_POST["siteid"];

if ($siteid) {
// get site_parameters
	$site_params = new Ecom_site($db);
	if ($site_params->fetch($siteid, $user) < 0) {
		$mesg = '<div class="error">' . "erreur lecture site get " . $siteid . '</div>';
	}
	else {
	}
}


/*
 * Actions
 */

// imports par fichiers
if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'ImportFile') {
	// gestion des imports
	$nom_fic = $_FILES["fichier"]["name"];
	$newfic = DOL_DATA_ROOT . '/' . $nom_fic;
	$temp_fic = $_FILES["fichier"]["tmp_name"];
	if (move_uploaded_file($temp_fic, $newfic)) $res = "ok";
	else $res = "ko";

	$eimport = new E_import($db, $newfic, $siteid, $user);

	//recup des variables
	$firstline = $_POST["firstline"];
	$actionverif = $_POST["verifier"];
	$actionDoli = isset($_POST["traiterDoli"]) ? $_POST["traiterDoli"] : '';
	$actionEcom = isset($_POST["traiterEcom"]) ? $_POST["traiterEcom"] : '';
	$typeactionDoli = $_POST["Dolitype"];
	$typeactionEcom = $_POST["Ecomtype"];

	if ($firstline == "on") $eimport->firstline = 1;

	if ($actionverif == "on") {
		$imp_result = $eimport->validate_import($newfic);

		if ($imp_result < 0) $mesg = '<div class="error">' . "erreur de validation " . $eimport->error . '</div>';
	}
	/*	if ($actionDoli =="on" && !$imp_result  )
		{
			$imp_result = $eimport->import2Dolibarr('product', $typeactionDoli);
			if ($imp_result < 0) $mesg = "erreur import Dolibarr ".$eimport->error;
		}*/
	if ($actionEcom == "on" && !$imp_result) {
		$imp_result = $eimport->ImportOnEcommerce($typeactionEcom);
		if ($imp_result) $mesg = '<div class="error">' . "erreur import Ecommerce " . $eimport->error . '</div>';
		else $mesg = '<div class="warning">' . $langs->trans("ImportDone") . '</div>';
	}

}

// création liste csv
if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'ExportCsv') {
	$maxprods = isset($_POST["LastProds"]) ? $_POST["LastProds"] : 0;
	$fromprod = isset($_POST["FromProdsId"]) ? $_POST["FromProdsId"] : 0;
	$datecreate = isset($_POST["ProdsCreateDate"]) ? $_POST["ProdsCreateDate"] : '';
	$datemodif = isset($_POST["ProdsUpdateDate"]) ? $_POST["ProdsUpdateDate"] : '';
	$fournid = isset($_POST["FourId"]) ? $_POST["FourId"] : 0;
	$categid = isset($_POST["CatId"]) ? $_POST["CatId"] : 0;
	$ecomtype = isset($_POST["Ecomptype"]) ? $_POST["Ecomptype"] : 'C';

	$whereclause = '';
	$nbclause = 0;
	$byclause = "DESC";
	if ($fromprod || $datecreate || $datemodif || $fournid || $categid) {
		$whereclause = "WHERE ";
		if ($fromprod) {
			$whereclause .= " p.rowid >= '" . $fromprod . "'";
			$byclause = "ASC";
			$nbclause++;
		}
		if ($datecreate) {
			if ($nbclause) $whereclause .= ' AND ';
			$whereclause .= " p.date >= '" . $datecreate . "'";
			$byclause = "ASC";
			$nbclause++;
		}
		if ($datemodif) {
			/* 	if ($nbclause) $whereclause .= ' AND ';
				$whereclause .= " p.date >= '".$datecreate."'" ;
				$nbclause++;
			*/
		}
		if ($fournid) {
			if ($nbclause) $whereclause .= ' AND ';
			$whereclause .= " f.fk_soc = '" . $fournid . "'";
			$nbclause++;
		}
		if ($categid) {
			if ($nbclause) $whereclause .= ' AND ';
			$whereclause .= " c.fk_categorie = '" . $categid . "'";
			$nbclause++;
		}
	}

	if ($ecomtype == 'C') $sql = "SELECT p.ref, '1' as qty, p.weight, '' as manufacturer, '' as category, p.tva_tx, p.price_ttc, '' as long_desc ";
	else $sql = "SELECT p.ref, '1' as qty, p.weight, '0' as manufacturer, '' as category, p.tva_tx, p.price_ttc, p.tosell as visible ";
	$sql .= "FROM " . MAIN_DB_PREFIX . "product p ";
	if ($categid) $sql .= " JOIN " . MAIN_DB_PREFIX . "categorie_product c ON c.fk_product = p.rowid ";
	if ($fournid) $sql .= " JOIN " . MAIN_DB_PREFIX . "product_fournisseur f ON f.fk_product = p.rowid ";
	if ($whereclause) $sql .= $whereclause;
	$sql .= " ORDER BY p.rowid " . $byclause;
	if ($maxprods) $sql .= " LIMIT " . $maxprods;

	$mesg = $sql;
	dol_syslog(__FILE__ . " requête " . $sql, LOG_DEBUG);

	// datas
	$tabexp = array();

	$resql = $db->query($sql);
	if ($resql) {
		while ($row = $db->fetch_object($resql)) {
			$tabexp[] = $row;
		}


	}
	else $mesg = '<div class="error">' . "Erreur sql " . '</div>';

	$sqlmanu = "SELECT ecom_manufacturer as id, ecom_manuname as lib FROM " . MAIN_DB_PREFIX . "ecom_manufacturer WHERE siteid = '" . $siteid . "'";
	dol_syslog("liste fabricants " . $sqlmanu, LOG_DEBUG);
	$sqlcateg = "SELECT ecom_catid as id, ecom_catname as lib FROM " . MAIN_DB_PREFIX . "ecom_categories WHERE siteid = '" . $siteid . "'";
	dol_syslog("liste catégories " . $sqlcateg, LOG_DEBUG);
	$sqlvat = "SELECT ecom_id as id, ecom_lib as lib FROM " . MAIN_DB_PREFIX . "ecom_params WHERE siteid = '" . $siteid . "' AND partype='taxrate'";
	dol_syslog("liste vat " . $sqlvat, LOG_DEBUG);

}


// création d'un fichier csv
if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'CreateCsv') {
	if (is_array($_POST['toGenerate'])) {
		$text = 'ref;qty;weight;manuf;categ;vat;price;';
		if (GETPOST('Ecomtype') == "M") $text .= 'A/I';
		else $text .= 'desc';
		$text .= "<br />";

		foreach ($_POST['toGenerate'] as $key => $elt) {
			if (is_array($_POST['ref'])) {
				$text .= isset($_POST['ref'][$key]) ? $_POST['ref'][$key] : '';
				$text .= ";";
			}
			$text .= $_POST["qty"][$key] . ";";
			if (is_array($_POST['weight'])) {
				$text .= isset($_POST['weight'][$key]) ? $_POST['weight'][$key] : '';
				$text .= ";";
			}
			if (is_array($_POST['SiteManufacturer'])) {
				$idman = isset($_POST['SiteManufacturer'][$key]) ? $_POST['SiteManufacturer'][$key] : '';
				if ($idman == '-1') $idman = '';
				$text .= $idman;
				$text .= ";";
			}
			if (is_array($_POST['SiteCategory'])) {
				$idcat = isset($_POST['SiteCategory'][$key]) ? $_POST['SiteCategory'][$key] : '';
				$text .= ($idcat == '-1') ? '' : $idcat;
				$text .= ";";
			}
			if (is_array($_POST['SiteVat'])) {
				$idvat = isset($_POST['SiteVat'][$key]) ? $_POST['SiteVat'][$key] : '';
				$text .= ($idvat == '-1') ? '' : $idvat;
				$text .= ";";
			}
			$text .= $_POST['price'][$key] . ";";
			if (GETPOST('Ecomtype') == "M") $text .= 'A;';
			else $text .= ';';

			$text .= "<br />";
		}
	}


	// sauvegarde du fichier
	$expfilename = DOL_DATA_ROOT . '/ecommerce/temp/export_prodcsv.csv';
	$fi = @fopen($expfilename, "w");
	if (!$fi) {
		//erreur création fichier
		$mesg .= '<p><div class="error">' . "erreur ouverture " . '.DOL_DATA_ROOT.' / ecommerce / temp / export_prodcsv . csv . '</div></p>';
	}
	else {
		fwrite($fi, preg_replace("/\<br\s*\/?\>/i", "\n", $text));
		fclose($fi);
		//envoi du fichier au navigateur
		header('Location:' . DOL_URL_ROOT . '/document.php?modulepart=ecommerce&file=temp/export_prodcsv.csv');
	}
}

/*
 * View
 */

llxHeader();

$form = new Form($db);
$formfile = new FormFile($db);
$ecomform = new Ecom_html($db);
?>
<script language="javascript" type="text/javascript">
	jQuery(document).ready(function () {
		jQuery("#checkall").click(function () {
			jQuery(".checkformerge").attr('checked', true);
		});
		jQuery("#checknone").click(function () {
			jQuery(".checkformerge").attr('checked', false);
		});
	});
</script>
<?php
global $sqlmanu, $sqlcateg, $sqlvat, $newfic;
$manu_list = $ecomform->ecom_ddform($siteid, $sqlmanu, 'SiteManufacturer[]');
$categ_list = $ecomform->ecom_ddform($siteid, $sqlcateg, 'SiteCategory[]');
$vat_list = $ecomform->ecom_ddform($siteid, $sqlvat, 'SiteVat[]');

$text = $langs->trans("SiteArea");

print_fiche_titre($text, '', 'ecommerce@ecommerce');
print '<br>';
$h = 0;
$head = array();

$head[$h][0] = dol_buildpath("/ecommerce/site_index.php?siteid=$siteid", 1);
$head[$h][1] = $site_params->site_name;
$head[$h][2] = 'ecommerce';
$h++;

dol_fiche_head($head, 'ecommerce', $langs->trans("ImportProds"));

// Put here content of your page
$eimport = new E_import($db, $newfic, $siteid, $user);
if ($mesg) print '<p><div class="error">' . $mesg . '</div></p>';
if ($eimport->error) print '<p><div class="error">' . $eimport->error . '</div></p>';
// ...

print "\n";
print "<br/>";
print '<table class="notopnoleftnoright" width="75%" >';
print '<tr>';
print '<td width="20%">' . $langs->trans("ImportFileProd") . '</td>';
print '<td colspan="2"><form action="site_prodimport.php?siteid=' . $siteid . '" method="POST" enctype="multipart/form-data">';
print '<input type="file" name="fichier" size="40">';
print '<input type="hidden" name="imptype" value="cat">';
print '<input type="hidden" name="action" value="ImportFile">';
print '</td></tr>';
print '<tr><td width="20%">&nbsp;</td><td><input type="checkbox" name="firstline" checked></td><td>' . $langs->trans("ImportFirstLine") . '</td></tr>';
print '<tr><td width="20%">&nbsp;</td><td><input type="checkbox" name="verifier"></td><td>' . $langs->trans("ImportVerif") . '</td></tr>';
//print '<tr><td width="20%" valign="center">&nbsp;</td><td><input type="checkbox" name="traiterDoli"></td><td>'.$langs->trans("ImportDoli").'</td>';
//print '<td width="40%"><input type="Radio" name ="Dolitype" value="C" checked>'.$langs->trans("ImportCreate").'<br/><input type="Radio" name ="Dolitype" value="M" >'.$langs->trans("ImportMaj").'<br/><input type="Radio" name ="Dolitype" value="D" >'.$langs->trans("ImportDel").'<br/><br/></td></tr>';
print '<tr><td width="20%">&nbsp;</td><td><input type="checkbox" name="traiterEcom"></td><td>' . $langs->trans("ImportEcom") . '</td>';
print '<td width="40%"><input type="Radio" name ="Ecomtype" value="C" checked>' . $langs->trans("ImportCreate") . '<br/><input type="Radio" name ="Ecomtype" value="M" >' . $langs->trans("ImportMaj") . '<br/><br/></td></tr>';
print'<tr><td colspan="3" align="center"><input type="submit" value="' . $langs->trans("Envoyer") . '">';
print '</td></form></tr>';

print '</table>';
print '<br /><br />';

// création fichier pour import
print_fiche_titre($langs->trans("FileExport"), '', '');

print '<br /><div>' . $langs->trans("FileExportMess") . '</div><br />';
print '<table class="notopnoleftnoright" width="100%" ';
print '<tr><form action="site_prodimport.php?siteid=' . $siteid . '" method="POST" >';
print '<input type="hidden" name="action" value="ExportCsv">';
print '<td width="20%">' . $langs->trans("ExpLastProducts") . '</td>';
print '<td width="20%"><input type="text" name="LastProds" size="5" ></td>';
print '<td width="20%">' . $langs->trans("FromProductsId") . '</td>';
print '<td width="20%"><input type="text" name="FromProdsId" size="5"></td>';
print '<td width="20%"></td>';
print '</tr>';
print '<tr>';
print '<td width="20%">' . $langs->trans("ProdCreateDate") . '</td>';
print '<td width="20%"><input type="text" name="ProdsCreateDate" size="5"></td>';
print '<td width="20%">' . $langs->trans("ProdModifDate") . '</td>';
print '<td width="20%"><input type="text" name="ProdsUpdateDate" size="5"></td>';
print '<td width="20%"></td>';
print '</tr>';
print '<tr>';
print '<td width="20%">' . $langs->trans("ExpLastProductsCat") . '</td>';
print '<td width="20%"><input type="text" name="CatId" size="5"></td>';
print '<td width="20%">' . $langs->trans("ExpLastProductsFour") . '</td>';
print '<td width="20%"><input type="text" name="FourId" size="5"></td>';
print '<td width="20%" ></td>';
print '</tr>';
print '<tr><td width="40%"><input type="Radio" name ="Ecomtype" value="C" checked>' . $langs->trans("ImportCreate") . '&nbsp;&nbsp;&nbsp;<input type="Radio" name ="Ecomtype" value="M" >' . $langs->trans("ImportMaj") . '</td></tr>';
print '<tr><td></td><td colspan="4" align="left"><input type="submit" value="' . $langs->trans("Envoyer") . '">';
print '</form></table>';

$tabexp = array();
if (count($tabexp) > 0) {
	print '<form action="site_prodimport.php?siteid=' . $siteid . '" method="POST" >';
	print '<table width="100%">';
	print '<tr >';
	print '<td class="liste_titre" align="center">';
	if ($conf->use_javascript_ajax) print '<a href="#" id="checkall">' . $langs->trans("All") . '</a> / <a href="#" id="checknone">' . $langs->trans("None") . '</a>';
	print '</td>';
	print '<td class="liste_titre" align="center">' . $langs->trans('ArticleRef') . '</td><td class="liste_titre" align="center">' . $langs->trans('ProdStock') . '</td><td class="liste_titre" align="center">' . $langs->trans('ProdWeight') . '</td>';
	print '<td class="liste_titre" align="center">' . $langs->trans('ArticleManufactor') . '</td><td class="liste_titre" align="center">' . $langs->trans('ProdCat') . '</td><td class="liste_titre" align="center">' . $langs->trans('ProdTax') . '</td>';
	print '<td class="liste_titre" align="center">' . $langs->trans('ProdPrice') . '</td><td class="liste_titre" align="center">' . $langs->trans('SiteLongDesc') . '</td></tr>';

	$var = true;
	foreach ($tabexp as $elt) {
		print '<tr' . $bc[$var] . '>';
		print '<td align="center">';
		print '<input id="cb' . $p->rowid . '" class="flat checkformerge" type="checkbox" name="toGenerate[]" value="' . $p->rowid . '">';
		print '</td>';
		print '<td>' . $elt->ref . '</td>';
		print '<input type="hidden" name="ref[]" value="' . $elt->ref . '" />';
		print '<td>' . $elt->qty . '</td>';
		print '<input type="hidden" name="qty[]" value="' . $elt->qty . '" />';
		print '<td>' . $elt->weight . '</td>' . "\n";
		print '<input type="hidden" name="weight[]" value="' . $elt->weight . '" />';
		print '<td>' . $manu_list . '</td>'; //$elt->manufacturer
		print '<td>' . $categ_list . '</td>'; //$elt->category
		print '<td>' . $vat_list . '</td>'; //price2num($elt->tva_tx)
		print '<td ><input name="price[]" value="' . price($elt->price_ttc) . '" /></td>';
		print '<td></td>';
		//print '<td>'.$elt->long_desc.'</td>';
		//print '<td ><input type="hidden" name="weight[]" value="'.$elt->weight.'" /></td>';

		print '</tr>';
		$var = !$var;
	}

	print '</table>';
	print '<input type="hidden" name="Ecomtype" value="' . GETPOST("Ecomtype") . '">';
	print '<input type="hidden" name="action" value="CreateCsv" />';
	print '<input type="hidden" name="siteid" value="' . $siteid . '" />';
	print '<p><input class="button" type="submit" name="save" value="' . $langs->trans("Save") . '"></p>';
	print '</form>';
}

if ($eimport->process_msg) print '<p>' . nl2br($eimport->process_msg) . '</p>';

// End of page
llxFooter();

$db->close();


