<?php
/* Copyright (C) 2007 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2008 Jean Heimburger	   <jean@tiaris.fr>
 * Copyright (C) 2011-2013 Philippe Grand  <philippe.grand@atoo-net.com>
 * Copyright (C) 2013 Juanjo Menent        <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *       \file       scripts/ecommerce/products.inc.php
 *         \ingroup    Ecommerce
 *       \brief      Order Import function for use in import script
 *         \author     Jean Heimburger http://www.tiaris.fr
 */
require_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");
dol_include_once("/ecommerce/class/ecom_log.class.php");
dol_include_once("/ecommerce/class/E_product.class.php");
dol_include_once("/ecommerce/class/E_params.class.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/includes/nusoap/lib/nusoap.php");
//dol_include_once("/ecommerce/common_functions.php");
//define('DEBUG','?XDEBUG_SESSION_START=PhpStorm');

/** Importe les produits avec doli_product = 0 dans Ecom_product depuis prestashop
 * @param $siteid
 * @param $db
 * @param $user
 * @param string $limit non utilisé
 * @param string $first offset dans ecom_product
 * @return int|mixed
 * @throws Exception
 */
function get_products($siteid, $db, $user, $limit = '0', $first = '0')
{
    global $langs;
    $now = dol_now();

    $sql = "SELECT ep.rowid, ep.ecom_product, ep.ecom_attribut, ep.ecom_ref FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
    $sql .= " WHERE ep.doli_product = '0' AND ep.siteid = '" . $siteid . "' AND ecom_product > '" . $first . "' ";
//	if ($limit > 0) $sql .= " LIMIT 0,".$limit;

    $ecomlog = new Ecom_log($db);

    dol_syslog("products.inc.php::get_products $sql", LOG_DEBUG);
    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {
            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {
                    // You can use here results
                    $e_prod = new E_product($db, $siteid, $user);
                    if ($e_prod->import_product($obj->ecom_product, $obj->ecom_attribut, $obj->ecom_ref, $obj->rowid) < 0) {
                        dol_syslog("products.inc.php::get_products Erreur import " . $obj->ecom_product . " , " . $obj->ecom_ref, LOG_DEBUG);
                        // log
                        $ecomlog->site_id = $siteid;
                        $ecomlog->log_date = $now;
                        $ecomlog->log_fct = 'PRD';
                        $ecomlog->log_type = "ERR";
                        $ecomlog->log_fonction = $langs->trans("ErrImpPrd", $obj->ecom_product, $obj->ecom_ref);
                        $ecomlog->log_message = $langs->trans("ErrError") . " " . $e_prod->error;
                        $ecomlog->create($user);
                        // si l'import echoue on met a jour doli_product
                        $e_prod->doli_product = -1;
                        $e_prod->mdate = $now;
                        dol_syslog("products.inc.php::get_products maj ecom_product " . $e_prod->doli_product, LOG_DEBUG);
                        if ($e_prod->update($user) < 0) {
                            dol_syslog("products.inc.php::get_products erreur maj ecom_product " . $e_prod->error, LOG_DEBUG);
                        }
                    } else {
                        dol_syslog("products.inc.php::get_products   import de " . $obj->ecom_product . " r�ussi ", LOG_DEBUG);
                    }
                }
                $i++;
            }
        } else {
            dol_syslog("products.inc.php::get_products rien a traiter num= " . $num, LOG_DEBUG);
            return 0;
        }
    } else {
        dol_syslog("products.inc.php::get_products Erreur requete $sql " . $db->error, LOG_DEBUG);
        return -1;
    }
    return $num;
}

// verifie s'il existe de nouveaux produits sur le site ecommerce non presents dans dolibarr
// Si oui ajouter pour chaque produit une ligne dans ecom_product avec doli_product = 0
function get_new_products($siteid, $db, $user, $limit = '0')
{
    global $conf, $langs;
    $now = dol_now();

// lecture du site
    if ($siteid) {
        $ecomlog = new Ecom_log($db);
        // get site_parameters
        $site_params = new Ecom_site($db);
        if ($site_params->fetch($siteid, $user) < 0) {
            dol_syslog("ws_import::get_new_products erreur lecture site " . $site_params->error, LOG_DEBUG);
            return -1;
        }
    } else {
        dol_syslog("ws_import::get_new_products erreur lecture site " . $siteid, LOG_DEBUG);
        return -1;
    }

    // le dernier produit connu dans dolibarr
    $sql = "SELECT max(ecom_product) last FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
    $sql .= "WHERE ep.siteid = '" . $siteid . "' ";

    dol_syslog("products.inc.php::get_new_products $sql", LOG_DEBUG);
    $resql = $db->query($sql);
    if ($resql) {

        $obj = $db->fetch_object($resql);
        if ($obj) {
            $last = $obj->last;
            if (!isset($last)) $last = 0;
        } else {
            dol_syslog("products.inc.php::get_new_products rien a faire", LOG_DEBUG);
            //return -1;
            $last = 0;
        }
    } else {
        dol_syslog("products.inc.php::get_new_products erreur " . $sql, LOG_DEBUG);
        return -1;

    }
    // si le parametre $limit <> 0 le parametre l'emporte sur la configuration du site
    if ($limit == 0) $limite = $site_params->site_maxproduct;
    elseif ($limit > 0) $limite = $limit;
    else {
        dol_syslog("erreur limit doit etre >= 0 : " . $limit, LOG_ERR);
        return -1;
    }

    dol_syslog("E_product::get_new_products last= $last, limite=$limite", LOG_DEBUG);
    // appel methode
    dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

    // Set the parameters to send to the WebService
    $parameters = array("lastprodid" => $last, "limit" => $limite);

    // Set the WebService URL
    $client = new nusoap_client($site_params->site_ws_url . "ws_articles.php" . (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

    // Call the WebService and store its result in $obj
    $obj = $client->call("get_new_products", $parameters);
    if ($client->fault) {
        dol_syslog("E_product::get_new_products FAULT", LOG_DEBUG);
        // inscription en log
        $ecomlog->site_id = $siteid;
        $ecomlog->log_date = $now;
        $ecomlog->log_type = "ERR";
        $ecomlog->log_fct = 'PRD';
        $ecomlog->log_fonction = $langs->trans("ErrImpPrd");
        $ecomlog->log_message = $langs->trans("ErrLogPrdNoConnect");
        $ecomlog->create($user);
        return -1;
    } elseif (!($err = $client->getError())) {
        dol_syslog("E_product::get_new_prods last=$last limit=$limit", LOG_DEBUG);

        // creation de ecom_prod
        if ($obj) {
            $sz = sizeof($obj);
            for ($i = 0; $i < $sz; $i++) {
                // on cree toujours le ecom_product

                $ec = new Ecom_product($db);
                $ec->siteid = $siteid;
                $ec->doli_product = 0;
                $ec->ecom_product = $obj[$i]["ecom_product"];
                $ec->ecom_attribut = $obj[$i]["ecom_attribut"];
                $ec->doli_ref = 'P' . $obj[$i]["ecom_product"];
                if (!empty($obj[$i]["ecom_attribut"])) $ec->doli_ref .= 'A' . $ec->ecom_attribut;
                $ec->ecom_ref = $obj[$i]["ecom_ref"];
                $ec->site_status = $obj[$i]["site_status"];
                $ec->site_stock = $obj[$i]["site_stock"];
                $ec->date_send = $ec->datem = dol_now();
                $ec->date_modif = $obj[$i]["date_modif"];
                $ec->long_desc = $obj[$i]["long_desc"];
                $ec->ecom_manuf = $obj[$i]["ecom_manuf"];
                $ec->ecom_category = $obj[$i]["ecom_category"];
                $ec->ecom_price = $obj[$i]["ecom_price"];
                $ec->declinaison = $obj[$i]["declinaison"];
                if ($ec->create($user) < 0) {
                    $msg = " ko " . $ec->error;
                    $ecomlog->site_id = $siteid;
                    $ecomlog->log_date = $now;
                    $ecomlog->log_fct = 'PRD';
                    $ecomlog->log_type = "ERR";
                    $ecomlog->log_fonction = $langs->trans("ErrImpPrd");
                    $ecomlog->log_message = $langs->trans("ErrLogPrdEcomCreate") . " " . $ec->ecom_product . " " . $ec->error;
                    $ecomlog->create($user);
                } else $msg = " réussi " . $ec->doli_ref;
                $msg .= "\n";
                unset($ec);
                dol_syslog("products.inc::get_new_prods " . $msg, LOG_DEBUG);
            }
        }
        return $last;
    } else {
        dol_syslog("products.inc::get_new_prods " . $err, LOG_DEBUG);
        return -1;
    }
}


// trigger for updating product qty on ecommerce site
// Buggé : Fait d'autres choses aussi
function update_ecom_prod($db, $prodid, $entrepot_id, $qty, $user)
{
    global $conf;

    if (!$conf->global->ECOM_ONLINE_PRODUCT_QTY_UPDATE) {
        dol_syslog("products.inc.php:: update_ecom_prod est désactivé ", LOG_DEBUG);
        return 0;
    }

    dol_syslog("products.inc.php:: update_ecom_prod product = $prodid  entrepot = $entrepot_id qty = $qty ECOM_ONLINE_PRODUCT_QTY_UPDATE =" . $conf->global->ECOM_ONLINE_PRODUCT_QTY_UPDATE, LOG_DEBUG);
    $product = new Product($db);
    $result = $product->fetch($prodid);
    if ($result < 0) {
        dol_syslog("products.inc.php:: update_ecom_prod error reading product " . $product->error, LOG_ERR);
        return 0;
    }
    if ($product->load_stock() < 0) {
        dol_syslog("products.inc.php:: update_ecom_prod error loading product product_stock" . $product->error, LOG_ERR);
        return 0;
    }

    //get products stock available in warehouse
    $stock = $product->stock_warehouse[$entrepot_id]->real;
    $stock_commande_client = 0;

    /* TODO
     * cette fonction pose des problèmes de gestion de stock
     * mantis n° 128
         $result=$product->load_stats_commande(0,'1,2');
        if ($result > 0) $stock_commande_client=$product->stats_commande['qty'];
    */

    dol_syslog("products.inc.php:: update_ecom_prod stock_reel = $stock  stock_commande_client = $stock_commande_client ", LOG_DEBUG);

    // en vente sur sites internet liés au stock indiqué !!
    $sql = "SELECT ep.rowid, ep.siteid, ep.ecom_product FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
    $sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_site es ON es.rowid = ep.siteid AND es.site_entrepot='" . $entrepot_id . "' ";
    $sql .= " WHERE doli_product ='" . $prodid . "' ";
    dol_syslog("products.inc.php:: update_ecom_prod sql= $sql", LOG_DEBUG);

    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {
            $newstock = ($stock - $stock_commande_client); // on reporte tout le stock sur chaque site / $num;
            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {
                    $ecom_prod = new E_product($db, $obj->siteid, $user);
                    $ecom_prod->ecom_product = $obj->ecom_product;
                    $ecom_prod->site_stock = $newstock;
                    $ecom_prod->ecom_ref = $product->ref;
                    $ecom_prod->name = $product->libelle;
                    $ecom_prod->desc_short = $product->description;

                    $product->fetch_barcode();
                    if ($product->barcode_type_code == "EAN13") {
                        $ecom_prod->ean13 = $product->barcode;
                    }

                    if ($ecom_prod->modify($prodid) < 0) {
                        //traitement erreur à prévoir
                        dol_syslog("products.inc.php:: update_ecom_prod erreur mise à jour site " . $obj->siteid, LOG_ERR);
                    }
                } else {
                    // on ne fait rien
                }
                $i++;
            }
        }
    } else {
        dol_syslog("products.inc.php:: update_ecom_prod erreur sql= $sql", LOG_ERR);
    }

    return 0;
}

/**
 *
 * Synchronize ref, desc, label on ecommerce sites
 * @param database object $db
 * @param integer $prodid product dolibarr
 * @param user object $user
 */
function syncro_ecom_prod($db, $prodid, $user)
{
    global $conf;

    if (empty($conf->global->ECOM_ONLINE_SYNCRO_PRODUCTS)) {
        dol_syslog("products.inc.php:: syncro_ecom_prod est désactivé ", LOG_DEBUG);
        return 0;
    }

    dol_syslog("products.inc.php:: syncro_ecom_prod product = $prodid ECOMMERCE_SYNCRO_PRODUCTS =" . $conf->global->ECOM_ONLINE_SYNCRO_PRODUCTS, LOG_DEBUG);
    $product = new Product($db);
    $result = $product->fetch($prodid);
    if ($result < 0) {
        dol_syslog("products.inc.php:: update_ecom_prod error reading product " . $product->error, LOG_ERR);
        return 0;
    }

    // en vente sur sites internet ?
    $sql = "SELECT siteid FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
    $sql .= "WHERE doli_product ='" . $prodid . "'";
    dol_syslog("products.inc.php:: syncro_ecom_prod sql= $sql", LOG_DEBUG);

    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {

            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {
                    $ecom_prod = new E_product($db, $obj->siteid, $user);

                    // TODO voir pour le prix $ecom_prod->price =$product->price;
                    $ecom_prod->name = $product->libelle;
                    //TODO à voir $ecom_prod->desc_short = $product->description;
                    $ecom_prod->desc = $product->description;
                    $ecom_prod->ecom_ref = $product->ref;
                    $ecom_prod->weight = $product->weight;

                    $ecom_prod->price = $product->price;
                    $ecom_prod->name = $product->libelle;
                    $ecom_prod->desc_short = $product->description;
                    $ecom_prod->ecom_ref = $product->ref;

                    $product->fetch_barcode();
                    if ($product->barcode_type_code == "EAN13") {
                        $ecom_prod->ean13 = $product->barcode;
                    }

                    $myobject = new Ecom_Site($db);
                    $myobject->fetch($obj->siteid);

                    $ecom_prod->site_stock = $product->stock_warehouse[$myobject->site_entrepot]->real;

                    $taxid = get_vat_rate_id($product->tva_tx);

                    $ecom_prod->taxrate = $taxid;

                    if ($ecom_prod->modify($prodid) < 0) {
                        //traitement erreur à prévoir
                        dol_syslog("products.inc.php:: syncro_ecom_prod erreur mise à jour site " . $obj->siteid, LOG_ERR);
                    }
                } else {
                    // on ne fait rien
                }
                $i++;
            }
        }
    } else {
        dol_syslog("products.inc.php:: update_ecom_prod erreur sql= $sql", LOG_ERR);
    }

    return 0;
}

/**
 *
 * Add a product a category on e-commerce site
 *
 * @param databse object $db
 * @param int $catid category id
 * @param int $prodid product id
 * @param user object $user
 */
function add_categorie_ecom_prod($db, $catid, $prodid, $user)
{
    global $conf;
    dol_include_once("/ecommerce/class/E_categorie.class.php");

    if (!$conf->global->ECOM_ONLINE_SYNCRO_PRODUCTS) {
        dol_syslog("products.inc.php:: syncro_ecom_prod est désactivé ", LOG_DEBUG);
        return 0;
    }

    $product = new Product($db);
    $result = $product->fetch($prodid);
    if ($result < 0) {
        dol_syslog("products.inc.php:: update_ecom_prod error reading product " . $product->error, LOG_ERR);
        return 0;
    }

    // en vente sur sites internet ?
    $sql = "SELECT rowid, siteid FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
    $sql .= "WHERE doli_product ='" . $prodid . "'";
    dol_syslog("products.inc.php:: syncro_ecom_prod sql= $sql", LOG_DEBUG);

    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {

            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {

                    $e_prod = new E_product($db, $obj->siteid, $user);
                    //$e_prod->fetch($obj->rowid);
                    $ecat = new E_categorie($db, $obj->siteid, $user);
                    $ecatid = $ecat->get_e_cat($catid);
                    $e_prod->catid = $ecatid;
                    $e_prod->ecom_ref = $product->ref;
                    $e_prod->modify($prodid);

                } else {
                    // on ne fait rien
                }
                $i++;
            }
        }
    } else {
        dol_syslog("products.inc.php:: update_ecom_prod erreur sql= $sql", LOG_ERR);
    }

    return 0;
}

function delete_categorie_ecom_prod($db, $catid, $prodid, $user)
{
    global $conf;
    dol_include_once("/ecommerce/class/E_categorie.class.php");

    if (!$conf->global->ECOM_ONLINE_SYNCRO_PRODUCTS) {
        dol_syslog("products.inc.php:: syncro_ecom_prod est désactivé ", LOG_DEBUG);
        return 0;
    }

    $product = new Product($db);
    $result = $product->fetch($prodid);
    if ($result < 0) {
        dol_syslog("products.inc.php:: update_ecom_prod error reading product " . $product->error, LOG_ERR);
        return 0;
    }

    // en vente sur sites internet ?
    $sql = "SELECT rowid, ecom_product, siteid FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
    $sql .= "WHERE doli_product ='" . $prodid . "'";
    dol_syslog("products.inc.php:: syncro_ecom_prod sql= $sql", LOG_DEBUG);

    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {

            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {

                    $e_prod = new E_product($db, $obj->siteid, $user);
                    //$e_prod->fetch($obj->rowid);
                    $ecat = new E_categorie($db, $obj->siteid, $user);
                    $ecatid = $ecat->get_e_cat($catid);
                    $e_prod->catid = '';
                    $e_prod->ecom_ref = $product->ref;
                    $e_prod->modify($prodid);

//TODO					$e_prod->delete_category($obj->ecom_product, $ecatid);

                } else {
                    // on ne fait rien
                }
                $i++;
            }
        }
    } else {
        dol_syslog("products.inc.php:: update_ecom_prod erreur sql= $sql", LOG_ERR);
    }

    return 0;
}

/**
 *
 * Add a product a category on e-commerce site
 *
 * @param int $prod product
 * @param int $catid presta category id
 */
function set_product_category($prod, $catid, $siteid = 1)
{
    global $conf, $db, $user;
    // selon le parametre ECOM_IMP_CATPROD on ajoute le produit dans sa catégorie si elle existe
    dol_syslog("import_product gestion catégorie produit " . $prod->id . " " . $catid . "  catégorie " . $conf->global->ECOM_IMP_CATPROD, LOG_DEBUG);
    if ($conf->global->ECOM_IMP_CATPROD > 0) {
        dol_include_once("/ecommerce/class/ecom_categories.class.php");
        if ($catid) {
            $ecat = new E_categorie($db, $siteid, $user);
            $dolicat = $ecat->get_dolicat($catid);
            $cat = new Categorie($db);
            if ($dolicat > 0) {
                $result = $cat->fetch($dolicat);
            } else {
                // si on ne trouve pas la catégorie on prend celle par défaut
                $result = $cat->fetch($conf->global->ECOM_IMP_CATPROD);
            }
            // affectation
            if ($dolicat > 0) {

                $sql = "DELETE FROM " . MAIN_DB_PREFIX . "categorie_product";
                $sql .= " WHERE fk_product = " . ((int)$prod->id);

                if ($result=$db->query($sql)< 0) return -1;
                $result = $cat->add_type($prod, 'product');
                if ($result >= 0) {
                    dol_syslog("::import_product ajout du produit " . $prod->id . " à la catégorie " . $catid, LOG_DEBUG);
                } else dol_syslog("E_product::import_product erreur gestion de la catégorie du produit " . $prod->id . " catégorie " . $dolicat . " " . $cat->error, LOG_DEBUG);
            } else dol_syslog("::import_product catégorie inexistante " . $prod->id . " catégorie " . $dolicat . " " . $cat->error, LOG_WARNING);
        }
    } else dol_syslog("::import_product pas de classement en catégories ", LOG_DEBUG);
    return 1;
}

//trigger for DELETE_PRODUCT in dolibarr
function product_isdeleted($idprod)
{
    global $db, $user;

    $sql = "SELECT rowid, siteid, ecom_product, ecom_attribut ";
    $sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
    $sql .= "WHERE doli_product ='" . $idprod . "'";
    dol_syslog("products.inc.php:: product_isdeleted sql= $sql", LOG_DEBUG);

    $resql = $db->query($sql);
    if ($resql) {
        $num = $db->num_rows($resql);
        $i = 0;
        if ($num) {
            $ecom_prod = new ecom_product($db);
            $error = 0;
            $db->begin();
            while ($i < $num) {
                $obj = $db->fetch_object($resql);
                if ($obj) {
                    if ($ecom_prod->fetch($obj->rowid) > 0) {
// TODO vérifier l'existence sur sites ecommerce
                        if ($obj->ecom_product > 0) {
                            // produit existe sur ecommerce mis à jour pour réimporter
                            $ecom_prod->doli_product = -1;
                            //	$ecom_prod->doli_ref = '';
                            $ecom_prod->datem = dol_now();
                            if ($ecom_prod->update() < 0) {
                                dol_syslog("products.inc.php:: product_isdeleted erreur mise à jour " . $obj->rowid, LOG_ERR);
                                $error++;
                            }
                        }
                        else {
                            // produit n'existe pas sur ecommerce suppression ligne
                            if ($ecom_prod->delete($user) < 0) {
                                dol_syslog("products.inc.php:: product_isdeleted erreur suppression " . $obj->rowid, LOG_ERR);
                                $error++;
                            }
                        }
                    }
                    else {
                        dol_syslog("products.inc.php:: product_isdeleted erreur fetch ecom_product " . $obj->rowid, LOG_ERR);
                        $error++;
                    }
                }
                $i++;
            } // fin du while
            if ($error) $db->rollback();
            else $db->commit();
        }
    }
    else {
        dol_syslog("products.inc.php:: product_isdeleted SQL Error sql= $sql  ", LOG_ERR);
        return -1;
    }

    return 0;
}

/** Enregistre le prix et stock pour un produit
 * @param $idprod
 * @param $stock
 * @param $entrepot
 * @param int $setprice set price, no by default
 * @param int $price
 * @param int $tva_tx
 * @param int $setstock set stock, true by default
 * @return int
 */
function set_product_price_and_stock($idprod, $stock, $entrepot, $setprice = 0, $price = 0, $tva_tx = 0, $label = '', $setstock = 1)
{
    global $db, $user;
    $error = 0;
    if ($setprice) {
        $price_ttc = $price * (1 + $tva_tx / 100);
        $sql = "INSERT INTO " . MAIN_DB_PREFIX . "product_price(price_level, fk_product, date_price, price, price_ttc, price_base_type, tva_tx, price_min,price_min_ttc,fk_user_author) ";
        $sql .= " VALUES(1," . $idprod . ",'" . $db->idate(dol_now()) . "','" . $price . "','$price_ttc'," . "'HT'" . ",'" . $tva_tx . "',0,0,$user->id)";
        $resql = $db->query($sql);
        if (!$resql) {
            setEventMessage($db->lasterror(), 'errors');
            $error++;
        }
    }

    if ($setstock) {
        $sql = "INSERT INTO " . MAIN_DB_PREFIX . "product_stock (fk_product,fk_entrepot,reel) VALUES";
        $sql .= "($idprod,$entrepot," . (empty($stock) ? 0 : $stock) . ")";
        $resql = $db->query($sql);
        $sql = "UPDATE " . MAIN_DB_PREFIX . "product_stock SET reel =" . (empty($stock) ? 0 : $stock);
        $sql .= " WHERE fk_entrepot = " . $entrepot . " AND fk_product = " . $idprod;
        $resql = $db->query($sql);
        if (!$resql) {
            setEventMessage($db->lasterror(), 'errors');
            $error++;
        }
        if (!$error) {
            $label = str_replace("'", "''", $label);
            $sql = "UPDATE " . MAIN_DB_PREFIX . "product SET";
            if (!empty($label)) $sql .= " label='$label',";
            if ($setprice) {
                $sql .= " price_base_type='HT', price='$price', price_ttc='$price_ttc',";
                $sql .= " price_min=0, price_min_ttc=0, tva_tx='" . $tva_tx . "',";
            }
            $sql .= " stock=" . (empty($stock) ? 0 : $stock);
            $sql .= " WHERE rowid = " . $idprod;
            $resql = $db->query($sql);
            if (!$resql) {
                setEventMessage($db->lasterror(), 'errors');
            }
        }
    }
    if (!$error) return 1;
    else return 0;
}

function syncin_product($siteid,$prodid,$attribut='')
{
    global $db,$conf, $langs, $user;
    $error = 0;
    $site = new Ecom_site($db);
    if ($site->fetch($siteid, $user) < 0) {
        setEventMessage($site->error, 'errors');
        $error++;
    }
    if (!$error) {
        $e_prod = new E_product($db, $siteid, $user);
        $ec= new E_product($db, $siteid, $user);
        $e_prodid=$e_prod->findInSite($prodid);
        $e_prod->fetch($e_prodid);
        //Charger information détaillée depuis le site
        dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

        // Set the parameters to send to the WebService
        $p = new Product($db);
        // Set the WebService URL
        $client = new nusoap_client($site->site_ws_url . "/ws_articles.php" . (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
        // Call the WebService and store its result in $obj
        $parameters = array("prodid" =>$prodid );
        $obj = $client->call("get_article_with_declinations", $parameters);
        if ($client->fault) {
            setEventMessage($client->error, 'errors');
            $error++;
        }
        else {
            if (!empty($obj)) {
                $found = array();//Tableau des déclinaisons trouvées dans Prestashop
                if (count($obj) == 1){
                    if(empty($obj[0]['id_product_attribute'])) {
                        //Traitement sync produit sans déclinaison

                        $sql = "SELECT rowid,ecom_attribut FROM " . MAIN_DB_PREFIX . "ecom_product WHERE ecom_product=" . $obj[0]['id_product'];
                        $sql .= " AND ecom_attribut is not NULL AND ecom_attribut<>''";
                        $resql = $db->query($sql);
                        if ($resql) {
                            if (($num = $db->num_rows($resql)) > 0) {
                                //Si des déclinaisons préalables existent, il faut convertire la première en produit sans déclinaison et unsync les autres
                                for ($i = 0; $i < $num; $i++) {
                                    $obj = $db->fetch_object($resql);
                                    $e_prod->fetch($obj->rowid);
                                    if ($i == 0) {
                                        $p->fetch($e_prod->doli_product);
                                        $p->ref='P'.$e_prod->ecom_product;
                                        $p->update($e_prod->doli_product,$user);
                                        $e_prod->ecom_attribut = '';
                                    }
                                    else $e_prod->ecom_product = 0;
                                    $e_prod->update($user);
                                }
                            }
                            else {
                                //Sinon
                                //Mise à jour du produit dans Dolibarr
                                $p->fetch($e_prod->doli_product);
                                $p->label = $obj[0]['name'];
                                $p->status = $obj[0]['active'];
                                $p->description = $obj[0]['description_short'];
                                $p->array_options['options_prodref'] = $obj[0]['reference'];
                                $p->array_options['options_declinaison'] = $obj[0]['declinaison'];
                                $p->update($p->id, $user);
                                set_product_category($p, $obj[0]['id_category_default'], $site->id);
                                set_product_price_and_stock($p->id, $obj[0]['quantity'], $site->site_entrepot, 1, $obj[0]['price'], $p->tva_tx, $obj[0]['name']);
                                //Mise à jour du produit dans Ecom_product
                                $e_prod->ecom_ref = $obj[0]['reference'];
                                $e_prod->long_desc = $obj[0]['name'];
                                $e_prod->declinaison = $obj[0]['declinaison'];
                                $e_prod->site_status = $obj[0]['state'];
                                $e_prod->ecom_category = $obj[0]['id_category_default'];
                                $e_prod->ecom_price = $obj[0]['price'];
                                $e_prod->site_stock = $obj[0]['quantity'];
                                $e_prod->date_modif = $obj[0]['date_upd'];
                                $e_prod->site_status = $obj[0]['active'];
                                $e_prod->update($user);
                            }
                        }
                    }
                    else{
                        //Il s'agit d'une création de la première déclinaison d'un produit ou de la suppression de toutes les déclinaisons sauf une.
                        //On remplace le produit par sa première déclinaison et on supprime dans ecom_product
                        $rowid = $e_prod->findInSite($obj[0]['id_product']);
                        $e_prod->fetch($rowid);
                        $e_prod->ecom_product = $obj[0]["id_product"];
                        $e_prod->ecom_attribut = $obj[0]['id_product_attribute'];
                        $e_prod->ecom_ref = $obj[0]['reference'];
                        $e_prod->long_desc = $obj[0]['name'];
                        $e_prod->declinaison = $obj[0]['declinaison'];
                        $e_prod->site_status = $obj[0]['active'];
                        $e_prod->ecom_category = $obj[0]['id_category_default'];
                        $e_prod->ecom_price = $obj[0]['price'];
                        $e_prod->site_stock = $obj[0]['quantity'];
                        $e_prod->date_modif = $obj[0]['date_upd'];
                        $e_prod->update($user);
                        $p->fetch($e_prod->doli_product);
                        $p->label = $obj[0]['name'];
                        $p->status = $obj[0]['active'];
                        $p->description = $obj[0]['description_short'];
                        $p->array_options['options_prodref'] = $obj[0]['reference'];
                        $p->array_options['options_declinaison'] = $obj[0]['declinaison'];
                        $p->ref = 'P' . $obj[0]['id_product'] . 'A' . $obj[0]['id_product_attribute'];
                        $p->update($e_prod->doli_product, $user);
                        //Unsync du produit dans Dolibarr pour toutes les déclinaisons supprimées dans prestashop si la fonction est appelée sans attribut
                        $sql = "SELECT rowid,ecom_attribut FROM " . MAIN_DB_PREFIX . "ecom_product WHERE ecom_product=" . $e_prod->ecom_product;
                        $sql .= " AND ecom_attribut is not NULL AND ecom_attribut<>'' AND ecom_attribut<>" . $e_prod->ecom_attribut;
                        $resql = $db->query($sql);
                        if ($resql) {
                            if (($num = $db->num_rows($resql)) > 0) {
                                for ($i = 0; $i < $num; $i++) {
                                    $obj = $db->fetch_object($resql);
                                    $e_prod->fetch($obj->rowid);
                                    $e_prod->ecom_product = 0;
                                    $e_prod->update();
                                }
                            }
                        }
                    }
                }
                else {
                    //Traitement déclinaisons de produits
                    foreach ($obj as $key => $value) {
                        $rowid = $e_prod->findInSite($value['id_product'], $value['id_product_attribute']);
                        if (empty($rowid)) {
                            //Nouvelle inclinaison créée dans prestashop
                            //Importation dans Dolibarr
                            $e_prod->siteid = $siteid;
                            $e_prod->doli_product = 0;
                            $e_prod->ecom_product = $value["id_product"];
                            $e_prod->ecom_attribut = $value["id_product_attribute"];
                            $e_prod->doli_ref = 'P' . $e_prod->ecom_product . 'A' . $e_prod->ecom_attribut;
                            $e_prod->ecom_ref = $value["reference"];
                            $e_prod->site_status = $value["active"];
                            $e_prod->site_stock = $value["quantity"];
                            $e_prod->date_send = $e_prod->datem = dol_now();
                            $e_prod->date_modif = $value["date_upd"];
                            $e_prod->long_desc = $value["description_short"];
                            $e_prod->ecom_category = $value["id_category_default"];
                            $e_prod->ecom_price = $value["price"];
                            $e_prod->declinaison = $value["declinaison"];
                            $result=$e_prod->create($user) ;
                            if ($result< 0) {
                                $msg = " ko " . $e_prod->error;
                                $ecomlog = new Ecom_log($db);
                                $ecomlog->log_date = dol_now();
                                $ecomlog->site_id = $siteid;
                                $ecomlog->log_fct = 'PRD';
                                $ecomlog->log_type = "ERR";
                                $ecomlog->log_fonction = $langs->trans("ErrImpPrd");
                                $ecomlog->log_message = $langs->trans("ErrLogPrdEcomCreate") . " " . $e_prod->ecom_product . " " . $e_prod->error;
                                $ecomlog->create($user);
                            }
                            else {
                                if ($e_prod->import_product($e_prod->ecom_product, $e_prod->ecom_attribut) > 0)
                                    setEventMessage($langs->trans("msgImportProduct", $e_prod->ecom_product, $e_prod->ecom_attribut, 'warnings'));// "traitement de l'import de ".$_POST['ecomid']." ". $_POST['ecomref'];
                                else {
                                    setEventMessage($e_prod->error, 'errors');
                                }
                            }
                        }
                        else{
                            //Traitement sync déclinaison
                            $e_prod->fetch($rowid);
                            $p->fetch($e_prod->doli_product);
                            //Mise à jour du produit dans Dolibarr
                            $p->label = $value['name'];
                            $p->description = $value['description_short'];
                            $p->array_options['options_prodref'] = $value['reference'];
                            $p->array_options['options_declinaison'] = $value['declinaison'];
                            $p->update($p->id, $user);
                            set_product_category($p, $value['id_category_default'], $site->id);
                            set_product_price_and_stock($p->id, $value['quantity'], $site->site_entrepot, 1, $value['price'] + $value['pprice'], $p->tva_tx, $value['name']);
                            //Mise à jour du produit dans Ecom_product
                            $e_prod->ecom_ref = $value['reference'];
                            $e_prod->long_desc = $value['name'];
                            $e_prod->declinaison = $value['declinaison'];
                            $e_prod->site_status = $value['state'];
                            $e_prod->ecom_category = $value['id_category_default'];
                            $e_prod->ecom_price = $value['price'] + $value['pprice'];
                            $e_prod->site_stock = $value['quantity'];
                            $e_prod->date_modif = $value['date_upd'];
                            $e_prod->update($user);
                            if ($e_prod->import_product($e_prod->ecom_product, $e_prod->ecom_attribut) > 0)
                                setEventMessage($langs->trans("msgImportProduct", $e_prod->ecom_product, $e_prod->ecom_attribut, 'warnings'));// "traitement de l'import de ".$_POST['ecomid']." ". $_POST['ecomref'];
                            else {
                                setEventMessage($e_prod->error, 'errors');
                            }
                        }
                        $found[] = $e_prod->ecom_attribut;//ajout de la déclinaison aux déclinaisons trouvées
                    }
                    if (!empty($attribut)) {
                        //Unsync du produit dans Dolibarr si la fonction est appelée avec un attribut et que sa déclinaison est supprimée dans prestashop
                        if (!in_array($attribut, $found)) {
                            $rowid = $e_prod->findInSite(GETPOST('ecomid', 'int'), $attribut);
                            $e_prod->fetch($rowid);
                            $e_prod->ecom_product = 0;
                            $e_prod->update();
                        }
                    }
                    else {
                        //si la fonction est appelée sans attribut, Unsync du produit dans Dolibarr pour toutes les déclinaisons supprimées dans prestashop
                        $sql = "SELECT rowid,ecom_attribut FROM " . MAIN_DB_PREFIX . "ecom_product WHERE ecom_product=$prodid";
                        $resql = $db->query($sql);
                        if ($resql) {
                            if (($num=$db->num_rows($resql)) > 0) {
                                for($i=0;$i<$num;$i++) {
                                    $obj = $db->fetch_object($resql);
                                    if (!in_array($obj->ecom_attribut, $found)) {
                                        $e_prod->fetch($obj->rowid);
                                        $e_prod->ecom_product = 0;
                                        $e_prod->update();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else {
                //Produit (sans déclinaisons ou à plusieurs déclinaisons inexistantes ou supprimées) supprimé dans prestashop
                //Unsync du produit dans Dolibarr
                $e_prod->ecom_product = 0;
                $e_prod->update();
            }
        }
    }

}
