<?php
/* Copyright (C) 2007 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2008 Jean Heimburger	   <jean@tiaris.fr>
 * Copyright (C) 2011 Juanjo Menent		   <jmenent@2byte.es>
 * Copyright (C) 2008 Jean Heimburger	   <jean@tiaris.fr>
 * Copyright (C) 2011-2013 Philippe Grand  <philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *       \file       scripts/ecommerce/orders.inc.php
 *         \ingroup    Ecommerce
 *       \brief      Order Import function for use in import script
 *         \author     Jean Heimburger
 *         \remarks     http://www.tiaris.fr
 */

require_once(DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php');
require_once(DOL_DOCUMENT_ROOT . '/commande/class/commande.class.php');
require_once(DOL_DOCUMENT_ROOT . '/compta/paiement/class/paiement.class.php');
include_once(DOL_DOCUMENT_ROOT . '/compta/bank/class/account.class.php');
dol_include_once("/ecommerce/class/ecom_log.class.php");
// webservcies
dol_include_once("/ecommerce/class/webservice_ecom.class.php");

/*** préimporte les commandes en créant les enregsistrements dans ecom_orders
 * @param $siteid
 * @param $db
 * @param $user
 * @param int $debut
 * @return int
 * @throws Exception
 */
function get_orders($siteid, $db, $user, $debut = 0)
{
	global $conf, $langs;
	$langs->load("ecommerce@ecommerce");

	$ecomlog = new Ecom_log($db);
	$now = dol_now();

	// lecture du site
	if ($siteid) {
		// get site_parameters
		$site_params = new Ecom_site($db);
        $result=$site_params->fetch($siteid, $user);
		if ($result< 0) {
			dol_syslog("ws_import::get_orders erreur lecture site " . $site_params->error, LOG_ERR);
			return -1;
		}
		else {
			dol_syslog("ws_import::get_orders maxorder = " . $site_params->site_maxorder, LOG_DEBUG);
			$ecomlog->site_id = $siteid;
			$ecomlog->log_date = $now;
			$ecomlog->log_type = "EXP";
			$ecomlog->log_fonction = $langs->trans("NewOrders");
			$ecomlog->log_message = $langs->trans("ordDebutImport");// "début import";
			$ecomlog->create($user);
			// appel du webservice

			//WebService Client.
			dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

			$e_order = new E_order($db, $siteid, $user);

			if (!$debut) {
				// begin from last imported
				$e_order->get_lastorder($siteid);
				if ($e_order->ecom_order > 0) $ecomid = $e_order->ecom_order;
				else $ecomid = 0;
			}
			else $ecomid = $debut;

			// Set the parameters to send to the WebService
			$limit = 1;
			if ($site_params->site_maxorder) $limit = $site_params->site_maxorder;

			$parameters = array("orderid" => $ecomid, "limit" => $limit);

			dol_syslog("ws_import::get_orders ecomid= $ecomid maxorder= $limit pour " . $site_params->site_ws_url, LOG_DEBUG);

			// Set the WebService URL"orderid"=>$ecomid
			$client = new nusoap_client($site_params->site_ws_url . "ws_orders.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

			$result = $client->call("get_NewOrder", $parameters);

			if ($client->fault) {
				dol_syslog("ws_import::get_orders erreur de connexion fault " . $site_params->site_ws_url . "ws_orders.php " . $client->getError(), LOG_DEBUG);
				return -1;
			}
			elseif (!($err = $client->getError())) {
				$num = 0;
				if ($result) $num = count($result);
				if ($num > 0) {
					$i = 0;
					while ($i < $num) {
						if (isset($result[$i]["mes"])) {
							dol_syslog("ws_import::get_orders pas de commande " . $result[$i]["mes"] . " " . $result[$i]["sql"], LOG_DEBUG);
						}
						else {
							$order = new Ecom_order($db);
							if (!$e_order->findInSite($result[$i]["orders_id"], $siteid)) {
								$order->siteid = $siteid;
								$order->ecom_order = $result[$i]["orders_id"];
								$order->site_order_status = $result[$i]["orders_status"];

								$order->site_client_name = convertCharset($result[$i]["customers_name"]); //mb_convert_encoding($result[$i]["customers_name"], 'UTF-8','ISO-8859-1');
								$order->datem = $now;
								$order->site_order_date = strtotime($result[$i]["date_purchased"]);
								$order->site_order_total_HT = $result[$i]["total"];
								$order->site_total_port = $result[$i]["port"];
								$order->doli_order = 0;
								$order->site_total_vat = 0.0; // à revoir
								$order->exp_meth_id = (isset($result[$i]["exped_id"]) ? $result[$i]["exped_id"] : null);
								$order->exp_meth = (isset($result[$i]["exped_name"]) ? $result[$i]["exped_name"] : null);

								$oid = $order->create($user);
								if ($oid < 0) {
									//dolibarr_print_error($db,$order->error);
									dol_syslog("ws_import::get_orders erreur création commande " . $order->error, LOG_ERR);
									return -1;
								}
								else {
									dol_syslog("ws_import::get_orders cde  $oid cree " . $order->site_client_name . " " . $order->ecom_order, LOG_DEBUG);
								}
								unset($order);
							}
							else    dol_syslog("ws_import::get_orders cde  " . $result[$i]["orders_id"] . " existe déjà", LOG_DEBUG);
						}

						$i++;
					} /* while */
				} // if num >0
				else {
					dol_syslog("ws_import::get_orders aucune commande à importer $num\n", LOG_INFO);
					//		return 1;
				}
			} // getError
			else {
				dol_syslog("ws_import::get_orders erreur SOAP " . $err, LOG_ERR);
				return -1;
			}
		} //fetch

		// mise à jour du log
//		$i=0;
		$ecomlog->site_id = $siteid;
		$ecomlog->log_date = $now;
		$ecomlog->log_type = "EXP";
		$ecomlog->log_fonction = $langs->trans('NewOrders');
		$ecomlog->log_message = $langs->trans("ordFinImport", $i); //"fin d'import ".$i." nouvelles commandes à traiter" ;
		$ecomlog->create($user);
	}//siteid

	return 1;
}


/*** Importe les commandes dans Dolibarr à partir des enregistrements dans ecom_orders
 * @param $siteid
 * @param $db
 * @param $user
 * @return int|mixed
 * @throws Exception
 */
function import_orders($siteid, $db, $user)
{

	global $langs, $conf;
	$langs->load("ecommerce@ecommerce");
	$now = dol_now();

	$ecomlog = new Ecom_log($db);

	$sql = "SELECT eo.rowid, eo.doli_order, eo.ecom_order, eo.site_order_date, eo.site_order_status ";
	$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order eo ";
	$sql .= " WHERE eo.doli_order ='0' AND eo.siteid = '" . $siteid . "'";

	dol_syslog("ws_import::import_orders sql=" . $sql, LOG_DEBUG);
	$resql = $db->query($sql);
	if ($resql) {
		$num = $db->num_rows($resql);
		$i = 0;
		if ($num) {

			while ($i < $num) {
				$obj = $db->fetch_object($resql);
				if ($obj) {
					$e_order = new E_order($db, $siteid, $user);
                    $result=$e_order->import_order($obj->ecom_order);
                    if ($result< 0) {
						dol_syslog("ws_import::import_orders Commande " . $obj->ecom_order . " ECHEC de l'import\n", LOG_ERR);
						//trace dans log
						$ecomlog->site_id = $siteid;
						$ecomlog->log_date = $now;
						$ecomlog->log_fct = 'COM';
						$ecomlog->log_type = "ERR";
						$ecomlog->log_fonction = "Import commande " . $obj->ecom_order;
						$ecomlog->log_message = $e_order->error;
						$ecomlog->create($user);
						// si on échoue dans l'import on passe le doli_order à -1
						if ($e_order->findInSite($obj->ecom_order, $siteid) > 0) {
							$e_order->doli_order = -1;
							$e_order->datem = $now;

							dol_syslog("orders.inc::import commandes update ecom_order " . $e_order->id, LOG_ERR);
							if ($e_order->update($user) < 0) {
								dol_syslog("orders.inc::import commandes update ecom_order échoué " . $e_order->error, LOG_ERR);
							}
						}
					}
					else {
						// traitements d'après création de commande
						dol_syslog("ws_import::import_orders Commande " . $obj->ecom_order . " importée numéro " . $obj->doli_order . "\n", LOG_DEBUG);

						$commande = new Commande($db);
						if ($commande->fetch($e_order->doli_order) < 0) {
							dol_syslog("ws_import::import_orders erreur lecture commande" . $commande->error, LOG_ERR);
							return -1;
						}
						dol_syslog("ws_import::import_orders test date commande à date de début de traitement " . $commande->date_commande . " site " . $e_order->site->site_startdate, LOG_DEBUG);
						if ($commande->date_commande >= $e_order->site->site_startdate) // TODO test
						{

							if (!empty($conf->global->ECOM_CREATE_FACTURE) && $conf->global->ECOM_CREATE_FACTURE) {
								$commande = new Commande($db);
								if ($commande->fetch($e_order->doli_order) < 0) {
									dol_syslog("ws_import::import_orders erreur lecture commande" . $commande->error, LOG_ERR);
									return -1;
								}
								$facture_ok = 0;
								//TODO tester si défini
								// on ne créé une facture que pour une commande validée ou clôturée
								if (($commande->statut == -1) || ($commande->statut == 0)) {
									$facture_ok++;
									dol_syslog("ws_import::import_orders facturation statut commande " . $commande->statut . " non validable ", LOG_DEBUG);
								}
								// on ne créé une facture que pour payement CB
								if (($commande->mode_reglement_id != $conf->global->ECOM_CB_PAYE)
									&& ($commande->mode_reglement_id != $conf->global->ECOM_PAYPAL)
									&& ($commande->mode_reglement_id != $conf->global->ECOM_PAYBOX)) {
									$facture_ok++;
									dol_syslog("ws_import::import_orders facturation règlement " . $commande->mode_reglement_id . " non validable ", LOG_DEBUG);
								}

								if ($facture_ok == 0) {
									$facid = create_facture($db, $user, $commande, $siteid);

									if ($facid > 0) {
										// si CB ou ECOM_PAYPAL on créé le paiement
										// si ECOM_PAYPAL, ECOM_PAYBOX on créé un enreg pour la commission
										if ($commande->mode_reglement_id == $conf->global->ECOM_PAYPAL) $payaccount = $conf->global->ECOM_PAYPAL_ACCOUNT;
										elseif ($commande->mode_reglement_id == $conf->global->ECOM_PAYBOX) $payaccount = $conf->global->ECOM_PAYBOX_ACCOUNT;
										else  $payaccount = $conf->global->ECOM_CB_ACCOUNT;

										create_paiement($db, $user, $facid, $commande->mode_reglement_id, $payaccount);
									}
								}
								else dol_syslog("ws_import::import_orders facturation commande impossible " . $e_order->doli_order . " facture_ok =" . $facture_ok . "rgt " . $commande->mode_reglement_id . " statut " . $commande->statut, LOG_DEBUG);
							}//creation facture
						}
						else {
							// traitement commande archive
							dol_syslog("ws_import::import_orders commande antérieure à date de début de traitement " . $commande->date_commande . " site " . $e_order->site->site_startdate, LOG_DEBUG);

							$e_params = new E_params($db, $siteid, $user);
							$newstatus = $e_params->ecom2dolibarr($obj->site_order_status, 'ordstat');

							switch ($newstatus) {
								case 1:
									$commande->valid($user);
									break;
								case 2:
									$commande->valid($user);// pas de mouvement de stock même si mode gestion validation de commande
									//TODO statut 2
									break;
								case 3:
									$commande->valid($user);
									$commande->cloture($user);
									$commande->classer_facturee(); // TODO complètement traitée sur site
									break;
								case -1 :
									$commande->cancel($user);
									break;
							}
							/*	if ( $newstatus > 0)
								{
									dol_syslog("ws_import::import_orders commande antérieure nouveau statut ".$newstatus, LOG_DEBUG);
								//	$e_order->change_local_status($e_order->ecom_order, $newstatus);
									$sql = $sql = 'UPDATE '.MAIN_DB_PREFIX.'commande';
									$sql.= ' SET fk_statut = '.$newstatus.',';
									$sql.= ' fk_user_cloture = '.$user->id.',';
									$sql.= ' date_cloture = date_commande ';
									$sql.= ', date_valid = date_commande ';
									$sql.= ', fk_user_valid = '.$user->id;
									$sql.= ' WHERE rowid = '.$e_order->doli_order;

									$resql=$db->query($sql);
									if (! $resql)
									{
										dol_syslog("maj Commande::update() Echec update - 10 - sql=".$sql, LOG_ERR);
										return -1;
										//		dol_print_error($this->db);

									}
								}*/

						}
					} //else
					unset($e_order);
				} // if $obj
				$i++;
			} //while
		} // if $num
		else dol_syslog("ws_import::import_orders aucune commande a traiter \n", LOG_DEBUG);
		$retval = $num;
	}
	else {
		dol_syslog("ws_import::import_orders erreur sql " . $db->error, LOG_ERR);
		$retval = -1;
	}

	return $retval;
}

function create_facture($db, $user, $commande, $siteid = -1)
{
	global $conf;
	$now = dol_now();
	// création de la facture
	$facture = new Facture($db);
	$e_order = new E_order($db, $siteid, $user);

	// importation du site e-commerce
	$ecomsite = new Ecom_site($db);
	if ($ecomsite->fetch($siteid, $user) < 0) {
		dol_syslog("E_order::Constructeur " . $site->error, LOG_ERR); // traitement erreur
	}

	dol_syslog("ws_import::import_orders création facture pour " . $e_order->doli_order . " société " . $commande->socid, LOG_DEBUG);
	$db->begin();

	$facture->commandeid = $commande->id;
	$facture->origin = 'commande';
	$facture->origin_id = $commande->id;
	$facture->socid = $commande->socid;
	$facture->type = '0';
	$facture->date = $commande->date; //mktime(0, 0, 0, date("m"), date("d"), date("y"));//$commande->date_commande;
	$facture->note_public = $commande->note_public;
	$facture->note_private = "Auto creation by import ecommerce ";
	$facture->ref_client = $commande->ref;

	//Test condition pas de modèle défini pour le site soit celui par défaut
	if (!isset($ecomsite->site_invoicetemplate)) {
		$facture->modelpdf = $conf->global->FACTURE_ADDON_PDF;
	}
	else {
		$facture->modelpdf = $ecomsite->site_invoicetemplate;
	}
	$facture->projetid = $commande->fk_project; //default model
	$facture->cond_reglement_id = $commande->cond_reglement_id;
	$facture->mode_reglement_id = $commande->mode_reglement_id;
	$facture->amount = $commande->total_ht;
	$facture->remise_absolue = $commande->remise_absolue;
	$facture->remise_percent = $commande->remise_percent;

	$facture->linked_objects['commande'] = $commande->id;

	$facid = $facture->create($user);

	$mess = '';
	$error = 0;
	if ($facid > 0) {
		$commande->fetch_lines();
		$lines = $commande->lines;
		for ($i = 0; $i < count($lines); $i++) {
			$desc = ($lines[$i]->desc ? $lines[$i]->desc : $lines[$i]->libelle);

			$result = $facture->addline(
				$desc,
				$lines[$i]->subprice,
				$lines[$i]->qty,
				$lines[$i]->tva_tx,
				0, //tva espagne
				0, //tva espagne
				$lines[$i]->fk_product,
				$lines[$i]->remise_percent,
				'',
				'',
				0,
				$lines[$i]->info_bits,
				$lines[$i]->fk_remise_except
			);
			if ($result < 0) {
				$error++;
				$mess .= " erreur addline $i " . $lines[$i]->fk_product;
				break;
			}
		}
	}
	else {
		$error++;
		$mess .= 'erreur facture ' . $facture->error;
	}

	if ($facid > 0 && !$error) {
		$db->commit();
		dol_syslog("ws_import::import_orders facture créée " . $facid, LOG_DEBUG);
	}
	else {
		$db->rollback();
		dol_syslog("ws_import::import_orders erreur création facture " . $mess, LOG_ERR);
		unset($facture);
		return -1;
	}

	// validation de la facture
	$facture->fetch($facid);
	dol_syslog(basename(__FILE__) . "::" . __FUNCTION__ . ":: entrepot " . $ecomsite->site_entrepot, LOG_DEBUG);
	if ($facture->validate($user, '', $ecomsite->site_entrepot) < 0) dol_syslog("ws_import::import_orders erreur validation facture " . $facture->error, LOG_ERR);
	unset($facture);

	// classer commande facturée
	if ($commande->classifyBilled() != 1) dol_syslog("ws_import::import_orders erreur classement commande facturée", LOG_ERR);
	return $facid;
}

function create_paiement($db, $user, $factid, $modpaye, $account_id)
{
	global $conf, $langs;
	$now = dol_now();
	dol_syslog("ws_import::create paiement  " . $modpaye . "  " . $account_id, LOG_DEBUG);
	$amounts = array();

	$fact = new Facture($db);
	if ($fact->fetch($factid) < 0) {
		dol_syslog("ws_import::create paiement erreur fetch facture " . $fact->error, LOG_ERR);
		return -1;
	}
	if ($fact->statut != 1) {
		dol_syslog("ws_import::create paiement erreur statut facture " . $fact->statut . "must be 1 (validatetd) no paiement created ", LOG_WARNING);
		return -1;
	}

	$amounts["$factid"] = $fact->total_ttc;

	$db->begin();
	$error = 0;

	// Creation de la ligne paiement
	$paiement = new Paiement($db);
	$paiement->datepaye = $fact->date; // mktime(0, 0, 0, date("m"), date("d"), date("y")); //$fact->date;
	$paiement->amounts = $amounts;   // Tableau de montant
	$paiement->paiementid = $modpaye; //clé du mode paiement CB
	$paiement->num_paiement = '';
	$paiement->note = 'paiement CB ecommerce';

	$paiement_id = $paiement->create($user);

	dol_syslog("orders.inc.php::create paiement paiement_id " . $paiement_id, LOG_DEBUG);

	if ($paiement_id > 0) {
		if ($conf->banque->enabled) {
			$acc = new Account($db, $account_id);

			$result = $paiement->addPaymentToBank($user, 'payment', '(CustomerInvoicePayment)', $account_id, '', '');
			if ($result < 0) {
				$errmsg = $paiement->error;
				$error++;
			}

			// commission Paypal ou paybox
			if ($error == 0) {
				dol_syslog("orders.inc.php::calcul de la commision pour " . $modpaye, LOG_DEBUG);
				if (($modpaye == $conf->global->ECOM_PAYPAL && $conf->global->ECOM_PAYPAL_COM > 0) ||
					($modpaye == $conf->global->ECOM_PAYBOX && $conf->global->ECOM_PAYBOX_COM > 0)) {

					if ($modpaye == $conf->global->ECOM_PAYPAL) {
						$amount = calculate_commission($conf->global->ECOM_PAYPAL, $amounts["$factid"]);
						$label = "(PAYPALCommission)";
					}
					else {
						$amount = calculate_commission($conf->global->ECOM_PAYBOX, $fac->amount); // montant HT de la facture
						$label = "(PAYBOX Commission)";
					}

					dol_syslog('orders.inc.php::create_paiement PAYPAL/PAYBOX ' . $amount . " " . $modpaye . " " . $label . " " . $paiement->paiementid, LOG_DEBUG);
					$acc->rowid = $account_id;
					$bank_line_id = $acc->addline($paiement->datepaye,
						$modpaye,
						$label,
						-$amount,
						'',
						'',
						$user,
						'', //emetteur
						''  //banque
					);
					if ($bank_line_id < 0) {
						dol_syslog('orders.inc.php::create_paiement PAYPAL/PAYBOX erreur ajout commision ' . $acc->error, LOG_ERR);
						$error++;
					}
				} // PPL ou PBX
			}

		}// conf_bank
	} //payement_id
	else {
		$error++;
		dol_syslog("ws_import::create paiement erreur creation paiement " . $paiement_error, LOG_ERR);
	}

	if ($error == 0) {
		dol_syslog("ws_import::create paiement création réussie ", LOG_DEBUG);
		$db->commit();
		// ça s'est bien passé, on solde la facture
		$result = $fact->set_paid($user);
		//	création fichier pdf
		$fact->fetch_thirdparty();
		dol_syslog("ws_import::create paiement création pdf", LOG_DEBUG);
		facture_pdf_create($db, $fact, $fact->modelpdf, $langs);
		return 1;
	}
	else {
		dol_syslog("ws_import::create paiement erreur paiement ", LOG_ERR);
		$db->rollback();
		return -1;
	}
}

// calcule la commission selon le mode de paiement basé sur le montant
function calculate_commission($paytype, $amount)
{
	global $conf;
	$commission = 0.0;

	switch ($paytype) {
		case $conf->global->ECOM_PAYPAL:
			// formule a revoir
			$commission = $amount * $conf->global->ECOM_PAYPAL_COM / 100 + 0.25;
			break;
		case $conf->global->ECOM_PAYBOX:
			$commission = $amount * $conf->global->ECOM_PAYBOX_COM / 100;
			if ($commission < 0.65) $commission = 0.65;
			break;
		default:
			$commission = 0.0;
	}

	$commission = price2num($commission, 'MT');

	return $commission;
}

/**
 *
 * create a supplier invoice for commission
 * @param integer $socid
 * @param string $partype (Paypal, Paybox...)
 * @param decimal $amount
 * @param string $ref : order reference
 */
function create_commission_invoice($socid, $partype, $amount, $ref, $user)
{
	global $db, $langs;
	require_once DOL_DOCUMENT_ROOT . '/fourn/class/fournisseur.facture.php';

	// TODO contrôles
	if (empty($socid)) {
		dol_syslog(basename(__FILE__) . "::" . __FUNCTION__ . ": socid is empty ", LOG_ERR);
		return -1;
	}

	$factfour = new FactureFournisseur($db);

	$factfour->socid = $socid;
	$factfour->ref_supplier = $langs->trans("PaypalRefStd", $ref);

	$commission = calculate_commission($paytype, $amount);
	$factfour->addline($langs->trans("PaypalComDesc"), $commission, 0, '', '', 1);

	if ($factfour->create($user) < 0) {
		dol_syslog(basename(__FILE__) . "::" . __FUNCTION__ . ": error create invoice " . $factfour->error, LOG_ERR);
		return -1;
	}

	if ($factfour->validate($user) < 0) {
		dol_syslog(basename(__FILE__) . "::" . __FUNCTION__ . ": error validate invoice " . $factfour->error, LOG_ERR);
		return -1;
	}

	// create paiement


	return 1;

}


