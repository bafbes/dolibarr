<?php
/* Copyright (C) 2007 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010 Jean Heimburger	<jean@tiaris.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 * \file       htdocs/ecommerce/inc/prospects.inc.php
 * \ingroup    ecommerce
 * \brief      function for importing prospects from ecommerce site
 * \version
 * \author        Jean Heimburger
 * \remarks        http://www.tiaris.fr
 */

function get_new_prospects($siteid, $db, $user, $limit)
{

	global $conf, $langs;

	// lecture du site
	if ($siteid) {
		$ecomlog = new Ecom_log($db);
		// get site_parameters
		$site_params = new Ecom_site($db);

		if ($site_params->fetch($siteid, $user) < 0) {
			dol_syslog("ws_import::get_new_prospects erreur lecture site " . $site_params->error, LOG_DEBUG);
			return -1;
		}
	}
	else {
		dol_syslog("ws_import::get_new_prospects erreur lecture site " . $site_params->error, LOG_DEBUG);
		return -1;
	}

	$sql = "SELECT max(ecom_customer) last FROM " . MAIN_DB_PREFIX . "ecom_customer ";
	$sql .= " WHERE siteid = '" . $siteid . "' AND site_cust_status = 'P' ";

	dol_syslog("prospects.inc.php::get_new_prospects $sql", LOG_DEBUG);
	$resql = $db->query($sql);
	if ($resql) {
		$obj = $db->fetch_object($resql);
		if ($obj) {
			$last = $obj->last;
			if (!isset($last)) $last = 0;
		}
		else {
			dol_syslog("prospects.inc.php::get_new_prospects rien à faire", LOG_DEBUG);
			$last = 0;
		}
	}
	else {
		dol_syslog("prospects.inc.php::get_new_prospects erreur " . $sql, LOG_DEBUG);
		return -1;

	}

	if ($limit == 0) $limite = $site_params->site_maxclient;
	elseif ($limit > 0) $limite = $limit;
	else {
		dol_syslog("erreur limit doit être >= 0 : " . $limit, LOG_ERR);
		return -1;
	}

	dol_syslog("prospects.inc.php::get_new_prospects last= $last, limite=$limite", LOG_DEBUG);

	// appel méthode
	dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

	// Set the parameters to send to the WebService
	$parameters = array("custid" => $last, "limit" => $limite);

	// Set the WebService URL
	$client = new nusoap_client($site_params->site_ws_url . "ws_customers.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

	// Call the WebService and store its result in $obj
	$obj = $client->call("get_newProspects", $parameters);
	if ($client->fault) {
		dol_syslog("prospects.inc.php::get_new_prospects FAULT", LOG_DEBUG);
		// inscription en log
		$ecomlog->site_id = $siteid;
		$ecomlog->log_date = mktime();
		$ecomlog->log_type = "ERR";
		$ecomlog->log_fct = 'CUS';
		$ecomlog->log_fonction = $langs->trans("ErrLogCus");
		$ecomlog->log_message = $langs->trans("ErrLogPrdNoConnect");
		$ecomlog->create($user);
		return -1;
	}
	elseif (!($err = $client->getError())) {
		dol_syslog("prospects.inc.php::get_new_prospects " . $id_ecom, LOG_DEBUG);

		// création de ecom_customer
		if ($obj) {
			$sz = sizeof($obj);
			$ec = new Ecom_customer($db);
			for ($i = 0; $i < $sz; $i++) {
				$msg = "création de " . $obj[$i]["customers_id"];

				// on créé toujours le ecom_customer
				$ec->siteid = $siteid;
				$ec->ecom_customer = $obj[$i]["customers_id"];
				$ec->doli_soc = 0;
				$ec->site_cust_status = 'P';
				$ec->datem = mktime();
				if ($ec->create($user) < 0) {
					$msg .= " ko " . $ec->error;
					$ecomlog->site_id = $siteid;
					$ecomlog->log_date = mktime();
					$ecomlog->log_type = "ERR";
					$ecomlog->log_fct = 'CUS';
					$ecomlog->log_fonction = $langs->trans("ErrLogCus");
					$ecomlog->log_message = $langs->trans("ErrLogCusEcomCreate") . " " . $ec->ecom_product . " " . $ec_error;
					$ecomlog->create($user);
				}
				else $msg .= " réussi " . $doliref;
				$msg .= "\n";
				dol_syslog("prospects.inc::get_new_prods " . $msg, LOG_DEBUG);
			}
			unset($ec);
		}
		return $last;
	}
	else {
		dol_syslog("prospects.inc::get_new_prospects " . $err, LOG_DEBUG);
		return -1;
	}

}


function import_prospects($siteid, $db, $user, $limit, $last)
{
	global $langs;

	$sql = "SELECT ec.ecom_customer FROM " . MAIN_DB_PREFIX . "ecom_customer ec ";
	$sql .= " WHERE ec.siteid = '" . $siteid . "' AND ec.site_cust_status = 'P' AND ec.doli_soc = '0' ";
//	$sql .= " AND ec.ecom_customer > '".$last."' ";
	if ($limit > 0) $sql .= " LIMIT 0," . $limit;

	$ecomlog = new Ecom_log($db);

	dol_syslog("prospects.inc.php::import_prospects $sql", LOG_DEBUG);
	$resql = $db->query($sql);
	if ($resql) {
		$num = $db->num_rows($resql);
		$i = 0;
		if ($num) {
			$e_cust = new E_customer($db, $siteid, $user);
			while ($i < $num) {
				$obj = $db->fetch_object($resql);
				if ($obj) {
					if ($e_cust->import_customer($obj->ecom_customer, 'P') < 0) {
						dol_syslog("prospects.inc.php::import_prospects Erreur import " . $obj->ecom_customer, LOG_DEBUG);
						// log
						$ecomlog->site_id = $siteid;
						$ecomlog->log_date = mktime();
						$ecomlog->log_fct = 'CUS';
						$ecomlog->log_type = "ERR";
						$ecomlog->log_fonction = $langs->trans("ErrLogCus") . " " . $obj->ecom_customer;
						$ecomlog->log_message = $langs->trans("ErrError") . " " . $e_cust->error;
						$ecomlog->create($user);
						// si l'import échoue on met à jour doli_product
						$e_cust->doli_soc = -1;
						$e_cust->mdate = mktime();
						dol_syslog("prospects.inc.php::import_prospects maj ecom_customer " . $e_cust->doli_soc, LOG_DEBUG);
						if ($e_cust->update($user) < 0) {
							dol_syslog("prospects.inc.php::get_prospects erreur maj ecom_customer " . $e_cust->error, LOG_DEBUG);
						}
					}
				}
				$i++;
			}
		}
	}
	else {
		dol_syslog("prospects.inc.php::import_prospects Erreur requête $sql " . $db->error, LOG_DEBUG);
		return -1;
	}
	return $num;
}


