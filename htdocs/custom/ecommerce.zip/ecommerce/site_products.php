<?php
/* Copyright (C) 2007 		Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2008 		Jean Heimburger	   	<jean@tiaris.fr>
 * Copyright (C) 2011-2013 	Philippe Grand      <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2014 	Juanjo Menent		<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
global $langs, $user, $db, $conf, $bc;

/**
 *        \file       ecommerce/site_products.php
 *        \ingroup    ecommerce
 *        \brief      Products management for e-commerce site
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */

require("./pre.inc.php");
require_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");
require_once(DOL_DOCUMENT_ROOT . "/core/lib/admin.lib.php");
require_once(DOL_DOCUMENT_ROOT . "/core/lib/functions.lib.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/E_product.class.php");
//compatibilité
dol_include_once("/ecommerce/class/webservice_ecom.class.php");
dol_include_once("/ecommerce/includes/products.inc.php");
dol_include_once("/ecommerce/class/E_categorie.class.php");

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("other");
$langs->load("ecommerce@ecommerce");


// Protection if external user
$socid = GETPOST('socid', 'int');
if ($user->societe_id) $socid = $user->societe_id;
$result = restrictedArea($user, 'societe', $socid);

// Get parameters
$siteid = GETPOST('siteid', 'int');
$typeliste = GETPOST('select', 'alpha');
if (empty($typeliste)) $typeliste = 'All';
$action = GETPOST('action', 'alpha');
$confirm = GETPOST('confirm', 'alpha');

dol_syslog(basename(__FILE__) . ":: action " . $action, LOG_DEBUG);

if ($siteid) {
// get site_parameters
    $site_params = new Ecom_site($db);
    if ($site_params->fetch($siteid, $user) < 0) {
        $mesg = $langs->trans("ErrLecSite", $_GET["siteid"], $_POST["siteid"]);
        setEventMessage($mesg, 'errors');    //"erreur lecture site get ".$_GET["siteid"].' post '.$_POST["siteid"];
    }
    else {
    }
}

// Pagination
$sortfield = GETPOST("sortfield", 'alpha');
$sortorder = GETPOST("sortorder", 'alpha');
if (!$sortfield) $sortfield = "ep.rowid";
if (!$sortorder) $sortorder = "DESC";

$page = GETPOST("page", 'int');
$limit = GETPOST("limit", 'int') ? GETPOST("limit", 'int') : $conf->liste_limit;
$offset = GETPOST("offset", 'int') ? GETPOST("offset", 'int') : 0;

// recherche
$secomid = GETPOST("secomid", 'int');
$secomattribut = GETPOST("secomattribut", 'int');
$sdeclinaison = GETPOST("sdeclinaison", 'int');
$secomref = GETPOST("secomref", 'alpha');
$slabel = GETPOST("slabel", 'alpha');
$sdoliid = GETPOST("sdoliid", 'int');

$secomid = trim($secomid);
$secomattribut = trim($secomattribut);
$sdeclinaison = trim($sdeclinaison);
$secomref = trim($secomref);
$slabel = trim($slabel);
$sdoliid = trim($sdoliid);

$param = '&siteid=' . $siteid;
$param .= '&select=' . (empty($typeliste) ? 'All' : $typeliste);

/*
 * Actions
 */


if (isset($_POST["button_removefilter_x"])) {
    $secomid = "";
    $secomattribut = "";
    $sdeclinaison = "";
    $sdoliid  = "";
    $secomref = "";
    $slabel = "";
    $sdoliid = "";
}

// Importer un produit existant dans Ecom_product et inexistant dans Dolibarr
if (isset($action) && $action == 'import') {
    // import a product
    $e_prod = new E_product($db, $siteid, $user);
    if ($e_prod->import_product(GETPOST('ecomid', 'int'), GETPOST('attribut', 'alpha'), GETPOST('ecomref', 'alpha')) > 0)
        setEventMessage($langs->trans("msgImportProduct", GETPOST('ecomid', 'int'), GETPOST('ecomref', 'alpha')), 'warnings');// "traitement de l'import de ".$_POST['ecomid']." ". $_POST['ecomref'];
    else {
        setEventMessage($e_prod->error, 'errors');
    }
}

//Bouton importer nouveaux en haut
elseif (isset($action) && $action == 'import_new') {
    //Import de nouveaux produits sur Presta
    $limite = 0;
    if ($site_params->site_maxproduct) $limite = $site_params->site_maxproduct;
    setEventMessage($langs->trans("msgImportNewsProducts", $limite));
    $last = get_new_products($siteid, $db, $user, $limite);
    if ($last < 0) {
        setEventMessage($langs->trans("ImportNewProducts1KO"), 'errors'); // "Erreur traitement des produits Etape 1"."\n";8
    }
    else {
        setEventMessage($langs->trans("ImportNewProducts1OK"));//"fin Etape 1 debut etape 2"."\n";
        if (get_products($siteid, $db, $user, $limite, $last) >= 0) {
            setEventMessage($langs->trans("ImportNewProducts2OK"));//"traitement produit reussi"." \n";
        }
        else {
            setEventMessage($langs->trans("ImportNewProducts2KO"), 'errors'); //"Erreur traitement des produits"."\n";
        }
    }
}
// syncin d'un produit existant dans Dolibarr depuis Prestashop
elseif (isset($action) && $action == 'syncin') {
    //parameter verification
    $prodid=GETPOST('ecomid', 'int');
    $attribut = GETPOST('attribut', 'int');
    syncin_product($siteid,$prodid,$attribut);
}

//soumission du Formulaire après clic sur le bouton exporter
//elseif (isset($action) && $action == 'export_confirm' and $confirm=='yes') {
elseif (isset($action) && $action == 'syncout') {

    // modification sur site et base
    $prodid=GETPOST('prodid');
    $p=new Product($db);
    $p->fetch($prodid);
    include_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
    dol_include_once('/ecommerce/class/E_categorie.class.php');
    $cat = new Categorie($db);
    $categories = $cat->containing($prodid, 'product');
    $cat = new E_categorie($db, $siteid, $user);
    $site_entrepot=$site_params->site_entrepot;
    $sql = "SELECT reel";
    $sql .= " FROM ".MAIN_DB_PREFIX."product_stock";
    $sql .= " WHERE fk_product = $prodid";
    $sql .= " AND fk_entrepot=$site_entrepot";
    $resql = $db->query($sql);
    if ($resql) {
        $obj = $db->fetch_object($resql);
        $reel=$obj->reel;
    } else {
        dol_print_error($db);
    }


    $e_prod = new E_product($db, $siteid, $user);
    if (($rowid=$e_prod->findrowid($p->id)) <= 0) {
        setEventMessage($langs->trans("AddProductExists", $p->id, $p->ref, $siteid), 'warnings');
        $e_prod->doli_product = $p->id;
    }
    $e_prod->id = $rowid;
    $e_prod->doli_product = $prodid;
    $e_prod->doli_ref = $p->ref;
    $e_prod->ecom_ref = $p->array_options['options_prodref'];
    $e_prod->catid = $cat->get_e_cat($categories[0]->id);
    $e_prod->price = $p->price;
    $e_prod->site_stock = $reel;
    $e_prod->weight = $p->weight;
    $e_prod->update($user);

    $modify = $e_prod->modify($prodid);

    if ($modify > 0) setEventMessage($langs->trans("ModifProductOK", $_POST['prodid']), 'warnings'); //" Le produit ".$_POST['prodid']." a ete mis a jour ";
    else setEventMessage($langs->trans("ModifProductKO", $e_prod->error), 'errors'); //"Erreur de la mise a jour ".$e_prod->error;
}

elseif (isset($action) && ($action == 'vendre')) {
    // Modify a product
    //$mesg = "Fonction en dev  ".$_POST['ecomid'];
    include_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
    $form=new Form($db);
    $formconfirm = $form->formconfirm($_SERVER["PHP_SELF"]."?prodid=".$_POST['prodid']."&siteid=$siteid", $langs->trans('vendreProduct',$_POST['prodid']), 'Etes vous sûr ?', 'vendre_confirm',array() , 'no', 2);
}
//soumission du Formulaire après clic sur le bouton vendre
elseif (isset($action) && $action == 'vendre_confirm' and $confirm=='yes') {

    // modification sur site et base
    $prodid=GETPOST('prodid');
    $p=new Product($db);
    $p->fetch($prodid);
    $e_prod = new E_product($db, $siteid, $user);
    $e_prod->doli_product = $prodid;
    $e_prod->price = $p->price;
    $site_entrepot=$site_params->site_entrepot;
    $sql = "SELECT reel";
    $sql .= " FROM ".MAIN_DB_PREFIX."product_stock";
    $sql .= " WHERE fk_product = $prodid";
    $sql .= " AND fk_entrepot=$site_entrepot";
    $resql = $db->query($sql);
    if ($resql) {
            $obj = $db->fetch_object($resql);
            $reel=$obj->reel;
    } else {
        dol_print_error($db);
    }

    $e_prod->site_stock = $reel;
    $e_prod->weight = $p->weight;

    include_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
    dol_include_once('/ecommerce/class/E_categorie.class.php');
    $cat = new Categorie($db);
    $categories = $cat->containing($prodid, 'product');
    $cat=new E_categorie($db, $siteid, $user);
    $e_prod->catid = $cat->get_e_cat($categories[0]->id);

    if ($e_prod->sell_product($prodid, $e_prod->catid, $p->tva_tx) > 0) setEventMessage($langs->trans("SellProductOK", $_POST['prodid']), 'warnings'); // " Produit ".$_POST['prodid']." mis en vente";
    else setEventMessage($langs->trans("SellProductKO", $prodid, $e_prod->error), 'errors'); //" Erreur de la mise en vente de  ".$_POST['prodid']." : ".$e_prod->error;
}
//soumission du Formulaire après clic sur le bouton annuler
elseif (isset($action) && $action == 'unsync') {
    $e_prod = new E_product($db, $siteid, $user);
    $e_prod->id = $_POST['rowid'];
    $e_prod->delete($user);
}
//Bouton activer sur chaque ligne
elseif (isset($action) && $action == 'activer') {
    // Activate a product on line
    $e_prod = new E_product($db, $siteid, $user);
    if ($e_prod->activate($_GET['prodid'], 1) > 0) setEventMessage($langs->trans("ActivProductOK", $_GET['prodid']), 'warnings'); //" Le produit ".$_GET['prodid']." est disponible ";
    else setEventMessage($langs->trans("ActivProductKO", $e_prod->error), 'errors'); //"Erreur de l'activation ".$e_prod->error;
}
//Bouton désactiver sur chaque ligne
elseif (isset($action) && $action == 'desactiver') {
    // Desactivate a product on line
    $e_prod = new E_product($db, $siteid, $user);
    if ($e_prod->activate($_GET['prodid'], 0) > 0) setEventMessage($langs->trans("DeactivProductOK", $_GET['prodid']), 'warnings'); //;" Le produit ".$_GET['prodid']."est indisponible";
    else setEventMessage($langs->trans("DeactivProductKO", $e_prod->error), 'errors'); //"Erreur dans le traitement ".$e_prod->error;
}
//Formulaire d'ajout de produit en bas
elseif (isset($action) && $action == 'ajout') {
    // ajouter un produit
    $pref = GETPOST('pRef', 'alpha');
    $pid = GETPOST('pId', 'int');
    $pref = trim($pref);
    $pid = trim($pid);

    $prod = new Product($db);
    $p = $prod->fetch($pid, $pref);

    if (!$prod->id) setEventMessage($langs->trans("AddProductNoExist", $pid, $pref), 'errors'); // "erreur produit non trouve ref :".$pref." id : ".$pid;
    else {
        $e_prod = new E_product($db, $siteid, $user);
        $e_prod->siteid = $siteid;
        if ($e_prod->findrowid($prod->id) <= 0) {
            $e_prod->doli_product = $prod->id;
            $e_prod->ecom_attribut = '';
            $e_prod->ecom_product = '0';
            $e_prod->doli_ref = $prod->ref;

            if ($result = $e_prod->create($user) < 0) setEventMessage($langs->trans("AddProductKO", $pid, $pref), 'errors'); //"erreur création produit ".$pId." ".$pRef;
            else setEventMessage($langs->trans("AddProductOK", $pid, $pref, $siteid)); //'ajout du produit '.$pid." ref ".$pref." pour le site ".$siteid;
        }
        else setEventMessage($langs->trans("AddProductExists", $prod->id, $prod->ref, $siteid), 'warnings');
    }
}

elseif (isset($action) && $action == 'logdelete') {
    if (isset($_POST["logrowid"])) {
        $elog = new Ecom_log($db);
        $elog->id = $_POST["logrowid"];
        $elog->delete($_POST["logrowid"], 1);
    }
}

elseif (isset($action) && $action == 'deletelogselected') {
    if (is_array($_POST['toGenerate'])) {
        $elog = new Ecom_log($db);
        foreach ($_POST['toGenerate'] as $elt => $key) {
            $elog->id = $key;
            $elog->delete($key, 1);
        }
    }
}

elseif (isset($action) && $_REQUEST["action"] == 'export_new' && !empty($conf->global->ECOMMERCE_EXPORT_DOLI2ECOM)) {
    require_once(DOL_DOCUMENT_ROOT . "/categories/class/categorie.class.php");
    dol_include_once("/ecommerce/class/E_categorie.class.php");

    if ($conf->global->ECOM_DOLICAT > 0) {
        $object = new Categorie($db);
        $result = $object->fetch($conf->global->ECOM_DOLICAT);
        if ($result > 0) {
            if ($object->type == 0) {
                $prods = $object->get_type("product", "Product");
                if (count($prods) > 0) {
                    dol_syslog("Ecommerce::export_new::Init " . $mesg);
                    foreach ($prods as $prod) {
                        $error = 0;

                        //View if product exists
                        $sql = "SELECT rowid,ecom_product";
                        $sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product";
                        $sql .= " WHERE siteid= " . $siteid;
                        $sql .= " AND doli_product = " . $prod->id;

                        $resql = $db->query($sql);
                        if ($resql) {
                            $num = $db->num_rows($resql);
                        }

                        if (!$num) {
                            //Create product
                            $e_prod = new E_product($db, $siteid, $user);
                            $e_prod->doli_product = $prod->id;
                            $e_prod->ecom_attribut = '';
                            $e_prod->ecom_product = '0';
                            $e_prod->doli_ref = $prod->ref;
                            $e_prod->long_desc = $prod->description;
                            $e_prod->siteid = $siteid;

                            $e_prod_id = $e_prod->create($user);
                            if ($e_prod_id < 0) {
                                $mesg = setEventMessage($langs->trans("AddProductKO", $prod->id), 'errors');
                            }
                            else {
                                $e_prod->price = $prod->price;
                                $sell = $e_prod->sell_product($prod->id, 1, 1);
                                $mesg = setEventMessage($langs->trans("AddProductOK", $prod->id));
                            }
                            dol_syslog("Ecommerce::export_new::create " . $mesg);
                        }
                        else {
                            $obj = $db->fetch_object($resql);
                            $ecom_product = $obj->ecom_product;
                        }

                        $resql = $db->query($sql);
                        if ($resql) {
                            $num = $db->num_rows($resql);
                        }

                        if (!$sell || $sell > 0) {
                            //Modify
                            if (!$error) {
                                if ($num) {
                                    $e_prod = new E_product($db, $siteid, $user);
                                    $e_prod->fetch($ecom_product);
                                }

                                $myobject = new Ecom_Site($db);
                                $myobject->fetch($siteid);

                                //control categ
                                $c = new Categorie($db);
                                $ecat = new E_categorie($db, $siteid, $user);
                                $cats = $c->containing($prod->id, 0);
                                if (sizeof($cats) > 0) {
                                    foreach ($cats as $cat) {
                                        if ($cat->id != $conf->global->ECOM_DOLICAT) {
                                            $dolcat = $cat->id;
                                            $ecatid = $ecat->get_e_cat($cat->id);
                                            $e_prod->catid = $ecatid;
                                        }
                                    }
                                }

                                $prod->load_stock();
                                $e_prod->site_stock = $prod->stock_warehouse[$myobject->site_entrepot]->real;
                                $e_prod->weight = $prod->weight;
                                $e_prod->ecom_ref = $prod->ref;
                                $e_prod->e_name = $prod->libelle;
                                $e_prod->e_desc_short = $prod->description;
                                $e_prod->price = $prod->price;
                                $e_prod->doli_product = $prod->id;

                                $prod->fetch_barcode();
                                if ($prod->barcode_type_code == "EAN13") {
                                    $e_prod->e_ean13 = $prod->barcode;
                                }

                                if ($e_prod->modify($prod->id) > 0) {
                                    $mesg .= " " . setEventMessage($langs->trans("ModifProductOK", $_POST['prodid']));
                                }
                                else {
                                    $mesg .= " " . setEventMessage($langs->trans("ModifProductKO", $e_prod->error), 'errors'); //"Erreur de la mise à jour ".$e_prod->error;
                                }
                                dol_syslog("Ecommerce::export_new::modify " . $mesg);

                                //View if product exists
                                $sql = "DELETE FROM ";
                                $sql .= MAIN_DB_PREFIX . "categorie_product";
                                $sql .= " WHERE fk_categorie= " . $conf->global->ECOM_DOLICAT;
                                $sql .= " AND fk_product = " . $prod->id;

                                $resql = $db->query($sql);
                                dol_syslog("Ecommerce::export_new::modify " . $mesg);
                            }
                        }
                    }
                }
            }
        }
    }
}

/*
 * View
 */

llxHeader();
print $formconfirm;

$form = new Form($db);

if (!empty($conf->global->ECOMMERCE_EXPORT_DOLI2ECOM)) {
    $colspan = 12;
    $colspanimp = 10;
}
else {
    $colspan = 12;
    $colspanimp = 11;
}

//if ($mesg && empty($conf->global->ECOMMERCE_EXPORT_DOLI2ECOM)) print '<p><div class="warning">'.$mesg.'</div></p>';

$sql = "SELECT ep.rowid,ep.ecom_product as ecom_product, ep.ecom_attribut, ep.ecom_ref as ecom_ref,ep.doli_ref as doli_ref,ep.doli_ref,ep.declinaison,";
$sql .= " ep.site_status, ep.site_stock as site_stock,";
$sql .= " p.rowid as doli_product, p.price, p.weight, p.label, ps.reel,";
if(!empty($conf->global->ECOM_SHOW_TOTAL_STOCK_COLUMN)) $sql .= "(SELECT sum(psa.reel) FROM " . MAIN_DB_PREFIX . "product_stock psa WHERE ep.doli_product = psa.fk_product GROUP BY psa.fk_product) totalstock,";
$sql .= " (SELECT ifnull(sum(cd.qty),0)";
$sql .= " FROM " . MAIN_DB_PREFIX . "commandedet cd WHERE cd.fk_product = p.rowid) as stock_commande "; // TODO sum(cd.qty) et group by posent probl�me
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "product p ON p.rowid = ep.doli_product";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "product_stock ps ON ep.doli_product = ps.fk_product AND ps.fk_entrepot = '" . $site_params->site_entrepot . "' ";
$sql .= " WHERE ep.siteid ='" . $siteid . "'";
// liste
switch ($typeliste) {
    case 'onSale' :
        $sql .= ' AND ecom_product > 0 AND site_status = 1';
        break;
    case 'Waiting' :
        $sql .= ' AND (ecom_product = 0 OR doli_product <= 0) ';
        break;
    case 'unAvail' :
        $sql .= ' AND ecom_product > 0 AND site_status = 0 ';
        break;
    case 'Different' :
        break;
        $sql .= ' AND ep.site_stock!=p.stock OR ep.ecom_price!=p.price ';
    case 'All' :
        break;
    default :
        break;
}
//recherche
if ($secomid) $sql .= " AND ep.ecom_product = '" . $secomid . "'";
if ($secomattribut) $sql .= " AND ep.ecom_attribut = '" . $secomattribut . "'";
if ($sdeclinaison) $sql .= " AND ep.declinaison = '" . $sdeclinaison . "'";
if ($secomref) $sql .= " AND ep.ecom_ref like '%" . $secomref . "%'";
if ($slabel) $sql .= " AND p.label like '%" . $slabel . "%'";
if ($sdoliid) $sql .= " AND doli_product like = " . $sdoliid . "'";
$sql .= " ORDER BY $sortfield $sortorder ";

$nbtotalofrecords = 0;
if (empty($conf->global->MAIN_DISABLE_FULL_SCANLIST)) {
    $result = $db->query($sql);
    $nbtotalofrecords = $db->num_rows($result);
}
$sql .= $db->plimit($limit, $offset);

dol_syslog("site_products:: sql=" . $sql, LOG_DEBUG);


$resql = $db->query($sql);
if ($resql) {
    $num = $db->num_rows($resql);
    // entete
    $text = $langs->trans("SiteArea");

    print_fiche_titre($text, '', 'ecommerce@ecommerce');

    print '<form action="' . $_SERVER['PHP_SELF'] . '?siteid=' . $siteid . $param . '" method="POST">';
    print '<input type="hidden" name="siteid" value="' . $siteid . '">';
    print '<input type="hidden" name="action" value="resetlimitoffset">';
    print 'Nombre d\'enregistrements : ';
    print '<input type="text" id="limit" name="limit" value="' . $limit . '">';
    print 'Décalage depuis la fin : ';
    print '<input type="text" id="offset" name="offset" value="' . $offset . '">';
    print '<input type="hidden" id="offset" name="select" value="' . $typeliste . '">';
    print '<input class="button" type="submit" value="' . $langs->trans("Update") . '">';
    print '</form>';
    print '<br/>';
    $h = 0;
    $head = array();

    $head[$h][0] = dol_buildpath("/ecommerce/site_index.php?siteid=$siteid&limit=$limit&offset=$offset", 1);
    $head[$h][1] = $site_params->site_name;
    $head[$h][2] = 'ecommerce';
    $h++;

    // Onglets
    $head = ecom_prepare_head_product($siteid, $limit, $offset);
    $ongletdefault = (empty($typeliste) ? 'All' : $typeliste);

    dol_fiche_head($head, $ongletdefault, $langs->trans("ProductManagement"), 0, 'product');
    //dol_fiche_head($head, 'ecommerce', $langs->trans("SiteProductAdmin"));
    $texte = "$num " . $langs->trans("lines");
    print_barre_liste($texte, $page, "site_products.php", '&select=' . $ongletdefault . '&siteid=' . $siteid, $sortfield, $sortorder, '', $num, $nbtotalofrecords, 'generic', 0,  '',  '',  '',  1, 1);

    print '<table class="liste" width="100%">';

    print '<tr class="liste_titre">';
    $url = 'site_products.php?siteid=' . $siteid;
    if ($page) $url .= '&page=' . $page;
    print '<td colspan="11" align="left"><form action="' . $_SERVER['PHP_SELF'] . '?siteid=' . $siteid . $param . '" method="POST">';
    print '<input type="hidden" name="siteid" value="' . $siteid . '">';
    print '<input type="hidden" name="action" value="import_new">';
    print '<input type="submit" class="button" value="' . $langs->trans("SiteImport") . '">';
    print '</form></td>';

//    if (!empty($conf->global->ECOMMERCE_EXPORT_DOLI2ECOM)) print '<td align="center"><a href="site_products.php?siteid=' . $siteid . '&action=export_new">' . $langs->trans("SiteExport") . '</a></td>';
    print "<td>&nbsp;</td>";
    print "</tr>\n";

    print '<tr><td>&nbsp;</td></tr>';
    print '<tr class="liste_titre">';
    print '<td colspan="' . $colspan . '" align="center"><h3>' . $langs->trans("SiteProductAdmin") . '</h3></td>';
    print '</tr>';
    print '<tr class="liste_titre">';
    print_liste_field_titre($langs->trans("SiteProdId"), "site_products.php", "ep.ecom_product", $param, "", "", $sortfield, $sortorder);
    print_liste_field_titre($langs->trans("SiteProdAttrId"), "site_products.php", "ep.ecom_attribut", $param, "", "", $sortfield, $sortorder);
    print_liste_field_titre($langs->trans("Declinaison"), "site_products.php", "declinaison", $param, "", "", $sortfield, $sortorder);
    print_liste_field_titre($langs->trans("SiteProdRef"), "site_products.php", "ecom_ref", $param, "", "", $sortfield, $sortorder);
    print_liste_field_titre($langs->trans("DoliRef"), "site_products.php", "doli_ref", $param, "", "", $sortfield, $sortorder);
    print_liste_field_titre($langs->trans("SiteProdStatus"), "site_products.php", "ep.site_status", $param, "", "", $sortfield, $sortorder);
    print_liste_field_titre($langs->trans("ProdName"), "site_products.php", "p.label", $param, "", "", $sortfield, $sortorder);
//    print_liste_field_titre($langs->trans("IdProd"), "site_products.php", "doli_product", $param, "", "", $sortfield, $sortorder);
    if ($typeliste == 'Waiting') print '<td align="center">' . $langs->trans("DateSendShort") . '</td>';
    else print '<td></td>';
    print '<td align="left">' . $langs->trans("Action") . '</td>';
    print '<td align="right">' . $langs->trans("SiteProdStock") . '</td>';
    print '<td align="right"">' . $langs->trans("ProdOrder") . '</td>';
    print '<td align="right" >' . $langs->trans("DoliProdStock") . '</td>';
    if(!empty($conf->global->ECOM_SHOW_TOTAL_STOCK_COLUMN)) print '<td align="right" >' . $langs->trans("TotalStock") . '</td>';
    print '<td class="liste_titre"></td>';
    print '<td class="liste_titre"></td></tr>';
    $param .= "&sortfield=$sortfield&sortorder=$sortorder";

    // recherche
    print "\n";
    print '<form action="site_products.php?x=w"' . $param . ' method="post" name="formulaire">';
    print '<input type="hidden" name="siteid" value="' . $siteid . '">';
    print '<input type="hidden" name="select" value="' . $typeliste . '">';
    print '<tr class="liste_titre">';
    print '<td class="liste_titre" align="left">';
    print '<input class="flat" type="text" name="secomid" size="8" value="' . $secomid . '">';
    print '</td>';
    print '<td class="liste_titre" align="left">';
    print '<input class="flat" type="text" name="secomattribut" size="8" value="' . $secomattribut . '">';
    print '</td>';
    print '<td class="liste_titre" align="left">';
    print '<input class="flat" type="text" name="sdeclinaison" size="8" value="' . $sdeclinaison . '">';
    print '</td>';
    print '<td class="liste_titre" align="left">';
    print '<input class="flat" type="text" name="secomref" size="10" value="' . $secomref . '">';
    print '</td>';
    print '<td class="liste_titre" align="left" colspan="2"></td>';
    print '<td class="liste_titre" align="left">';
    print '<input class="flat" type="text" name="slabel" size="15" value="' . $slabel . '">';
    print '</td>';
/*    print '<td class="liste_titre" align="left">';
    print '<input class="flat" type="text" name="sdoliid" size="8" value="' . $sdoliid . '">';
    print '</td>';*/
    print '<td class="liste_titre" align="left" colspan="4"></td>';
    if(!empty($conf->global->ECOM_SHOW_TOTAL_STOCK_COLUMN)) print '<td class="liste_titre"></td>';
    print '<td class="liste_titre" align="left">';
//    print "\n";
    print '<input type="image" class="liste_titre" name="button_search" src="' . DOL_URL_ROOT . '/theme/' . $conf->theme . '/img/search.png" alt="' . $langs->trans("Search") . '">';
    print '<input type="image" class="liste_titre" name="button_removefilter" src="' . DOL_URL_ROOT . '/theme/' . $conf->theme . '/img/searchclear.png" alt="' . $langs->trans("RemoveFilter") . '">';
//    print "\n";
    print '</td>';

    print '</tr>';
    print '</form>';
    print "\n";
    $i = 0;
    $p = new Product($db);
    if ($num) {
        $var = True;
        $url = 'site_products.php?siteid=' . $siteid;
        if ($page) $url .= '&page=' . $page;
        $transmitinputs = '';
        if ($secomid) $transmitinputs .= '<input type="hidden" name="secomid" value="' . $secomid . '">';
        if ($secomattribut) $transmitinputs .= '<input type="hidden" name="secomattribut" value="' . $secomattribut . '">';
        if ($sdeclinaison) $transmitinputs .= '<input type="hidden" name="sdeclinaison" value="' . $sdeclinaison . '">';
        if ($secomref) $transmitinputs .= '<input type="hidden" name="secomref" value="' . $secomref . '">';
        if ($slabel) $transmitinputs .= '<input type="hidden" name="slabel" value="' . $slabel . '">';
        if ($sdoliid) $transmitinputs .= '<input type="hidden" name="sdoliid" value="' . $sdoliid . '">';
        while ($i < $num) {
            $obj = $db->fetch_object($resql);
            if ($obj) {
                print '<tr ' . $bc[$var] . '>';
                print '<td>' . $obj->ecom_product . '</td>';
                print '<td>' . $obj->ecom_attribut . '</td>';
                print '<td>' . $obj->declinaison . '</td>';
                print '<td>' . $obj->ecom_ref . '</td>'; //référence
                //référence dolibarr
                print '<td>';
                if ($obj->doli_product > 0) {
                    $p->fetch($obj->doli_product);
                    print $p->getNomUrl(1);
                }
                print '</td>';
                if (!$obj->site_status) {
                    // produit dispo
                    //$lien = '<a href="site_products.php?siteid='.$siteid.'&action=activer&prodid='.$obj->doli_product.'">';
                    $lien = '<a href="' . $url . '&action=activer&prodid=' . $obj->doli_product . $param .
                        '" alt="Activer" title="' . $langs->trans("Activer") . '" width="10" height="10">
                        <span class="fas fa-toggle-off fa-15" style=" padding-right: 6px" title="Configuration"></span></a>&nbsp;&nbsp;';
                }
                else {
//                    $lien = '<img src="img/switch_off.png" border="0" alt="Actif" title="' . $langs->trans("Actif") . '" width="10" height="10">&nbsp;&nbsp;';
                    $lien = '<a href="site_products.php?siteid=' . $siteid . '&action=desactiver&prodid=' . $obj->doli_product .
                        '" alt="Désactiver" title=" Désactiver " width="10" height="10">
                        <span class="fas fa-toggle-on fa-15" style=" padding-right: 6px" title="Configuration"></span></a>&nbsp;&nbsp;';
//                    $lien .= '<a href="' . $url . '&action=desactiver&prodid=' . $obj->doli_product . '"><img src="img/icon_status_red_light.gif" border="0" alt="Désactiver" title="' . $langs->trans("Desactiver") . '" width="10" height="10"></a>';
                }
                print '<td>';
                if (!empty($obj->ecom_product)) print  $lien;
                print '</td>';
                //print '<td>'.$obj->doli_product.'</td>';
                print '<td>' . $obj->label . '</td>'; // nom
                //print '<td>?</td>'; //fournisseur
                /*                if ($obj->doli_product) {
                                    print '<td align="right"><a href="' . DOL_URL_ROOT . '/product/card.php?id=' . $obj->doli_product . '">' . $obj->doli_product . '</a></td>';
                                }
                                else
                                    print '<td> </td>';
                */
                print '<td>';

                print '<form action="' . $url . $param . '" name="vente" method="POST">';
                // transmettre la sélection
                print $transmitinputs;
                print '<input type="hidden" name="select" value=' . $typeliste . ' >';

                if ($obj->doli_product) {
                    if (!empty($obj->ecom_product)) {
                        $lib = $langs->trans("Syncout");
                        print '<input type="hidden" name="action" value="syncout">';
                        print '<input type="hidden" name="ecomid" value="' . $obj->ecom_product . '">';
                        print '<input type="hidden" name="attribut" value="' . $obj->ecom_attribut . '">';
                        print '<input type="hidden" name="prodid" value="' . $obj->doli_product . '">';
                    }
                    else {
                        $lib = $langs->trans("Vendre");
                        print '<input type="hidden" name="action" value="vendre">';
                        print '<input type="hidden" name="prodid" value="' . $obj->doli_product . '">';
                    }
                }
                else {
                    $lib = $langs->trans("Import");
                    print '<input type="hidden" name="action" value="import">';
                    print '<input type="hidden" name="ecomid" value="' . $obj->ecom_product . '">';
                    print '<input type="hidden" name="ecomref" value="' . $obj->ecom_ref . '">';
                    print '<input type="hidden" name="attribut" value="' . $obj->ecom_attribut . '">';
                }
                print '<input class="button" type="submit" value="' . $lib . '">';
                print '</form>';
                print '</td>';
                //bouton import
                if (!empty($obj->doli_product) && !empty($obj->ecom_product) &&$typeliste != 'Waiting') {
                    print '<td>';
                    print '<form action="' . $url . $param . '" name="syncweb" method="POST" >';
                    print $transmitinputs;
                    print '<input type="hidden" name="action" value="syncin">';
                    print '<input type="hidden" name="ecomid" value="' . $obj->ecom_product . '">';
                    print '<input type="hidden" name="rowid" value="' . $obj->rowid . '">';
                    print '<input type="hidden" name="attribut" value="' . $obj->ecom_attribut . '">';
                    print '<input type="hidden" name="select" value=' . $typeliste . ' >';
                    print '<input class="button" type="submit" value="' . $langs->trans("Syncin") . '">';
                    print '</form>';
                    print '</td>';    // bouton synchro web
                }
                else {
                    print '<td>';
                    print '<form action="' . $url . $param . '" name="syncweb" method="POST" >';
                    print '<input type="hidden" name="action" value="unsync">';
                    print '<input type="hidden" name="rowid" value="' . $obj->rowid . '">';
                    print '<input class="button" type="submit" value="' . $langs->trans("Cancel") . '">';
                    print '</form>';
                    print '</td>';
                }

                print '<td align="right">' . (empty($obj->site_stock) ? 0 : $obj->site_stock) . '</td>';
                print '<td align="right">' . (empty($obj->stock_commande) ? 0 : $obj->stock_commande) . '</td>';
                print '<td align="right">' . (empty($obj->reel) ? 0 : $obj->reel) . '</td>';
                if(!empty($conf->global->ECOM_SHOW_TOTAL_STOCK_COLUMN)) print '<td align="right">' . (empty($obj->totalstock) ? 0 : $obj->totalstock) . '</td>';
                print '</tr>';

                // le formulaire de vente
                if (0&&(isset($action) && $action == 'vendre') && (isset($_REQUEST['prodid']) && $_REQUEST['prodid'] == $obj->doli_product)) {
                    $doliprod = new Product($db);
                    $doliprod->fetch($obj->doli_product);
                    print '<tr>';
                    print '<td colspan ="9"><b><u> ' . $langs->trans("ProdVente") . '</td>';
                    print '</tr>';
                    print '<tr>';
                    print '<form action="' . $url . $param . '" name="maj" method="POST" >';
                    print $transmitinputs;
                    print '<input type="hidden" name="action" value="vendre_confirm" />';
                    print '<input type="hidden" name="ecomid" value="' . $_POST["ecomid"] . '" />';
                    print '<input type="hidden" name="prodid" value="' . $obj->doli_product . '" />';
                    print '<input type="hidden" name="select" value=' . $typeliste . ' >';
                    print '<td><b>' . $langs->trans("ProdPrice") . '</td>';
                    print '<td><b><input type="text" name="prix" value="' . price($obj->price) . '" /> </td>';
                    print '<td><b>' . $langs->trans("ProdStock") . '</td>';
                    print '<td><input type="text" name="stock" value="' . (isset($obj->reel) ? $obj->reel : 1) . '" /> </td>';
                    print '<td><b>' . $langs->trans("ProdWeight") . '</td>';
                    print '<td><input type="text" name="weight" value="' . $obj->weight . '" />  </td>';
                    print '<td colspan="3"> </td>';
                    print '</tr>';
                    print '<tr>';

                    // gestion de la catégorie du site
                    $sql = "SELECT ecom_catid, ecom_catname ";
                    $sql .= " FROM " . MAIN_DB_PREFIX . "ecom_categories ";
                    $sql .= " WHERE siteid = '" . $siteid . "' ORDER BY ecom_catname ";

                    dol_syslog("site_products::dropdown categories sql=" . $sql, LOG_DEBUG);
                    $resql1 = $db->query($sql);
                    if ($resql1) {
                        $rows = $db->num_rows($resql1);
                        $j = 0;
                        print '<td><b>' . $langs->trans("ProdCat") . '</td>';
                        if ($rows) {
                            print '<td><select class="flat" name="cat" id="cat">';
                            print '<option value="" "selected"> </option>';
                            while ($j < $rows) {
                                $objf = $db->fetch_object($resql1);
                                if ($objf) {
                                    print '<option value="' . $objf->ecom_catid . '">' . $objf->ecom_catname . '</option>';
                                }
                                $j++;
                            }
                            print '</td></select>';
                        }
                        else {
                            dol_syslog("site_products::dropdown categories pas de lignes sql=" . $sql, LOG_DEBUG);
                            print '<td> </td>';
                        }
                    }
                    else {
                        print '<td>*</td><td>*</td>';
                        dol_syslog("site_products::dropdown categories erreur sql=" . $sql, LOG_DEBUG);
                    }

                    /*					// gestion du fournisseur du site
                                        $sql = "SELECT ecom_manufacturer, ecom_manuname ";
                                        $sql .= " FROM " . MAIN_DB_PREFIX . "ecom_manufacturer ";
                                        $sql .= " WHERE siteid = '" . $siteid . "' AND manutype = '0' ORDER BY ecom_manuname ";

                                        dol_syslog("site_products::dropdown fournisseurs sql=" . $sql, LOG_DEBUG);
                                        $resql1 = $db->query($sql);
                                        if ($resql1) {
                                            $rows = $db->num_rows($resql1);
                                            $j = 0;
                                            print '<td>' . $langs->trans("ProdFour") . '</td>';
                                            if ($rows) {
                                                print '<td><select class="flat" name="fourn">';
                                                print '<option value="" "selected"> </option>';
                                                while ($j < $rows) {
                                                    $objf = $db->fetch_object($resql1);
                                                    if ($objf) {
                                                        print '<option value="' . $objf->ecom_manufacturer . '">' . $objf->ecom_manuname . '</option>';
                                                    }
                                                    $j++;
                                                }
                                                print '</select></td>';
                                            }
                                            else {
                                                dol_syslog("site_products::dropdown fournisseurs pas de lignes sql=" . $sql, LOG_DEBUG);
                                                print '<td> </td>';
                                            }
                                        }
                                        else {
                                            print '<td>*</td><td>*</td>';
                                            dol_syslog("site_products::dropdown fournisseurs erreur sql=" . $sql, LOG_DEBUG);
                                        }*/
                    //TVA
                    $sql = "SELECT ecom_id, ecom_lib ";
                    $sql .= " FROM " . MAIN_DB_PREFIX . "ecom_params ";
                    $sql .= " WHERE siteid = '" . $siteid . "' AND partype = 'taxrate'";

                    dol_syslog("site_products::dropdown TVA sql=" . $sql, LOG_DEBUG);
                    $resql1 = $db->query($sql);
                    if ($resql1) {
                        $rows = $db->num_rows($resql1);
                        $j = 0;
                        print '<td><b> ' . $langs->trans("ProdTax") . '</td>';
                        if ($rows) {
                            print '<td><select class="flat" name="taxe">';
                            print '<td><select class="flat" name="taxe">';
                            while ($j < $rows) {
                                $objf = $db->fetch_object($resql1);
                                if ($objf) {
                                    print '<option value="' . $objf->ecom_id . '">' . $objf->ecom_lib . '</option>';
                                }
                                $j++;
                            }
                            print '</select></td>';
                        }
                        else {
                            dol_syslog("site_products::dropdown TVA pas de lignes sql=" . $sql, LOG_DEBUG);
                            print '<td> </td>';
                        }
                    }
                    else {
                        print '<td>*</td><td>*</td>';
                        dol_syslog("site_products::dropdown TVA erreur sql=" . $sql, LOG_DEBUG);
                    }
                    print '<td colspan="3"><input type="submit" value="Envoyer"  style="background-color: #dee7ec;font-weight: bold;"/></td>';
                    print '</tr>';
                    print '</form>';
                }
            }

            $i++;
            $var = !$var;
        }
        // Navigation

        print '<input type="hidden" name="siteid" value="' . $siteid . '" />';
//		print_barre_liste($texte, $page, "site_products.php", '&select=' . $ongletdefault . '&siteid=' . $siteid, $sortfield, $sortorder, '', $num, $nbtotalofrecords);


    }
}

print '<br />';

// formulaire ajout produit

print '<form action="' . $url . $param . '" name="addprod" method="POST">';
print '<table class="liste" width="50%">';
print '<tr class="liste_titre">';
print '<td colspan="3" align="center">' . $langs->trans("ProductAdd") . '</td></tr>';
print '<tr ' . $bc[0] . '><td>';
print $langs->trans("Ref") . ':</td><td><input class="flat" type="text" size="18" name="pRef"></td>';
print '<td rowspan="2"><input type="submit" class="button" value="' . $langs->trans("Add") . '"/></td></tr>';
print '<input type="hidden" name="action" value="ajout"/>';
print '<input type="hidden" name="select" value=' . $typeliste . ' >';
print "<tr $bc[0]><td>";
print $langs->trans("ProdId") . ':</td><td><input class="flat" type="text" size="18" name="pId"/></td>';
print '</tr>';

print '</table></form>';

// affichage des logs & Products out of local stock && Products out of stock on ecommerce
/*    print '<br/>';

$sql = "SELECT rowid, log_date, log_fonction, log_message ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_log l";
$sql .= " WHERE site_id = '" . $siteid . "' AND log_fct = 'PRD' AND log_type = 'ERR' ";
$sql .= " ORDER BY l.log_date DESC ";
$sql .= " LIMIT 10";

$resql = $db->query($sql);
if ($resql) {
    $num = $db->num_rows($resql);
    $i = 0;
    if ($num) {
        print '<table class="liste" width="100%">';
        print '<tr class="liste_titre">';
        print '<td colspan="4" align="center">' . $langs->trans("LogAdmin") . '</td></tr>';
        print '<tr class="liste_titre">';
        print '<td class="liste_titre">' . $langs->trans("LogDate") . '</td>';
        print '<td class="liste_titre">' . $langs->trans("LogFonc") . '</td>';
        print '<td class="liste_titre">' . $langs->trans("LogMessage") . '</td>';
        print '<td class="liste_titre" align="center">';
        if ($conf->use_javascript_ajax) print '<a href="#" id="checkall">' . $langs->trans("All") . '</a> / <a href="#" id="checknone">' . $langs->trans("None") . '</a>';
        print '</td>';
        print '</tr>';
        $var = True;
        print '<form action="' . $url . '" name="deletelog" method="POST">';
        print '<input type="hidden" name="action" value="deletelogselected"/>';
        print '<input type="hidden" name="select" value=' . $typeliste . ' >';
        while ($i < $num) {
            $obj = $db->fetch_object($resql);
            if ($obj) {
                print '<tr ' . $bc[$var] . '><td>' . $obj->log_date . '</td>';
                print '<td>' . $obj->log_fonction . '</td>';
                print '<td>' . $obj->log_message . '</td>';
                //print '<form action="'.$url .'" name="deletelog" method="POST">';
                //print '<input type="hidden" name="action" value="logdelete"/>';
                print '<input type="hidden" name="logrowid" value="' . $obj->rowid . '"/>';
                // Checkbox
                print '<td align="center">';
                print '<input id="cb' . $obj->rowid . '" class="flat checkformerge" type="checkbox" name="toGenerate[]" value="' . $obj->rowid . '">';
                print '</td>';
                print '</tr>';
            }
            $i++;
            $var = !$var;
        }
        print '<tr><td colspan="4" align="center"><input type="submit" class="button" value="' . $langs->trans("Delete") . '" /></td>';
        print '</form></table>';
    }
}

print '</tr>';
print '</form>';
print '<tr><td>&nbsp;</td></tr></table>';

$sql = "SELECT cd.fk_product, p.ref, p.label, sum(cd.qty) qte_cde, ps.reel ";
$sql .= " FROM " . MAIN_DB_PREFIX . "commandedet AS cd ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "commande AS c on c.rowid = cd.fk_commande AND c.fk_statut IN (1,2) ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "product AS p on p.rowid = cd.fk_product ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_order AS eo ON eo.doli_order = cd.fk_commande AND eo.siteid = '" . $siteid . "' ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "product_stock AS ps ON ps.fk_product = cd.fk_product AND ps.fk_entrepot = '" . $site_params->site_entrepot . "' ";
$sql .= " GROUP BY  cd.fk_product having qte_cde > ps.reel";

$taboutstock = array();
$resql = $db->query($sql);
if ($resql) {
    $num = $db->num_rows($resql);
    $i = 0;
    if ($num) {
        while ($i < $num) {
            $obj = $db->fetch_object($resql);
            if ($obj) {
                $taboutstock[$i]["fk_product"] = $obj->fk_product;
                $taboutstock[$i]["ref"] = $obj->ref;
                $taboutstock[$i]["label"] = $obj->label;
                $taboutstock[$i]["qte_cde"] = $obj->qte_cde;
                $taboutstock[$i]["reel"] = $obj->reel;
                $taboutstock[$i]["siteid"] = $obj->siteid;
            }
            $i++;
        }
    }
}

// Products out of stock on ecommerce

$sql = "SELECT ep.ecom_product, ep.site_stock, ";
$sql .= " p.ref, p.label ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product AS ep ";
$sql .= " LEFT OUTER JOIN " . MAIN_DB_PREFIX . "product AS p ON p.rowid = ep.doli_product ";
$sql .= " WHERE ep.site_stock <='0' AND ep.site_status = '1' AND ep.siteid = '" . $siteid . "' ";
$sql .= " LIMIT 10 ";
dol_syslog("site_index stock sql=" . $sql, LOG_DEBUG);
$tabproduct = array();
$resql = $db->query($sql);
if ($resql) {
    $num = $db->num_rows($resql);
    $i = 0;
    if ($num) {
        while ($i < $num) {
            $obj = $db->fetch_object($resql);
            if ($obj) {
                $tabproduct[$i]["ecom_product"] = $obj->ecom_product;
                $tabproduct[$i]["ref"] = $obj->ref;
                $tabproduct[$i]["label"] = $obj->label;
                $tabproduct[$i]["site_stock"] = $obj->site_stock;
                $tabproduct[$i]["siteid"] = $obj->siteid;
                $tabproduct[$i]["site_name"] = $obj->site_name;
            }
            $i++;
        }
    }
}
// Products
print '<table class="notopnoleftnoright" width="95%" >';
print '<tr >';
print '<td colspan="2" align="left"><h3>' . $langs->trans("SiteArticle") . '</b></td>';
print '</tr>';
print '<tr><td align="left"><h4>' . $langs->trans("SiteProdOutStock") . '</b></td><td align="left"><h4>' . $langs->trans("SiteArticleStock") . '</b></td></tr>';
"\n";
print '<tr><td valign="top" align="left">';
if (count($taboutstock) > 0) {
    print '<table  width="95%">';
    print '<tr >';
    print '<th  align="left">' . $langs->trans("SiteProdId") . '</th>';
    print '<th  align="left">' . $langs->trans("ArticleRef") . '</th>';
    print '<th  align="left">' . $langs->trans("ArticleLib") . '</th>';
    print '<th  align="left">' . $langs->trans("ArticleStock") . '</th>';
    print '<th  align="left">' . $langs->trans("SiteName") . '</th>';
    print "</tr>\n";
    $var = True;
    foreach ($taboutstock as $elt) {
        print '<tr ' . $bc[$var] . '><td>';
        print $elt["fk_product"];
        print '</td><td>';
        print '<a href="' . dol_buildpath('/product/card.php', 1) . '?id=' . $elt["fk_product"] . '">' . $elt["ref"] . '</a>';
        print '</td><td>';
        print $elt["label"];
        print '</td><td align="left">';
        print $elt["qte_cde"];
        print '</td><td><a href="' . dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $siteid . '">' . $siteid . '</a>';
        print '</td></tr>';
        $var = !$var;
    }
    print '</table>';
}
print '</td>';
print '<td valign="top" align="left">';
if (count($tabproduct) > 0) {
    print '<table class="notopnoleftnoright" width="95%">';
    print '<tr >';
    print '<th  align="left">' . $langs->trans("SiteProdId") . '</th>';
    print '<th  align="left">' . $langs->trans("ArticleRef") . '</th>';
    print '<th  align="left">' . $langs->trans("ArticleLib") . '</th>';
    print '<th  align="left">' . $langs->trans("ArticleStock") . '</th>';
    print '<th  align="left">' . $langs->trans("SiteName") . '</th>';
    print "</tr>\n";
    $var = True;
    foreach ($tabproduct as $elt) {
        print '<tr ' . $bc[$var] . '><td>';
        print $elt["ecom_product"];
        print '</td><td>';
        print $elt["ref"];
        print '</td><td>';
        print $elt["label"];
        print '</td><td align="left">';
        print $elt["site_stock"];
        print '</td><td><a href="' . dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $siteid . '">' . $siteid . '</a>';
        print '</td></tr>';
        $var = !$var;
    }
    print '</table>';
}
print '</td></tr>';
print '<tr><td colspan="2">&nbsp;</td></tr>';
*/

// End of page
llxFooter();

$db->close();
?>
<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery("#checkall").click(function () {
            jQuery(".checkformerge").attr('checked', true);
        });
        jQuery("#checknone").click(function () {
            jQuery(".checkformerge").attr('checked', false);
        });
        $('#cat').select2();
        $('#categ').select2();
    });
</script>

