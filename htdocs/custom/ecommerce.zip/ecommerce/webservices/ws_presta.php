<?php
/* Copyright (C) 2014      Juanjo Menent	    <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
*/

define('NOCSRFCHECK',1);
$res = include_once("../master.inc.php");        // For root directory
if (!$res) $res = include_once("../../master.inc.php");
if (!$res) $res = include_once("../../../master.inc.php");

include_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
include_once DOL_DOCUMENT_ROOT.'/product/stock/class/mouvementstock.class.php';
$user->fetch('', $conf->global->ECOM_BATCH_USER, '');


//Chargement des droits
$user->getrights('');

dol_include_once("/ecommerce/includes/orders.inc.php");

dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/E_order.class.php");
dol_include_once("/ecommerce/class/ecom_log.class.php");
dol_include_once("/ecommerce/class/ecom_order.class.php");
dol_include_once("/ecommerce/core/lib/ecommerce.lib.php");
dol_include_once("/ecommerce/class/E_product.class.php");

include_once(DOL_DOCUMENT_ROOT ."/core/lib/functions.lib.php");

include_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");

//require_once(NUSOAP_PATH."/nusoap.php");
dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
$s = new soap_server;

// Register a method available for soap client
$s->register('neworder');
$s->register('updateproduct');
$s->register('updatequantity');

function neworder($siteid)
{
	global $db, $user, $conf;
	$result = array();
	$error = 0;

	if (!$conf->global->ECOM_ORDER_PRESTA2DOLI || !$siteid) {
		dol_syslog("ws_neworder:: syncro_orders_presta_2doli est désactivé ou siteid not indicated ", LOG_DEBUG);
		$result["result"] = 0;
		return $result;
	}
	else {
		$sql = "SELECT entity ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_site ";
		$sql .= " WHERE rowid = '" . $siteid . "' ";

		$resql = $db->query($sql);
		dol_syslog("ws_neworder:: " . $sql, LOG_DEBUG);

		if ($resql) {
			$num = $db->num_rows($resql);
			$i = 0;
			if ($num) {
				$obj = $db->fetch_object($resql);
				$conf->entity = $obj->entity;

				$res = get_orders($siteid, $db, $user);
				if (!$res)
					$error++;
				$res = import_orders($siteid, $db, $user);
				if (!$res)
					$error++;
			}
			else {
				$error++;
			}

		}

		dol_syslog("ws_neworder:: errors " . $error, LOG_DEBUG);

		if ($error)
			$result["result"] = -1;
		else
			$result["result"] = 1;

	}
	return $result;
}

function updateproduct($siteid,$productid)
{
	global $db, $user, $conf,$langs;
	$result = array();
	$error = 0;
    // Si option "Importation automatique des produits Prestashop modifiés" désactivée
	if (!$conf->global->ECOM_PRODUCT_PRESTA2DOLI || !$siteid) {
		dol_syslog("ws_update_product:: syncro_orders_presta_2doli,désactivé ou siteid ", LOG_DEBUG);
		$result["result"] = 0;
		return $result;
	}

    // import  product
    $e_prod = new E_product($db, $siteid, $user);
    $result=$e_prod->findInSite($productid);
    if($result>0) syncin_product($siteid,$productid);
    elseif ($e_prod->import_product_with_declinations($productid)) setEventMessage($langs->trans("msgImportProductWeb", GETPOST('ecomid', 'int')));// "traitement de l'import de ".$_POST['ecomid']." ". $_POST['ecomref'];
    else {
        setEventMessage($e_prod->error, 'errors');
        $error++;
    }

	if ($error)
		$result["result"] = -1;
	else
		$result["result"] = 1;
	return $result;
}
/*
function updatequantity($siteid, $idproduct, $id_product_attribute, $quantity)
{
    global $db, $user, $conf, $langs;
    $result = array();
    $error = 0;
    // Si option "Importation automatique des produits Prestashop modifiés" désactivée
    if (!$conf->global->ECOM_PRODUCT_PRESTA2DOLI || !$siteid) {
        dol_syslog("ws_updatequantity:: syncro_quantity_presta_2doli,désactivé ou siteid ", LOG_DEBUG);
        $result["result"] = 0;
        return $result;
    }
    $site = new Ecom_site($db);
    if ($site->fetch($siteid, $user) < 0) {
        $result["result"] = -1;
    	return $result;
    }

    // import  product
    $e_prod = new E_product($db, $siteid, $user);
    if (($rowid = $e_prod->findInSite($idproduct, $id_product_attribute)) > 0) {
        $e_prod->fetch($rowid);
        $p = new Product($db);
        $p->fetch($e_prod->doli_product);
        $p->load_stock();
        $mvt = new MouvementStock($db);
        $qtymove=$quantity -$p->stock_warehouse[$site->site_entrepot]->real;
        $mvt->reception($user, $p->id, $site->site_entrepot, $qtymove);
        $e_prod->site_stock=$quantity;
        $e_prod->update($user);
    }
    else {
        setEventMessage($e_prod->error, 'errors');
        $error++;
    }
    if ($error)
        $result["result"] = -1;
    else
        $result["result"] = 1;
	return $result;
}
*/

// Return the results.
$s->service(file_get_contents("php://input"));
