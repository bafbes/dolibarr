<?php
/* Copyright (C) 2007-2012 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *  \file       dev/skeletons/ecommanufacturer.class.php
 *  \ingroup    mymodule othermodule1 othermodule2
 *  \brief      This file is an example for a CRUD class file (Create/Read/Update/Delete)
 *                Initialy built by build_class_from_table on 2013-05-12 17:55
 */

// Put here all includes required by your class file
//require_once(DOL_DOCUMENT_ROOT."/core/class/commonobject.class.php");
//require_once(DOL_DOCUMENT_ROOT."/societe/class/societe.class.php");
//require_once(DOL_DOCUMENT_ROOT."/product/class/product.class.php");


/**
 *    Put here description of your class
 */
class Ecom_manufacturer // extends CommonObject
{
	var $db;                            //!< To store db handler
	var $error;                            //!< To return error code (or message)
	var $errors = array();                //!< To return several error codes (or messages)
	//var $element='ecommanufacturer';			//!< Id that identify managed objects
	//var $table_element='ecommanufacturer';	//!< Name of table without prefix where object is stored

	var $id;

	var $siteid;
	var $manutype;
	var $doli_manufacturer;
	var $ecom_manufacturer;
	var $ecom_manuname;
	var $datem = '';


	/**
	 *  Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *  Create object into database
	 *
	 * @param User $user User that create
	 * @param int $notrigger 0=launch triggers after, 1=disable triggers
	 * @return int                 <0 if KO, Id of created object if OK
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->manutype)) $this->manutype = trim($this->manutype);
		if (isset($this->doli_manufacturer)) $this->doli_manufacturer = trim($this->doli_manufacturer);
		if (isset($this->ecom_manufacturer)) $this->ecom_manufacturer = trim($this->ecom_manufacturer);
		if (isset($this->ecom_manuname)) $this->ecom_manuname = trim($this->ecom_manuname);


		// Check parameters
		// Put here code to add control on parameters values

		// Insert request
		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_manufacturer(";

		$sql .= "siteid,";
		$sql .= "manutype,";
		$sql .= "doli_manufacturer,";
		$sql .= "ecom_manufacturer,";
		$sql .= "ecom_manuname,";
		$sql .= "datem";


		$sql .= ") VALUES (";

		$sql .= " " . (!isset($this->siteid) ? 'NULL' : "'" . $this->siteid . "'") . ",";
		$sql .= " " . (!isset($this->manutype) ? 'NULL' : "'" . $this->manutype . "'") . ",";
		$sql .= " " . (!isset($this->doli_manufacturer) ? 'NULL' : "'" . $this->doli_manufacturer . "'") . ",";
		$sql .= " " . (!isset($this->ecom_manufacturer) ? 'NULL' : "'" . $this->ecom_manufacturer . "'") . ",";
		$sql .= " " . (!isset($this->ecom_manuname) ? 'NULL' : "'" . $this->db->escape($this->ecom_manuname) . "'") . ",";
		$sql .= " " . (!isset($this->datem) || dol_strlen($this->datem) == 0 ? 'NULL' : "'".$this->db->idate($this->datem). "'") ;
		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_manufacturer");

			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_CREATE',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}


	/**
	 *  Load object in memory from database
	 *
	 * @param int $id Id object
	 * @return int            <0 if KO, >0 if OK
	 */
	function fetch($id)
	{
		global $langs;
		$sql = "SELECT";
		$sql .= " t.rowid,";

		$sql .= " t.siteid,";
		$sql .= " t.manutype,";
		$sql .= " t.doli_manufacturer,";
		$sql .= " t.ecom_manufacturer,";
		$sql .= " t.ecom_manuname,";
		$sql .= " t.datem";


		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_manufacturer as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;

				$this->siteid = $obj->siteid;
				$this->manutype = $obj->manutype;
				$this->doli_manufacturer = $obj->doli_manufacturer;
				$this->ecom_manufacturer = $obj->ecom_manufacturer;
				$this->ecom_manuname = $obj->ecom_manuname;
				$this->datem = $this->db->jdate($obj->datem);


			}
			$this->db->free($resql);

			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 *  Update object into database
	 *
	 * @param User $user User that modify
	 * @param int $notrigger 0=launch triggers after, 1=disable triggers
	 * @return int                 <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->manutype)) $this->manutype = trim($this->manutype);
		if (isset($this->doli_manufacturer)) $this->doli_manufacturer = trim($this->doli_manufacturer);
		if (isset($this->ecom_manufacturer)) $this->ecom_manufacturer = trim($this->ecom_manufacturer);
		if (isset($this->ecom_manuname)) $this->ecom_manuname = trim($this->ecom_manuname);


		// Check parameters
		// Put here code to add control on parameters values

		// Update request
		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_manufacturer SET";

		$sql .= " siteid=" . (isset($this->siteid) ? $this->siteid : "null") . ",";
		$sql .= " manutype=" . (isset($this->manutype) ? $this->manutype : "null") . ",";
		$sql .= " doli_manufacturer=" . (isset($this->doli_manufacturer) ? $this->doli_manufacturer : "null") . ",";
		$sql .= " ecom_manufacturer=" . (isset($this->ecom_manufacturer) ? $this->ecom_manufacturer : "null") . ",";
		$sql .= " ecom_manuname=" . (isset($this->ecom_manuname) ? "'" . $this->db->escape($this->ecom_manuname) . "'" : "null") . ",";
		$sql .= " datem=" . (dol_strlen($this->datem) != 0 ? "'" . $this->db->idate($this->datem) . "'" : 'null') . "";


		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_MODIFY',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *  Delete object in database
	 *
	 * @param User $user User that delete
	 * @param int $notrigger 0=launch triggers after, 1=disable triggers
	 * @return    int                     <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$this->db->begin();

		if (!$error) {
			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_DELETE',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		if (!$error) {
			$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_manufacturer";
			$sql .= " WHERE rowid=" . $this->id;

			dol_syslog(get_class($this) . "::delete sql=" . $sql);
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				$this->errors[] = "Error " . $this->db->lasterror();
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *    Load an object from its id and create a new one in database
	 *
	 * @param int $fromid Id of object to clone
	 * @return    int                    New id of clone
	 */
	function createFromClone($fromid)
	{
		global $user, $langs;

		$error = 0;

		$object = new Ecommanufacturer($this->db);

		$this->db->begin();

		// Load source object
		$object->fetch($fromid);
		$object->id = 0;
		$object->statut = 0;

		// Clear fields
		// ...

		// Create clone
		$result = $object->create($user);

		// Other options
		if ($result < 0) {
			$this->error = $object->error;
			$error++;
		}

		if (!$error) {


		}

		// End
		if (!$error) {
			$this->db->commit();
			return $object->id;
		}
		else {
			$this->db->rollback();
			return -1;
		}
	}


	/**
	 *    Initialise object with example values
	 *    Id must be 0 if object instance is a specimen
	 *
	 * @return    void
	 */
	function initAsSpecimen()
	{
		$this->id = 0;

		$this->siteid = '';
		$this->manutype = '';
		$this->doli_manufacturer = '';
		$this->ecom_manufacturer = '';
		$this->ecom_manuname = '';
		$this->datem = '';


	}

}


