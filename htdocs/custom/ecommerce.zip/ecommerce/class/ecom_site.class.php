<?php
/* Copyright (C) 2007-2011 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2013      Philippe Grand       <philippe.grand@atoo-net.com>
 * Copyright (C) 2013      Juanjo Menent        <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *      \file       htdocs/ecommerce/class/ecom_site.class.php
 *      \ingroup    ecommerce
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */

/**
 *       \class      Ecom_site
 *       \brief      Ecom_site class for e-commerce site
 */
class Ecom_site extends CommonObject
{
	public $element = 'ecom_site';
	public $table_element = 'ecom_site';
	public $fk_element = 'site';
	public $ismultientitymanaged = 1;

	var $id;

	var $site_url;
	var $site_name;
	var $site_ws_url;
	var $site_ws_user;
	var $site_ws_pwd;
	var $site_entrepot;
	var $site_startdate = '';
	var $site_maxcategory;
	var $site_maxorder;
	var $site_maxproduct;
	var $site_maxclient;
	var $site_commercial;
	var $site_customercategory;
	var $site_prospectcategory;
	var $site_ecom_system;
	var $site_ecom_system_version;
	var $site_ecom_module_version;
	var $site_invoicetemplate;


	/**
	 *  Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *      Create object into database
	 * @param user            User that create
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, Id of created object if OK
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->site_url)) $this->site_url = trim($this->site_url);
		if (isset($this->site_name)) $this->site_name = trim($this->site_name);
		if (isset($this->site_ws_url)) $this->site_ws_url = trim($this->site_ws_url);
		if (isset($this->site_ws_user)) $this->site_ws_user = trim($this->site_ws_user);
		if (isset($this->site_ws_pwd)) $this->site_ws_pwd = trim($this->site_ws_pwd);
		if (isset($this->site_entrepot)) $this->site_entrepot = trim($this->site_entrepot);
		if (isset($this->site_maxcategory)) $this->site_maxcategory = trim($this->site_maxcategory);
		if (isset($this->site_maxorder)) $this->site_maxorder = trim($this->site_maxorder);
		if (isset($this->site_maxproduct)) $this->site_maxproduct = trim($this->site_maxproduct);
		if (isset($this->site_maxclient)) $this->site_maxclient = trim($this->site_maxclient);
		if (isset($this->site_commercial)) $this->site_commercial = trim($this->site_commercial);
		if (isset($this->site_customercategory)) $this->site_customercategory = trim($this->site_customercategory);
		if (isset($this->site_prospectcategory)) $this->site_prospectcategory = trim($this->site_prospectcategory);
		if (isset($this->site_ecom_system)) $this->site_ecom_system = trim($this->site_ecom_system);
		if (isset($this->site_ecom_system_version)) $this->site_ecom_system_version = trim($this->site_ecom_system_version);
		if (isset($this->site_ecom_module_version)) $this->site_ecom_module_version = trim($this->site_ecom_module_version);
		if (isset($this->site_invoicetemplate)) $this->site_invoicetemplate = trim($this->site_invoicetemplate);

		// Insert request
		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_site(";
		$sql .= "entity,";
		$sql .= "site_url,";
		$sql .= "site_name,";
		$sql .= "site_ws_url,";
		$sql .= "site_ws_user,";
		$sql .= "site_ws_pwd,";
		$sql .= "site_entrepot,";
		$sql .= "site_startdate,";
		$sql .= "site_maxcategory,";
		$sql .= "site_maxorder,";
		$sql .= "site_maxproduct,";
		$sql .= "site_maxclient,";
		$sql .= "site_commercial,";
		$sql .= "site_customercategory,";
		$sql .= "site_prospectcategory,";
		$sql .= "site_ecom_system,";
		$sql .= "site_ecom_system_version,";
		$sql .= "site_ecom_module_version,";
		$sql .= "site_invoicetemplate";
		$sql .= ") VALUES (";

		$sql .= " " . $conf->entity . ",";
		$sql .= " " . (!isset($this->site_url) ? 'NULL' : "'" . $this->db->escape($this->site_url) . "'") . ",";
		$sql .= " " . (!isset($this->site_name) ? 'NULL' : "'" . $this->db->escape($this->site_name) . "'") . ",";
		$sql .= " " . (!isset($this->site_ws_url) ? 'NULL' : "'" . $this->db->escape($this->site_ws_url) . "'") . ",";
		$sql .= " " . (!isset($this->site_ws_user) ? 'NULL' : "'" . $this->db->escape($this->site_ws_user) . "'") . ",";
		$sql .= " " . (!isset($this->site_ws_pwd) ? 'NULL' : "'" . $this->db->escape($this->site_ws_pwd) . "'") . ",";
		$sql .= " " . (!isset($this->site_entrepot) ? 'NULL' : "'" . $this->site_entrepot . "'") . ",";
		$sql .= " " . (!isset($this->site_startdate) || dol_strlen($this->site_startdate) == 0 ? 'NULL' : "'" . $this->db->idate($this->site_startdate)) . "',";
		$sql .= " " . (!isset($this->site_maxcategory) ? 'NULL' : "'" . $this->site_maxcategory . "'") . ",";
		$sql .= " " . (!isset($this->site_maxorder) ? 'NULL' : "'" . $this->site_maxorder . "'") . ",";
		$sql .= " " . (!isset($this->site_maxproduct) ? 'NULL' : "'" . $this->site_maxproduct . "'") . ",";
		$sql .= " " . (!isset($this->site_maxclient) ? 'NULL' : "'" . $this->site_maxclient . "'") . ",";
		$sql .= " " . (!isset($this->site_commercial) ? 'NULL' : "'" . $this->site_commercial . "'") . ",";
		$sql .= " " . (!isset($this->site_customercategory) ? 'NULL' : "'" . $this->site_customercategory . "'") . ",";
		$sql .= " " . (!isset($this->site_prospectcategory) ? 'NULL' : "'" . $this->site_prospectcategory . "'") . ",";
		$sql .= " " . (!isset($this->site_ecom_system) ? 'NULL' : "'" . $this->db->escape($this->site_ecom_system) . "'") . ",";
		$sql .= " " . (!isset($this->site_ecom_system_version) ? 'NULL' : "'" . $this->db->escape($this->site_ecom_system_version) . "'") . ",";
		$sql .= " " . (!isset($this->site_ecom_module_version) ? 'NULL' : "'" . $this->db->escape($this->site_ecom_module_version) . "'") . ",";
		$sql .= " " . (!isset($this->site_invoicetemplate) ? 'NULL' : "'" . $this->db->escape($this->site_invoicetemplate) . "'") . "";

		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_site");

			if (!$notrigger) {

			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}


	/**
	 *  Load object in memory from the database
	 *
	 * @param int $id Id object
	 * @return int                        <0 if KO, >0 if OK
	 */
	function fetch($id)
	{
		global $langs;

		$sql = "SELECT";
		$sql .= " t.rowid,";
		$sql .= " t.site_url,";
		$sql .= " t.site_name,";
		$sql .= " t.site_ws_url,";
		$sql .= " t.site_ws_user,";
		$sql .= " t.site_ws_pwd,";
		$sql .= " t.site_entrepot,";
		$sql .= " t.site_startdate,";
		$sql .= " t.site_maxcategory,";
		$sql .= " t.site_maxorder,";
		$sql .= " t.site_maxproduct,";
		$sql .= " t.site_maxclient,";
		$sql .= " t.site_commercial,";
		$sql .= " t.site_customercategory,";
		$sql .= " t.site_prospectcategory,";
		$sql .= " t.site_ecom_system,";
		$sql .= " t.site_ecom_system_version,";
		$sql .= " t.site_ecom_module_version,";
		$sql .= " t.site_invoicetemplate";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_site as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;

				$this->site_url = $obj->site_url;
				$this->site_name = $obj->site_name;
				$this->site_ws_url = $obj->site_ws_url;
				$this->site_ws_user = $obj->site_ws_user;
				$this->site_ws_pwd = $obj->site_ws_pwd;
				$this->site_entrepot = $obj->site_entrepot;
				$this->site_startdate = $this->db->jdate($obj->site_startdate);
				$this->site_maxcategory = $obj->site_maxcategory;
				$this->site_maxorder = $obj->site_maxorder;
				$this->site_maxproduct = $obj->site_maxproduct;
				$this->site_maxclient = $obj->site_maxclient;
				$this->site_commercial = $obj->site_commercial;
				$this->site_customercategory = $obj->site_customercategory;
				$this->site_prospectcategory = $obj->site_prospectcategory;
				$this->site_ecom_system = $obj->site_ecom_system;
				$this->site_ecom_system_version = $obj->site_ecom_system_version;
				$this->site_ecom_module_version = $obj->site_ecom_module_version;
				$this->site_invoicetemplate = $obj->site_invoicetemplate;
				$ret = 1;
			}
			else $ret = 0;

			$this->db->free($resql);
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}

		return $ret;
	}


	/**
	 *  Update object into database
	 *
	 * @param User $user User that modifies
	 * @param int $notrigger 0=launch triggers after, 1=disable triggers
	 * @return int                 <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->site_url)) $this->site_url = trim($this->site_url);
		if (isset($this->site_name)) $this->site_name = trim($this->site_name);
		if (isset($this->site_ws_url)) $this->site_ws_url = trim($this->site_ws_url);
		if (isset($this->site_ws_user)) $this->site_ws_user = trim($this->site_ws_user);
		if (isset($this->site_ws_pwd)) $this->site_ws_pwd = trim($this->site_ws_pwd);
		if (isset($this->site_entrepot)) $this->site_entrepot = trim($this->site_entrepot);
		if (isset($this->site_maxcategory)) $this->site_maxcategory = trim($this->site_maxcategory);
		if (isset($this->site_maxorder)) $this->site_maxorder = trim($this->site_maxorder);
		if (isset($this->site_maxproduct)) $this->site_maxproduct = trim($this->site_maxproduct);
		if (isset($this->site_maxclient)) $this->site_maxclient = trim($this->site_maxclient);
		if (isset($this->site_commercial)) $this->site_commercial = trim($this->site_commercial);
		if (isset($this->site_customercategory)) $this->site_customercategory = trim($this->site_customercategory);
		if (isset($this->site_prospectcategory)) $this->site_prospectcategory = trim($this->site_prospectcategory);
		if (isset($this->site_ecom_system)) $this->site_ecom_system = trim($this->site_ecom_system);
		if (isset($this->site_ecom_system_version)) $this->site_ecom_system_version = trim($this->site_ecom_system_version);
		if (isset($this->site_ecom_module_version)) $this->site_ecom_module_version = trim($this->site_ecom_module_version);
		if (isset($this->site_invoicetemplate)) $this->site_invoicetemplate = trim($this->site_invoicetemplate);


		// Update request
		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_site SET";

		$sql .= " site_url=" . (isset($this->site_url) ? "'" . $this->db->escape($this->site_url) . "'" : "null") . ",";
		$sql .= " site_name=" . (isset($this->site_name) ? "'" . $this->db->escape($this->site_name) . "'" : "null") . ",";
		$sql .= " site_ws_url=" . (isset($this->site_ws_url) ? "'" . $this->db->escape($this->site_ws_url) . "'" : "null") . ",";
		$sql .= " site_ws_user=" . (isset($this->site_ws_user) ? "'" . $this->db->escape($this->site_ws_user) . "'" : "null") . ",";
		$sql .= " site_ws_pwd=" . (isset($this->site_ws_pwd) ? "'" . $this->db->escape($this->site_ws_pwd) . "'" : "null") . ",";
		$sql .= " site_entrepot=" . (isset($this->site_entrepot) ? $this->site_entrepot : "null") . ",";
		$sql .= " site_startdate=" . (dol_strlen($this->site_startdate) != 0 ? "'" . $this->db->idate($this->site_startdate) . "'" : 'null') . ",";
		$sql .= " site_maxcategory=" . (isset($this->site_maxcategory) ? $this->site_maxcategory : "null") . ",";
		$sql .= " site_maxorder=" . (isset($this->site_maxorder) ? $this->site_maxorder : "null") . ",";
		$sql .= " site_maxproduct=" . (isset($this->site_maxproduct) ? $this->site_maxproduct : "null") . ",";
		$sql .= " site_maxclient=" . (isset($this->site_maxclient) ? $this->site_maxclient : "null") . ",";
		$sql .= " site_commercial=" . (isset($this->site_commercial) ? $this->site_commercial : "null") . ",";
		$sql .= " site_customercategory=" . (isset($this->site_customercategory) ? $this->site_customercategory : "null") . ",";
		$sql .= " site_prospectcategory=" . (isset($this->site_prospectcategory) ? $this->site_prospectcategory : "null") . ",";
		$sql .= " site_ecom_system=" . (isset($this->site_ecom_system) ? "'" . $this->db->escape($this->site_ecom_system) . "'" : "null") . ",";
		$sql .= " site_ecom_system_version=" . (isset($this->site_ecom_system_version) ? "'" . $this->db->escape($this->site_ecom_system_version) . "'" : "null") . ",";
		$sql .= " site_ecom_module_version=" . (isset($this->site_ecom_module_version) ? "'" . $this->db->escape($this->site_ecom_module_version) . "'" : "null") . ",";
		$sql .= " site_invoicetemplate=" . (isset($this->site_invoicetemplate) ? "'" . $this->db->escape($this->site_invoicetemplate) . "'" : "null") . "";

		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *  Delete object in database
	 *
	 * @param User $user User that deletes
	 * @param int $notrigger 0=launch triggers after, 1=disable triggers
	 * @return    int                            <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_site";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::delete sql=" . $sql);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *    Initialise object with example values
	 *    Id must be 0 if object instance is a specimen
	 *
	 * @return    void
	 */
	function initAsSpecimen()
	{
		$this->id = 0;

		$this->site_url = '';
		$this->site_name = '';
		$this->site_ws_url = '';
		$this->site_ws_user = '';
		$this->site_ws_pwd = '';
		$this->site_entrepot = '';
		$this->site_startdate = '';
		$this->site_maxcategory = '';
		$this->site_maxorder = '';
		$this->site_maxproduct = '';
		$this->site_maxclient = '';
		$this->site_commercial = '';
		$this->site_customercategory = '';
		$this->site_prospectcategory = '';
		$this->site_ecom_system = '';
		$this->site_ecom_system_version = '';
		$this->site_ecom_module_version = '';
		$this->site_invoicetemplate = '';
	}

}


