<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010      Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013 Philippe Grand       <philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       htdocs/ecommerce/class/ecom_log.class.php
 *      \ingroup    products
 *      \class      Ecom_log
 *      \brief      Log class for e-commerce site
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */
class Ecom_log extends CommonObject
{
	var $id;

	var $site_id;
	var $log_date = '';
	var $log_fct;
	var $log_type;
	var $log_fonction;
	var $log_message;


	/**
	 *   Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *      Create in database
	 * @param user            User that create
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, Id of created object if OK
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->site_id)) $this->site_id = trim($this->site_id);
		if (isset($this->log_fct)) $this->log_fct = trim($this->log_fct);
		if (isset($this->log_type)) $this->log_type = trim($this->log_type);
		if (isset($this->log_fonction)) $this->log_fonction = trim($this->log_fonction);
		if (isset($this->log_message)) $this->log_message = trim($this->log_message);


		// Insert request

		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_log(";
		$sql .= "site_id,";
		$sql .= "log_date,";
		$sql .= "log_fct,";
		$sql .= "log_type,";
		$sql .= "log_fonction,";
		$sql .= "log_message";


		$sql .= ") VALUES (";
		$sql .= " " . (!isset($this->site_id) ? 'NULL' : "'" . $this->site_id . "'") . ",";
		$sql .= " " . (!isset($this->log_date) || dol_strlen($this->log_date) == 0 ? 'NULL' : "'" . $this->db->idate($this->log_date)) . "',";
		$sql .= " " . (!isset($this->log_fct) ? 'NULL' : "'" . $this->db->escape($this->log_fct) . "'") . ",";
		$sql .= " " . (!isset($this->log_type) ? 'NULL' : "'" . $this->db->escape($this->log_type) . "'") . ",";
		$sql .= " " . (!isset($this->log_fonction) ? 'NULL' : "'" . $this->db->escape($this->log_fonction) . "'") . ",";
		$sql .= " " . (!isset($this->log_message) ? 'NULL' : "'" . $this->db->escape($this->log_message) . "'") . "";
		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_log");

			if (!$notrigger) {

			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}


	/**
	 *    Load object in memory from database
	 *
	 * @param id          id object
	 * @return     int         <0 if KO, >0 if OK
	 */
	function fetch($id)
	{
		global $langs;
		$sql = "SELECT";
		$sql .= " t.rowid,";
		$sql .= " t.site_id,";
		$sql .= " t.log_date,";
		$sql .= " t.log_fct,";
		$sql .= " t.log_type,";
		$sql .= " t.log_fonction,";
		$sql .= " t.log_message";

		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_log as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;
				$this->site_id = $obj->site_id;
				$this->log_date = $this->db->jdate($obj->log_date);
				$this->log_fct = $obj->log_fct;
				$this->log_type = $obj->log_type;
				$this->log_fonction = $obj->log_fonction;
				$this->log_message = $obj->log_message;


			}
			$this->db->free($resql);

			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 *      Update database
	 *
	 * @param user            User that modify
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->site_id)) $this->site_id = trim($this->site_id);
		if (isset($this->log_fct)) $this->log_fct = trim($this->log_fct);
		if (isset($this->log_type)) $this->log_type = trim($this->log_type);
		if (isset($this->log_fonction)) $this->log_fonction = trim($this->log_fonction);
		if (isset($this->log_message)) $this->log_message = trim($this->log_message);


		// Update request

		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_log SET";
		$sql .= " site_id=" . (isset($this->site_id) ? $this->site_id : "null") . ",";
		$sql .= " log_date=" . (dol_strlen($this->log_date) != 0 ? "'" . $this->db->idate($this->log_date) . "'" : 'null') . ",";
		$sql .= " log_fct=" . (isset($this->log_fct) ? "'" . $this->db->escape($this->log_fct) . "'" : "null") . ",";
		$sql .= " log_type=" . (isset($this->log_type) ? "'" . $this->db->escape($this->log_type) . "'" : "null") . ",";
		$sql .= " log_fonction=" . (isset($this->log_fonction) ? "'" . $this->db->escape($this->log_fonction) . "'" : "null") . ",";
		$sql .= " log_message=" . (isset($this->log_message) ? "'" . $this->db->escape($this->log_message) . "'" : "null") . "";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *   Delete object in database
	 *
	 * @param user            User that delete
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_log";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::delete sql=" . $sql);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}

}


