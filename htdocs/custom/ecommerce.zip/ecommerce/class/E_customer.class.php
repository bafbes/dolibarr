<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2011      Philippe Grand       <philippe.grand@atoo-net.com>
 * Copyright (C) 2013      Jean Heimburger       <jean@tiaris.info>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *       \file       dev/skeletons/ecom_customer.class.php
 *       \ingroup    mymodule othermodule1 othermodule2
 *       \brief      This file is an example for a class file
 *         \version    $Id: E_customer.class.php,v 1.3.4.4.2.1 2012-06-23 09:41:59 tiaris Exp $
 *         \author     Put author name here
 *         \remarks     Initialy built by build_class_from_table on 2008-03-19 21:38
 */

/**
 *       \class      E_customer
 *       \brief      Put here description of your class
 *         \remarks     Initialy built by build_class_from_table on 2008-03-19 21:38
 */

//dol_include_once("/ecommerce/common_functions.php");
dol_include_once("/ecommerce/class/ecom_customer.class.php");
dol_include_once("/ecommerce/class/ecom_contact.class.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
require_once(DOL_DOCUMENT_ROOT . "/societe/class/societe.class.php");
require_once(DOL_DOCUMENT_ROOT . "/contact/class/contact.class.php");

class E_customer extends Ecom_customer
{

	var $e_custsoc;
	var $e_custcode; // Code Client e-commerce
	var $e_custfirstname;
	var $e_custlastname;
	var $e_custstreet;
	var $e_custpostcode;
	var $e_custcity;
	var $e_custtel;
	var $e_custmobile;
	var $e_custfax;
	var $e_custmail;
	var $e_custidcountry;
	var $e_custcodecountry;
	var $e_custcountry;
	var $e_vatnumber;
	var $e_dni;

	var $site;
	var $siteid;

	var $user;

	// tableau des doublons
	var $doublons = array();


	function E_customer($DB, $siteid, $user)
	{
		$this->db = $DB;
		$this->site = new Ecom_site($this->db);
		$this->user = $user;
		if ($this->site->fetch($siteid, $user) < 0) {
			dol_syslog("E_cutomer::Constructeur $site->error", LOG_DEBUG);
			return -1;
		}
		$this->siteid = $siteid;

		return 1;
	}

	function wsfetch($id = '')
	{

		global $conf, $langs;

		$this->error = '';
		dol_syslog("E_customer::fetch id=$id ");
		// Verification parametres
		if (!$id) {
			$this->error = $langs->trans('ErrorWrongParameters');
			return -1;
		}

		//WebService Client.
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

		// Set the parameters to send to the WebService
		$parameters = array("custid" => $id);

		// Set the WebService URL
		$client = new nusoap_client($this->site->site_ws_url . "/ws_customers.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

		// Call the WebService (client->fault) and store its result in $obj
		$obj = $client->call("get_Client", $parameters);

		if ($client->fault) {
			$this->error = "Fault detected " . $client->getError();
			return -1;
		}
		elseif (!($err = $client->getError())) {
			$this->ecom_customer = $obj[0]["customers_id"];
			$this->e_custcode = convertCharset($obj[0]["customers_code"]);
			$this->e_custsoc = convertCharset($obj[0]["entry_company"]);
			$this->e_custfirstname = convertCharset($obj[0]["entry_firstname"]);
			$this->e_custlastname = convertCharset($obj[0]["entry_lastname"]);
			$this->e_custstreet = convertCharset($obj[0]["entry_street_address"]);
			$this->e_custpostcode = convertCharset($obj[0]["entry_postcode"]);
			$this->e_custcity = convertCharset($obj[0]["entry_city"]);
			$this->e_custtel = $obj[0]["customers_telephone"];
			$this->e_custmobile = $obj[0]["customers_mobile"];
			$this->e_custfax = $obj[0]["customers_fax"];
			$this->e_custmail = convertCharset($obj[0]["customers_email_address"]);
			$this->e_custidcountry = $obj[0]["entry_country_id"];
			$this->e_custcodecountry = $obj[0]["countries_iso_code_2"];
			$this->e_custcountry = convertCharset($obj[0]["countries_name"]);
			$this->e_custcodestate = (!empty($obj[0]["state_iso_code"]) ? $obj[0]["state_iso_code"] : '');
			$this->e_custstate = convertCharset($obj[0]["state_name"]);
			$this->address_id = $obj[0]["default_address_id"];
			$this->e_vatnumber = $obj[0]["vat_number"];
			$this->e_siret = $obj[0]["siret"];
			$this->e_dni = $obj[0]["dni"];
		}
		else {
			$this->error .= 'Erreur wsfetch ' . $err;
			return -1;
		}
		return 1;
	}


	function ecom2dolibarr($ecom_custid)
	{
		global $conf, $langs;

		$result = $this->wsfetch($ecom_custid);

		if ($result) {
			$societe = new Societe($this->db);
			if ($_error == 1) {
				dol_syslog("E_customer::ecom2dolibarr erreur création société", LOG_DEBUG);
				return '';
			}

			/* initialisation */
			if (!$this->e_custsoc) {
				// c'est un particulier
				$societe->nom = $this->e_custfirstname . ' ' . $this->e_custlastname;
				$societe->particulier = 1;
				$societe->typent_id = 8;
			}
			else {
				// c'est une societe
				$societe->nom = $this->e_custsoc;
				$societe->particulier = 0;
			}
			$societe->nom_particulier = $this->e_custlastname;
			$societe->prenom = $this->e_custfirstname;
			$societe->address = $this->e_custstreet;
			$societe->cp = $this->e_custpostcode;
			$societe->zip = $this->e_custpostcode;
			$societe->ville = $this->e_custcity;
			$societe->town = $this->e_custcity;
			$societe->departement_id = 0;
			$societe->pays_code = $this->e_custcodecountry;
			$societe->country_code = $this->e_custcodecountry;
			$societe->country_id = $this->get_paysid($this->e_custcodecountry);
			$societe->pays_id = $societe->country_id;
			$societe->tel = $this->e_custtel;
			$societe->phone = $this->e_custtel;
			$societe->fax = $this->e_custfax;
			$societe->email = $this->e_custmail;
			if (!empty($this->e_vatnumber)) $societe->tva_intra = $this->e_vatnumber;
			$societe->siret = (!empty($this->e_siret) ? $this->e_siret : ''); //TODO vérifier quel idprof mettre
			if (!empty($this->e_dni)) $societe->idprof1 = $this->e_dni;
			$societe->state_code = $this->e_custcodestate;
			$societe->state_id = $this->get_stateid($this->e_custcodestate, $societe->pays_id);

			if (!empty($conf->global->ECOM_CHAMP_DOUBLON) && !empty($this->e_dni)) {
				switch ($conf->global->ECOM_CHAMP_DOUBLON) {
					case "idprof1":
						$societe->idprof1 = $this->e_dni;
						break;
					case "idprof2":
						$societe->idprof2 = $this->e_dni;
						break;
					case "idprof3":
						$societe->idprof3 = $this->e_dni;
						break;
					case "idprof4":
						$societe->idprof4 = $this->e_dni;
						break;
					case "idprof5":
						$societe->idprof5 = $this->e_dni;
						break;
					case "idprof6":
						$societe->idprof6 = $this->e_dni;
						break;
				}
			}
			dol_syslog("controle nni " . $conf->global->ECOM_CHAMP_DOUBLON . " " . $this->e_dni . " state " . $societe->state_code . " " . $societe->state_id . " VAT " . $this->e_vatnumber, LOG_DEBUG);
			/* on force */
			$societe->url = '';
			$societe->siren = '';
			$societe->ape = '';
			$societe->client = 1; // mettre 0 si prospect


			$error = "";

			dol_syslog("E_cutomer::ecom2dolibarr $this->e_custsoc", LOG_DEBUG);
		}
		else {
			dol_syslog("E_customer::ecom2dolibarr " . $this->error, LOG_DEBUG);
			return '';
		}
		dol_syslog("E_customer::ecom2dolibarr nom " . $societe->nom, LOG_DEBUG);
		return $societe;
	}

	// importe un client ecommerce et créé la société et le contact
	function import_customer($custid, $type = 'C')
	{
		$error = 0;
		$soc = new Societe($this->db);
		dol_syslog("E_customer::import_customer ", LOG_DEBUG);
		$soc = $this->ecom2dolibarr($custid);
		if (!soc) {
			$this->error .= " Erreur conversion ecom2dolibarr ";
			dol_syslog("E_customer::import_customer conversion client �chou� " . $this->error);
			return -1;
		}

		/*
		 * code_client permettant de différencier les clients selon le code
		* qu'ils ont renseigné dans la page configuration de Dolipresta
		*/
		if (empty($this->e_custcode)) {
			$soc->code_client = -1;
		}
		else {
			$soc->code_client = $this->e_custcode;
		}

		// prospect ou client
		if ($type == 'P') $soc->client = 2;
		else $soc->client = 1;

		$creation = false;
		// Is client in ecom_customer
		$res = $this->findInSite($custid, $this->siteid);
		if ($res > 0) {

			dol_syslog(get_class($this) . ":: trouvé " . $this->doli_soc . "  " . $this->ecom_customer, LOG_DEBUG);
			$soc->id = $this->doli_soc;
			if ($this->doli_soc <= 0) $creation = true;
		}
		else {

			// test si client existe dans dolibarr
			$doublons_method = 0;
			$existedoublons = $this->findInDolibarr($soc, $doublons_method);
			dol_syslog(get_class($this) . ":: doublons " . $existedoublons, LOG_DEBUG);

			switch ($existedoublons) {
				case 0:
					// il faut créer une société
					$creation = true;
					break;
				case 1:
					// on relie à la société existante dans Dolibarr
					$soc->id = $this->doublons[0]->rowid;
					// TODO mise à jour données ? créer un contact par défaut
					break;
				default:
					if ($existedoublons < 0) {
						$this->error = " unexpected value for existedoublons " . $existedoublons;
						dol_syslog(get_class($this) . ":" . __METHOD__ . " unexpected value for existedoublons " . $existedoublons, LOG_ERR);
						$error++;
					}
					else {
						// A traiter
						dol_syslog(get_class($this) . ":" . __METHOD__ . " traitement des doublons", LOG_DEBUG);
						$soc->id = -1;
					}
			}
		}

		dol_syslog("E_customer::import_customer avant enreg " . $soc->nom . " creation " . $creation . " existedoublons " . $existedoublons, LOG_DEBUG);

		$this->db->begin();

		if ($creation && !$error) {
			// création de la société
            $res=$soc->create($this->user);
            if ($res< 0) {
				$this->error .= " Erreur creation societe " . $custid;
				$error++;
				dol_syslog("E_customer::import_customer creation societe echouee " . $soc->errors[0], LOG_DEBUG);
			}
			else {
				dol_syslog("E_customer::import_customer creation societe OK " . $soc->id, LOG_DEBUG);
				if ($this->add_to_categorie($soc) < 0) {
					dol_syslog("E_customer::import_customer catégorisation KO", LOG_ERR);
				}
				else dol_syslog("E_customer::import_customer catégorisation OK", LOG_DEBUG);

				if ($this->site->site_commercial) {
					$soc->add_commercial($this->user, $this->site->site_commercial);
					dol_syslog("E_customer::import_customer ajout commercial " . $this->site->site_commercial, LOG_DEBUG);
				}
			}
		}

		if (!$error) {
			// enregistrement dans ecom_customer
			$this->siteid = $this->site->id;
			$this->doli_soc = $soc->id;
			$this->datem = dol_now();
			$this->site_cust_status = $type;

			if ($type == 'P') {
				$prospectid = $this->findInSite($custid, $this->site->id);
				if ($prospectid > 0) {
					$this->doli_soc = $soc->id;
					$this->datem = dol_now();
					$this->site_cust_status = $type;
					if ($this->update() < 0) {
						$this->error .= " Erreur mise à jour ecom_customer ";
						dol_syslog("E_customer::import_customer mise à jour ecom_customer échouée " . $this->error);
						$error++;
					}
				}
				else {
					$this->error .= " Erreur prospect introuvable ";
					dol_syslog("E_customer::import_customer " . $this->error);
					$error++;
				}
			}
			else {
				// contact par défaut créé dans tous le cas
				if (!$error) {
					// creation du contact
					dol_syslog("E_customer:: import_customer creation contact", LOG_DEBUG);
					$adr = array();

					$adr["civilite_id"] = $soc->civilite_id;
					$adr["nom_particulier"] = $soc->nom_particulier;
					$adr["prenom"] = $soc->prenom;
					$adr["adresse"] = $soc->address;
					$adr["cp"] = $soc->cp;  // zip
					$adr["ville"] = $soc->ville; // town
					$adr["pays_id"] = $soc->country_id;
					$adr["pays_code"] = $this->e_custcodecountry;
					$adr["state_code"] = $this->e_custcodestate;
					$adr["state_id"] = $soc->state_id;
					$adr["email"] = $soc->email;
					$adr["telephone"] = $this->e_custtel;
					$adr["mobile"] = $this->e_custmobile;


					dol_syslog("E_customer::import_customer creation contact par défaut " . $this->address_id, LOG_DEBUG);
                    $result=$this->new_societe_contact($soc->id, $adr, $this->address_id, 1);
                    if ( $result< 0) //TODO le ws doit ramener l'id adresse id adresse =0 pour adresse principale
					{
						$this->error .= " Erreur creation contact " . $custid;
						$error++;
						dol_syslog("E_customer::import_customer creation contact echouee " . $contact->errors[0]);
					}
				}
                $this->doli_soc=$soc->id;
                $result=$this->create($this->user) ;
				if ($result< 0) {
					$this->error .= " Erreur creation ecom_customer ";
					doli_syslog("E_customer::import_customer création ecom_customer échouée " . $this->error);
					$error++;
				}
			}
		}
		if ($error > 0) {
			dol_syslog("E_customer:: import_customer création contact ratée " . $this->error, LOG_DEBUG);
			$this->db->rollback();
			return -1;
		}
		else {
			$this->db->commit();
			dol_syslog("E_customer:: import_customer création réussie");
		}

		if ($existedoublons > 1) {
			$this->error = " unable to determine customer " . $existedoublons . " possible ";
			dol_syslog(get_class($this) . ":" . __METHOD__ . " unable to determine customer " . $existedoublons . " possible ", LOG_ERR);
			return -1;
		}
		return 0;
	}

	function add_to_categorie($doli_soc)
	{
		global $langs;
		if (!$dolicat) {
			if ($doli_soc->client == 1) $dolicat = $this->site->site_customercategory;
			elseif ($doli_soc->client == 2) $dolicat = $this->site->site_prospectcategory;
			else $dolicat = 0;
		}

		$type = 'customer';
		//	dol_syslog("société ".$doli_soc->name."  ".$doli_soc->client." catégorie ".$dolicat." site ".print_r($doli_soc,true), LOG_DEBUG);

		if ($dolicat) {
			dol_syslog("classement catégorie " . $dolicat, LOG_DEBUG);
			$cat = new Categorie($this->db);
			$result = $cat->fetch($dolicat);

			$result = $cat->add_type($doli_soc, $type);
			if ($result >= 0) {
				$mesg = $langs->trans("WasAddedSuccessfully", $cat->label);
			}
			else {
				if ($cat->error == 'DB_ERROR_RECORD_ALREADY_EXISTS') $mesg = $langs->trans("ObjectAlreadyLinkedToCategory");
				else {
					$mesg = $langs->trans("Error") . ' ' . $cat->error;
					dol_syslog("E_customer::add_to_categorie " . $mesg, LOG_ERR);
					return -1;
				}
			}
			dol_syslog("E_customer::add_to_categorie " . $mesg, LOG_DEBUG);
		}

		return $dolicat;
	}

	/*
		 * control if customer exists in dolibarr
		 * soc : societe object
		 * type : default 0 : by name,
		 * 			1 :	+ e-mail
		 * 			2 : + country
		 * TODO affiner recherche de doublons
		 */
	function findInDolibarr($soc, $type = 0)
	{
		global $conf;

		$this->doublons = array();
		$socid = 0;

		dol_syslog(get_class($this) . ":" . __METHOD__ . "entréé " . empty($conf->global->ECOM_RECHDOUBLONS), LOG_DEBUG);
// fonction désactivée
		if (empty($conf->global->ECOM_RECHDOUBLONS)) return 0;
		$sql = "SELECT s.rowid, s.nom, s.email, s.fk_pays, p.label as pays ";
		$sql .= ',s.zip, s.town ';
		$sql .= "FROM " . MAIN_DB_PREFIX . "societe s ";
		$sql .= " JOIN " . MAIN_DB_PREFIX . "c_country p ON p.rowid = s.fk_pays ";

		if ($conf->global->ECOM_RECHDOUBLONS == 1) {
			// pour une société recherche sur VAT
			if ($soc->particulier == 0) {
				// TODO $soc->particulier est deprecated en 3.4
				if (!empty($soc->tva_intra)) $sql .= " WHERE s.tva_intra = '" . $soc->tva_intra . "'";
				elseif (!empty($soc->idprof1) && !empty($conf->global->ECOM_CHAMP_DOUBLON)) $sql .= " WHERE s." . $conf->global->ECOM_CHAMP_DOUBLON . " = '" . $soc->idprof1 . "'";
				else return 0; // impossible pas de n° tva ou siret
			}
			else {
				if (!empty($soc->idprof1) && !empty($conf->global->ECOM_CHAMP_DOUBLON)) {
					// particulier recherche sur champ indiqué
					$sql .= " WHERE s." . $conf->global->ECOM_CHAMP_DOUBLON . " = '" . $soc->idprof1 . "'";
				}
				else return 0;
			}
		}
		elseif ($conf->global->ECOM_RECHDOUBLONS == 9) {
			// Déconseillée par nom et e-mail
			$sql .= " WHERE upper(s.nom)='" . strtoupper($this->db->escape($soc->nom)) . "'";
			if ($type == 1) $sql .= " AND s.email='" . $soc->email . "'";
			if ($type == 2) $sql .= " AND s.fk_pays='" . $soc->pays_id . "'";
		}


		dol_syslog(get_class($this) . ":" . __METHOD__ . " sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			$doublons = 0;
			while ($obj = $this->db->fetch_object($resql)) {
				$this->doublons[] = $obj;
				$doublons++;
			}
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . ":" . __METHOD__ . " " . $this->error, LOG_ERR);
			return -1;
		}

		dol_syslog(get_class($this) . ":" . __METHOD__ . " " . print_r($this->doublons, true), LOG_DEBUG);
		return $doublons;
	}

	/*
	 * test if ecom customer is allready in table
	 */
	function findInSite($custid, $siteid)
	{
		$sql = "SELECT c.rowid FROM " . MAIN_DB_PREFIX . "ecom_customer c";
		$sql .= " WHERE c.ecom_customer = '" . $custid . "' AND c.siteid = '" . $siteid . "'";

		dol_syslog(get_class($this) . ":" . __METHOD__ . " sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$this->id = $obj->rowid;
				dol_syslog(get_class($this) . ":" . __METHOD__ . " " . $this->db->num_rows($resql), LOG_DEBUG);
				/* initialisation de l'objet */
				$this->fetch($this->id);
			}
			else return 0;
			$this->db->free($resql);
			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . ":" . __METHOD__ . " " . $this->error, LOG_ERR);
			return -1;
		}
	}

	/*
	 * test if doli customer is allready in table
	 */
	function findCustInSite($custid)
	{
		$sql = "SELECT c.rowid FROM " . MAIN_DB_PREFIX . "ecom_customer c";
		$sql .= " WHERE c.doli_soc = '" . $custid . "' AND c.siteid = '" . $this->site->id . "'";

		dol_syslog(get_class($this) . ":" . __METHOD__ . " sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$this->id = $obj->rowid;
				/* initialisation de l'objet */
				$this->fetch($this->id);
			}
			else return 0;
			$this->db->free($resql);
			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . ":" . __METHOD__ . " " . $this->error, LOG_ERR);
			return -1;
		}
	}

	function get_paysid($code_pays)
	{
		$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "c_country ";
		$sql .= " WHERE code = '" . $code_pays . "'";

		dol_syslog(get_class($this) . ":" . __METHOD__ . " sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$res = $obj->rowid;
			}
			$this->db->free($resql);
			return $res;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog("E_customer::get_paysid " . $this->error, LOG_ERR);
			return -1;
		}
	}

	/**
	 *
	 * gets id for state from ISO code
	 * @param string $code_state code iso département
	 * @param int $id_pays rowid pays
	 */
	function get_stateid($code_state, $id_pays)
	{
		if (empty($code_state) || empty($id_pays)) {
			dol_syslog(get_class($this) . ":" . __METHOD__ . " code_state = $codestate id_pays = $id_pays", LOG_ERR);
			return '';
		}
		$initpos = strpos($code_state, "-");
		if ($initpos) {
			$code_state2 = substr($code_state, $initpos + 1);
		}

		$sql = "SELECT d.rowid,  d.code_departement,  d.nom as depname, r.nom as regname, p.label as paysname";
		$sql .= " FROM " . MAIN_DB_PREFIX . "c_departements d ";
		$sql .= " JOIN " . MAIN_DB_PREFIX . "c_regions r ON d.fk_region = r.rowid ";
		$sql .= " JOIN " . MAIN_DB_PREFIX . "c_country p ON r.fk_pays = p.rowid ";
		$sql .= " WHERE (code_departement = '" . $code_state . "' OR code_departement = '" . $code_state2 . "') AND p.rowid = '" . $id_pays . "' ";

		dol_syslog(get_class($this) . ":" . __METHOD__ . " sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$res = $obj->rowid;
			}
			$this->db->free($resql);
			return $res;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . ":" . __METHOD__ . " : " . $this->error, LOG_ERR);
			return -1;
		}
	}

	function get_adresse_livraison($socid, $adrlabel)
	{
		return 0;
	}

	/**
	 *
	 * Creates or update a contact from soc with ecommerce datas
	 * @param  $socid : dolibarr thirdparty
	 * @param array $adr : address datas
	 * @param integer $ecom_adr_id : ecommerce address id
	 * @return $cid contact_id if OK or <0 if KO
	 */
	function new_societe_contact($socid, $adr, $ecom_adr_id, $default = 0)
	{
		// creation du contact
		if (empty($adr["pays_id"])) $adr["pays_id"] = $this->get_paysid($adr["pays_code"]);
		if (empty($adr["state_id"])) $adr["state_id"] = $this->get_stateid($adr["state_code"], $adr["pays_id"]);

		dol_syslog("E_customer:: new_societe_contact gestion contact " . $ecom_adr_id . " defaut " . $default . " valeurs " . print_r($adr, true), LOG_INFO);
		$contact = new Contact($this->db);

		$contact->civilite_id = $adr["civilite_id"];
		$contact->name = $adr["nom_particulier"];
		$contact->lastname = $adr["nom_particulier"];
		$contact->firstname = $adr["prenom"];
		$contact->address = $adr["adresse"];
		$contact->cp = $adr["cp"];
		$contact->zip = $adr["cp"];
		$contact->ville = $adr["ville"];
		$contact->town = $adr["ville"];

		$contact->fk_pays = $adr["pays_id"]; //$this->get_paysid($adr["pays_id"]);
		$contact->country_id = $adr["pays_id"];
		$contact->country_code = $adr["pays_code"];
//		$contact->country_id = $contact->fk_pays;

		$contact->state_id = $adr["state_id"];
		$contact->state_code = $adr["state_code"];
		$contact->fk_departement = $adr["state_id"];
		$contact->socid = $socid;                    // fk_soc
		$contact->status = 1;
		$contact->email = $adr["email"];
		$contact->priv = 0;
		$contact->phone_pro = $adr["telephone"];
		$contact->phone_mobile = $adr["mobile"];
		$contact->note = $adr["note"];


		// mise a jour ecom_contact
		$ecom_contact = new Ecom_contact($this->db);
		$ecom_contact->siteid = $this->site->id;
		$ecom_contact->ecom_cust_id = $this->ecom_customer;
		$ecom_contact->ecom_address_id = $ecom_adr_id;
		$ecom_contact->ecom_default_addr = $default;
		$ecom_contact->datem = dol_now();

		// Contact existe déjà ?
		$contact_id = $this->get_customer_contact($this->ecom_customer, $ecom_adr_id);
		if ($contact_id > 0) {
			$contact->id = $contact_id;
			if ($contact->update($contact_id, $this->user) < 0) {
				dol_syslog("E_customer::new_societe_contact maj contact KO " . $contact->errors[0], LOG_ERR);
				return -1;
			}
			if ($this->ecom_contact_rowid > 0) {
				dol_syslog("E_customer::new_societe_contac ecom_contact_rowid =" . $this->ecom_contact_rowid, LOG_DEBUG);
				$ecom_contact->id = $this->ecom_contact_rowid;
				$ecom_contact->doli_contact_id = $contact->id;
				if ($ecom_contact->update($this->user) < 0) {
					$this->error .= " Erreur maj ecom_contact " . $ecom_contact->error;
					dol_syslog("E_customer::import_customer maj ecom_customer KO " . $this->error, LOG_ERR);
					return -2;
				}
			}
			else {
				$this->error .= " Erreur maj ecom_contact inexistant ecom_contact_rowid est null";
				dol_syslog("E_customer::import_customer maj ecom_customer KO " . $this->error, LOG_ERR);
				return -2;
			}
		}
		else {
			if ($contact->create($this->user) < 0) {
				dol_syslog("E_customer::new_societe_contact création contact KO " . $contact->errors[0], LOG_ERR);
				return -1;
			}
			dol_syslog("E_customer::new_societe_contact création contact " . $contact->id, LOG_DEBUG);
			$ecom_contact->doli_contact_id = $contact->id;
			$ecom_contact->ecom_default_addr = $default;
			if ($ecom_contact->create($this->user) < 0) {
				$this->error .= " Erreur creation ecom_contact " . $ecom_contact->error;
				dol_syslog("E_customer::import_customer création ecom_customer KO " . $this->error, LOG_ERR);
				return -2;
			}
		}

		return $contact->id;
	}

	/**
	 *
	 * get the contact id from an adress code to update contact address with ecommerce data
	 * @param address_id ecommerce address id
	 * @param customer_id ecomemrce customer id
	 *
	 * return 0 : not exist, dolibarr contact id if exist
	 */

	function get_customer_contact($custid, $address_id = 0)
	{
		$cid = 0;

		$sql = "SELECT doli_contact_id, rowid FROM " . MAIN_DB_PREFIX . "ecom_contact ";
		$sql .= " WHERE ecom_cust_id = '" . $custid . "' AND siteid = " . $this->site->id;
		if($address_id) $sql .=" AND ecom_address_id = '" . $address_id . "'";
		dol_syslog("E_customer::get_customer_contact sql=" . $sql, LOG_DEBUG);

		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$cid = $obj->doli_contact_id;
				$this->ecom_contact_rowid = $obj->rowid;
			}
			$this->db->free($resql);
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog("E_customer::get_customer_contact " . $this->error, LOG_ERR);
			$cid = -1;
		}

		return $cid;
	}


	/***
	 * update dolibarr sociéte and default contact with web datas
	 *
	 */
	function update_dolisoc($doli_id, $ecom_custid)
	{
		dol_syslog(get_class($this) . "::update_dolisoc " . $doli_id . "  " . $ecom_custid, LOG_DEBUG);
		// get web-datas
		if ($this->wsfetch($ecom_custid) < 0) {
			//error
			return -1;
		}

		$societe = new societe($this->db);
		if ($societe->fetch($doli_id) < 0) {
			//error
			return -2;
		}

		$societe->address = $this->e_custstreet;
		$societe->zip = $this->e_custpostcode;
		$societe->town = $this->e_custcity;
		$societe->departement_id = 0;
		$societe->country_code = $this->e_custcodecountry;
		$societe->country_id = $this->get_paysid($this->e_custcodecountry);
		$societe->state_id = $this->get_stateid($this->e_custcodestate, $societe->country_id);
		$societe->phone = $this->e_custtel;
		$societe->fax = $this->e_custfax;
		$societe->email = $this->e_custmail;

		// TODO gérer une transaction
		if ($societe->update($doli_id, $this->user, 0) < 0) {
			//erreur
			$this->error = "societe update error for ecom_cust = " . $ecom_custid . "  " . $societe->error;
			dol_syslog(get_class($this) . "::update_dolisoc " . $this->error, LOG_ERR);
			return -3;
		}

		// maj du contact par défaut
		$cid = $this->get_customer_contact($ecom_custid);
		dol_syslog(get_class($this) . "::update_dolisoc résultat cid =" . $cid . " rowid= " . $this->rowid . " siteid " . $this->siteid, LOG_DEBUG);
		if ($cid <= 0) {
			$this->error = "error default contact not found for ecom_cust = " . $ecom_custid;
			dol_syslog(get_class($this) . "::update_dolisoc " . $this->error, LOG_ERR);
			return -2;
		}

		$contact = new Contact($this->db);
		$contact->fetch($cid);

		$contact->address = $this->e_custstreet;
		$contact->cp = $this->e_custpostcode;
		$contact->zip = $this->e_custpostcode;
		$contact->ville = $this->e_custcity;
		$contact->town = $this->e_custcity;
		$contact->country_code = $this->e_custcodecountry;
		$contact->country_id = $this->get_paysid($this->e_custcodecountry);
		$contact->email = $this->e_custmail;
		$contact->priv = 0;
		$contact->phone_pro = $this->e_custtel;
		$contact->phone_mobile = $this->e_custmobile;

		if ($contact->update($cid, $this->user, 0) < 0) {
			//erreur
			$this->error = "default contact update error for ecom_cust = " . $ecom_custid . "  " . $contact->error;
			dol_syslog(get_class($this) . "::update_dolisoc " . $this->error, LOG_ERR);
			return -4;
		}
		//TODO maj de ecom_customer


		dol_syslog(get_class($this) . "::update_dolisoc " . $doli_id . "  " . $ecom_custid, LOG_DEBUG);
		return 0;
	}

	/***
	 * deleting records where a deleted contcat appears.
	 * $cid : contact_id
	 */
	function delete_contact($cid)
	{
		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_contact ";
		$sql .= " WHERE doli_contact_id = '" . $cid . "'";

		dol_syslog(get_class($this) . "::delete_contact " . $sql, LOG_DEBUG);

		if (!$this->db->query($sql)) {
			$this->error = $this->db->error;
			dol_syslog(get_class($this) . "::delete_contact error " . $this->error, LOG_ERR);
			return -1;
		}

		return 1;

	}

	/*
	 * updating ecom_customer and ecom_contact when a customer is deleted (trigger)
	 */
	function del_dolicustomer($socid)
	{

		$sql = "SELECT rowid, ecom_customer, siteid FROM " . MAIN_DB_PREFIX . "ecom_customer WHERE doli_soc ='" . $socid . "'";
		dol_syslog(get_class($this) . "::del_dolicustomer " . $sql, LOG_DEBUG);

		$resql = $this->db->query($sql);
		if ($resql) {
			$this->db->begin();
			while ($obj = $this->db->fetch_object($resql)) {
				//1. deleting ecom_contacts
				$sql1 = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_contact WHERE ecom_cusid ='" . $obj->ecom_customer . "' AND siteid = '" . $obj->siteid . "'";
				dol_syslog(get_class($this) . "::del_dolicustomer delete contact" . $sql1, LOG_DEBUG);
				if (!$this->db->query($sql1)) {
					$error++;
					dol_syslog(get_class($this) . "::del_dolicustomer delete contact error " . $sql1, LOG_ERR);
				}

				//2. updating ecom_customer
				$sql1 = "UPDATE " . MAIN_DB_PREFIX . "ecom_customer SET doli_soc = 0 WHERE doli_soc ='" . $socid . "' AND siteid ='" . $obj->siteid . "'";
				dol_syslog(get_class($this) . "::del_dolicustomer update ecom_customer" . $sql1, LOG_DEBUG);
				if (!$this->db->query($sql1)) {
					$error++;
					dol_syslog(get_class($this) . "::del_dolicustomer delete contact error " . $sql1, LOG_ERR);
				}
			}

			if ($error) $this->db->rollback();
			else {
				$this->db->commit();
				dol_syslog(get_class($this) . "::del_dolicustomer update ok for socid =" . $socid, LOG_DEBUG);
			}
		}


	}

	/**
	 *
	 * create a customer card on ecomerce site
	 * @param int $custid id
	 */
	function send_customertosite($custid)
	{
		global $langs, $conf;

		$contact = new Contact($this->db);
		$contact->fetch($custid);

		if (!$contact->id) {
			$this->error = "Contact undefined " . $custid;
			return -1;
		}

		$soc = new Societe($this->db);
		if ($soc->fetch($contact->socid) < 0) {
			$this->error = $langs->trans("Thirdparty not Found");
			return -1;
		}

		if ($this->findCustInSite($contact->socid) > 0) {
			$this->error = $langs->trans("EcomCustAllreadyExists");
			return -1;
		}

		// TODO test si société existe déjà

		$custarray = array();
		$custarray['email'] = (empty($contact->email) ? $soc->email : $contact->email);
		$custarray['gender'] = $contact->civilite_id;
		$custarray['lastname'] = (empty($contact->name) ? $soc->name : $contact->name);
		$custarray['firstname'] = $contact->firstname;
		$custarray['address1'] = (empty($contact->address) ? $soc->address : $contact->address); // TODO à formater
		$custarray['address2'] = "";
		$custarray['postcode'] = (empty($contact->zip) ? $soc->zip : $contact->zip);
		$custarray['city'] = (empty($contact->town) ? $soc->town : $contact->town);
		$custarray['phone'] = $contact->phone;
		$custarray["phone_mobile"] = $contact->phone_mobile;
		$custarray["country"] = (empty($contact->country_code) ? $soc->country_code : $contact->country_code);

		if ($soc->particulier) $custarray["company"] = '';
		else $custarray["company"] = $soc->name;

		// gestion des groupes
		if (!empty($conf->global->PRODUIT_MULTIPRICES)) {
			// transmettre le tarif en groupe par défaut
			if (!empty($soc->price_level)) {
				$defaultgroup = get_groupforlevel($soc->price_level, $this->siteid);
				if ($defaultgroup > 0) $custarray["default_group"] = $defaultgroup;
			}
		}

		if (!empty($conf->global->ECOM_CLIENTTYPESYNCHRO)) {
			// le type lient transmis comme un groupe
			$group = $this->get_groupfortypent($soc->typent_id);
			if ($group > 0) $custarray["groups"][] = $group;
		}

		//send to ecommerce
		$parameters = array("tabcust" => $custarray);
        //WebService Client.
        dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

        // Set the parameters to send to the WebService
        $parameters = array("custid" => $custid);

        // Set the WebService URL
        $soap_client = new nusoap_client($this->site->site_ws_url . "/ws_customers.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

        // Call the WebService (client->fault) and store its result in $obj
        $obj = $soap_client->call("create_customer", $parameters);
/*
        if ($soap_client->fault) {
            $this->error = "Fault detected " . $client->getError();
            return -1;
        }*/
		if (!$soap_client->resko) {
			dol_syslog("E_customer:create_customer OK", LOG_DEBUG);
			$ecom_id = $soap_client->ws_data["customer_id"];
			$adr_id = $soap_client->ws_data["address_id"];
		}
		else {
			dol_syslog("E_customer:create_customer KO " . $soap_client->error, LOG_DEBUG);
			$this->error = $soap_client->error;
			return -1;
		}

		if (empty($ecom_id)) {
			dol_syslog("E_customer:create_customer KO error creating customre " . $soap_client->error, LOG_DEBUG);
			$this->error = "Customer creation error on ecommerce ";
			return -1;
		}

		$this->db->begin();
		$errorsql = 0;
		// update local
		$this->siteid = $this->site->id;
		$this->doli_soc = $contact->socid;
		$this->ecom_customer = $ecom_id;
		$this->datem = dol_now();
		$this->site_cust_status = 'C'; // TODO

		if ($this->create($this->user) < 0) {
			$this->error = "error creating ecom_customer ";
			$errorsql++;
		}

		if (empty($adr_id)) {
			dol_syslog("E_customer:create_customer KO error creating address" . $soap_client->error, LOG_DEBUG);
			$this->error = "Customer address creation error on ecommerce ";
			$errorsql++;
		}
		$ecomcont = new Ecom_contact($this->db);
		$ecomcont->siteid = $this->site->id;
		$ecomcont->ecom_cust_id = $ecom_id;
		$ecomcont->doli_contact_id = $custid;
		$ecomcont->ecom_address_id = $adr_id;
		$ecomcont->ecom_default_addr = 1;

		if ($ecomcont->create($this->user) < 0) {
			$this->error = "error creating ecom_contact " . $ecomcont->error;
			$errorsql++;
		}

		if ($errorsql) {
			$this->db->rollback();
			return -1;
		}
		else $this->db->commit();

		return 1;
	}

	/**
	 *
	 * Update customer informations on ecommerce from Dolibarr
	 * @param integer $socid dolibarr id
	 * @param array $tabvalues indexed array array("default_group"=>1, "customer_group"=>5...)
	 */
	function update_ecom_customer($socid = '', $ecomid = '', $tabvalues)
	{
		// find ecom customer
		if (!empty($socid)) {
			if ($this->findCustInSite($soctid) > 0) $ecomid = $this->ecom_customer;
			else {
				dol_syslog(basename(__FILE__) . ":: update_ecom_customer no ecomsoc found for " . $socid, LOG_WARN);
				return 0;
			}
		}

		if (empty($ecomid)) {
			dol_syslog(basename(__FILE__) . ":: update_ecom_customer no ecomid provided " . $socid, LOG_WARN);
			return 0;
		}

		//send to ecommerce
		$parameters = array("custid" => $ecomid, "tabmod" => $tabvalues);
		$soap_client = new webservice_ecom($this->site->site_ws_url, 'ws_customers.php');
		$soap_client->ws_call('update_Client', $parameters);
		if (!$soap_client->resko) {
			dol_syslog("E_customer:update_ecom_customer OK", LOG_DEBUG);
		}
		else {
			dol_syslog("E_customer:create_customer KO " . $soap_client->error, LOG_DEBUG);
			$this->error = $soap_client->error;
			return -1;
		}

		return 1;
	}

	/**
	 *
	 * Get the ecommerce customer group linked to sociéte type
	 * @param integer $typent
	 */
	function get_groupfortypent($typent)
	{
		if (empty($typent)) {
			dol_syslog("get_groupfortypent typent is empty", LOG_ERR);
			return 0;
		}

		$sql = "SELECT ecom_id FROM " . MAIN_DB_PREFIX . "ecom_customer_type WHERE doli_typent_id = '" . $typent . "'";

		$id_ecom = 0;
		dol_syslog("get_groupfortypent sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$id_ecom = $obj->ecom_id;
			}
		}
		else {
			dol_syslog("E_customer::get_groupfortypent sql=" . $sql, LOG_ERR);
			return -1;
		}

		return $id_ecom;

	}


	function new_adresse_livraison($socid, $adr)
	{
// TODO creation de l'adresse de livraison
		return 0;
		/*
		$livraison = new AdresseLivraison($this->db);
		$livraison->socid     = $socid;
    	$livraison->label     = "ECOM-".$this->siteid."-".$adr["shipping_address_id"] ;
    	$livraison->nom       = $adr["shipping_name"];
	   	$livraison->address   = $adr["shipping_adresse"];
 	  	$livraison->cp        = $adr["shipping_cp"];
    	$livraison->ville     = $adr["shipping_ville"];
    	$livraison->pays_id   = $adr["shipping_pays_id"];
 	   $livraison->note		 = "Adresse commande internet ".$this->siteid."/".$adr["shipping_address_id"] ; //id oscommerce

 		$result  = $livraison->create($socid, $user);

        if ($result >= 0)
        {
        	dol_syslog("E_order::import_order cr�ation adresse livraison pour client ".$socid. " " .$livraison->label , LOG_DEBUG);
        	return $livraison->id;
        }
        else
        {
        	dol_syslog("E_order::import_order create ECHEC cr�ation adresse livraison pour client ".$socid. " " .$livraison->label , LOG_DEBUG);
        	return -1;
        }
        */
	}

}
