<?php
/* Copyright (C) 2007  		Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010   	Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013  Philippe Grand       <philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *        \file       htdocs/ecommerce/class/ecom_html.class.php
 *        \ingroup    ecommerce
 *        \brief      html class of ecommerce module
 */
class Ecom_html
{

	var $db;
	var $error;


	/**
	 *  Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}

	/***
	 * draw a simple form with a text and a button
	 * $text : text displayed before button
	 * $action : value for action parameter
	 * $buttontext : text for button
	 * $textheader : text displayed above fileds
	 */
	function ecom_simple_form($text, $action, $buttontext, $textheader)
	{
		global $langs;

		$ret = '<table>';
		if ($textheader) $ret .= '<th colspan="2">' . $langs->trans($textheader) . '</th>';
		$ret .= '<tr><td>' . $langs->trans($text);
		$ret .= '</td>';
		$ret .= '<td><form action="" method="POST" name="' . $action . '">';
		$ret .= '<input type="hidden" name="action" value="' . $action . '">';
		$ret .= '<input class="button" type="submit" value="' . $langs->trans($buttontext) . '">';
		$ret .= '</td></form></tr>';
		$ret .= '</table>';

		return $ret;
	}

	function ecom_pricelevel_form($siteid, $htmlname = '', $disabled = '')
	{
		global $langs;
		$sql = "SELECT ecom_id, ecom_lib FROM " . MAIN_DB_PREFIX . "ecom_customer_type WHERE siteid ='" . $siteid . "'";
		dol_syslog(__FILE__ . " :: " . __METHOD__ . " sql =" . $sql, LOG_DEBUG);

		$tabpricelevel = array();

		$ret = '';
		$resql = $this->db->query($sql);
		if ($resql) {
			while ($obj = $this->db->fetch_object($resql)) {
				$tabpricelevel[] = $obj;
			}
		}

		$ret = '<select class="flat" name="' . $htmlname . '"' . ($disabled ? ' disabled="true"' : '') . '>';
		$ret .= '<option value="-1" selected="selected">&nbsp;</option>' . "\n";
		foreach ($tabpricelevel as $elt) {
			$ret .= '<option value="' . $elt->ecom_id . '"> ' . $elt->ecom_lib . "</option>";
		}
		$ret .= '</select>';
//		dol_syslog(__FILE__." :: ".__METHOD__." ret =".$ret, LOG_DEBUG);
		return $ret;

	}

	// construit un select avec id et lib, le sql doit être select xxx as id , yy as lib...
	function ecom_ddform($siteid, $sql = '', $htmlname = '', $disabled = '')
	{
		if ($sql == '') return '';

		$ret = array();

		$resql = $this->db->query($sql);
		if ($resql) {
			$taboption = array();
			while ($obj = $this->db->fetch_object($resql)) {
				$taboption[] = $obj;
			}

			$retstring = '<select class="flat" name="' . $htmlname . '"' . ($disabled ? ' disabled="true"' : '') . '>';
			$retstring .= '<option value="-1" selected="selected">&nbsp;</option>' . "\n";
			foreach ($taboption as $elt) {
				$retstring .= '<option value="' . $elt->id . '"> ' . $elt->lib . "</option>";
			}
			$retstring .= '</select>';
		}
		else dol_syslog(__FILE__ . " :: " . __METHOD__ . " sql error " . $sql, LOG_ERR);
		//		dol_syslog(__FILE__." :: ".__METHOD__." ret =".$retstring, LOG_DEBUG);
		$ret[0] = $retstring;
		$ret[1] = count($taboption);
		return $ret;
	}

	/**
	 *
	 * sends a link to a ecommerce site
	 * @param integer $siteid
	 */
	function getsiteurl($siteid)
	{
		$link = "";
		$sql = "SELECT site_name, site_url FROM " . MAIN_DB_PREFIX . "ecom_site WHERE rowid ='" . $siteid . "'";
		$resql = $this->db->query($sql);
		if ($resql) {
			$obj = $this->db->fetch_object($resql);
			$link = '<a href="' . $obj->site_url . '" target="_blank">' . $obj->site_name . "</a>";
		}

		return $link;
	}

}


