<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010      Jean Heimburger     	<jean@tiaris.info>
 * Copyright (C) 2011-2013 Philippe Grand     	<philippe.grand@atoo-net.com>
 * Copyright (C) 2011      Juanjo Menent      	<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *      \file       htdocs/ecommerce/class/ecom_order.class.php
 *      \ingroup    products
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */

/**
 *      \class      Ecom_order
 *      \brief      Order class for e-commerce site
 */
class Ecom_order extends CommonObject
{
	//var $element='ecom_order';			//!< Id that identify managed objects
	//var $table_element='ecom_order';	//!< Name of table without prefix where object is stored

	var $id;

	var $siteid;
	var $doli_order;
	var $ecom_order;
	var $datem = '';
	var $site_order_status;
	var $site_order_date = '';
	var $site_order_total_HT;
	var $site_total_vat;
	var $site_total_port;
	var $site_client_name;
	var $exp_meth_id;
	var $exp_meth;


	/**
	 *  Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *      Create object into database
	 * @param user            User that create
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, Id of created object if OK
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->doli_order)) $this->doli_order = trim($this->doli_order);
		if (isset($this->ecom_order)) $this->ecom_order = trim($this->ecom_order);
		if (isset($this->site_order_status)) $this->site_order_status = trim($this->site_order_status);
		if (isset($this->site_order_total_HT)) $this->site_order_total_HT = trim($this->site_order_total_HT);
		if (isset($this->site_total_vat)) $this->site_total_vat = trim($this->site_total_vat);
		if (isset($this->site_total_port)) $this->site_total_port = trim($this->site_total_port);
		if (isset($this->site_client_name)) $this->site_client_name = trim($this->site_client_name);
		if (isset($this->exp_meth_id)) $this->exp_meth_id = trim($this->exp_meth_id);
		if (isset($this->exp_meth)) $this->exp_meth = trim($this->exp_meth);


		// Check parameters
		// Put here code to add control on parameters values

		// Insert request
		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_order(";

		$sql .= "siteid,";
		$sql .= "doli_order,";
		$sql .= "ecom_order,";
		$sql .= "datem,";
		$sql .= "site_order_status,";
		$sql .= "site_order_date,";
		$sql .= "site_order_total_HT,";
		$sql .= "site_total_vat,";
		$sql .= "site_total_port,";
		$sql .= "site_client_name,";
		$sql .= "exp_meth_id,";
		$sql .= "exp_meth";


		$sql .= ") VALUES (";

		$sql .= " " . (!isset($this->siteid) ? 'NULL' : "'" . $this->siteid . "'") . ",";
		$sql .= " " . (!isset($this->doli_order) ? 'NULL' : "'" . $this->doli_order . "'") . ",";
		$sql .= " " . (!isset($this->ecom_order) ? 'NULL' : "'" . $this->ecom_order . "'") . ",";
		$sql .= " " . (!isset($this->datem) || dol_strlen($this->datem) == 0 ? 'NULL' : "'".$this->db->idate($this->datem)) . "',";
		$sql .= " " . (!isset($this->site_order_status) ? 'NULL' : "'" . $this->site_order_status . "'") . ",";
		$sql .= " " . (!isset($this->site_order_date) || dol_strlen($this->site_order_date) == 0 ? 'NULL' : "'".$this->db->idate($this->site_order_date)) . "',";
		$sql .= " " . (!isset($this->site_order_total_HT) ? 'NULL' : "'" . $this->site_order_total_HT . "'") . ",";
		$sql .= " " . (!isset($this->site_total_vat) ? 'NULL' : "'" . $this->site_total_vat . "'") . ",";
		$sql .= " " . (!isset($this->site_total_port) ? 'NULL' : "'" . $this->site_total_port . "'") . ",";
		$sql .= " " . (!isset($this->site_client_name) ? 'NULL' : "'" . $this->db->escape($this->site_client_name) . "'") . ",";
		$sql .= " " . (!isset($this->exp_meth_id) ? 'NULL' : "'" . $this->exp_meth_id . "'") . ",";
		$sql .= " " . (!isset($this->exp_meth) ? 'NULL' : "'" . $this->db->escape($this->exp_meth) . "'") . "";


		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_order");

			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_CREATE',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}


	/**
	 *    Load object in memory from database
	 * @param id          id object
	 * @return     int         <0 if KO, >0 if OK
	 */
	function fetch($id)
	{
		global $langs;
		$sql = "SELECT";
		$sql .= " t.rowid,";

		$sql .= " t.siteid,";
		$sql .= " t.doli_order,";
		$sql .= " t.ecom_order,";
		$sql .= " t.datem,";
		$sql .= " t.site_order_status,";
		$sql .= " t.site_order_date,";
		$sql .= " t.site_order_total_HT,";
		$sql .= " t.site_total_vat,";
		$sql .= " t.site_total_port,";
		$sql .= " t.site_client_name,";
		$sql .= " t.exp_meth_id,";
		$sql .= " t.exp_meth";


		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;

				$this->siteid = $obj->siteid;
				$this->doli_order = $obj->doli_order;
				$this->ecom_order = $obj->ecom_order;
				$this->datem = $this->db->jdate($obj->datem);
				$this->site_order_status = $obj->site_order_status;
				$this->site_order_date = $this->db->jdate($obj->site_order_date);
				$this->site_order_total_HT = $obj->site_order_total_HT;
				$this->site_total_vat = $obj->site_total_vat;
				$this->site_total_port = $obj->site_total_port;
				$this->site_client_name = $obj->site_client_name;
				$this->exp_meth_id = $obj->exp_meth_id;
				$this->exp_meth = $obj->exp_meth;


			}
			$this->db->free($resql);

			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 *      Update object into database
	 * @param user            User that modify
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->doli_order)) $this->doli_order = trim($this->doli_order);
		if (isset($this->ecom_order)) $this->ecom_order = trim($this->ecom_order);
		if (isset($this->site_order_status)) $this->site_order_status = trim($this->site_order_status);
		if (isset($this->site_order_total_HT)) $this->site_order_total_HT = trim($this->site_order_total_HT);
		if (isset($this->site_total_vat)) $this->site_total_vat = trim($this->site_total_vat);
		if (isset($this->site_total_port)) $this->site_total_port = trim($this->site_total_port);
		if (isset($this->site_client_name)) $this->site_client_name = trim($this->site_client_name);
		if (isset($this->exp_meth_id)) $this->exp_meth_id = trim($this->exp_meth_id);
		if (isset($this->exp_meth)) $this->exp_meth = trim($this->exp_meth);


		// Check parameters
		// Put here code to add control on parameters values

		// Update request
		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_order SET";

		$sql .= " siteid=" . (isset($this->siteid) ? $this->siteid : "null") . ",";
		$sql .= " doli_order=" . (isset($this->doli_order) ? $this->doli_order : "null") . ",";
		$sql .= " ecom_order=" . (isset($this->ecom_order) ? $this->ecom_order : "null") . ",";
		$sql .= " datem=" . (dol_strlen($this->datem) != 0 ? "'" . $this->db->idate($this->datem) . "'" : 'null') . ",";
		$sql .= " site_order_status=" . (isset($this->site_order_status) ? $this->site_order_status : "null") . ",";
		$sql .= " site_order_date=" . (dol_strlen($this->site_order_date) != 0 ? "'" . $this->db->idate($this->site_order_date) . "'" : 'null') . ",";
		$sql .= " site_order_total_HT=" . (isset($this->site_order_total_HT) ? $this->site_order_total_HT : "null") . ",";
		$sql .= " site_total_vat=" . (isset($this->site_total_vat) ? $this->site_total_vat : "null") . ",";
		$sql .= " site_total_port=" . (isset($this->site_total_port) ? $this->site_total_port : "null") . ",";
		$sql .= " site_client_name=" . (isset($this->site_client_name) ? "'" . $this->db->escape($this->site_client_name) . "'" : "null") . ",";
		$sql .= " exp_meth_id=" . (isset($this->exp_meth_id) ? $this->exp_meth_id : "null") . ",";
		$sql .= " exp_meth=" . (isset($this->exp_meth) ? "'" . $this->db->escape($this->exp_meth) . "'" : "null") . "";


		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_MODIFY',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *   Delete object in database
	 * @param user            User that delete
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return    int                <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_order";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::delete sql=" . $sql);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_DELETE',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}

	/**
	 *        Initialise object with example values
	 *        Id must be 0 if object instance is a specimen.
	 */
	function initAsSpecimen()
	{
		$this->id = 0;

		$this->siteid = '';
		$this->doli_order = '';
		$this->ecom_order = '';
		$this->datem = '';
		$this->site_order_status = '';
		$this->site_order_date = '';
		$this->site_order_total_HT = '';
		$this->site_total_vat = '';
		$this->site_total_port = '';
		$this->site_client_name = '';
		$this->exp_meth_id = '';
		$this->exp_meth = '';


	}

}


