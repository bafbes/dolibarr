<?php
include_once DOL_DOCUMENT_ROOT . '/core/class/stats.class.php';
include_once DOL_DOCUMENT_ROOT . '/core/lib/date.lib.php';

class ecom_stadistics extends Stats
{

	function __construct($db)
	{
		global $user, $conf;

		$this->db = $db;
	}

	function getNbByMonth($year, $siteid)
	{
		global $user;

		$sql = "SELECT date_format(ec.site_order_date,'%m') as dm, COUNT(*) as nb ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order AS ec , " . MAIN_DB_PREFIX . "commande as c";
		$sql .= " WHERE ec.doli_order=c.rowid ";
		$sql .= "AND ec.site_order_date BETWEEN '" . $this->db->idate(dol_get_first_day($year)) . "' AND '" . $this->db->idate(dol_get_last_day($year)) . "'";
		$sql .= " AND c.fk_statut > 0";
		if (isset($siteid)) {
			$sql .= " AND ec.siteid=" . $siteid;
		}

		$sql .= " GROUP BY dm";
		$sql .= $this->db->order('dm', 'DESC');

		$res = $this->_getNbByMonth($year, $sql);
		return $res;
	}

	function getAmountByMonth($year, $siteid)
	{
		global $user;

		$sql = "SELECT date_format(ec.site_order_date,'%m') as dm, SUM(ec.site_order_total_ht)";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order as ec, " . MAIN_DB_PREFIX . "commande as c";
		$sql .= " WHERE ec.doli_order=c.rowid ";
		$sql .= "AND ec.site_order_date BETWEEN '" . $this->db->idate(dol_get_first_day($year)) . "' AND '" . $this->db->idate(dol_get_last_day($year)) . "'";
		$sql .= " AND c.fk_statut > 0";
		if (isset($siteid)) {
			$sql .= " AND ec.siteid=" . $siteid;
		}

		$sql .= " GROUP BY dm";
		$sql .= $this->db->order('dm', 'DESC');

		$res = $this->_getAmountByMonth($year, $sql);
		return $res;
	}

	function _getAmountByMonth($year, $sql, $format = 0)
	{
		$result = array();
		$res = array();

		dol_syslog(get_class($this) . '::' . __FUNCTION__ . "", LOG_DEBUG);

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			$i = 0;
			while ($i < $num) {
				$row = $this->db->fetch_row($resql);
				$j = $row[0] * 1;
				$result[$j] = $row[1];
				$i++;
			}
			$this->db->free($resql);
		}
		else dol_print_error($this->db);

		for ($i = 1; $i < 13; $i++) {
			$res[$i] = isset($result[$i]) ? $result[$i] : 0;
		}

		$data = array();

		for ($i = 1; $i < 13; $i++) {
			$month = dol_print_date(dol_mktime(12, 0, 0, $i, 1, $year), ($format ? "%m" : "%b"));
			$month = dol_substr($month, 0, 3);
			$data[$i - 1] = array($month, $res[$i]);
		}

		return $data;
	}

	function getNbByMonthWithPrevYear($endyear, $startyear, $cachedelay = 0, $siteid)
	{
		global $conf, $user, $langs;

		if ($startyear > $endyear) return -1;

		$datay = array();

		// Search into cache
		if (!empty($cachedelay)) {
			include_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';
			include_once DOL_DOCUMENT_ROOT . '/core/lib/json.lib.php';
		}

		$newpathofdestfile = $conf->user->dir_temp . '/' . get_class($this) . '_' . __FUNCTION__ . '_' . (empty($this->cachefilesuffix) ? '' : $this->cachefilesuffix . '_') . $langs->defaultlang . '_user' . $user->id . '.cache';
		$newmask = '0644';

		$nowgmt = dol_now();

		$foundintocache = 0;
		if ($cachedelay > 0) {
			$filedate = dol_filemtime($newpathofdestfile);
			if ($filedate >= ($nowgmt - $cachedelay)) {
				$foundintocache = 1;

				$this->_lastfetchdate[get_class($this) . '_' . __FUNCTION__] = $filedate;
			}
			else {
				dol_syslog(get_class($this) . '::' . __FUNCTION__ . " cache file " . $newpathofdestfile . " is not found or older than now - cachedelay (" . $nowgmt . " - " . $cachedelay . ") so we can't use it.");
			}
		}

		// Load file into $data
		if ($foundintocache)    // Cache file found and is not too old
		{
			dol_syslog(get_class($this) . '::' . __FUNCTION__ . " read data from cache file " . $newpathofdestfile . " " . $filedate . ".");
			$data = json_decode(file_get_contents($newpathofdestfile), true);
		}
		else {
			$year = $startyear;
			while ($year <= $endyear) {
				$datay[$year] = $this->getNbByMonth($year, $siteid);
				$year++;
			}

			$data = array();

			for ($i = 0; $i < 12; $i++) {
				$data[$i][] = $datay[$endyear][$i][0];
				$year = $startyear;
				while ($year <= $endyear) {
					$data[$i][] = $datay[$year][$i][1];
					$year++;
				}
			}
		}

		// Save cache file
		if (empty($foundintocache) && ($cachedelay > 0 || $cachedelay == -1)) {
			dol_syslog(get_class($this) . '::' . __FUNCTION__ . " save cache file " . $newpathofdestfile . " onto disk.");
			if (!dol_is_dir($conf->user->dir_temp)) dol_mkdir($conf->user->dir_temp);
			$fp = fopen($newpathofdestfile, 'w');
			fwrite($fp, json_encode($data));
			fclose($fp);
			if (!empty($conf->global->MAIN_UMASK)) $newmask = $conf->global->MAIN_UMASK;
			@chmod($newpathofdestfile, octdec($newmask));

			$this->_lastfetchdate[get_class($this) . '_' . __FUNCTION__] = $nowgmt;
		}

		// return array(array('Month',val1,val2,val3),...)
		return $data;
	}

	function getAmountByMonthWithPrevYear($endyear, $startyear, $cachedelay = 0, $siteid)
	{
		global $conf, $user, $langs;

		if ($startyear > $endyear) return -1;

		$datay = array();

		// Search into cache
		if (!empty($cachedelay)) {
			include_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';
			include_once DOL_DOCUMENT_ROOT . '/core/lib/json.lib.php';
		}

		$newpathofdestfile = $conf->user->dir_temp . '/' . get_class($this) . '_' . __FUNCTION__ . '_' . (empty($this->cachefilesuffix) ? '' : $this->cachefilesuffix . '_') . $langs->defaultlang . '_user' . $user->id . '.cache';
		$newmask = '0644';

		$nowgmt = dol_now();

		$foundintocache = 0;
		if ($cachedelay > 0) {
			$filedate = dol_filemtime($newpathofdestfile);
			if ($filedate >= ($nowgmt - $cachedelay)) {
				$foundintocache = 1;

				$this->_lastfetchdate[get_class($this) . '_' . __FUNCTION__] = $filedate;
			}
			else {
				dol_syslog(get_class($this) . '::' . __FUNCTION__ . " cache file " . $newpathofdestfile . " is not found or older than now - cachedelay (" . $nowgmt . " - " . $cachedelay . ") so we can't use it.");
			}
		}

		// Load file into $data
		if ($foundintocache)    // Cache file found and is not too old
		{
			dol_syslog(get_class($this) . '::' . __FUNCTION__ . " read data from cache file " . $newpathofdestfile . " " . $filedate . ".");
			$data = json_decode(file_get_contents($newpathofdestfile), true);
		}
		else {
			$year = $startyear;
			while ($year <= $endyear) {
				$datay[$year] = $this->getAmountByMonth($year, $siteid);
				$year++;
			}

			$data = array();
			// $data = array('xval'=>array(0=>xlabel,1=>yval1,2=>yval2...),...)
			for ($i = 0; $i < 12; $i++) {
				$data[$i][] = $datay[$endyear][$i][0];    // set label
				$year = $startyear;
				while ($year <= $endyear) {
					$data[$i][] = $datay[$year][$i][1];    // set yval for x=i
					$year++;
				}
			}
		}

		// Save cache file
		if (empty($foundintocache) && ($cachedelay > 0 || $cachedelay == -1)) {
			dol_syslog(get_class($this) . '::' . __FUNCTION__ . " save cache file " . $newpathofdestfile . " onto disk.");
			if (!dol_is_dir($conf->user->dir_temp)) dol_mkdir($conf->user->dir_temp);
			$fp = fopen($newpathofdestfile, 'w');
			fwrite($fp, json_encode($data));
			fclose($fp);
			if (!empty($conf->global->MAIN_UMASK)) $newmask = $conf->global->MAIN_UMASK;
			@chmod($newpathofdestfile, octdec($newmask));

			$this->_lastfetchdate[get_class($this) . '_' . __FUNCTION__] = $nowgmt;
		}

		return $data;
	}


}

