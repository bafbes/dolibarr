<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010-2013 Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2012 Juanjo Menent		<jmenent@2byte.es>
 * Copyright (C) 2011-2013 Philippe Grand       <philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       htdocs/ecommerce/class/E_product.class.php
 *      \ingroup    products
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */

/**
 *      \class      E_product
 *      \brief      class for ecommerce product handling
 */
//dol_include_once("/ecommerce/common_functions.php");

include_once DOL_DOCUMENT_ROOT . "/product/class/product.class.php";
include_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';
dol_include_once("/ecommerce/class/ecom_product.class.php");
dol_include_once("/ecommerce/class/E_categorie.class.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/webservice_ecom.class.php");
dol_include_once("/ecommerce/includes/products.inc.php");

dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

class E_product extends Ecom_product
{

	var $e_name;
	var $e_desc;
	var $e_desc_short;
	var $e_price;
	var $e_tva;
	var $e_stockmini;

	var $e_four;
	var $e_image;
	var $catid;
	var $e_weight;
	var $e_taxrate;
	var $e_ean13;

	var $e_is_pack;
	var $e_pack_items;
	//ecotaxe
	var $ecotax_rate;
	var $ecotax_id;
	//supplier
	var $ecomsupplier_id;
	var $ecomsupplier_ref;
	var $ecomsupplier_price;

	var $site;
	var $user;


	/**
	 *  Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	function __construct($db, $siteid, $user)
	{
		$this->db = $db;
		$this->site = new Ecom_site($this->db);
		if ($this->site->fetch($siteid, $user) < 0) {
			dol_syslog(get_class($this) . "::Constructeur" . $this->site->error, LOG_DEBUG);
			return -1;
		}
		$this->siteid = $this->site->id;
		$this->user = $user;
		return 1;
	}

	/**Charge le produit Ecommerce en mémoire
	 * @param id      Id du produit dans OsC
	 * @param $attribut      Id attribut du produit dans OsC
	 * @return     int     <0 si ko, >0 si ok
	 */
	function wsfetch($id, $attribut = '')
	{
		global $conf, $langs;
		$this->error = '';
		dol_syslog(get_class($this) . "::wsfetch entrée id=$id attribut=$attribut", LOG_DEBUG);

		// Verification parametres
		if (!$id ) {
			$this->error = $langs->trans("ErrWrongParams", $id);
			dol_syslog(get_class($this) . "::wsfetch " . $this->error, LOG_DEBUG);
			return -1;
		}

		//WebService Client.
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

		// Set the parameters to send to the WebService
		$parameters = array("id" => $id, "attribut" => $attribut);

		// Set the WebService URL
		$client = new nusoap_client($this->site->site_ws_url . "/ws_articles.php" . (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

		// Call the WebService and store its result in $obj
		$obj = $client->call("get_article", $parameters);
		if ($client->fault) {
			$this->error = $langs->trans("ErrWSFault") . " " . $client->getError();
			dol_syslog(get_class($this) . "::wsfetch get_article" . $this->error, LOG_DEBUG);
			return -1;
		}
		elseif (!($err = $client->getError())) {
//champs calculés
			$this->_image = $obj['_image'];
			$this->_is_pack = $obj['_is_pack'];
			$this->_pack_items = $obj['_pack_items'];
			$this->_tax_rate = $obj['_tax_rate'];
//champs standards
			$this->active = $obj["active"];
			$this->description = $this->description_short = $obj['description_short'];
			$this->ean13 = $obj['ean13'];
			$this->ecom_ref = $obj['reference'];
			$this->ecotax = $obj['ecotax'];
			$this->id_category_default = $obj['id_category_default'];
			$this->id_manufacturer = $obj['id_manufacturer'];
			$this->id = $this->id_product = $obj['id_product'];
			$this->id_supplier = $obj['id_supplier'];
			$this->name = $obj['name'];
			$this->price = $obj['price'];
			$this->quantity = $obj['quantity'];
			$this->reference = $obj["reference"];
			$this->supplier_reference = $obj["supplier_reference"];
			$this->weight = $obj['weight'];
			$this->wholesale_price = $obj['wholesale_price'];
//product_lang

//			$this->ecomsupplier_price = $obj["ecomsupplier_price"];
//			$this->products_reference= $obj["products_reference"];
		}
		else {
			$this->error = $langs->trans("ErrError") . $client->getError();
			dol_syslog(get_class($this) . "::wsfetch erreur client soap" . $this->error, LOG_DEBUG);
			return -1;
		}
		return 0;
	}

	// renvoie un objet produit dolibarr

	/** renvoie un objet produit dolibarr depuis une référence produit,attribut prestashop
	 * @param $ecom_productid
	 * @param $attribut
	 * @param $withfetch fetch from Presta
	 * @return Product|string
	 * @throws Exception
	 */
	function ecom2dolibarr($ecom_productid, $attribut = '',$withfetch=1)
	{
		global $langs;
		if($withfetch) $result = $this->wsfetch($ecom_productid, $attribut, '');
		else $result=0;

		if (!$result) {
			$product = new Product($this->db);
			dol_syslog(get_class($this) . "::ecom2dolibarr  " . $ecom_productid . " - " . $attribut, LOG_DEBUG);
			if ($product->error == 1) {
				dol_syslog(get_class($this) . "::ecom2dolibarr création product " . $product->error, LOG_DEBUG);
				return '';
			}
			dol_syslog(get_class($this) . "::ecom2dolibarr initialisation " . $this->ecom_ref . ' ' . $attribut, LOG_DEBUG);
			// initialisation
			$product->doli_ref = $this->doli_ref;
			$product->label = $langs->trans($this->name);
			if(empty($product->label))$product->label='N/D';

			if ($this->description_short) {
				$product->description = nl2br($this->description_short);
			}
			else {
				$product->description = nl2br($this->description);
			}

			dol_syslog(get_class($this) . "::ecom2dolibarr " . $this->description . " - " . $this->description_short . " fin ", LOG_DEBUG);
			$product->price = $this->price;
			$product->price_ttc = price2num($this->price * (1. + $this->_tax_rate / 100.), 'MT');
			$product->type = 0;
			//$product->catid = $this->get_catid($this->osc_catid) ;
			$product->seuil_stock_alerte = 0; // on force
			$product->status = 1; // on sell
			$product->status_buy = 1; // on purchase
			$product->tva_tx = $this->_tax_rate;
			$product->finished = 1; // c'est un produit fini
			$product->price_base_type = 'TTC'; //on se base sur le prix TTC pour calculer le prix HT (arrondis)

			$product->weight = $this->weight;
			$product->weight_units = 0;

			$product->barcode = $this->ean13;
			$product->barcode_type = 2;
			$product->array_options["options_prodref"] = $this->reference;

			return $product;
		}
		dol_syslog(get_class($this) . "::ecom2dolibarr erreur wsfetch" . $ecom_productid . ' ' . $this->error, LOG_DEBUG);
		return '';
	}

	/** Importation d'un produit
	 * Si le produit existe dans Dolibarr seulement le stock est mis à jour
	 * sinon le produit est créé avec stock,image et sous produits
	 * 1-Le produit est importé de Presta -wsfetch
	 * 2-Recherche de l'enregistrement du produit dans ecom_product - findInSite
	 * 3-Lecture de doli_ref dans ecom_product
	 * 4-si doli_ref existe lecture du produit dans $prod
	 * 5-Si $prod->id > 0, le produit existe dans Dolibarr le stock est mis à jour dans llx_product et ecom_product
	 * 6-sinon :
	 * * Le produit est réimporté de Presta -wsfetch dans ecom2dolibarr
	 * * Il est créé Dans dolibarr
	 * * Sa photo exst importée
	 * * Son code barre est importé
	 * * les sous produits sont créés
	 * * Le record dans ecom_product est màj
	 * * Les stock du produit est modifiéé dans prodct_stock avec product_stock donc trigger déclenché.
	 * * Ajout de la liaison vers la catégorie correspondante dans Dolibarr
	 * * Si un fournisseur ou fabricant est présent dans le produit importé et que ce fabricant existe dans ecom_manufacturer,
	 * on ajoute le lien vers le fournisseur et le prix fournisseur
	 * @param $ecomid ecom_product dans llx_ecom_product
	 * @param $ecomattribut ecom_attribut dans llx_ecom_product
	 * @param $ecomref ecom_ref dans llx_ecom_product
	 * @param string $rowid rowid dans llx_ecom_product
	 * @return int
	 * @throws Exception
	 */

	function import_product($ecomid,$ecomattribut = '', $ecomref='', $rowid='')
	{
		/* controle paramètres */
		/* siteid, ecomid, $ecomref */
		global $conf, $langs,$user;

		dol_syslog(get_class($this) . "::import product ecomid" . $ecomid . " - " . "ecomref " . $ecomref . ' ' . $ecomattribut, LOG_DEBUG);
		$this->error = '';
		$result=$this->wsfetch($ecomid, $ecomattribut, '');
		if ($result< 0) {
			$this->error .= " " . $langs->trans("ErrWSFetch");
			dol_syslog(get_class($this) . "::import_product erreur " . $this->error, LOG_DEBUG);
			return -1;
		}
		else {
			$prod = new Product($this->db);
			/* on vérifie si la référence est connue */
//			$res = $this->findInSite($ecomid, $ecomattribut, $this->ecom_ref);
			if(empty($rowid)) $rowid = $this->findInSite($ecomid, $ecomattribut);
			if ($rowid > 0) {
				$ec = new Ecom_product($this->db);
                $result=$ec->fetch($rowid);
				if ( $result> 0) {
					$doli_ref = $ec->doli_ref;
					dol_syslog(get_class($this) . "::import_product *** ec_product trouvé " . $ecomid . "attr " . $ecomattribut . ' ' . $doli_ref, LOG_DEBUG);
				}
				else {
					dol_syslog(get_class($this) . "::import_product ec_product non trouvé " . $ecomid . "attr " . $ecomattribut, LOG_DEBUG);
					return -1;
				}
			}
			else {
				dol_syslog(get_class($this) . "::import_product ec_product non trouvé " . $ecomid . "attr " . $ecomattribut, LOG_DEBUG);
				return -1;
			}
			dol_syslog(get_class($this) . "::import_product vérification existence prod  " . $doli_ref, LOG_DEBUG);

			if(!empty($doli_ref)) $prodexist = $prod->fetch('', $doli_ref);
			if ($prod->id > 0) {
				// produit existe déjà, cette fonction n'est pas appelée dans ce cas
				//Il est possible de ne pas créer $ecom_prod et utiliser $ec à la place
				$ecom_prod = new Ecom_product($this->db);
				$ecom_prod->siteid = $this->siteid;
				$res = $this->findInSite($ecomid, $ecomattribut, $this->ecom_ref);
				dol_syslog(get_class($this) . "::import_product produit existant " . $this->ecom_ref . " " . $ecomattribut . "  prod : " . $res, LOG_DEBUG);
				if ($res > 0) {
					$ecom_prod->doli_product = $prod->id;
                    $ecom_prod->doli_ref = $doli_ref;
                    $ecom_prod->ecom_product = $ecomid;
                    $ecom_prod->ecom_attribut = $ecomattribut;
                    $ecom_prod->ecom_ref = $this->reference;
                    $ecom_prod->site_status = $this->active;
                    $ecom_prod->site_stock = $this->quantity;
                    $ecom_prod->ecom_price = $this->price;
					$ecom_prod->long_desc = $this->description;
					$ecom_prod->declinaison = $this->declinaison;
					$ecom_prod->ecom_category = $this->id_category_default;
					$ecom_prod->datem = $prod->date_modification;
					$ecom_prod->date_send = $prod->date_modification;
					$ecom_prod->date_modif = $prod->date_modification;
                    $ecom_prod->id = $res;
                    $ecom_prod->siteid = $this->siteid;
					if ($ecom_prod->update($user) == -1) {
						$this->error .= $langs->trans("ErrMajPrdExist");

						dol_syslog(get_class($this) . "::import_product Erreur update " . $ecom_prod->error, LOG_DEBUG);
						return -1;
					}
					$prod->label = $this->label ;
					$prod->description = $this->description;
					$prod->array_options['options_prodref'] = $this->reference;
					$prod->array_options['options_declinaison'] = $this->declinaison;
					$prod->update($prod->id,$user);
					// import du stock et prix sans déclenchement de hook
					set_product_price_and_stock($prod->id,$this->quantity,$this->site->site_entrepot,1,$this->price,$this->_tax_rate,$this->name);
					set_product_category($prod,$this->id_category_default, $this->site->id);
				}
				else {
					dol_syslog(get_class($this) . "::import_product ecom_product non trouvé $ecomid, $ecomattribut" , LOG_DEBUG);
					return -1;
				}
			}
			else {
				// import
				$prod = $this->ecom2dolibarr($ecomid, $ecomattribut,0);
				if (!$prod) {
					$this->error .= $langs->trans("ErrEc2Dl");
					dol_syslog(get_class($this) . "::import_product Erreur ecom2dolibarr" . $ecomid . ' ' . $ecomattribut, LOG_DEBUG);
					return -1;
				}
				else {
					$prod->ref=$doli_ref;
					$prod->array_options["options_declinaison"] = $ec->declinaison;
					$id = $prod->create($this->user);
					if ($id > 0) {
						dol_syslog(get_class($this) . "::import_product produit créé " . $id . " image " . $this->e_image . " rep: " . $conf->produit->dir_output . "\n", LOG_DEBUG);
						$this->add_photo_web($id, $this->_image);

						// Barcode type
						$prod->setValueFrom('fk_barcode_type', 2);
						// Barcode value
						$prod->setValueFrom('barcode', $this->ean13);

						//Packs
						if ($this->is_pack) {
							foreach ($this->_pack_items as $item) {
								$idPr = ($this->findInSite($item['id_product_item'], '', $this->ecom_ref, 1));
								$prod->add_sousproduit($id, $idPr, $item['quantity']);
							}
						}

						$ecom_prod = new Ecom_product($this->db);
						if(empty($rowid)) $rowid = $this->findInSite($ecomid, $ecomattribut);
						if (!$rowid) {
							$this->error .= $langs->trans("ErrPrdEcomNotExist");
							dol_syslog(get_class($this) . "::import_product Erreur id introuvable " . $ecom_prod->error, LOG_DEBUG);
							return -1;
						}

						$res = $ecom_prod->fetch($rowid);
						if ($res == 1) {
							$this->db->begin();
							$error=0;
							$ecom_prod->doli_product = $id;
							$ecom_prod->site_stock = $this->quantity;
							$ecom_prod->site_status = $this->active;
							$ecom_prod->doli_ref = $doli_ref;
							$ecom_prod->ecom_ref = $this->ecom_ref;
							$ecom_prod->long_desc = $this->description;
							if ($ecom_prod->update($this->user) == -1) {
								$this->error .= $langs->trans("ErrMajEcom");
								dol_syslog(get_class($this) . "::import_product Erreur update " . $ecom_prod->error, LOG_DEBUG);
								return -1;
							}
							set_product_price_and_stock($id,$this->quantity,$this->site->site_entrepot,1,$this->price,$this->_tax_rate,$this->name);
							$this->db->commit();
							dol_syslog(get_class($this) . "::import_product stock " . $this->site->site_entrepot . " , " . $this->site_stock . " , resultat " . $res, LOG_DEBUG);
						}
						else {
							dol_syslog(get_class($this) . "::import_product ecom_product non trouvé " . $id, LOG_DEBUG);
							$this->error .= $langs->trans("ErrPrdEcomNotExist");
							return -1;
						}
					}
					else {
						$this->error .= $langs->trans("ErrPrdCreate") . " " . $prod->error;
						dol_syslog(get_class($this) . "::import_product erreur création produit " . $prod->error, LOG_DEBUG);
						return -1;
					}
					//Category
					set_product_category($prod,$this->id_category_default, $this->site->id);
					// if given create a supplier ref and price
					if ($this->ecomsupplier_id && $this->ecomsupplier_ref && $this->ecomsupplier_price) {
						$error = 0;

						$e_par = new E_params($this->db, $this->siteid, $this->user);
						$doli_supplierid = $e_par->ecom2doli_supplier($this->ecomsupplier_id);
						// TODO créer une configuration ?
						if (!$doli_supplierid) {
							dol_syslog(basename(__FILE__) . ":: Error no supplier found for " . $this->ecomsupplier_id, LOG_ERR);
							$error++;
						}
						$prodfour = new ProductFournisseur($this->db);
						if ($prodfour->fetch($prod->id) < 0) {
							dol_syslog(basename(__FILE__) . ":: Error no product found for" . $prod->id, LOG_ERR);
							$error++;
						}
						$supplier = new Fournisseur($this->db);
						if ($doli_supplierid && $supplier->fetch($doli_supplierid) < 0) {
							dol_syslog(basename(__FILE__) . ":: Error no supplier found for" . $doli_supplierid, LOG_ERR);
							$error++;
						}

						if ($error > 0) return -1;

						$this->db->begin();

						$ret = $prodfour->add_fournisseur($this->user, $doli_supplierid, $this->ecomsupplier_ref, 1);

						if ($ret < 0) {
							// TODO error traetement
							$error++;
						}
						else {
							$ret = $prodfour->update_buyprice(1, $this->ecomsupplier_price, $this->user, 'HT', $supplier, '', $this->ecomsupplier_ref, $this->e_taxrate);
							if ($ret < 0) {
								// TODO error
								$error++;
							}
						}

						if (!$error) $this->db->commit();
						else $this->db->rollback();

					}
				}
			}
		}
		return 1;
	}

	/** Import product informations with all its declinations (in ecom_product and product)
	 * If product exists in ecom_product, update in ecom_product and import in llx_product
	 * If product does not exist in ecom_product, create in ecom_product and import in llx_product
	 * @param $ecom_prodid
	 * @param $ecom_attribute
	 * @return int
	 * @throws Exception
	 */
	function import_product_with_declinations($ecom_prodid)
	{
		//parameter verification
		global $conf, $langs, $user;

		//webservice call to get all declinations and infos
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

		// Set the parameters to send to the WebService
		$parameters = array("prodid" => $ecom_prodid);

		// Set the WebService URL
		$client = new nusoap_client($this->site->site_ws_url . "/ws_articles.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

		// Call the WebService and store its result in $obj
		$obj = $client->call("get_article_with_declinations", $parameters);
		if ($client->fault) {
			$this->error = $langs->trans("ErrWSFault") . " " . $client->getError();
			dol_syslog("E_product::wsfetch get_article_with_declinations" . $this->error, LOG_DEBUG);
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if (is_array($obj) && count($obj) > 0) {
				foreach ($obj as $prodinfo) {
					// treat results

					$rowid = $this->findInSite($prodinfo["id_product"], $prodinfo["id_product_attribute"], $prodinfo["reference"], 0);
					if ($rowid > 0) {
						//product is on site : update ecom_prod
						$this->fetch($rowid);
						$this->site_stock = $prodinfo["quantity"];
						$this->site_status = $prodinfo["state"];
						$this->ecom_attribut = $prodinfo["id_product_attribute"];
						$this->datem = dol_now();
						$this->ecom_price = $prodinfo["price"];
						$this->ecom_ref = $prodinfo["reference"]; //mb_convert_encoding($obj[$i]["products_reference"], 'UTF-8','ISO-8859-1');
						$this->site_status = $prodinfo["state"];
						if ($this->update($this->user, 1) < 0) {
							//TODO error treatement in ecom_log also
							dol_syslog(get_class($this) . "::preimport_product_with_declinations " . $this->error, LOG_ERR);
						}
						else {
							if ($this->import_product($prodinfo["id_product"], $prodinfo["id_product_attribute"]) < 0) {
								dol_syslog(get_class($this) . "::preimport_product_with_declinations error creating new product declination " . $this->error, LOG_ERR);
								// ecom Log treatement
							}
						}
					}
					else {
						//new declination found we import article
						$this->datem = dol_now();
						$this->doli_ref = 'P'.$prodinfo["id_product"];
						if(!empty($prodinfo["id_product_attribute"]))$this->doli_ref .= 'A'.$prodinfo["id_product_attribute"];
						$this->doli_product = 0;
						$this->ecom_attribut = $prodinfo["id_product_attribute"]; //mb_convert_encoding($obj[$i]["attribut"], 'UTF-8','ISO-8859-1');
						$this->ecom_price = $prodinfo["price"];
						$this->ecom_product = $prodinfo["id_product"];
						$this->ecom_ref = $prodinfo["reference"]; //mb_convert_encoding($obj[$i]["products_reference"], 'UTF-8','ISO-8859-1');
						$this->siteid = $this->siteid;
						$this->site_status = $prodinfo["state"];
						if ($this->create($user) < 0) {
							$ecomlog = new Ecom_log($this->db);
							$ecomlog->site_id = $this->siteid;
							$ecomlog->log_date = dol_now();
							$ecomlog->log_type = "ERR";
							$ecomlog->log_fct = 'PRD';
							$ecomlog->log_fonction = $langs->trans("ErrImpPrd");
							$ecomlog->log_message = $langs->trans("ErrLogPrdEcomCreate") . " " . $this->ecom_product . " " . $this->error;
							$ecomlog->create($user);
						}
						else {
							if ($this->import_product($prodinfo["id_product"], $prodinfo["id_product_attribute"]) < 0) {
								dol_syslog(get_class($this) . "::preimport_product_with_declinations error creating new product declination " . $this->error, LOG_ERR);
								// ecom Log treatement
							}
						}
					}
				} // foreach declination
			} // if $obj
		}
		else {
			// webservice error
			$this->error = $langs->trans("ErrError") . $client->getError();
			dol_syslog(get_class($this) . "::wsfetch erreur client soap" . $this->error, LOG_ERR);
			return -1;
		}
		return 1;
	}

	/** appeler depuis import_product pour Vérifier si le stock existe pour le produit dans Dolibarr
	 *
	 *
	 **/
	function find_stock($entrepot, $doliprod)
	{
		$sql = "SELECT rowid, fk_entrepot, fk_product, reel FROM " . MAIN_DB_PREFIX . "product_stock ";
		$sql .= " WHERE fk_entrepot = '" . $entrepot . "' AND fk_product = '" . $doliprod . "'";
		dol_syslog(get_class($this) . "::find-stock" . $entrepot . ', ' . $doliprod . "\n" . $sql . "\n", LOG_DEBUG);

		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				return $obj->rowid;
			}
			else {
				return -1;
			}
		}
		else {
			dol_syslog(get_class($this) . "::find_stock sql=" . $sql, LOG_DEBUG);
			return -1;
		}

	}

	/** Appelée depuis ecom2dolibarr pour retourner doli_product à partir de $ecomprod et $attribut
	 * @param $ecomprod
	 * @param string $attribut
	 * @return string
	 * @throws Exception
	 */
	function get_doliproduct($ecomprod, $attribut = '')
	{

		$sql = "SELECT ep.doli_product ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
		$sql .= " WHERE ep.ecom_product = '" . $ecomprod . "' AND ep.siteid = '" . $this->site->id . "'";
		if(!empty($attribut))$sql .= " AND ep.ecom_attribut = '" . $attribut. "'";
		else {
			$sql .= " ORDER BY ep.rowid LIMIT 1";
		}

		dol_syslog(get_class($this) . "::get_doliproduct sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				return $obj->doli_product;
			}
			else {
				return '0';
			}
		}
		else {
			dol_syslog(get_class($this) . "::get_doliproduct sql=" . $sql, LOG_DEBUG);
			return '';
		}
	}

	/** find product in ecom_product
	 *
	 * on ecomid + attrib code
	 */
	function findInSite($ecomprod, $attribut = '', $ref = '', $mode = 0)
	{

		// search on reference
		if ($ref) {
			$sql = "SELECT ep.rowid, ep.doli_product ";
			$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
			$sql .= " WHERE ep.doli_ref = '" . $ref . "' AND ep.ecom_product = '" . $ecomprod . "' AND ep.siteid = '" . $this->site->id . "'";

			dol_syslog(__FILE__ . "::" . __FUNCTION__ . " : search on ref " . $sql, LOG_DEBUG);
			$resql = $this->db->query($sql);
			if ($resql) {
				if ($this->db->num_rows($resql)) {
					$obj = $this->db->fetch_object($resql);
					if ($mode == 0)
						return $obj->rowid;
					else
						return $obj->doli_product;
				}
				// not found by ref
				else {
					dol_syslog(__FILE__ . "::" . __FUNCTION__ . " : search on ref error " . $sql, LOG_DEBUG);
				}
			}
		}

		$sql = "SELECT ep.rowid, ep.doli_product ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
		$sql .= " WHERE ep.ecom_product = '" . $ecomprod . "' AND ep.siteid = '" . $this->site->id . "'";
		if ($attribut) $sql .= " AND ep.ecom_attribut='" . $attribut . "'";

		dol_syslog(get_class($this) . "::findInSite sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				if ($mode == 0)
					return $obj->rowid;
				else
					return $obj->doli_product;
			}
			else {
				return '';
			}
		}
		else {
			dol_syslog(get_class($this) . "::findInSite sql=" . $sql, LOG_DEBUG);
			return '';
		}
	}

	/** Non appelée
	 *
	 */
	function get_stock_site($prodid)
	{
		// lecture stock du produit dans l'entrepot

		$sql = "SELECT reel ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "product_stock ";
		$sql .= " WHERE fk_product = '" . $prodid . "' AND fk_entrepot = '" . $this->site->site_entrepot . "'";

		dol_syslog(get_class($this) . "::get_stock_site sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				return $obj->reel;
			}
			else {
				return '';
			}
		}
		else {
			dol_syslog(get_class($this) . "::stock_site sql=" . $sql, LOG_DEBUG);
			return '';
		}
	}

	/** Crée un produit sur Presta et ajoute l'enregistrement correspondant dans ecom_product
	 * @param $prodid id produit dans Dolibarr
	 * @param $catid id catégorie dans Presta
	 * @param $taxid non utilisé pour le moment
	 * @return int
	 * @throws Exception
	 */
	function sell_product($prodid, $catid, $taxid)
	{
		global $conf, $langs;

		// sell a product on site
		/* contrôle parameters */
		if (!$this->siteid) {
			dol_syslog(get_class($this) . "::sell_product error siteid", LOG_DEBUG);
			return -1;
		}

		$doliprod = new Product($this->db);
		$doliprod->fetch($prodid);

		if (!$doliprod->id) {
			dol_syslog(get_class($this) . "::sell_product error product" . $prodid, LOG_DEBUG);
			return -1;
		}

		//stock dispo
		//$stock = $this->get_stock_site($prodid);
		//if (!$stock) $stock = 0;
		//le stock saisi remplace le stock en ligne ou par défaut 0
		if (!$this->site_stock) $this->site_stock = 0;

		// initialise variables
		$prod = array();
		$prod['ref'] = $doliprod->ref;
		$prod['nom'] = $doliprod->label;
		$prod['desc'] = $doliprod->description;
		$prod['long_desc'] = $this->long_desc;
		$prod['quant'] = $this->site_stock;
		$prod['prix'] = ($this->price) ? (string)$this->price : '';

		$taxid = get_vat_rate_id($doliprod->tva_tx);

		$prod['ttax'] = $taxid;
		$prod['poids'] = ($this->weight) ? (string)$this->weight : $doliprod->weight;
		// gèrer $doliprod->weight_units
		$prod['dispo'] = '';
		$prod['status'] = ($this->price) ? '1' : '0';
		$prod['fourn'] = ($this->fourn) ? (string)$this->fourn : '';
		$prod['url'] = '';
		$prod['catid'] = $catid;
		//ecotaxe montant
		$prod['ecotax'] = $this->ecotax;

/*		// multiprix
		if (!empty($conf->global->PRODUIT_MULTIPRICES)) {
			// TODO tenir compte du $multiprices_base_type de la tva ...
			$tabprices = array();
			dol_syslog("E_product::sell_product multipirx " . print_r($doliprod->multiprices, true), LOG_DEBUG);
			foreach ($doliprod->multiprices as $key => $price) {
				$group_id = $this->get_groupforlevel($key);
				if (!empty($price) && $group_id > 0) $tabprices[] = array("group" => $group_id, "price" => $price);
			}
			$prod["multiprice"] = $tabprices;
		}*/

		// features
		$prod["features"] = $this->get_features($prodid);

		//recherche de l'image
		$pdir = get_exdir($doliprod->id, 2, 0, 0, $doliprod, '');
		$dir = $conf->produit->dir_output . '/' . $pdir;
		$img = $doliprod->liste_photos($dir);
		dol_syslog(get_class($this) . "::sell_product image " . $dir . count($img), LOG_DEBUG);
		if (count($img) == 0) $prod['image'] = '';
		else {
			//on prend toujours la grande
			$filename = $img[0]['photo'];
			$prod['image'] = $filename; //dolibarr_trunc($filename,25);
			dol_syslog(get_class($this) . "::sell_product image filename" . $filename . count($img), LOG_DEBUG);
		}
		if (!$conf->global->ECOM_PRODUCT_WITH_IMAGE) {
			dol_syslog(get_class($this) . "::sell_product ECOM_PRODUCT_WITH_IMAGE= " . $conf->global->ECOM_PRODUCT_WITH_IMAGE, LOG_DEBUG);
			if ($prod["image"] == '') {
				$this->error = $langs->trans("ErrNoImage");
				dol_syslog(get_class($this) . "::sell_product no image", LOG_DEBUG);
				return -1;
			}
			else dol_syslog(get_class($this) . "::sell_product image" . $dir . count($img), LOG_DEBUG);
		}

		//WebService Client.
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . '/nusoapmime.php');

		// Création
		// Set the parameters to send to the WebService
		$parameters = array("prod" => $prod);

		dol_syslog(get_class($this) . "::sell_product paramas : " . print_r($parameters, true), LOG_DEBUG);
		// Set the WebService URL
		$client = new nusoap_client_mime($this->site->site_ws_url . "/ws_articlesmime.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''), false);
		if ($err = $client->getError()) {
			$this->error = $langs->trans("ErrWSFault") . " " . $err;
			dol_syslog(get_class($this) . "::sell_product Erreur constructeur", LOG_DEBUG);
			return -1;
		}

		//attacher l'image
		if ($prod["image"]) $cid = $client->addAttachment('', $conf->produit->dir_output . '/' . $pdir . $prod['image']);

		// Call the WebService and store its result in $result.
		$result = $client->call("send_article", $parameters);
		if ($client->fault) {
			$this->error = $langs->trans("ErrWSFault");
			return -1;
		}
		elseif (!($err = $client->getError())) {
			dol_syslog("E_product::sell_product result " . print_r($result, true), LOG_ERR);
			if ($result) {
				// maj de ecom_product
				$this->id = $this->findrowid($prodid);
				$this->fetch($this->id);

				$prid = $result["article"];
				if ($prid < 0) {
					dol_syslog("E_product::sell_product product online $prid " . $result["error"], LOG_ERR);
					$this->error = $result["error"];
					$this->date_send = null;
					$retour = -1;
				}
				else {
					$this->ecom_product = $prid;
					$this->doli_product = $prodid;
					$this->ecom_ref = $doliprod->ref;
					$this->datem = mktime();
					$this->site_status = '1';
					$this->ecom_attribut = '';
					$this->ecom_price = 0.0;
					$retour = 1;
				}
				if ($this->id < 0) {
					if ($this->create($user) < 0) {
						$this->error = $langs->trans("ErrEcomPrdCreate");
						dol_syslog(get_class($this) . "::sell_product erreur création ecom_product " . $this->error, LOG_DEBUG);
						return -1;
					}
					else dol_syslog(get_class($this) . "::sell_product création ecom_product ok", LOG_DEBUG);
				}
				else {
					if ($this->update($user) < 0) {
						$this->error = $langs->trans("ErrEcomPrdMaj");
						dol_syslog(get_class($this) . "::sell_product erreur création ecom_product " . $this->error, LOG_DEBUG);
						return -1;
					}
					else dol_syslog(get_class($this) . "::sell_product création ecom_product ok", LOG_DEBUG);
				}
			}
			else {
				dol_syslog(get_class($this) . "::sell_product erreur result " . $result, LOG_ERR);
				return -1;
			}
		}
		else {
			$message = print_r($client->response, true);
			dol_syslog(get_class($this) . "::sell_product error ws $err " . $message, LOG_ERR);
			return -1;
		}


		return $retour;
	}


	/** renvoie le rowid depuis l'id dolibarr doli_product, -1 si non trouvé
	 * @param $prodid
	 * @return int
	 * @throws Exception
	 */
	function findrowid($prodid)
	{
		$sql = "SELECT rowid ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ";
		$sql .= " WHERE doli_product = '" . $prodid . "' AND siteid = '" . $this->site->id . "'";

		dol_syslog(get_class($this) . "::findrow sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				return $obj->rowid;
			}
			else {
				return -1;
			}
		}
		else {
			dol_syslog(get_class($this) . "::findrow sql=" . $sql, LOG_DEBUG);
			return -1;
		}
	}

	/** Active/désactive un produit dans Presta et dans llx_ecom
	 * @param $prodid
	 * @param string $action
	 * @return int
	 * @throws Exception
	 */
	function activate($prodid, $action = '0')
	{

		$sql = "SELECT rowid, ecom_product, doli_product";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ";
		$sql .= " WHERE doli_product = '" . $prodid . "' AND siteid = '" . $this->site->id . "'";

		dol_syslog(get_class($this) . "::activate sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$id_ecom = $obj->ecom_product;
                $p=new Product($this->db);
                $p->fetch($obj->doli_product);
                $p->status=$action;
                $p->update($obj->doli_product,$this->user);
			}
			else {
				return -1;
			}
		}
		else {
			dol_syslog(get_class($this) . "::activate sql=" . $sql, LOG_DEBUG);
			return -1;
		}
// mise à jour en ligne
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

		// Set the parameters to send to the WebService
		$parameters = array("prodid" => $id_ecom, "status" => $action);

		// Set the WebService URL
		$client = new nusoap_client($this->site->site_ws_url . "/ws_articles.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

		// Call the WebService and store its result in $obj
		$obj = $client->call("set_status", $parameters);
		if ($client->fault) {
			$this->error = $langs->trans("ErrWSFault");
			dol_syslog(get_class($this) . "::set_status " . $this->error, LOG_DEBUG);
			return -1;
		}
		elseif (!($err = $client->getError())) {
			dol_syslog(get_class($this) . "::activate réussie " . $id_ecom, LOG_DEBUG);
		}
		else {
			dol_syslog(get_class($this) . "::activate raté " . $err, LOG_DEBUG);
			return -1;
		}

		//mise à jour locale on active un produit et tous ses attributs

		$this->db->begin();
		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_product ";
		$sql .= " SET site_status ='" . $action . "', datem = FROM_UNIXTIME(" . dol_now().")";
		$sql .= " WHERE siteid ='" . $this->siteid . "' AND ecom_product ='" . $id_ecom . "'";

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);

		if (!$resql) {
			$this->db->rollback();
			dol_syslog(get_class($this) . "::activate error sql=" . $sql, LOG_ERR);
			return -1;
		}
		else $this->db->commit();
		return 1;
	}

	/** Modifie le produit Dolibarr dans presta conformément à this
	 * @param $doliprod Id Dolibarr du produit
	 * @return float|int
	 * @throws Exception$
	 */
	function modify($doliprod)
	{
		global $langs, $conf;

		$sql = "SELECT ep.rowid, ep.ecom_product, ep.ecom_attribut";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
		$sql .= " WHERE ep.doli_product = '" . $doliprod . "' AND ep.siteid = '" . $this->site->id . "'";

		dol_syslog(get_class($this) . "::modify sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$ecomid = $obj->ecom_product;
				$attrib = $obj->ecom_attribut;
				$rowid = $obj->rowid;
			}
			else {
				$this->error = $langs->trans("ErrNoProd") . " " . $doliprod;
				dol_syslog("E_product::modify " . $this->error, LOG_DEBUG);
				return -1;
			}
		}
		else {
			dol_syslog("E_product::modify sql=" . $sql, LOG_DEBUG);
			return -1;
		}
		$modifs = array();

		$p = new Product($this->db);
		$p->fetch($doliprod);
		$p->load_stock();
		$cat = new Categorie($this->db);
		$categories = $cat->containing($doliprod, 'product');
		$modifs['id_product_attribute'] = $attrib;
		$modifs['name'] = $p->label;
		$modifs['description_short'] = $p->description;
		$modifs['description'] = $p->description;
		$modifs['reference'] = $p->array_options['options_prodref'];
		$modifs['ecom_ref'] = $p->array_options['options_prodref'];
		$modifs['id_category_default'] = $categories[0]->id;
		$modifs['price'] = $p->price;
		$modifs['quantity'] =$p->stock_warehouse[$this->site->site_entrepot]->real ;
		$modifs['active'] =$p->status;
		$parameters = array("tabmod" => $modifs, "prodid" => $ecomid);
		dol_syslog("E_product::modify " . print_r($parameters, true), LOG_DEBUG);

		// Set the WebService URL
		$client = new nusoap_client($this->site->site_ws_url . "/ws_articles.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
		// Call the WebService and store its result in $obj
		$obj = $client->call("modif_article", $parameters);
		if ($client->fault) {
			$this->error = $langs->trans("ErrWSFault") . " " . $client->getError();
			dol_syslog("E_product::modify " . $this->error, LOG_DEBUG);
			return -1;
		}
		elseif (!($err = $client->getError())) {
			dol_syslog("E_product::modify réussi", LOG_DEBUG);
		}
		else {
			dol_syslog("E_product::modify raté " . $err . " " . print_r($client, true), LOG_DEBUG);
			return -1;
		}

		//mise à jour locale

		$this->fetch($rowid);

		if(isset($modifs['price']))$this->ecom_price=$modifs['price'];
		if(isset($modifs['quantity'])) $this->site_stock=$modifs['quantity'];
		if(isset($modifs['id_category_default'])) $this->ecom_category=$modifs['id_category_default'];
		return $this->update($this->user, 1); // traiter cas erreur
	}

	/** Non appelée
	 * sets a batch treatment for modify product online
	 * @param integer $prodid
	 * @param array $tabprod
	 */
	function batch_modify($prodid, $date_modif = '')
	{
		$tabprod = array("quantity" => $this->site_stock,
			"categ" => $this->catid,
			"manuf" => $this->fourn,
			"price" => $this->price
		);

		$rowid = $this->findrowid($prodid);
		if ($rowid < 0) {
			$this->error = 'Product not found';
			return -1;
		}
		$this->fetch($rowid);
		$this->site_stock = $tabprod["quantity"];
		$this->ecom_category = $tabprod["categ"];
		$this->ecom_manuf = $tabprod["manuf"];
		$this->ecom_price = $tabprod["price"];

		$this->date_modif = (empty($date_modif) ? dol_now() : $date_modif);

		if ($this->update($this->user) < 0) {
			$this->error = "Error batch modif " . $this->db->error;
			return -1;
		}
		return 1;

	}

	/** Non appelée
	 * @param $att
	 * @return string
	 * @throws Exception
	 */
	function get_attr_lib($att)
	{
		$lib_attr = ' ';
		while (strlen($att) > 0) {
			$ch = substr($att, 0, 5);
			$att = substr($att, 5);
			$n = sscanf($ch, "%02d%03d", $opt, $val);
			$ecomid = substr($ch, 2);

			$sql = "SELECT ecom_lib FROM " . MAIN_DB_PREFIX . "ecom_params ";
			$sql .= " WHERE siteid = '" . $this->site->id . "' AND partype = 'prdoptva' AND ecom_id = '" . $ecomid . "'";

			dol_syslog("E_product::get_attr_lib sql=" . $sql, LOG_DEBUG);

			$resql = $this->db->query($sql);
			if ($resql) {
				if ($this->db->num_rows($resql)) {
					$obj = $this->db->fetch_object($resql);
					$ecomlib = $obj->ecom_lib;
				}
				else {
					$ecomlib = '';
				}
			}
			else {
				dol_syslog("E_product::get_attr_lib sql=" . $sql, LOG_DEBUG);
				$ecomlib = 'erreur ' . $ecomid;
			}
			$lib_attr .= $ecomlib . ' ';
		}
		return $lib_attr;
	}

	/** Fonction non appelée et ne fait rien car la fonction get_groupforlevel n'est pas encore correctement implémentée et
	 * La constante ECOM_DEFAULT_PRICE_LEVEL n'existe pas
	 * Update price or prices on ecommerce site
	 * @param int $prodid
	 * @product object $product
	 */
	function update_prices($prodid, $product)
	{
		global $langs, $conf;

		if (!$product) {
			// TODO

		}
		// recherche id ecommerce
		$sql = "SELECT rowid, ecom_product, ecom_attribut ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product ";
		$sql .= " WHERE doli_product = '" . $prodid . "' AND siteid = '" . $this->site->id . "'";

		dol_syslog("E_product::update prices sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$id_ecom = $obj->ecom_product;
				//        	$attribut = $obj->ecom_attribut;
			}
			else {
				$this->error = "Prodcut not found on site ";
				dol_syslog("E_product::update price " . $this->error, LOG_DEBUG);
				return -1;
			}
		}

		dol_syslog("update_prices " . print_r($product, true), LOG_DEBUG);
		if ($product->pricelevel > 0) {
			$level = $product->pricelevel;
			dol_syslog("update_prices " . $level . "  " . $price, LOG_DEBUG);
			if (!empty($conf->global->ECOM_DEFAULT_PRICE_LEVEL) && ($level == $conf->global->ECOM_DEFAULT_PRICE_LEVEL)) {
				$this->price = $product->price;
				dol_syslog("E_product::update_prices  multi prix de base", LOG_DEBUG);
				return $this->modify($prodid);
			}

			// chercher le groupe correspondant au level
			$group_id = $this->get_groupforlevel($level);
			if ($group_id > 0) {
				$prices[] = array("group" => $group_id, "price" => $product->multiprices[$level]);
				// appel web service
				$soap_client = new webservice_ecom($this->site->site_ws_url, 'ws_articles.php');
				$p = array("prodid" => $id_ecom, "attrib" => $attribut, "prices" => $prices);
				$soap_client->ws_call('update_price', $p);

				if (!$soap_client->resko) {
					dol_syslog("E_product::update_prices multi OK", LOG_DEBUG);
				}
				else {
					dol_syslog("E_product::update_prices multi KO " . $soap_client->error, LOG_DEBUG);
				}
			}
		}
		else {
			//maj prix classique
			$this->price = $product->price;
			return $this->modify($prodid);
		}
	}

	/** Non appelée Inutiliséé au niveau du serveur avec $prod["multiprice"] danssell_product . Utilise la table inexistante ecom_customer_type.
	 * Appelée par auto:sellproduct et auto:updateprices
	 * gets ecommerce group id for dolibarr price level
	 * @param int $level
	 */
	function get_groupforlevel($level)
	{
		$sql = "SELECT ecom_id FROM " . MAIN_DB_PREFIX . "ecom_customer_tysell_product pe WHERE doli_tarif_id = '" . $level . "'";

		$id_ecom = 0;
		dol_syslog("E_product::get_groupforlevel sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$id_ecom = $obj->ecom_id;
			}
			else {
				return -1;
			}
		}
		else {
			dol_syslog("E_product::get_groupforlevel sql=" . $sql, LOG_ERR);
			return -1;
		}

		return $id_ecom;
	}

	/** appelée depuis sell_product pourr retourner un tableau de features depuis les champs extra du produit
	 * @param $doliprod id produit dans Dolibarr
	 * @return array
	 * @throws Exception
	 */
	function get_features($doliprod)
	{
		$sql = "SELECT * FROM " . MAIN_DB_PREFIX . "product_extrafields WHERE fk_object = '" . $doliprod . "'";
		dol_syslog("E_product::get_features sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			$prodoptions = $this->db->fetch_array($resql);
		}
		else return array();

		$tab = array();
		$sql = "SELECT ep.ecom_id, ep.doli_id, ex.name FROM " . MAIN_DB_PREFIX . "ecom_params ep ";
		$sql .= " JOIN " . MAIN_DB_PREFIX . "extrafields ex ON ex.rowid = ep.doli_id ";
		$sql .= " WHERE ep.siteid = '" . $this->siteid . "' AND ep.partype = 'prdfeat' AND ep.doli_id > 0";

		dol_syslog("E_product::get_features sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			while ($row = $this->db->fetch_object($resql)) {
				$tab[] = array("feature_id" => $row->ecom_id, "feature_value" => $prodoptions[$row->name]);
			}
		}

		dol_syslog("E_product::get_feature " . print_r($tab, true), LOG_DEBUG);
		return $tab;
	}

	/**
	 *
	 * returns value of field defined as longdesc
	 * @param integer $product
	 */

	/**  Non appelée  et ECOM_FIELD_LONGDESC non définie
	 * @param $productid
	 * @return string
	 * @throws Exception
	 */
	function get_longdesc($productid)
	{
		global $conf;

		if (empty($conf->global->ECOM_FIELD_LONGDESC)) return '';

		$sql = "SELECT " . $conf->global->ECOM_FIELD_LONGDESC . " as longdesc FROM " . MAIN_DB_PREFIX . "product_extrafields WHERE fk_object = '" . $productid . "' ";
		dol_syslog("E_product::get_longdesc sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			$obj = $this->db->fetch_object($resql);
			if ($obj) return $obj->longdesc;
			else return '';
		}
		else {
			dol_syslog(basename(__FILE__) . "::" . __FUNCTION__ . ":: erreur sql " . $sql, LOG_ERR);
			return '';
		}
	}

	/** Non appelée
	 * Replace images from ecommerce with dolibarr's pictures
	 * @param integer $doliprod
	 */
	function replace_images($doliprod_id)
	{
		global $conf, $langs;

		// is product on sell on e-commerce
		$rowid = $this->findrowid($doliprod_id);
		if ($rowid < 0) {
			$this->error = "Product not on sell on ecommerce " . $doliprod_id;
			return -1;
		}

		$doliprod = new Product($this->db);
		$doliprod->fetch($doliprod_id);

		$this->fetch($rowid);
		$ecomid = $this->ecom_product;
		$attribut = $this->ecom_attribut;

		// dolibarr images
		$pdir = get_exdir($doliprod->id, 2) . $doliprod->id . "/photos/";
		$dir = $conf->produit->dir_output . '/' . $pdir;
		$imglist = $doliprod->liste_photos($dir);
		dol_syslog(get_class($this) . ":: image $dir " . sizeof($imglist), LOG_DEBUG);
		asort($imglist); // tri en ordre croissant

		$img_to_process = array();
		if (count($imglist) > 0) {
			if (!empty($conf->global->ECOM_MAXIMAGES_SEND)) $maxim = (count($imglist) > $conf->global->ECOM_MAXIMAGES_SEND) ? $conf->global->ECOM_MAXIMAGES_SEND : count($imglist);
			else $maxim = 1;
			$i = 0;
			foreach ($imglist as $image) {
				if ($i < $maxim) $img_to_process[] = $image["photo"];
				$i++;
			}
			$prod["image"] = $img_to_process[0]; // photo de couverture

			dol_syslog(get_class($this) . '::' . __METHOD__ . ":: nombre d'image à envoyer " . $maxim . " " . print_r($img_to_process, true), LOG_DEBUG);

		}
		else return 1; // pas d'images à traiter

		// webservices
		require_once(DOL_DOCUMENT_ROOT . "/ecommerce/class/webservice_ecom.class.php");
		$ecomws = new webservice_ecom($this->site->site_ws_url, 'ws_articlesmime.php', 'MIME');
		// TODO gestion attributs
		$attribut = '';
		// attacher les images
		if ($maxim) {
			foreach ($img_to_process as $image) {
				$filename = $dir . $image;
				dol_syslog(get_class($this) . ":: attache image " . $filename, LOG_DEBUG);
				if ($ecomws->addAttachment('', $filename) < 0) {
					dol_syslog(get_class($this) . '::' . __METHOD__ . ":: error image attachement " . $ecomws->error, LOG_ERR);
				}
				//$cid = $client->addAttachment($data, basename($filename));
			}
		}
		$p = array('id_product' => $ecomid, 'attribut' => $attribut);
		$res = $ecomws->ws_call('replace_image', $p);

		if ($res < 0) {
			$this->error = "webservice error " . $ecomws->error;
			return -1;
		}
		if ($ecomws->resko) {
			$this->error = "webservice error " . $ecomws->error;
			return -1;
		}
		else {
			dol_syslog(get_class($this) . '::' . __METHOD__ . ":: images send", LOG_DEBUG);
		}

		return 1;

	}

	/**  Copie fichier image depuis Presta
	 *
	 * @param string $sdir Repertoire destination finale
	 * @param string $file url de l'image
	 * @return    void
	 */
	function add_photo_web($id, $file)
	{
		global $conf;

		$sdir = $conf->produit->dir_output;
		$p = new Product($this->db);
		$p->fetch($id);
		$dir = $sdir . '/' . get_exdir($id, 2, 0, 0, $p);

		$dir_osencoded = dol_osencode($dir);
		if (!file_exists($dir_osencoded)) {
			dol_syslog("Product Create " . $dir);
			dol_mkdir($dir);
		}

		if (file_exists($dir_osencoded)) {
			// Cree fichier en taille vignette
			// TODO A faire
			$stream = stream_context_create(array(
				'ssl'=>array(
					'verify_peer'=> false,
					'verify_peer_name'=> false, ),
				'http' => array(
					'timeout' => 30     ) )     );

			// Cree fichier en taille origine
			$content = file_get_contents($file,0,$stream);
/*			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $file);
			$content = curl_exec($ch);
			curl_close($ch);*/

			if ($content) {
				$nom = basename($file);
				$im = fopen(dol_osencode($dir . $nom), 'wb');
				fwrite($im, $content);
				fclose($im);
			}
		}
	}

}


