<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010      Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013 Philippe Grand       <philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       htdocs/ecommerce/class/ecom_product.class.php
 *      \ingroup    products
 *        \author        Jean Heimburger - www.tiaris.fr
 */

/**
 *      \class      Ecom_product
 *      \brief      Product class for e-commerce site
 */
class Ecom_product extends CommonObject
{
	var $id;

	var $siteid;
	var $doli_product;
	var $doli_ref;
	var $ecom_product;
	var $ecom_attribut;
	var $ecom_ref;
	var $site_status;
	var $site_stock;
	var $datem = '';
	var $long_desc;


	/**
	 *  Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *      Create in database
	 * @param user            User that create
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, Id of created object if OK
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->doli_product)) $this->doli_product = trim($this->doli_product);
		if (isset($this->doli_ref)) $this->doli_ref = trim($this->doli_ref);
		if (isset($this->ecom_product)) $this->ecom_product = trim($this->ecom_product);
		if (isset($this->ecom_attribut)) $this->ecom_attribut = trim($this->ecom_attribut);
		if (isset($this->ecom_ref)) $this->ecom_ref = trim($this->ecom_ref);
		if (isset($this->site_status)) $this->site_status = trim($this->site_status);
		if (isset($this->site_stock)) $this->site_stock = trim($this->site_stock);
		if (isset($this->long_desc)) $this->long_desc = trim($this->long_desc);
		if (isset($this->declinaison)) $this->declinaison = trim($this->declinaison);


		// Insert request
        $now=date('Y-m-d H:i:s', dol_now());

		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_product(";
		$sql .= " siteid,";
		$sql .= " doli_product,";
		$sql .= " doli_ref,";
		$sql .= " ecom_product,";
		$sql .= " ecom_attribut,";
		$sql .= " ecom_ref,";
		$sql .= " site_status,";
		$sql .= " site_stock,";
		$sql .= " datem,";
		$sql .= " date_send,";
		$sql .= " ecom_category,";
		$sql .= " ecom_price,";
		$sql .= " long_desc,";
		$sql .= " declinaison";

		$sql .= ") VALUES (";
		$sql .= " " . (!isset($this->siteid) ? 'NULL' : "'" . $this->siteid . "'") . ",";
		$sql .= " " . (!isset($this->doli_product) ? 'NULL' : "'" . $this->doli_product . "'") . ",";
		$sql .= " " . (!isset($this->doli_ref) ? 'NULL' : "'" . $this->db->escape($this->doli_ref) . "'") . ",";
		$sql .= " " . (!isset($this->ecom_product) ? 'NULL' : "'" . $this->ecom_product . "'") . ",";
		$sql .= " " . (!isset($this->ecom_attribut) ? "''" : "'" . $this->db->escape($this->ecom_attribut) . "'") . ",";
		$sql .= " " . (!isset($this->ecom_ref) ? 'NULL' : "'" . $this->db->escape($this->ecom_ref) . "'") . ",";
		$sql .= " " . (!isset($this->site_status) ? 'NULL' : "'" . $this->site_status . "'") . ",";
		$sql .= " " . (!isset($this->site_stock) ? 'NULL' : "'" . $this->site_stock . "'") . ",";
		$sql .= " " . (!isset($this->datem) || strlen($this->datem) == 0 ? 'NULL' : ("'" . $this->db->idate($this->datem)) ."'" ). ",";
		$sql .= " " . (!isset($this->date_send) ? "'" .$now. "'" : "'" . $this->db->idate($this->date_send) . "'") . ",";
		$sql .= " " . (!isset($this->ecom_category) ? '0' : "'" . $this->db->escape($this->ecom_category) . "'") . ",";
		$sql .= " " . (!isset($this->ecom_price) ? '0' : "'" . $this->db->escape($this->ecom_price) . "'") . ",";
		$sql .= " " . (!isset($this->long_desc) ? 'NULL' : "'" . $this->db->escape($this->long_desc) . "'") . ",";
		$sql .= " " . (!isset($this->declinaison) ? 'NULL' : "'" . $this->db->escape($this->declinaison) . "'") . "";
		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_product");

			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}


	/**
	 *    Load object in memory from database
	 * @param id          id object
	 * @return     int         <0 if KO, >0 if OK
	 */
	function fetch($id)
	{
		global $langs;
		$sql = "SELECT";
		$sql .= " t.rowid,";
		$sql .= " t.siteid,";
		$sql .= " t.doli_product,";
		$sql .= " t.doli_ref,";
		$sql .= " t.ecom_product,";
		$sql .= " t.ecom_attribut,";
		$sql .= " t.ecom_ref,";
		$sql .= " t.site_status,";
		$sql .= " t.site_stock,";
		$sql .= " t.datem,";
		$sql .= " t.date_modif,";
		$sql .= " t.ecom_category,";
		$sql .= " t.ecom_price,";
		$sql .= " t.long_desc,";
		$sql .= " t.declinaison";

		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;
				$this->siteid = $obj->siteid;
				$this->doli_product = $obj->doli_product;
				$this->doli_ref = $obj->doli_ref;
				$this->ecom_product = $obj->ecom_product;
				$this->ecom_attribut = $obj->ecom_attribut;
				$this->ecom_ref = $obj->ecom_ref;
				$this->site_status = $obj->site_status;
				$this->site_stock = $obj->site_stock;
				$this->datem = $this->db->jdate($obj->datem);
				$this->date_modif = $obj->date_modif;
				$this->ecom_category = $obj->ecom_category;
				$this->ecom_price = $obj->ecom_price;
				$this->long_desc = $obj->long_desc;
				$this->declinaison = $obj->declinaison;


			}
			$this->db->free($resql);

			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 *      Update database
	 * @param user            User that modify
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->doli_product)) $this->doli_product = trim($this->doli_product);
		if (isset($this->doli_ref)) $this->doli_ref = trim($this->doli_ref);
		if (isset($this->ecom_product)) $this->ecom_product = trim($this->ecom_product);
		if (isset($this->ecom_attribut)) $this->ecom_attribut = trim($this->ecom_attribut);
		if (isset($this->ecom_ref)) $this->ecom_ref = trim($this->ecom_ref);
		if (isset($this->site_status)) $this->site_status = trim($this->site_status);
		if (isset($this->site_stock)) $this->site_stock = trim($this->site_stock);
		if (isset($this->ecom_price)) $this->ecom_price = trim($this->ecom_price);
		if (isset($this->long_desc)) $this->long_desc = trim($this->long_desc);
		if (isset($this->declinaison)) $this->declinaison = trim($this->declinaison);
		if (isset($this->ecom_category)) $this->ecom_category = trim($this->ecom_category);


		// Update request

		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_product SET";
		if (isset($this->siteid)) $sql .= " siteid=" . $this->db->escape($this->siteid);
		else                            $sql .= " siteid=1";
		$sql .= " ,doli_product='" . $this->db->escape($this->doli_product) . "'";
		$sql .= " ,doli_ref='" . $this->db->escape($this->doli_ref) . "'";
		$sql .= " ,ecom_product='" . $this->db->escape($this->ecom_product) . "'";
		$sql .= " ,ecom_attribut='" . $this->db->escape($this->ecom_attribut) . "'";
		$sql .= " ,ecom_ref='" . $this->db->escape($this->ecom_ref) . "'";
		$sql .= " ,site_status='" . $this->db->escape($this->site_status) . "'";
		$sql .= " ,site_stock='" . $this->db->escape($this->site_stock) . "'";
		$sql .= " ,ecom_price='" . $this->db->escape(price2num($this->ecom_price)) . "'";
		$sql .= " ,long_desc='" . $this->db->escape($this->long_desc) . "'";
		$sql .= " ,declinaison='" . $this->db->escape($this->declinaison) . "'";
		$sql .= " ,ecom_category='" . $this->db->escape($this->ecom_category) . "'";
		$sql .= " ,datem='" . $this->db->idate($this->datem) . "'";
		$sql .= " ,date_send='" . $this->db->idate($this->datem) . "'";
		$sql .= " ,date_modif='" . $this->db->idate($this->datem) . "'";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *   Delete object in database
	 * @param user            User that delete
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_product";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::delete sql=" . $sql);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}

	/**
	 *        Initialise object with example values
	 * @remarks    id must be 0 if object instance is a specimen.
	 */
	function initAsSpecimen()
	{
		$this->id = 0;
		$this->siteid = '';
		$this->doli_product = '';
		$this->doli_ref = '';
		$this->ecom_product = '';
		$this->ecom_attribut = '';
		$this->ecom_ref = '';
		$this->site_status = '';
		$this->site_stock = '';
		$this->datem = '';
		$this->long_desc = '';

	}

}


