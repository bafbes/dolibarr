<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2008-2011 Jean Heimburger		<jean@tiaris.fr>
 * Copyright (C) 2011-2013 Juanjo Menent		<jmenent@2byte.es>
 * Copyright (C) 2011-2013 Philippe Grand       <philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *       \file       ecommerce/E_order.class.php
 *       \ingroup    ecommerce
 *       \brief      Class function for e-commerce order management
 *         \author     Jean Heimburger www.tiaris.fr
 */
dol_include_once("/ecommerce/class/ecom_order.class.php");
dol_include_once("/ecommerce/class/E_customer.class.php");
dol_include_once("/ecommerce/class/E_product.class.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/E_params.class.php");
require_once(DOL_DOCUMENT_ROOT . "/contact/class/contact.class.php");
require_once(DOL_DOCUMENT_ROOT . "/commande/class/commande.class.php");
require_once(DOL_DOCUMENT_ROOT . "/societe/class/societe.class.php");
require_once(DOL_DOCUMENT_ROOT . "/expedition/class/expedition.class.php");

/**
 * Class to manage E_order
 */
class E_order extends Ecom_order
{
	var $custid; //identifant du client e
	var $orderpayment;

	var $site;

	var $nb_lignes;
	var $lines = array();
	var $client_address_id;
	var $code_order; // Code commande Prestashop
	// adresse de livraison
	var $shipping_address_id;
	var $shipping_name;
	var $shipping_company;
	var $shipping_adresse;
	var $shipping_cp;
	var $shipping_ville;
	var $shipping_pays;
	var $shippping_telephone;
	var $shipping_mobile;
	// adresse facturation
	var $invoice_address_id;
	var $invoice_name;
	var $invoice_company;
	var $invoice_adresse;
	var $invoice_cp;
	var $invoice_ville;
	var $invoice_pays;
	var $invoice_telephone;
	var $invoice_mobile;

	var $subtotal; // total ttc des achats
	var $total; // total ttc de la commande
	var $currency_code;
	var $currency_value;
	//réductions
	var $discount;
	var $site_discount_tax_rate;

	//wrapping
	var $wrapping;
	var $wrappingmessage;
	//ecotaxe
	var $ecotax;
	var $ecotaxtva;
	// tva frais de port
	var $site_port_tax_rate;
	// note commande
	var $order_comment;
	var $order_comment_priv;
	var $delivery_comments;
	// expedition method
	var $expmeth_id; // carrier id
	var $expmeth; // carrier name

	//Compatibility with PS commissions
	var $payment_fee;
	var $payment_fee_rate;

	var $user;

	/**
	 *  Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	function __construct($db, $siteid, $user)
	{
		$this->db = $db;
		$this->user = $user;
		$this->currency_value = 1.0;
		if ($siteid) {
			$this->site = new Ecom_site($this->db);
			if ($this->site->fetch($siteid, $user) < 0) {
				dol_syslog(get_class($this) . "::Constructeur" . $site->error, LOG_ERR);
				return -1;
			}
			$this->siteid = $siteid;
		}
		return 1;
	}

	/**
	 * Load a ecommerce order
	 *
	 * @param string    id    Id order of site
	 * @return int            1 if OK <0 if KO
	 */
	function wsfetch($id = '')
	{

		global $langs, $conf,$user;
		$langs->load("ecommerce@ecommerce");

		$this->error = '';
		dol_syslog(get_class($this) . "::wsfetch id=" . $id, LOG_DEBUG);
		// Verification parametres
		if (!$id) {
			$this->error = $langs->trans('ErrorWrongParameters', LOG_ERR);
			return -1;
		}

		//WebService Client.
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

		// Set the parameters to send to the WebService
		$parameters = array("orderid" => $id);

		// Set the WebService URL
		$client = new nusoap_client($this->site->site_ws_url . "/ws_orders.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

		// Call the WebService and store its result in $obj
		$obj = $client->call("get_Order", $parameters);

		if ($client->fault) {
			$this->error = "Fault detected " . $client->getError();
			dol_syslog(get_class($this) . "::ws_fetch Soap Error " . $this->error, LOG_ERR);
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if ($obj["code"] < 0) {
				$this->error = "Message from webservice " . $obj["message"];
				dol_syslog(get_class($this) . "::ws_fetch " . $this->error, LOG_WARNING);
				return -1;
			}
			$this->ecom_order = (isset($obj["orders_id"]) ? $obj["orders_id"] : 0);
			$this->code_order = (isset($obj["orders_code"]) ? convertCharset($obj["orders_code"]) : 0);
			$this->site_client_name = (isset($obj["customers_name"]) ? convertCharset($obj["customers_name"]) : 0);
			$this->custid = (isset($obj["customers_id"]) ? $obj["customers_id"] : 0);
			$this->site_order_date = (isset($obj["date_purchased"]) ? $obj["date_purchased"] : null);
			$this->total = (isset($obj["total"]) ? $obj["total"] : 0);
			$this->subtotal = (isset($obj["subtotal"]) ? $obj["subtotal"] : 0);
			$this->orderpayment = convertCharset($obj["payment_method"]);
			$this->site_total_port = (isset($obj["port"]) ? $obj["port"] : null);
			$this->site_total_vat = (isset($obj["tax"]) ? $obj["tax"] : null);
			$this->discount = (isset($obj["discount"]) ? $obj["discount"] : null);
			$this->wrapping = (isset($obj["wrapping"]) ? $obj["wrapping"] : null);
			$this->wrappingmessage = (isset($obj["wrappingmessage"]) ? $obj["wrappingmessage"] : null);
			$this->shipping_address_id = (isset($obj["address_book_id"]) ? $obj["address_book_id"] : 0);
			$this->client_address_id = (isset($obj["customers_default_address_id"]) ? $obj["customers_default_address_id"] : 0);
			$this->shipping_name = (isset($obj["delivery_name"]) ? convertCharset($obj["delivery_name"]) : 0);
			$this->shipping_firstname = (isset($obj["delivery_firstname"]) ? convertCharset($obj["delivery_firstname"]) : 0);
			$this->shipping_lastname = (isset($obj["delivery_lastname"]) ? convertCharset($obj["delivery_lastname"]) : 0);
			$this->shipping_company = (isset($obj["delivery_company"]) ? convertCharset($obj["delivery_company"]) : 0);
			$this->shipping_adresse = (isset($obj["delivery_street_address"]) ? convertCharset($obj["delivery_street_address"]) : 0);
			if ($obj["delivery_suburb"]) $this->shipping_adresse .= "\n" . convertCharset($obj["delivery_suburb"]);
			$this->shipping_cp = (isset($obj["delivery_postcode"]) ? convertCharset($obj["delivery_postcode"]) : 0);
			$this->shipping_ville = (isset($obj["delivery_city"]) ? convertCharset($obj["delivery_city"]) : 0);
			$this->shipping_pays = (isset($obj["delivery_country"]) ? convertCharset($obj["delivery_country"]) : 0);
			$this->shipping_state = (isset($obj["delivery_state"]) ? convertCharset($obj["delivery_state"]) : 0);

			$this->shipping_telephone = (isset($obj["delivery_telephone"]) ? $obj["delivery_telephone"] : null);
			$this->shipping_mobile = (isset($obj["delivery_mobile"]) ? $obj["delivery_mobile"] : null);
			$this->shipping_alias = (isset($obj["delivery_alias"]) ? $obj["delivery_alias"] : null);
			// invoice
			$this->invoice_address_id = (isset($obj["invoice_address_id"]) ? $obj["invoice_address_id"] : 0);
			$this->invoice_name = (isset($obj["invoice_name"]) ? convertCharset($obj["invoice_name"]) : 0);
			$this->invoice_lastname = (isset($obj["invoice_lastname"]) ? convertCharset($obj["invoice_lastname"]) : 0);
			$this->invoice_firstname = (isset($obj["invoice_firstname"]) ? convertCharset($obj["invoice_firstname"]) : 0);
			$this->invoice_company = (isset($obj["invoice_company"]) ? convertCharset($obj["invoice_company"]) : 0);
			$this->invoice_adresse = (isset($obj["invoice_street_address"]) ? convertCharset($obj["invoice_street_address"]) : 0);
			$this->invoice_adresse .= (isset($obj["invoice_suburb"]) ? "\n" . convertCharset($obj["invoice_suburb"]) : 0);
			$this->invoice_cp = (isset($obj["invoice_postcode"]) ? convertCharset($obj["invoice_postcode"]) : 0);
			$this->invoice_ville = (isset($obj["invoice_city"]) ? convertCharset($obj["invoice_city"]) : 0);
			$this->invoice_pays = (isset($obj["invoice_country"]) ? convertCharset($obj["invoice_country"]) : 0);
			$this->invoice_state = (isset($obj["invoice_state"]) ? convertCharset($obj["invoice_state"]) : 0);
			$this->invoice_telephone = (isset($obj["invoice_telephone"]) ? $obj["invoice_telephone"] : null);
			$this->invoice_mobile = (isset($obj["invoice_mobile"]) ? $obj["invoice_mobile"] : null);
			$this->invoice_alias = (isset($obj["invoice_alias"]) ? $obj["invoice_alias"] : null);

			// ecotaxe
			$this->ecotax = (isset($obj["ecotax"]) ? $obj["ecotax"] : null);
			$this->ecotaxtva = (isset($obj["ecotaxtva"]) ? $obj["ecotaxtva"] : null);
			//devises
			if ($obj["currency_code"]) $this->currency_code = $obj["currency_code"];
			if ($obj["currency_value"]) $this->currency_value = $obj["currency_value"];
			//Tax frais de port
			$this->site_port_tax_rate = (empty($obj["port_tax"])) ? 0.0 : $obj["port_tax"];
			//tax discount
			$this->site_discount_tax_rate = (isset($obj["discount_taxrate"]) ? $obj["discount_taxrate"] : null);
			//order comment
			$this->order_comment = (isset($obj["order_comment"]) ? $obj["order_comment"] : null);
			//order comment_priv
			$this->order_comment_priv = (isset($obj["order_comment_priv"]) ? $obj["order_comment_priv"] : null);
			$this->delivery_comments = (isset($obj["delivery_msg"]) ? "#liv# " . $obj["delivery_msg"] . "\n" : null);
			$this->delivery_comments .= (isset($obj["invoice_msg"]) ? "#fac# " . $obj["invoice_msg"] : null);
			// expedition
			$this->expmeth_id = (isset($obj["exped_id"]) ? $obj["exped_id"] : 0);
			$this->expmeth = (isset($obj["exped_name"]) ? $obj["exped_name"] : null);

			//Compatibility with PS commissions
			$this->payment_fee = (isset($obj["payment_fee"]) ? $obj["payment_fee"] : 0);
			$this->payment_fee_rate = (isset($obj["payment_fee_rate"]) ? $obj["payment_fee_rate"] : 0);
			$this->orders_status = (isset($obj["orders_status"]) ? $obj["orders_status"] : 0);

			dol_syslog(get_class($this) . "::ws_fetch " . $obj["customers_default_address_id"] . " - " . $obj["customers_name"] . " - " . $obj["delivery_name"], LOG_DEBUG);
			$this->nb_lignes = $obj["nb_lignes"];
			for ($i = 1; $i <= $this->nb_lignes; $i++) {
				// les lignes
				$lg = 'line' . $i;
				$this->lines[$i - 1]["products_id"] = $obj[$lg]["products_id"];
				$this->lines[$i - 1]["products_name"] = convertCharset($obj[$lg]["products_name"]);
				$this->lines[$i - 1]["product_type"] = 0;
				$this->lines[$i - 1]["products_price"] = $obj[$lg]["products_price"];
				$this->lines[$i - 1]["final_price"] = $obj[$lg]["final_price"];
				$this->lines[$i - 1]["products_tax"] = $obj[$lg]["products_tax"];
				$this->lines[$i - 1]["quantity"] = $obj[$lg]["products_quantity"];
				$this->lines[$i - 1]["attribut"] = $obj[$lg]["attribut"];
				$this->lines[$i - 1]["ecotax"] = (isset($obj[$lg]["products_ecotax"]) ? $obj[$lg]["products_ecotax"] : null);
			}
		}
		else {
			$this->error = 'Web Service error ' . $err;
			dol_syslog(get_class($this) . "::ws_fetch " . $this->error, LOG_ERR);
			return -1;
		}
		return 1;
	}

	/**
	 * Returns Dolibarr Commande object
	 *
	 * @param int    ecom_orderid    id of ecommerce order
	 * @return Object Commande if ok <0 if KO
	 */
	function ecom2dolibarr($ecom_orderid)
	{
		global $langs, $conf;
		$langs->load("ecommerce");
		// traces dans log
		$ecomlog = new Ecom_log($this->db);

		$result = $this->wsfetch($ecom_orderid);
		dol_syslog(get_class($this) . "::ecom2dolibarr" . $ecom_orderid . "resultat" . $result . " adr " . $this->shipping_address_id);
		if ($result > 0) {
			$error = 0;
			dol_syslog(get_class($this) . "::ecom2dolibarr siteid" . $this->site->id . " adr " . $this->shipping_name, LOG_DEBUG);
			$commande = new Commande($this->db);

			if ($error == 1) {
				dol_syslog(get_class($this) . "::ecom2dolibarr erreur création commande ", LOG_ERR);
				return -1;
			}
			/* initialisation */
			$e_client = new E_customer($this->db, $this->site->id, $this->user);

			$clientid = 0; // A voir

			$e_product = new E_product($this->db, $this->site->id, $this->user);

			$commande->socid = $clientid;
			$commande->ref_client = $this->ecom_order;
			$commande->date = strtotime($this->site_order_date);
			$commande->date_commande = strtotime($this->site_order_date);
			if ($this->order_comment) $commande->note_public .= $this->order_comment;
			if ($this->order_comment_priv) $commande->note_private .= $this->order_comment_priv;
			if ($this->delivery_comments) $commande->note .= $this->delivery_comments;

			// mode de réglement
			dol_syslog(get_class($this) . "::ecom2dolibarr conversion mode paiement " . $this->orderpayment, LOG_DEBUG);
			$mdpid = $this->get_paiement_code($this->orderpayment);
			if(empty($mdpid)) $mdpid= $this->get_unknown_paiement_code($this->orderpayment);
			if ($mdpid > 0) $commande->mode_reglement_id = $mdpid;
			else {
				$commande->mode_reglement_id = 0;
				//trace dans log
				$ecomlog->site_id = $this->siteid;
				$ecomlog->log_date = dol_now();
				$ecomlog->log_fct = 'COM';
				$ecomlog->log_type = "ERR";
                $ecomlog->log_fonction = $langs->trans("OrderImport",$this->ecom_order) ;
				$ecomlog->log_message = $langs->trans("ErrorPayementMeth",$this->orderpayment);
				$result=$ecomlog->create($user);
			}
			$commande->cond_reglement_id = '1'; // à réception
			/* on force */
            $e_param = new E_params($this->db, $this->site->id, $this->user);
            $commande->statut =$e_param->ecom2dolibarr($this->orders_status, 'ordstat'); //à voir
			$commande->source = $this->site->id;

			//les lignes
			$totalTVA = 0.0;
			$totalHT = 0.0;
			$ep = new E_product($this->db, $this->siteid, $this->user);

			for ($i = 0; $i < count($this->lines); $i++) {
				$commande->lines[$i]->libelle = $this->lines[$i]["products_id"];
				$commande->lines[$i]->desc = $this->lines[$i]["products_name"];
				//$commande->lines[$i]->price = $this->lines[$i]["products_price"];
				//		$commande->lines[$i]->price = $this->lines[$i]["final_price"];
				//		$commande->lines[$i]->subprice = $this->lines[$i]["products_price"];
				$commande->lines[$i]->subprice = price2num($this->lines[$i]["products_price"], 'MU');
				$commande->lines[$i]->qty = $this->lines[$i]["quantity"];
				$commande->lines[$i]->product_type = 0;
				$commande->lines[$i]->tva_tx = $this->lines[$i]["products_tax"];
				// calcul du prix

				$commande->lines[$i]->total_ht = price2num($this->lines[$i]["quantity"] * $this->lines[$i]["final_price"], 'MT');
				$commande->lines[$i]->total_tva = price2num($commande->lines[$i]->total_ht * $this->lines[$i]["products_tax"] / 100.0, 'MU');
				/*vérifier l'existence des produits commandés  maj produit commandé */
				$result=$ep->import_product_with_declinations($this->lines[$i]["products_id"]);

				$prodid = $e_product->get_doliproduct($this->lines[$i]["products_id"], $this->lines[$i]["attribut"]);
				dol_syslog(get_class($this) . "::ecom2dolibarr recherche produit " . $this->lines[$i]["products_id"] . " attr : " . $this->lines[$i]["attribut"] . "  : " . $prodid, LOG_DEBUG);
				if (!$prodid && $conf->global->ECOM_PRODUCT_MUST_EXIST) {
					// log that product doesnot exist
					//trace dans log
					$ecomlog->site_id = $this->siteid;
					$ecomlog->log_date = dol_now();
					$ecomlog->log_fct = 'COM';
					$ecomlog->log_type = "ERR";
					$ecomlog->log_fonction = $langs->trans("OrderImport",$this->ecom_order) ;
                    $ecomlog->log_message = !empty($this->lines[$i]["attribut"])?$langs->trans("ErrorProductAttributeNotFound",$this->lines[$i]["products_id"],$this->lines[$i]["attribut"], $this->lines[$i]["products_name"]):
                        $langs->trans("ErrorProductNotFound",$this->lines[$i]["products_id"], $this->lines[$i]["products_name"])  ;
					$ecomlog->create($user);
				}

				$commande->lines[$i]->fk_product = $prodid; //$oscproduct->get_productid($this->osc_lines[$i][products_id]);
				$commande->lines[$i]->remise_percent = 0; // é calculer avec le finalprice

				//Buy price of product to calculate margins
				$sql = "SELECT	p.pmp as totpmp, p.pmp as warepmp ";
				$sql .= " FROM " . MAIN_DB_PREFIX . "product as p WHERE p.rowid = " . $prodid;
				$resql = $this->db->query($sql);

				if ($resql) {
					$objp = $this->db->fetch_object($resql);
					$pmp = $objp->warepmp;
					if ($pmp <= 0) {
						$pmp = $objp->totpmp;
						if ($pmp <= 0 && $conf->global->ForceBuyingPriceIfNull)
							$pmp = $commande->lines[$i]->subprice;
					}
				}
				$commande->lines[$i]->pa_ht = $pmp;

				$totalTVA += $commande->lines[$i]->total_tva;
				$totalHT += $commande->lines[$i]->total_ht;
			}
			// les frais de port
			$fp = count($this->lines);

			/*
						if (ECOM_FRSPORT_TVA > 0) $prix_ht = price2num($this->site_total_port / (1.0 + ECOM_FRSPORT_TVA /100.), 'MT');
						else $prix_ht = $this->site_total_port;
			*/
			if ((float)$this->site_port_tax_rate > 0.0) $prix_ht = price2num($this->site_total_port / (1.0 + $this->site_port_tax_rate / 100.), 'MU');
			else $prix_ht = $this->site_total_port;
			dol_syslog("ws_import::ecom2dolibarr frais port " . $prix_ht . "  taxe " . $this->site_port_tax_rate, LOG_DEBUG);

			$commande->lines[$fp]->libelle = $langs->trans("FraisdePort");
			$commande->lines[$fp]->desc = $langs->trans("FraisdePort");
			//$commande->lines[$fp]->price = $this->site_total_port;
			$commande->lines[$fp]->subprice = $prix_ht;
			$commande->lines[$fp]->qty = 1;
			// si la tva n'est pas définie par le web service, on applique celle définei dans le paramétrage
			if ($this->site_port_tax_rate >= 0.0) $commande->lines[$fp]->tva_tx = $this->site_port_tax_rate;
			else {
				$commande->lines[$fp]->tva_tx = (!empty($conf->global->ECOM_FRSPORT_TVA)) ? $conf->global->ECOM_FRSPORT_TVA : 0.0;
			}
			$commande->lines[$fp]->total_ht = $prix_ht;
			$commande->lines[$fp]->total_tva = price2num($this->site_total_port - $prix_ht);
			$commande->lines[$fp]->fk_product = 0; //FK_PORT;
			$commande->lines[$fp]->product_type = 1; // c'est un 'service'
			$commande->lines[$fp]->remise_percent = 0;
			$totalHT += $commande->lines[$fp]->total_ht;
			$totalTVA += $commande->lines[$fp]->total_tva;
			dol_syslog("ws_import::ecom2dolibarr Commande " . $ecom_orderid . " frais port " . $commande->lines[$fp]->subprice . "\n", LOG_DEBUG);
//
//			//Compatibility with PS commissions
//			if ($this->payment_fee != 0) {
//				$fp = $fp + 1;
//				if ((float)$this->payment_fee_rate > 0.0) $prix_ht = price2num($this->payment_fee / (1.0 + $this->payment_fee_rate / 100.), 'MU');
//				else $prix_ht = $this->payment_fee;
//				dol_syslog("ws_import::ecom2dolibarr comissions " . $prix_ht . "  taxe " . $this->payment_fee_rate, LOG_DEBUG);
//
//				$commande->lines[$fp]->libelle = $langs->trans("Commissions");
//				$commande->lines[$fp]->desc = $langs->trans("Commissions");
//				//$commande->lines[$fp]->price = $this->site_total_port;
//				$commande->lines[$fp]->subprice = $prix_ht;
//				$commande->lines[$fp]->qty = 1;
//				// si la tva n'est pas définie par le web service, on applique celle définei dans le paramétrage
//				$commande->lines[$fp]->tva_tx = $this->payment_fee_rate;
//
//				$commande->lines[$fp]->total_ht = $prix_ht;
//				$commande->lines[$fp]->total_tva = price2num($this->payment_fee - $prix_ht);
//				$commande->lines[$fp]->fk_product = 0; //FK_COMM;
//				$commande->lines[$fp]->product_type = 1; // c'est un 'service'
//				$commande->lines[$fp]->remise_percent = 0;
//				$totalHT += $commande->lines[$fp]->total_ht;
//				$totalTVA += $commande->lines[$fp]->total_tva;
//				dol_syslog("ws_import::ecom2dolibarr Commande " . $ecom_orderid . " comissions " . $commande->lines[$fp]->subprice . "\n", LOG_DEBUG);
//			}
//
//			//Les coupons de réduction
//			$fd = $fp;
//			if ($this->discount != 0.0) {
//				$fd = $fd + 1;
//				if ((float)$this->site_discount_tax_rate > 0) $discount = price2num($this->discount / (1 + $this->site_discount_tax_rate / 100.), 'MU');
//				else $discount = $this->discount;
//				$commande->lines[$fd]->libelle = $langs->trans("OrdDiscount");
//				$commande->lines[$fd]->desc = $langs->trans("OrdDiscountDesc") . " : " . $this->discount;
//				$commande->lines[$fd]->price = $discount;
//				$commande->lines[$fd]->subprice = $discount;
//				$commande->lines[$fd]->qty = -1;
//				$commande->lines[$fd]->tva_tx = $this->site_discount_tax_rate;
//				$commande->lines[$fd]->total_ht = $discount;
//				$commande->lines[$fd]->total_tva = price2num($this->discount - $discount, 'MU');
//				$commande->lines[$fd]->fk_product = 0;
//				$commande->lines[$fd]->product_type = 1; // c'est un 'service'
//				$commande->lines[$fd]->remise_percent = 0;
//				$commande->lines[$fd]->special_code = 2; // ecotaxe
//				$totalHT += $commande->lines[$fd]->total_ht;
//				$totalTVA += $commande->lines[$fd]->total_tva;
//			}
//
//			//Wrapping
//			$fd = $fp;
//			if ($this->wrapping != 0.0) {
//				$fd = $fd + 1;
//
//				if ((float)$this->site_port_tax_rate > 0.0) $wrapping = price2num($this->wrapping / (1.0 + $this->site_port_tax_rate / 100.), 'MT');
//				else $wrapping = $this->wrapping;
//
//				$commande->lines[$fd]->libelle = $langs->trans("OrdWrapping");
//				$commande->lines[$fd]->desc = $langs->trans("OrdWrappingDesc") . " : " . $this->wrappingmessage;
//				$commande->lines[$fd]->price = $wrapping;
//				$commande->lines[$fd]->subprice = $wrapping;
//				$commande->lines[$fd]->qty = 1;
//				$commande->lines[$fd]->tva_tx = $this->site_port_tax_rate;
//				$commande->lines[$fd]->total_ht = $wrapping;
//				$commande->lines[$fd]->total_tva = price2num($this->wrapping - $wrapping);
//				$commande->lines[$fd]->fk_product = 0;
//				$commande->lines[$fd]->product_type = 1; // c'est un 'service'
//				$commande->lines[$fd]->remise_percent = 0;
//				$commande->lines[$fd]->special_code = 2; // ecotaxe
//				$totalHT += $commande->lines[$fd]->total_ht;
//				$totalTVA += $commande->lines[$fd]->total_tva;
//			}
//
//			//L'écotaxe TODO
//			/*			if (($this->ecotax) && ($this->ecotax > 0.0))
//						{
//							$fd = $fd + 1;
//							$commande->lines[$fd]->libelle = "Ecotaxe";
//							$commande->lines[$fd]->desc = "Dont Ecotaxe";
//							$commande->lines[$fd]->price = $this->ecotax;
//							$commande->lines[$fd]->subprice = $this->ecotax;
//							$commande->lines[$fd]->qty = 1;
//							$commande->lines[$fd]->tva_tx = 0;
//							$commande->lines[$fd]->total_ht = $this->ecotax;
//							$commande->lines[$fd]->total_tva = $this->ecotaxtva;
//							$commande->lines[$fd]->fk_product = 0; //pas de ref ;
//							$commande->lines[$fd]->remise_percent = 0;
//							$totalHT += $commande->lines[$fd]->total_ht;
//							$totalTVA += $commande->lines[$fd]->total_tva;
//						}
//			*/
			$commande->total_tva = $totalTVA;
			$commande->total_ht = $totalHT;
			$commande->total_ttc = $totalHT + $totalTVA;

			return $commande;
		}
		dol_syslog(get_class($this) . "::ecom2dolibarr pas de résultat " . $this->error);
	}


	/**
	 * Import a site ecommerce order to Dolibarr
	 *
	 * @param int        orderid Id of site order
	 * @return int                <0 If KO >0 If OK
	 */
	function import_order($orderid)
	{
		global $langs,$conf,$user;
		$langs->load("ecommerce");

		$this->user->getrights('commande');
		/*1. créer commande dolibarr */
        $this->fetch(GETPOST('rowid'));
		$commande = new Commande($this->db);
        //Création de l'objet commande avec les lignes commande
		$commande = $this->ecom2dolibarr($orderid);

		if (!$commande) {
			$this->error .= "erreur conversion ecom2dolibarr ";
			dol_syslog(get_class($this) . "::import_order conversion commande échoué " . $this->error, LOG_ERR);
			return -1;
		}

		if (empty($this->code_order)) {
			$commande->ref_client = $this->ecom_order;
		}
		else {
			$commande->ref_client = $this->code_order;
		}

		$error = 0; // compteur d'erreurs
		// si le mode de paiement = 0 : erreur méthode de paiement
		if (!$commande->mode_reglement_id) $error++;

		/*2. gestion du client */
		$e_client = new E_customer($this->db, $this->site->id, $this->user);
		/*vérifier si le client existe pour ce site */
        $result=$e_client->findInSite($this->custid, $this->site->id);
        if ( $result< 0) {
			$this->error .= "erreur findInSite contrôle client " . $this->custid . " ";
			dol_syslog(get_class($this) . "::import_order erreur contrôle client " . $this->error, LOG_ERR);
			return -10;
		}
		else {
			if ($e_client->ecom_customer && ($e_client->doli_soc > 0)) {
				dol_syslog(get_class($this) . "::import_order code_client  $e_client->ecom_customer doli_soc $e_client->doli_soc", LOG_DEBUG);
				$commande->socid = $e_client->doli_soc;
				$dolicustid = $e_client->doli_soc;
				//maj adresse client
				if ($e_client->update_dolisoc($dolicustid, $this->custid) < 0) {
					dol_syslog(get_class($this) . "::import_order maj adresse client KO " . $e_client->doli_soc, LOG_ERR);
				}
				dol_syslog(get_class($this) . "::import_order maj adresse ok " . $e_client->doli_soc, LOG_INFO);
			}
			else
				dol_syslog(get_class($this) . "::import_order nouveau client  ", LOG_DEBUG);
		}

		if (!$e_client->doli_soc) {
			/* création du client */
            $result=$e_client->import_customer($this->custid);
            if ($result< 0) {
				$this->error .= "erreur import customer " . $e_client->error;
				dol_syslog(get_class($this) . "::import_order lecture client échouée " . $this->error, LOG_ERR);
				return -2;
			}
			else {
				$commande->socid = $e_client->doli_soc;
				$dolicustid = $e_client->doli_soc;
				dol_syslog(get_class($this) . "::import_order création client ok " . $e_client->doli_soc);
			} // fin création du client
		}

		//3. gestion des contacts de commande
		// 3..1 gestion de l'adresse de livraison si différente	l'id adresse est dans $this_>shipping_address
		// on créé tioujours les contacts
		$cust_contact = $e_client->get_customer_contact($e_client->ecom_customer);
		$contact_commande = $cust_contact;

		$soc = new Societe($this->db);
		if ($soc->fetch($dolicustid) < 0) {
			$this->error .= "erreur lecture societe " . $soc->error;
			dol_syslog(get_class($this) . "::import_order lecture sociéte échouée " . $this->error, LOG_ERR);
			return -2;
		}

		dol_syslog(get_class($this) . "::import_order création adresse livraison " . $this->shipping_address_id . " client " . $this->client_address_id . "\n", LOG_INFO);
		$contact_livraison = 0;
		if (($this->shipping_address_id > 0) && ($this->shipping_address_id != $this->invoice_address_id)) {
			$adr = array();
			//there is another address given
			$adr["civilite_id"] = '';
			$adr["nom_particulier"] = $this->shipping_lastname;//$this->shipping_name ;
			$adr["prenom"] = $this->shipping_firstname;//$soc->prenom;
			$adr["adresse"] = $this->shipping_adresse;
			if ($this->shipping_company) $adr["adresse"] = $this->shipping_company . "\n" . $adr["adresse"];
			$adr["cp"] = $this->shipping_cp;
			$adr["ville"] = $this->shipping_ville;
			$adr["pays_id"] = $e_client->get_paysid($this->shipping_pays);
			$adr["state_id"] = $e_client->get_stateid($this->shipping_state, $adr["pays_id"]);
			$adr["email"] = $soc->email;
			$adr["telephone"] = $this->shipping_telephone;
			$adr["mobile"] = $this->shipping_mobile;
			$adr["note"] = $this->shipping_alias;

			$contact_livraison = $e_client->new_societe_contact($dolicustid, $adr, $this->shipping_address_id);
			if ($contact_livraison < 0) {
				$this->error .= " Erreur création contact livraison " . $this->shipping_name . ' ' . $e_client->error;
				$error++;
				dol_syslog(get_class($this) . "::import_order création contact livraison échouée " . $this->error, LOG_ERR);
			}
		}
		else {
			$adr = array();

			$adr["civilite_id"] = '';
			$adr["nom_particulier"] = $this->invoice_lastname;//$this->invoice_name ;
			$adr["prenom"] = $this->invoice_firstname;//$soc->prenom;
			$adr["adresse"] = $this->invoice_adresse;
			if ($this->invoice_company) $adr["adresse"] = $this->invoice_company . "\n" . $adr["adresse"];
			$adr["cp"] = $this->invoice_cp;
			$adr["ville"] = $this->invoice_ville;
			$adr["pays_id"] = $e_client->get_paysid($this->invoice_pays);
			$adr["state_id"] = $e_client->get_stateid($this->invoice_state, $adr["pays_id"]);
			$adr["email"] = $soc->email;
			$adr["telephone"] = $this->invoice_telephone;
			$adr["mobile"] = $this->invoice_mobile;
			$adr["note"] = $this->invoice_alias;

			$contact_livraison = $e_client->new_societe_contact($dolicustid, $adr, $this->shipping_address_id);
			if ($contact_livraison < 0) {
				$this->error .= " Erreur création contact livraison " . $this->shipping_name . ' ' . $e_client->error;
				$error++;
				dol_syslog(get_class($this) . "::import_order création contact livraison échouée " . $this->error, LOG_ERR);
			}
		}
		dol_syslog(get_class($this) . "::import_order gestion contact livraison OK n ° " . $contact_livraison, LOG_INFO);

		// 3.2 contact de facturation
		dol_syslog(get_class($this) . "::import_order création adresse facturation " . $this->invoice_address_id . " client " . $this->client_address_id . "\n", LOG_INFO);
		$contact_facturation = 0;
		if (($this->invoice_address_id > 0) && ($this->invoice_address_id != $this->client_address_id)) {
			$adr = array();

			$adr["civilite_id"] = '';
			$adr["nom_particulier"] = $this->invoice_lastname;//$this->invoice_name ;
			$adr["prenom"] = $this->invoice_firstname;//$soc->prenom;
			$adr["adresse"] = $this->invoice_adresse;
			if ($this->invoice_company) $adr["adresse"] = $this->invoice_company . "\n" . $adr["adresse"];
			$adr["cp"] = $this->invoice_cp;
			$adr["ville"] = $this->invoice_ville;
			$adr["pays_id"] = $e_client->get_paysid($this->invoice_pays);
			$adr["state_id"] = $e_client->get_stateid($this->invoice_state, $adr["pays_id"]);
			$adr["email"] = $soc->email;
			$adr["telephone"] = $this->invoice_telephone;
			$adr["mobile"] = $this->invoice_mobile;
			$adr["note"] = $this->invoice_alias;


			$contact_facturation = $e_client->new_societe_contact($dolicustid, $adr, $this->invoice_address_id);
			if ($contact_facturation < 0) {
				$this->error .= " Erreur création contact facturation " . $this->invoice_name . ' ' . $e_client->error;
				$error++;
				dol_syslog(get_class($this) . "::import_order création contact facturation échouée " . $this->error, LOG_ERR);
			}
		}
		else {
			// we take contact of company
			$contact_facturation = $cust_contact;
		}
		dol_syslog(get_class($this) . "::import_order création contact facturation OK n ° " . $contact_facturation, LOG_INFO);


		//4. Vérifier si produits commandés existent dans dolibarr
		if ($conf->global->ECOM_PRODUCT_MUST_EXIST) {
			//then it is an error and no order will be created
			$proderror = 0;
			foreach ($commande->lines as $elt) {
				if (($elt->fk_product == 0) && ($elt->product_type == 0)) {
					$proderror++;
				}
			}
			if ($proderror > 0) {
                $errmsg = $langs->trans("ErrOrderedProductNotFound",$proderror);
                $this->error = $errmsg;
				dol_syslog(get_class($this) . "::import_order " . $this->error, LOG_ERR);

				return -1;
			}

		}

		/*5. création de la commande */
		dol_syslog(get_class($this) . "::import_order création commande pour client " . $commande->socid . "  pour " . count($commande->lines) . " lignes", LOG_DEBUG);
        if($this->doli_order>0) {
            //Mise à jour
            $commande->id=$this->doli_order;
            $com=new Commande($this->db);
            $com->fetch($this->doli_order);
            $commande->ref=$com->ref;
            $commande->update($this->user,1);
            if ($commande->id > 0) {
                //6. MAJ ecom_order
                if ($this->findInSite($this->ecom_order, $this->site->id) < 0) {
                    $this->error .= "Recherche ecom_order échouée " . $this->ecom_order;
                    dol_syslog(get_class($this) . "::import_order 4 create ecom_order échoué " . $this->error, LOG_ERR);
                    return -14;
                }
                $this->doli_order = $commande->id;
                $this->site_order_status=$this->orders_status;
                $this->site_total_vat = $commande->total_tva;
                $this->siteid = $this->site->id;
                $this->exp_meth_id = $this->expmeth_id;
                $this->exp_meth = $this->expmeth;
                $this->datem = dol_now();
                if ($this->id) {
                    if ($res=$this->update($user) < 0) {
                        dol_syslog(get_class($this) . "::import_order 4 update ecom_order échoué " . $this->error, LOG_ERR);
                        return -15;
                    }
                }
                dol_syslog(get_class($this) . "::import_order création commande dolibarr" . $id . "réussie", LOG_DEBUG);
            }
            else {
                $this->error .= "erreur import_order ";
                dol_syslog(get_class($this) . "::import_order création commande dolibarr échouée " . $commande->error, LOG_ERR);
                return -5;
            }
        }
        else {
            $savedstatut=$commande->statut;
            $commande->statut = Commande::STATUS_DRAFT;
            $id = $commande->create($this->user);
            if ($id > 0) {
                // contact suivi de commande
                if ($contact_commande > 0) {
                    dol_syslog(get_class($this) . "::import_order 4 :contact commande " . $contact_commande, LOG_INFO);
                    $res = $commande->add_contact($contact_commande, '101', 'external'); //cf table llx_c_type_contact
                    if ($res < 0) {
                        if ($commande->error == 'DB_ERROR_RECORD_ALREADY_EXISTS') {
                            $langs->load("errors");
                            $this->error = $langs->trans("ErrorThisContactIsAlreadyDefinedAsThisType");
                            dol_syslog(get_class($this) . "::import_order 4 " . $this->error, LOG_ERR);
                            return -15;
                        }
                        else {
                            $this->error = $commande->error;
                            dol_syslog(get_class($this) . "::import_order 4 " . $this->error, LOG_ERR);
                            return -17;
                        }
                    }
                }

                // ajout d'un éventuel contact de livraison
                if ($contact_livraison > 0) {
                    dol_syslog(get_class($this) . "::import_order 4 :contact livraison " . $contact_livraison, LOG_INFO);
                    $res = $commande->add_contact($contact_livraison, '102', 'external'); //cf table llx_c_type_contact
                    if ($res < 0) {
                        if ($commande->error == 'DB_ERROR_RECORD_ALREADY_EXISTS') {
                            $langs->load("errors");
                            $this->error = $langs->trans("ErrorThisContactIsAlreadyDefinedAsThisType");
                            dol_syslog(get_class($this) . "::import_order 4 " . $this->error, LOG_ERR);
                            return -15;
                        }
                        else {
                            $this->error = $commande->error;
                            dol_syslog(get_class($this) . "::import_order 4 " . $this->error, LOG_ERR);
                            return -17;
                        }
                    }
                }
                //  contact de facturation
                if ($contact_facturation > 0) {
                    dol_syslog(get_class($this) . "::import_order 4 :contact facturation " . $contact_facturation, LOG_INFO);
                    $res = $commande->add_contact($contact_facturation, '100', 'external'); //cf table llx_c_type_contact
                    if ($res < 0) {
                        if ($commande->error == 'DB_ERROR_RECORD_ALREADY_EXISTS') {
                            $langs->load("errors");
                            $this->error = $langs->trans("ErrorThisContactIsAlreadyDefinedAsThisType");
                            dol_syslog(get_class($this) . "::import_order 4 " . $this->error, LOG_ERR);
                            return -15;
                        }
                        else {
                            $this->error = $commande->error;
                            dol_syslog(get_class($this) . "::import_order 4 " . $this->error, LOG_ERR);
                            return -17;
                        }
                    }
                }

                //6. MAJ ecom_order
                if ($this->findInSite($this->ecom_order, $this->site->id) < 0) {
                    $this->error .= "Recherche ecom_order échouée " . $this->ecom_order;
                    dol_syslog(get_class($this) . "::import_order 4 create ecom_order échoué " . $this->error, LOG_ERR);
                    return -14;
                }
                $this->doli_order = $commande->id;
                $this->site_order_status=$this->orders_status;
                $this->site_total_vat = $commande->total_tva;
                $this->siteid = $this->site->id;
                $this->exp_meth_id = $this->expmeth_id;
                $this->exp_meth = $this->expmeth;
                $this->datem = dol_now();
                // TODO remettre le statut au statut sur le site
                if ($this->id) {
                    if ($this->update($user) < 0) {
                        dol_syslog(get_class($this) . "::import_order 4 update ecom_order échoué " . $this->error, LOG_ERR);
                        return -15;
                    }
                }
                dol_syslog(get_class($this) . "::import_order création commande dolibarr" . $id . "réussie", LOG_DEBUG);
            }
            else {
                $this->error .= "erreur import_order ";
                dol_syslog(get_class($this) . "::import_order création commande dolibarr échouée " . $commande->error, LOG_ERR);
                return -5;
            }
        }
        //6.  validation de la commande si elle est dans l'état en instance sur le site
/*        // TODO le test de l'état en instance
        if (($this->orderpayment != 'CB') && ($this->orderpayment != 'PPL') && ($this->orderpayment != 'PBX')) {
            $error++;
            dol_syslog('test orderpayment ' . $this->orderpayment . ' vaut : ' . ($this->orderpayment != 'CB') && ($this->orderpayment != 'PPL') && ($this->orderpayment != 'PBX'), LOG_DEBUG);
        }*/
        // si la commande est dans un état correspondant a brouillon on ne la valide pas
        $e_param = new E_params($this->db, $this->site->id, $this->user);
        if ($e_param->ecom2dolibarr($this->site_order_status, 'ordstat') == 0) $error++;

        dol_syslog(get_class($this) . "::import_order on ne valide que les paiements assurés " . $this->orderpayment . ' ; ecom status ' . $this->site_order_status . ' ; local ' . $e_param->ecom2dolibarr($this->site_order_status, 'ordstat') . ' controle : ' . $error, LOG_DEBUG);


        if ($error == 0) {
            if ($commande->fetch($commande->id) < 0) {
                $this->error .= "Impossible de trouver la commande " . $commande->id . " ; " . $commande->error;
                dol_syslog(get_class($this) . "::import_order echec du fetch avant valid " . $this->error, LOG_WARNING);
                return -6;
            }
            $saved_statut=$commande->statut;
            $commande->statut=0;
            if ($commande->valid($this->user, $this->site->site_entrepot,1) < 0) {
                $this->error .= "erreur validation commande " . $commande->id;
                dol_syslog(get_class($this) . "::import_order erreur validation cmd " . $commande->error . " user " . $this->user->nom . " " . $this->user->id, LOG_WARNING);
                return -7;
            }
            else
                dol_syslog(get_class($this) . "::import_order commande validée ", LOG_DEBUG);
            $commande->statut=$saved_statut;
            $res=$commande->update($this->user,1);
       }
        else dol_syslog(get_class($this) . "::import_order commande importée mais non validée " . $error . " ", LOG_DEBUG);

		return 1;
	}

	/**
	 * Search order in site orders list
	 *
	 * @param int        ordertid (site ecommerce id)
	 * @param int $siteid
	 * @return    int        <0 If KO >0 If OK
	 */
	function findInSite($ordertid, $siteid)
	{
		$sql = "SELECT o.rowid FROM " . MAIN_DB_PREFIX . "ecom_order o";
		$sql .= " WHERE o.ecom_order = '" . $ordertid . "' AND o.siteid = '" . $siteid . "'";

		dol_syslog(get_class($this) . "::findInSite ** sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			if ($num) {
				$obj = $this->db->fetch_object($resql);
				$this->id = $obj->rowid;
				/* initialisation de l'objet */
				$this->fetch($this->id);
			}
			$this->db->free($resql);
			return $num;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::findInSite " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 * Find site and id on ecommerce site from Dolibarr order id
	 *
	 * @param int        orderid        Dolibarr order id
	 * @return int                    >0 If Ok <0 If KO
	 */
	function getOrderSiteid($orderid)
	{
		$sql = "SELECT o.rowid, o.siteid, o.ecom_order FROM " . MAIN_DB_PREFIX . "ecom_order o";
		$sql .= " WHERE o.doli_order = '" . $orderid . "' ";

		dol_syslog(get_class($this) . "::getOrderSiteid sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$this->siteid = $obj->siteid;
				$this->ecom_order = $obj->ecom_order;
				$this->id = $obj->rowid;
				/* initialisation de l'objet */
				/* $this->fetch($this->id);*/
			}
			$this->db->free($resql);
			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::getOrderSiteid " . $this->error, LOG_ERR);
			return -1;
		}
	}

	/**
	 * Get last order imported from a site
	 *
	 * @param int        siteid    Site id
	 * @return int                >0 If OK <0 If KO
	 */
	function get_lastorder($siteid)
	{
		$sql = "SELECT o.rowid  FROM " . MAIN_DB_PREFIX . "ecom_order o";
		$sql .= " WHERE o.siteid = '" . $siteid . "' ORDER BY o.ecom_order DESC LIMIT 0,1";

		dol_syslog(get_class($this) . "::get_lastorder sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$this->id = $obj->rowid;
				/* initialisation de l'objet */
				$this->fetch($this->id);
			}
			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::findInSite " . $this->error, LOG_ERR);
			return -1;
		}
	}

	/**
	 * echo (répercuter) a change status of an order in dolibarr into ps
	 *
	 * @param int    ordid        Id of ecommerce order
	 * @param int    status       Dolibarr status id
	 * @return int                    >0 If OK <0 If KO
	 */
	function change_status($ordid = '0', $status = '0')
	{
		global $conf, $langs;
		$langs->load("ecommerce@ecommerce");
		// controle paramètres
		if (!$this->siteid) {
			dol_syslog(get_class($this) . "::change_status error siteid", LOG_WARNING);
			//return -1;
			$maj_ecom = False;
		}
		if ((!$status) || (!$ordid)) {
			dol_syslog(get_class($this) . "::change_status error parameters " . $ordid . ' ' . $status, LOG_WARNING);
			return -1;
		}

		//	recherche de l'enreg
		$sql = "SELECT eo.rowid, eo.doli_order, eo.site_order_status, ep.doli_id, eo.site_order_date ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order eo ";
		$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "ecom_params ep ON eo.site_order_status = ep.ecom_id AND eo.siteid = ep.siteid AND ep.partype = 'ordstat' ";
		$sql .= " WHERE ecom_order = '" . $ordid . "' AND eo.siteid = '" . $this->site->id . "'";

		dol_syslog(get_class($this) . "::change_status sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$id = $obj->rowid;
				$doliorder = $obj->doli_order;
				$ecom_status = $obj->site_order_status;
				$ecom_order_date = $this->db->jdate($obj->site_order_date);
			}
			else {
				dol_syslog(get_class($this) . "::change_status non trouvé sql=" . $sql, LOG_WARNING);
				return -1;
			}
		}
		else {
			dol_syslog(get_class($this) . "::change_status sql=" . $sql, LOG_ERR);
			return -1;
		}

		// Contrôles
		// si la date de commande est < à la date de début de traitement
		// c'est une commande qui a été traitée sur le site ecommerce qui ne doit pas être retraitée (historique)
		dol_syslog("E_order::change_status commande antérieure à date début traitement " . $ecom_order_date . " - " . $this->site->site_startdate, LOG_DEBUG);
		if ($ecom_order_date < $this->site->site_startdate) {
			dol_syslog("E_order::change_status commande antérieure à date début traitement " . $ecom_order_date . " - " . $this->site->site_startdate, LOG_DEBUG);
			//$maj_ecom = true;
			return 1;
		}


		$sql = "SELECT ecom_id FROM " . MAIN_DB_PREFIX . "ecom_params ";
		$sql .= " WHERE siteid ='" . $this->site->id . "' and partype = 'ordstat' and doli_id ='" . $status . "'";
		dol_syslog("E_order::change_status recherche ecom_id sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$site_status = $obj->ecom_id;
			}
			else {
				dol_syslog("E_order::change_status recherche ecom_id ratée pas de parmaétre ordstat pour " . $status, LOG_WARN);
				return -1;
			}
		}
		else {
			dol_syslog(get_class($this) . "::change_status erreur sql " . $sql, LOG_WARNING);
			return -1;
		}
		// règles de gestion
		$maj_ecom = True;

		// si le statut en ligne est deja positionne on ne le positionne plus
		if ($site_status == $ecom_status) {
			$maj_ecom = FALSE;
			dol_syslog(get_class($this) . "::change_status pas de changement site_status = ecom_status = " . $ecom_status, LOG_DEBUG);
		}

		// si la date de commande est < à la date de début de traitement
		// c'est une commande qui a été traitée sur le site ecommerce qui ne doit pas être retraitée (historique)
		if ($ecom_order_date < $this->site->site_startdate) {
			dol_syslog(get_class($this) . "::change_status commande antérieure à date début traitement " . $ecom_order_date . " - " . $this->site->site_startdate, LOG_DEBUG);
			$maj_ecom = FALSE;
		}

		$dolistatus = 0;
		if ($status == 1) {
			$message = $langs->trans("MsgOrderValidated");
			$notifclient = 0;
			if ($dolistatus != 0) $maj_ecom = FALSE;
			dol_syslog(get_class($this) . "::change_status validation commande ecom_status " . $ecom_status . " equivalent à " . $dolistatus . "  " . $maj_ecom, LOG_DEBUG);
		}
		if ($status == 2) {
			$message = $langs->trans("MsgOrderShipped");
			$notifclient = 0;
		}
		if ($status == 3) {
			$message = $langs->trans("MsgOrderClosed");
			$notifclient = 0;
			if ($dolistatus == 3) $maj_ecom = FALSE;
			dol_syslog(get_class($this) . "::change_status validation commande ecom_status " . $ecom_status . " equivalent à " . $dolistatus . "  " . $maj_ecom, LOG_DEBUG);
		}
		if ($status == -1) {
			$message = $langs->trans("MsgOrderCanceled");
			$notifclient = 0;
			if ($dolistatus == -1) $maj_ecom = FALSE;
			dol_syslog(get_class($this) . "::change_status validation commande ecom_status " . $ecom_status . " equivalent à " . $dolistatus . "  " . $maj_ecom, LOG_DEBUG);
		}

		$message = utf8_encode(html_entity_decode($message));
		dol_syslog("E_order charset message " . $message . mb_detect_encoding($message, "auto"), LOG_DEBUG);

		if ($maj_ecom && $status != 0) {

			// maj sur site ecom
			dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

			// Set the parameters to send to the WebService
			$parameters = array("ordid" => $ordid, "status" => $site_status, "message" => $message, "mail" => $notifclient);
			dol_syslog("E_order ws pour " . $ordid . " statut " . $site_status, LOG_DEBUG);
			// Set the WebService URL
			$client = new nusoap_client($this->site->site_ws_url . "/ws_orders.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

			// Call the WebService and store its result in $obj
			$soapres = $client->call("set_status", $parameters);
			if ($client->fault) {
				$this->error = "Fault detected";
				dol_syslog(get_class($this) . "::change_status " . $this->error, LOG_ERR);
				return -1;
			}
			elseif (!($err = $client->getError())) {
				dol_syslog(get_class($this) . "::change_status validation pour " . $soapres->ord . " valeur : " . $soapres->stat, LOG_DEBUG);
			}
			else {
				dol_syslog(get_class($this) . "::change_status raté " . $err, LOG_ERR);
				return -1;
			}

			// mise à jour locale
			$this->fetch($id, $this->user);
			$this->site_order_status = $site_status;
			dol_syslog(__FILE__ . "::" . __FUNCTION__ . ":: " . " maj statut " . $id . " " . $site_status, LOG_DEBUG);
			if ($this->update($this->user, 1) < 0) {
				dol_syslog(get_class($this) . "::change_status update local error " . $this->error, LOG_ERR);
				return -1;
			}
		}

		return 1;
	}

	/**
	 * Change local status of a order
	 *
	 * @param int    ecomid        Id of ecommerce order
	 * @param int        status        Status id
	 * @return int                    >0
	 */
	function change_local_status($ecomid, $status)
	{
		// recherche de la commande
		$res = $this->findInSite($ecomid, $this->siteid);
		if ($res > 0) {
			$commande = new Commande($this->db);
			$commande->fetch($this->doli_order);
			dol_syslog(get_class($this) . "::change_local_status commande trouvée " . $commande->id . "  " . $commande->modelpdf, LOG_DEBUG);

			switch ($status) {
				case 0:
					break;
				case 1:
					// validation
					if ($commande->valid($this->user, $this->site->site_entrepot) < 0) {
						$this->error = "validation dolibarr " . $commande->error;
						dol_syslog(get_class($this) . "::change_local_status erreur " . $this->error, LOG_ERR);
					}
					else dol_syslog(get_class($this) . "::change_local_status validation effectuée " . $this->doli_order . "  " . $ecomid, LOG_ERR);
					break;
				case 2 :
					break;
				case 3 :
					// clôture
					if ($commande->cloture($this->user) < 0) {
						$this->error = "Clôture dolibarr " . $commande->error;
						dol_syslog(get_class($this) . "::change_local_status erreur " . $this->error, LOG_ERR);
					}
					else dol_syslog(get_class($this) . "::change_local_status Clôture effectuée " . $this->doli_order . "  " . $ecomid, LOG_ERR);
					break;
				case -1 :
					// annulation
					if ($this->cancel_commande_dolipresta($commande, $this->site->site_entrepot) > 0) {
						$this->error = "Annulation dolibarr " . $commande->error;
						dol_syslog(get_class($this) . "::change_local_status erreur " . $this->error, LOG_ERR);
					}
					else dol_syslog(get_class($this) . "::change_local_status annulation effectuée " . $this->doli_order . "  " . $ecomid, LOG_ERR);
					break;
				default :
					dol_syslog(get_class($this) . "::change_local_status Erreur status non géré " . $status, LOG_WARNING);
					break;
			}
		}

		return 1;
	}


	/**
	 *
	 * @param Commande $commande object commande
	 * @param int $idwarehouse wharehose to manage stock
	 * @return    int            0 if OK, >0 if KO
	 */
	function cancel_commande_dolipresta($commande, $idwarehouse)
	{
		global $user, $langs, $conf;
		$error = 0;

		$this->db->begin();

		$sql = "UPDATE " . MAIN_DB_PREFIX . "commande";
		$sql .= " SET fk_statut = -1";
		$sql .= " WHERE rowid = " . $this->doli_order;

		dol_syslog("Commande::cancel sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			// Appel des triggers
			include_once DOL_DOCUMENT_ROOT . '/core/class/interfaces.class.php';
			$interface = new Interfaces($this->db);
			$result = $interface->run_triggers('ORDER_CANCEL', $commande, $user, $langs, $conf);
			if ($result < 0) {
				$error++;
				$this->errors = $interface->errors;
			}
			// Fin appel triggers
		}
		else {
			$error++;
			$this->db->rollback();
			return $error;
		}

		// If stock is decremented on validate order, we must reincrement it
		if (!empty($conf->stock->enabled) && $conf->global->STOCK_CALCULATE_ON_VALIDATE_ORDER == 1 && $commande->statut == 1) {
			require_once DOL_DOCUMENT_ROOT . '/product/stock/class/mouvementstock.class.php';
			$langs->load("agenda");

			$num = count($commande->lines);
			for ($i = 0; $i < $num; $i++) {
				if ($commande->lines[$i]->fk_product > 0) {
					$mouvP = new MouvementStock($this->db);
					// We increment stock of product (and sub-products)
					$result = $mouvP->reception($user, $commande->lines[$i]->fk_product, $idwarehouse, $commande->lines[$i]->qty, $commande->lines[$i]->subprice, $langs->trans("OrderCanceledInDolibarr", $commande->ref));
					if ($result < 0) {
						$error++;
					}
				}
			}
		}

		if ($error > 0) {
			$this->db->rollback();
		}
		else {
			$this->db->commit();
		}

		return $error;
	}


	/**
	 * Convert payment code into id
	 *
	 * @param string    paye_code    Code payment
	 * @return int                    >0 If OK <0 If KO
	 */
	function get_paiement_code($paye_code)
	{
		$sql = "SELECT id FROM " . MAIN_DB_PREFIX . "c_paiement WHERE code = '" . $paye_code . "' or libelle ='".
            $paye_code . "'" ;
		dol_syslog(get_class($this) . "::get_paiement_code sql=" . $sql, LOG_DEBUG);

		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				return $obj->id;
			}
			else {
				dol_syslog(get_class($this) . "::get_paiement_code code non trouvé " . $paye_code, LOG_ERR);
				return 0;
			}
		}
		else {
			dol_syslog(get_class($this) . "::get_paiement_code erreur sql=" . $sql, LOG_ERR);
			return -1;
		}
	}

	/**
	 * Return unknown payment code into id
	 *
	 * @param string    paye_code    Code payment
	 * @return int                    >0 If OK <0 If KO
	 */
	function get_unknown_paiement_code($paye_code)
	{
		$sql = "SELECT id FROM " . MAIN_DB_PREFIX . "c_paiement WHERE code = 'INC'";
		dol_syslog(get_class($this) . "::get_paiement_code sql=" . $sql, LOG_DEBUG);

		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				return $obj->id;
			}
			else {
				dol_syslog(get_class($this) . "::get_paiement_code code non trouvé " . $paye_code, LOG_ERR);
				return 0;
			}
		}
		else {
			dol_syslog(get_class($this) . "::get_paiement_code erreur sql=" . $sql, LOG_ERR);
			return -1;
		}
	}


	/**
	 * Set the tracking number and method from order and expedition
	 *
	 * @param int        doli_ordid    Dolibarr order id
	 * @param int        doli_expid    Dolibarr expedition id
	 * @return int                    <0 If KO >0 if OK
	 */
	function set_tracking_num($doli_ordid, $doli_expid)
	{
		// contrôles
		if (!$doli_ordid || !$doli_expid) {
			$this->error = "orderid and expedid must be set";
			dol_syslog(get_class($this) . "::set_tracking_num " . $this->error, LOG_WARNING);
			return -1;
		}

		// get informations
		// search Expedition
		$exped = new Expedition($this->db);
		if ($exped->fetch($doli_expid) < 0) {
			$this->error = "No Expedition";
			dol_syslog(get_class($this) . "::set_tracking_num " . $this->error, LOG_ERR);
			return -1;
		}

		//	search form ecom orderid
		$sql = "SELECT eo.rowid, eo.siteid, eo.ecom_order, eo.site_order_status ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order eo ";
		$sql .= " WHERE doli_order = '" . $doli_ordid . "' ";

		dol_syslog(get_class($this) . "::set_tracking_num sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				$id = $obj->rowid;
				$this->siteid = $obj->siteid;
				$ecom_id = $obj->ecom_order;
				$ecom_status = $obj->site_order_status;
			}
			else {
				dol_syslog(get_class($this) . "::set_tracking_num non trouvé sql=" . $sql, LOG_WARNING);
				return -1;
			}
		}
		else {
			dol_syslog(get_class($this) . "::set_tracking_num sql=" . $sql, LOG_ERR);
			return -1;
		}
		//get the ecom site params
		$this->site = new Ecom_site($this->db);
		if ($this->site->fetch($this->siteid, $this->user) < 0) {
			$this->error = "ecom site error : " . $this->site->error;
			dol_syslog(get_class($this) . "::set_tracking_num setting site" . $this->error, LOG_ERR);
			return -1;
		}

		// search Carrier equivalent
		$shipmethid =  $exped->shipping_method_id;

		dol_syslog("E_order::set_tracking_num id " . $shipmethid . " num " . $exped->tracking_number, LOG_DEBUG);
		if (empty($shipmethid) || empty($exped->tracking_number)) {
			$this->error = "No expedition or no tracking number";
			dol_syslog(get_class($this) . "::set_tracking_num setting site" . $this->error, LOG_ERR);
			return -3;
		}

		$eparams = new E_params($this->db, $this->siteid, $this->user);
		$carrier_id = $eparams->dolibarr2ecom($shipmethid, 'expmeth');
		if ($carrier_id <= 0) {
			$this->error = "Carrier does not exist";
			dol_syslog(get_class($this) . "::set_tracking_num Carrier " . $this->error, LOG_ERR);
			return -2;
		}

		dol_syslog(get_class($this) . "::set_tracking_num Carrier " . $carrier_id, LOG_DEBUG);

		// Set the parameters to send to the WebService
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		$client = new nusoap_client($this->site->site_ws_url . "/ws_orders.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

		$parameters = array("orderid" => $ecom_id, "carrier_id" => $carrier_id, "tracknum" => $exped->tracking_number);

		// Call the WebService method and store its result in $result.
		$soapres = $client->call("set_tracknum", $parameters);
		if ($client->fault) {
			$this->error = "Fault detected";
			dol_syslog(get_class($this) . "::set_tracking_num " . $this->error, LOG_ERR);
			return -1;
		}
		else {
			$err = $client->getError();
			if (!$err) {
				dol_syslog(get_class($this) . "::set_tracking_num  " . $soapres["ord"] . " effectué Error : " . $soapres["error"], LOG_DEBUG);
			}
			else {
				dol_syslog(get_class($this) . "::set_tracking_num Error " . $err, LOG_ERR);
				return -1;
			}
		}
		return 1;
	}


	/**
	 * Send Dolibarr invoice to site
	 *
	 * @param int        doli_order    Id of Dolibarr order
	 * @param string        facnumber    Dolibarr invoice ref
	 * @return int                        0 if OK <0 if KO
	 */
	function send_invoice($doli_order, $facnumber)
	{
		global $conf, $langs;
		require_once(DOL_DOCUMENT_ROOT . '/core/modules/facture/modules_facture.php');

		$this->siteid = 0;
		$this->ecom_order = 0;

		// vérifier que la commande vient d'un site internet
		$res = $this->getOrderSiteid($doli_order);
		dol_syslog(get_class($this) . "::send_invoice getordersiteid res=" . $res, LOG_DEBUG);
		if ($this->siteid && $this->ecom_order) {
			$this->site = new Ecom_site($this->db);
			if ($this->site->fetch($this->siteid, $user) < 0) {
				dol_syslog(get_class($this) . "::send_invoice " . $this->site->error, LOG_ERR);
				return -1;
			}
			$this->siteid = $this->site->id;

			$fact = new Facture($this->db);
			if ($fact->fetch('', $facnumber) < 0) {
				dol_syslog(get_class($this) . "::send_invoice erreur régénération doc pdf", LOG_WARNING);
				return -1;
			}
			$fact->fetch_thirdparty();
			dol_syslog(get_class($this) . "::send_invoice création pdf", LOG_DEBUG);
			// add/renew invoice pdf
			$result = $fact->generateDocument($fact->modelpdf, $langs);
			dol_syslog(get_class($this) . "::send_invoice création pdf res= " . $res, LOG_DEBUG);
			if ($result <= 0) {
				dol_syslog(get_class($this) . "::send_invoice erreur régénération doc pdf", LOG_WARNING);
				return -1;
			}

			// Set the parameters to send to the WebService
			dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
			dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . '/nusoapmime.php');
			$client = new nusoap_client_mime($this->site->site_ws_url . "/ws_ordersmime.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

			$parameters = array("order_id" => $this->ecom_order, "invoice_ref" => $facnumber);
			dol_syslog(get_class($this) . "::send_invoice parameters =" . print_r($parameters, true));

			$filename = dol_sanitizeFileName($facnumber);
			$filedir = $conf->facture->dir_output . '/' . dol_sanitizeFileName($facnumber);

			$cid = $client->addAttachment('', $filedir . '/' . $filename . '.pdf');
			dol_syslog(get_class($this) . "::send_invoice " . $filedir . $filename . 'pdf attachemnt res=' . $cid, LOG_DEBUG);
			// Call the WebService method and store its result in $result.
			$soapres = $client->call("send_invoice", $parameters);
			if ($client->fault) {
				$this->error = "Fault detected";
				dol_syslog(get_class($this) . "::send_invoice " . $this->error, LOG_ERR);
				// TODO tracer l'erreur			return -1;
			}
			else {
				$err = $client->getError();
				if (!$err) {
					dol_syslog(get_class($this) . "::send_invoice  " . $soapres["fichier"] . " Transmis : " . print_r($soapres, true), LOG_DEBUG);
				}
				else {
					dol_syslog(get_class($this) . "::send_invoice Error " . $soapres["erreur"] . "  " . $err, LOG_ERR);
					// TODO tracer l'erreur				return -1;
				}
			}
		}


		return 0;
	}


	/**
	 * Update ecommerce order data if order is deleted
	 *
	 * @param int        comid    Dolibarr order id
	 * @return int                <0 if KO 0 if OK
	 */
	function order_isdeleted($comid)
	{
		//rechercher la ligne dans ecom_order
		if ($this->getOrderSiteid($comid) < 0) {
			dol_syslog(get_class($this) . "::order_isdeleted Error " . $this->error, LOG_ERR);
			return -1;
		}
		if ($this->id > 0) {
			$this->fetch($this->id);
			$this->doli_order = -1;
			$this->datem = dol_now();
			$error = 0;
			$this->db->begin();
			if ($this->update($this->user) < 0) {
				dol_syslog(get_class($this) . "::order_isdeleted Error " . $this->error, LOG_ERR);
				$this->db->rollback();
				$this->error = "Erreur maj ecom_order " . $this->error;
				return -1;
			}
			$this->db->commit();
		}
		else dol_syslog(get_class($this) . "::order_isdeleted order not found " . $comid, LOG_DEBUG);

		return 0;
	}
}
