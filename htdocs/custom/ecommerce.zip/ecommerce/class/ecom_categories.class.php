<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010      Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013 	Philippe Grand		<philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       htdocs/ecommerce/class/ecom_categories.class.php
 *      \ingroup    products
 *        \author        Jean Heimburger - www.tiaris.fr
 */

/**
 *        \class      Ecom_categories
 *        \brief      Categories class for e-commerce site
 */
class Ecom_categories extends CommonObject
{
	var $id;

	var $siteid;
	var $doli_catid;
	var $ecom_catid;
	var $ecom_catname;


	/**
	 *   Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *      Create in database
	 * @param user        User that create
	 * @return     int         <0 si ko, >0 si ok
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->doli_catid)) $this->doli_catid = trim($this->doli_catid);
		if (isset($this->ecom_catid)) $this->ecom_catid = trim($this->ecom_catid);
		if (isset($this->ecom_catname)) $this->ecom_catname = trim($this->ecom_catname);


		// Insert request

		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_categories(";
		$sql .= " siteid,";
		$sql .= " doli_catid,";
		$sql .= " ecom_catid,";
		$sql .= " ecom_parentid,";
		$sql .= " ecom_catname";

		$sql .= ") VALUES (";
		$sql .= " '" . $this->siteid . "',";
		$sql .= " '" . $this->doli_catid . "',";
		$sql .= " '" . $this->ecom_catid . "',";
		$sql .= " '" . $this->ecom_parentid . "',";
		$sql .= " '" . $this->db->escape($this->ecom_catname) . "'";
		$sql .= ")";

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_categories");

			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}

	/**
	 *      Update database
	 * @param user            User that modify
	 * @param notrigger    0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->doli_catid)) $this->doli_catid = trim($this->doli_catid);
		if (isset($this->ecom_catid)) $this->ecom_catid = trim($this->ecom_catid);
		if (isset($this->ecom_catname)) $this->ecom_catname = trim($this->ecom_catname);


		// Update request

		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_categories SET";
		$sql .= " siteid=" . (isset($this->siteid) ? "'" . $this->db->escape($this->siteid) . "'" : "null") . ",";
		$sql .= " doli_catid=" . (isset($this->doli_catid) ? "'" . $this->db->escape($this->doli_catid) . "'" : "null") . ",";
		$sql .= " ecom_catid=" . (isset($this->ecom_catid) ? "'" . $this->db->escape($this->ecom_catid) . "'" : "null") . ",";
		$sql .= " ecom_catname=" . (isset($this->ecom_catname) ? "'" . $this->db->escape($this->ecom_catname) . "'" : "null");
		$sql .= " WHERE rowid=" . $this->id;

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *    Load object in memory from database
	 * @param id          id object
	 * @param user        User that load
	 * @return     int         <0 if KO, >0 if OK
	 */
	function fetch($id, $user = 0)
	{
		global $langs;
		$sql = "SELECT";
		$sql .= " t.rowid,";
		$sql .= " t.siteid,";
		$sql .= " t.doli_catid,";
		$sql .= " t.ecom_catid,";
		$sql .= " t.ecom_catname";

		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_categories as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;
				$this->siteid = $obj->siteid;
				$this->doli_catid = $obj->doli_catid;
				$this->ecom_catid = $obj->ecom_catid;
				$this->ecom_catname = $obj->ecom_catname;

			}
			$this->db->free($resql);

			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 *   Delete object in database
	 * @param user        User that delete
	 * @return        int            <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_categories";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::delete sql=" . $sql);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}
}


