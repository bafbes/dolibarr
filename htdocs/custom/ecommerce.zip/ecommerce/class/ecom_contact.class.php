<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010      Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013 Philippe Grand       <philippe.grand@atoo-net.com>
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       htdocs/ecommerce/class/ecom_contact.class.php
 *      \ingroup    products
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */

/**
 *      \class      Ecom_contact
 *      \brief      Contact class for e-commerce site
 */
class Ecom_contact extends CommonObject
{
	var $id;

	var $siteid;
	var $ecom_cust_id;
	var $ecom_address_id;
	var $doli_contact_id;
	var $datem = '';


	/**
	 *   Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *      Create in database
	 * @param user            User that create
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, Id of created object if OK
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->ecom_cust_id)) $this->ecom_cust_id = trim($this->ecom_cust_id);
		if (isset($this->ecom_address_id)) $this->ecom_address_id = trim($this->ecom_address_id);
		if (isset($this->doli_contact_id)) $this->doli_contact_id = trim($this->doli_contact_id);


		// Insert request

		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_contact(";
		$sql .= "siteid,";
		$sql .= "ecom_cust_id,";
		$sql .= "ecom_address_id,";
		$sql .= "doli_contact_id,";
		$sql .= "datem";

		$sql .= ") VALUES (";
		$sql .= " " . (!isset($this->siteid) ? 'NULL' : "'" . $this->siteid . "'") . ",";
		$sql .= " " . (!isset($this->ecom_cust_id) ? 'NULL' : "'" . $this->ecom_cust_id . "'") . ",";
		$sql .= " " . (!isset($this->ecom_address_id) ? 'NULL' : "'" . $this->ecom_address_id . "'") . ",";
		$sql .= " " . (!isset($this->doli_contact_id) ? 'NULL' : "'" . $this->doli_contact_id . "'") . ",";
		$sql .= " " . (!isset($this->datem) || strlen($this->datem) == 0 ? 'NULL' :"'" . $this->db->idate($this->datem)) . "'";
		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_contact");

			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}


	/**
	 *    Load object in memory from database
	 * @param id          id object
	 * @return     int         <0 if KO, >0 if OK
	 */
	function fetch($id)
	{
		global $langs;
		$sql = "SELECT";
		$sql .= " t.rowid,";
		$sql .= " t.siteid,";
		$sql .= " t.ecom_cust_id,";
		$sql .= " t.ecom_address_id,";
		$sql .= " t.doli_contact_id,";
		$sql .= " t.datem";

		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_contact as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;
				$this->siteid = $obj->siteid;
				$this->ecom_cust_id = $obj->ecom_cust_id;
				$this->ecom_address_id = $obj->ecom_address_id;
				$this->doli_contact_id = $obj->doli_contact_id;
				$this->datem = $this->db->jdate($obj->datem);

			}
			$this->db->free($resql);

			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 *      Update database
	 * @param user            User that modify
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->ecom_cust_id)) $this->ecom_cust_id = trim($this->ecom_cust_id);
		if (isset($this->ecom_address_id)) $this->ecom_address_id = trim($this->ecom_address_id);
		if (isset($this->doli_contact_id)) $this->doli_contact_id = trim($this->doli_contact_id);


		// Update request

		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_contact SET";
		$sql .= " siteid=" . (isset($this->siteid) ? "'" . $this->db->escape($this->siteid) . "'" : "null") . ",";
		$sql .= " ecom_cust_id=" . (isset($this->ecom_cust_id) ? "'" . $this->db->escape($this->ecom_cust_id) . "'" : "null") . ",";
		$sql .= " ecom_address_id=" . (isset($this->ecom_address_id) ? "'" . $this->db->escape($this->ecom_address_id) . "'" : "null") . ",";
		$sql .= " doli_contact_id=" . (isset($this->doli_contact_id) ? "'" . $this->db->escape($this->doli_contact_id) . "'" : "null") . ",";
		$sql .= " datem=" . (strlen($this->datem) != 0 ? "'" . $this->db->idate($this->datem) . "'" : 'null') . "";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *   Delete object in database
	 * @param user            User that delete
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_contact";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::delete sql=" . $sql);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}

	/**
	 *        Initialise object with example values
	 * @remarks    id must be 0 if object instance is a specimen.
	 */
	function initAsSpecimen()
	{
		$this->id = 0;
		$this->siteid = '';
		$this->ecom_cust_id = '';
		$this->ecom_address_id = '';
		$this->doli_contact_id = '';
		$this->datem = '';


	}

}


