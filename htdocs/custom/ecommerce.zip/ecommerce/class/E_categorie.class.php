<?php
/* Copyright (C) 2007 		Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2008 		Jean Heimburger		<jean@tiaris.fr>
 * Copyright (C) 2011-2013 	Philippe Grand		<philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013 	Juanjo Menent       <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       scripts/ecommerce/import_products.php
 *        \ingroup    ecommerce
 *      \brief      Imports a category list from ecommerce site
 *        \author        Jean Heimburger www.tiaris.fr
 */

dol_include_once("/ecommerce/class/ecom_categories.class.php");
require_once(DOL_DOCUMENT_ROOT . "/categories/class/categorie.class.php");

class E_categorie extends Ecom_categories
{
	var $site;
	var $user;

	var $ecom_parentid;

	/**
	 *   Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	function __construct($db, $siteid, $user)
	{
		$this->db = $db;
		$this->site = new Ecom_site($this->db);
		$this->user = $user;
		if ($this->site->fetch($siteid, $user) < 0) {
			dol_syslog(get_class($this) . '::Constructeur ' . $site->error . '', LOG_DEBUG);
			return -1;
		}

		return 1;
	}

	/**
	 *        gets categories informations from web service
	 * @param eid    category id on e-commerce
	 * @param rowid : id in ecom_categorie
	 *        Il y'a une erreur de valeur par défaut à un paramètre suivi de paramètre sans valeur par défaut
	 */

	function ws_fetch($eid = '', $rowid)
	{
		global $conf, $langs;
		if (!$rowid) {
			dol_syslog(get_class($this) . '::wsfetch rowid ne doit pas être nul', LOG_DEBUG);
			return -1;
		}
		$this->id = $rowid;
		$this->siteid = $this->site->id;

		$this->error = '';
		dol_syslog(get_class($this) . '::wsfetch eid=' . $eid . '', LOG_DEBUG);

		// Check parameters
		if (!$eid) {
			$this->error = $langs->load("CatErrParam");
			return -1;
		}

		//WebService Client.
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

		// Set the parameters to send to the WebService
		$parameters = array("catid" => $eid);

		// Set the WebService URL
		$client = new nusoap_client($this->site->site_ws_url . "ws_articles.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

		// Call the WebService client->fault and store its result in $obj
		$obj = $client->call("get_category", $parameters);

		if ($client->fault) {
			$this->error = $langs->trans("ErrWSFault") . ": " . $client->getError();
			dol_syslog(get_class($this) . '::fetch ' . $this->error . '', LOG_DEBUG);
			return -1;
		}
		elseif (!($err = $client->getError())) {
			$this->ecom_catname = mb_convert_encoding($obj[0]["categories_name"], 'UTF-8', mb_detect_encoding($obj[0]["categories_name"]));
			$this->ecom_parentid = $obj[0]["parent_id"];
			$this->ecom_catid = $obj[0]["categories_id"];
		}
		else {
			$this->error = $err;
			return -1;
		}

		return 1;
	}

	/**
	 *
	 *     transform an ecom_category in a dolibarr category sans fetch depuis llx_categorie
	 * @param ecomid : category id on ecom site
	 */
	function ecom2dolibarr($ecomid, $rowid)
	{
		global $langs;
		$result = $this->ws_fetch($ecomid, $rowid);
		dol_syslog(get_class($this) . '::ecom2dolibarr ' . $ecomid . ' result' . $result . '', LOG_DEBUG);
		if ($result) {
			$doli_cat = new Categorie($this->db);
			//$doli_cat->label          = sprintf("%02d:%02d_%02d_" ,$this->siteid,$this->ecom_parentid, $this->ecom_catid) . $this->ecom_catname;
			$doli_cat->label = $this->ecom_catname . " " . sprintf("(%s:%02d)", $this->site->site_name, $this->ecom_catid);
			$doli_cat->description = $this->ecom_catname;
			$doli_cat->visible = 1;
			$doli_cat->type = 0;
			if ($this->ecom_parentid == 0) {
				// categorie de niveau 0 a creer
			    $doli_cat->fk_parent = '';
			}
			else {
				$mere = $this->get_dolicat($this->ecom_parentid);
				if ($mere > 0) {
					// categorie de niveau 0 a creer
					$doli_cat->fk_parent = $mere;
				}
				else {
					dol_syslog(get_class($this) . '::ecom2dolibarr la categorie mere ' . $this->ecom_parentid . ' n\'existe pas', LOG_DEBUG);
					$this->error = $langs->load("CatErrMotherNotExists", $this->ecom_parentid);
					return '';
				}
			}
			return $doli_cat;
		}
		else return '';
	}

	/**
	 *
	 *    joins a ecom category to a dolibarr category if the dolibarr category does not exist it will be created
	 * @param catid    ecommerce catid
	 * @param rowid : id in ecom_categorie
	 */
	function import_categorie($catid, $rowid)
	{
		$doli_cat = new Categorie($this->db);
		$this->user->getrights('categorie');

		$doli_cat = $this->ecom2dolibarr($catid, $rowid);

		if ($this->get_dolicat($catid) > 0) {
			dol_syslog(get_class($this) . '::import_categorie ' . $catid . ' existe déjà', LOG_DEBUG);
			return -1;
		}
		if ($doli_cat) {
			$doli_cat->db = $this->db;
			dol_syslog(get_class($this) . '::import_categorie ' . $ecomid . ' création', LOG_DEBUG);
			$this->db->begin();
			$errorsql = 0;
			$doli_catid = $doli_cat->create();
			if ($doli_catid > 0) {
				$this->doli_catid = $doli_catid;
				if ($this->update($this->user) < 0) {
					$errorsql++;
					dol_syslog("E_categories::import_categorie erreur update ecom_categories " . $this->error, LOG_ERR);
				}
			}
			else {
				$errorsql++;
				dol_syslog("E_categories::import_categorie erreur creation categorie " . $doli_cat->error, LOG_ERR);
			}

			if (!$errorsql) {
				$this->db->commit();
				dol_syslog("E_categories::import_categorie creation categorie reussie " . $doli_catid, LOG_DEBUG);
				return 1;
			}
			else {
				$this->db->rollback();
				return -1;
			}
		}
		else return -1;
	}

	/**
	 *
	 *     returns the dolicat id for an existing ecom catid
	 * @param catid    ecommerce catid
	 */
	function get_dolicat($catid)
	{

		$sql = "SELECT ec.doli_catid FROM " . MAIN_DB_PREFIX . "ecom_categories ec WHERE ec.ecom_catid ='" . $catid . "' AND ec.siteid = '" . $this->site->id . "'";
		dol_syslog("E_category::get_dolicat  sql " . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			if ($num) {
				$obj = $this->db->fetch_object($resql);
				$retval = $obj->doli_catid;
			}
			else $retval = 0;
		}
		else {
			dol_syslog("E_category::get_dolicat erreur sql " . $sql, LOG_DEBUG);
			$retval = -1;
		}
		dol_syslog("E_category::get_dolicat  retourne " . $retval, LOG_DEBUG);
		return $retval;
	}


	/**
	 *
	 *     returns the ecom cat id for an existing dolibarr catid
	 * @param catid    ecommerce catid
	 */
	function get_e_cat($catid)
	{
		$sql = "SELECT ec.ecom_catid FROM " . MAIN_DB_PREFIX . "ecom_categories ec WHERE ec.doli_catid ='" . $catid . "' AND ec.siteid = '" . $this->site->id . "'";
		dol_syslog("E_category::getdolicat  sql " . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			if ($num) {
				$obj = $this->db->fetch_object($resql);
				$retval = $obj->ecom_catid;
			}
			else $retval = 0;
		}
		else {
			dol_syslog("E_category::get_e_cat erreur sql " . $sql, LOG_DEBUG);
			$retval = -1;
		}
		dol_syslog("E_category::get_e_cat  retourne " . $retval, LOG_DEBUG);
		return $retval;
	}


	/**
	 *
	 *    returns the dolicat id for an existing ecom catid
	 * @param catid    ecommerce catid
	 */
	function dolicat_exist($catid)
	{

		$sql = "SELECT count(*) as cpt FROM " . MAIN_DB_PREFIX . "ecom_categories ec WHERE ec.ecom_catid ='" . $catid . "' AND ec.siteid = '" . $this->site->id . "'";
		dol_syslog("E_category::dolicat_exist  sql " . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			$obj = $this->db->fetch_object($resql);
			$retval = $obj->cpt;
		}
		else {
			dol_syslog("E_category::getdolicat erreur sql " . $sql, LOG_DEBUG);
			$retval = -1;
		}
		dol_syslog("E_category::dolicat_exist  retourne " . $retval, LOG_DEBUG);
		return $retval;
	}

	/**
	 *
	 *    gets the categories from ecom site where id > first
	 * @param catid    ecommerce catid
	 */
	function import_new_cats($limit)
	{
		global $langs, $conf;
		// la derniere categorie connue dans dolibarr
		$sql = "SELECT max(ecom_catid) last FROM " . MAIN_DB_PREFIX . "ecom_categories ec ";
		$sql .= "WHERE ec.siteid = '" . $this->site->id . "' ";

		dol_syslog("E_category::import_new_cats $sql", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {

			$obj = $this->db->fetch_object($resql);
			if ($obj) {
				$last = $obj->last;
				if (!isset($last)) $last = 0;
			}
			else {
				dol_syslog("E_category::import_new_cats rien a faire", LOG_DEBUG);
				//return -1;
				$last = 0;
			}
		}
		else {
			dol_syslog("E_category::import_new_cats erreur " . $sql, LOG_DEBUG);
			return -1;
		}

		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");

		// Set the parameters to send to the WebService
		$parameters = array("catid" => $last, "limit" => $limit);

		// Set the WebService URL
		$client = new nusoap_client($this->site->site_ws_url . "/ws_articles.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));

		dol_syslog("E_category::import_new_cats service web " . $this->site->site_ws_url . "/ws_articles.php", LOG_DEBUG);

		// Call the WebService and store its result in $obj
		$wsresult = $client->call("get_categorylist", $parameters);
		if ($client->fault) {
			return -1;
		}
		elseif (!($err = $client->getError())) {
			// creation de ecom_categorie
			if ($wsresult) {
				$this->db->begin();
				$errorsql = 0;
				$sz = sizeof($wsresult);
				for ($i = 0; $i < $sz; $i++) {
					$ec = new Ecom_categories($this->db);

					$ec->siteid = $this->site->id;
					$ec->ecom_catid = $wsresult[$i]["categories_id"];
					$ec->ecom_parentid = $wsresult[$i]["parent_id"];
					$ec->ecom_catname = convertCharset($wsresult[$i]["categories_name"]); //mb_convert_encoding($wsresult[$i]["categories_name"], mb_detect_encoding($wsresult[$i]["categories_name"]));
					$ec->doli_catid = 0;
					if ($this->dolicat_exist($wsresult[$i]["categories_id"]) > 0) {
						dol_syslog("E_categories::import_categorie " . $wsresult[$i]["categories_id"] . "existe déjà maj", LOG_DEBUG);
						if ($ec->update($this->user) < 0) {
							continue;
							dol_syslog("E_category::import_new_cats erreur update ecom_categorie " . $ec->error, LOG_DEBUG);
						}
					}
					if ($ec->create($this->user) < 0) {
						dol_syslog("E_category::import_new_cats erreur cr�ation ecom_categorie " . $ec->error, LOG_DEBUG);
						$errorsql++;
					}
					else dol_syslog("E_category::import_new_cats ecom_categorie cree " . $ec->ecom_catname, LOG_DEBUG);

					unset($ec);
				}
				if ($errorsql > 0) {
					dol_syslog("E_category::import_new_cats rollback " . $errorsql, LOG_DEBUG);
					return -1;
				}
				else $this->db->commit();
			}
			else dol_syslog("E_category::import_new_cats pas de resultat ", LOG_DEBUG);
			// sortie sans erreur
			return 1;
		}
		else {
			dol_syslog("E_category::import_new_cats erreur ws " . $err, LOG_DEBUG);
			return -1;
		}
	}

}

