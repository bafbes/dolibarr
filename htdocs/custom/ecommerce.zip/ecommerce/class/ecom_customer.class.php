<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010      Jean Heimburger		<jean@tiaris.info>
 * Copyright (C) 2011-2013 Philippe Grand		<philippe.grand@atoo-net.com>
 * Copyright (C) 2011      Juanjo Menent      	<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       htdocs/ecommerce/class/ecom_customer.class.php
 *      \ingroup    products
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */

/**
 *      \class      Ecom_customer
 *      \brief      Customers class for e-commerce site
 */
class Ecom_customer extends CommonObject
{
	var $id;

	var $siteid;
	var $doli_soc;
	var $ecom_customer;
	var $site_cust_status;
	var $site_cust_newsletter;
	var $datem;


	/**
	 *  Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *  Create object into database
	 *
	 * @param User $user User that creates
	 * @param int $notrigger 0=launch triggers after, 1=disable triggers
	 * @return int                 <0 if KO, Id of created object if OK
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;
		$now = dol_now();

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->doli_soc)) $this->doli_soc = trim($this->doli_soc);
		if (isset($this->ecom_customer)) $this->ecom_customer = trim($this->ecom_customer);
		if (isset($this->site_cust_status)) $this->site_cust_status = trim($this->site_cust_status);
		else $this->site_cust_status = "C";
		if (isset($this->site_cust_newsletter)) $this->site_cust_newsletter = trim($this->site_cust_newsletter);
		else $this->site_cust_newsletter = "Y";
		$this->datem = $now;

		// Insert request
		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_customer(";
		$sql .= " siteid,";
		$sql .= " doli_soc,";
		$sql .= " ecom_customer,";
		$sql .= " site_cust_status,";
		$sql .= " site_cust_newsletter,";
		$sql .= " datem";
		$sql .= ") VALUES (";

		$sql .= " " . (!isset($this->siteid) ? 'NULL' : "'" . $this->siteid . "'") . ",";
		$sql .= " " . (!isset($this->doli_soc) ? 'NULL' : "'" . $this->doli_soc . "'") . ",";
		$sql .= " " . (!isset($this->ecom_customer) ? 'NULL' : "'" . $this->ecom_customer . "'") . ",";
		$sql .= " " . (!isset($this->site_cust_status) ? 'NULL' : "'" . $this->site_cust_status . "'") . ",";
		$sql .= " " . (!isset($this->site_cust_newsletter) ? 'NULL' : "'" . $this->site_cust_newsletter . "'") . ",";
		$sql .= " " . (!isset($this->datem) || dol_strlen($this->datem) == 0 ? 'NULL' : "'" . $this->db->idate($this->datem)). "'";
		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_customer");

			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}

	/**
	 *  Update object into database
	 *
	 * @param User $user User that modifies
	 * @param int $notrigger 0=launch triggers after, 1=disable triggers
	 * @return int                 <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->doli_soc)) $this->doli_soc = trim($this->doli_soc);
		if (isset($this->ecom_customer)) $this->ecom_customer = trim($this->ecom_customer);
		if (isset($this->site_cust_status)) $this->site_cust_status = trim($this->site_cust_status);
		if (isset($this->site_cust_newsletter)) $this->site_cust_newsletter = trim($this->site_cust_newsletter);


		// Update request

		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_customer SET";
		$sql .= " siteid=" . (isset($this->siteid) ? "'" . $this->db->escape($this->siteid) . "'" : "null") . ",";
		$sql .= " doli_soc=" . (isset($this->doli_soc) ? "'" . $this->db->escape($this->doli_soc) . "'" : "null") . ",";
		$sql .= " ecom_customer=" . (isset($this->ecom_customer) ? "'" . $this->db->escape($this->ecom_customer) . "'" : "null") . ",";
		$sql .= " site_cust_status=" . (isset($this->site_cust_status) ? "'" . $this->db->escape($this->site_cust_status) . "'" : "null") . ",";
		$sql .= " site_cust_newsletter=" . (isset($this->site_cust_newsletter) ? "'" . $this->db->escape($this->site_cust_newsletter) . "'" : "null") . ",";
		$sql .= " datem=" . (dol_strlen($this->datem) != 0 ? "'" . $this->db->idate($this->datem) . "'" : 'null') . "";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *  Load object in memory from the database
	 *
	 * @param int $id Id object
	 * @param string $user Ref of user (admin or not)
	 * @return int                        <0 if KO, >0 if OK
	 */
	function fetch($id, $user = 0)
	{
		global $langs;

		$sql = "SELECT";
		$sql .= " t.rowid,";
		$sql .= " t.siteid,";
		$sql .= " t.doli_soc,";
		$sql .= " t.ecom_customer,";
		$sql .= " t.site_cust_status,";
		$sql .= " t.site_cust_newsletter,";
		$sql .= " t.datem";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_customer as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;
				$this->siteid = $obj->siteid;
				$this->doli_soc = $obj->doli_soc;
				$this->ecom_customer = $obj->ecom_customer;
				$this->site_cust_status = $obj->site_cust_status;
				$this->site_cust_newsletter = $obj->site_cust_newsletter;
				$this->datem = $this->db->jdate($obj->datem);
				$ret = 1;
			}
			else $ret = 0;

			$this->db->free($resql);
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			$ret = -1;
		}

		return $ret;
	}


	/**
	 *  Delete object in database
	 *
	 * @param User $user User that deletes
	 * @param int $notrigger 0=launch triggers after, 1=disable triggers
	 * @return    int                            <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger)
	{
		global $conf, $langs;
		$error = 0;

		$this->db->begin();

		if (!$error) {
			if (!$notrigger) {

			}
		}

		if (!$error) {

			$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_customer";
			$sql .= " WHERE rowid=" . $this->id;

			dol_syslog(get_class($this) . "::delete sql=" . $sql);
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				$this->errors[] = "Error " . $this->db->lasterror();
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *        Initialise object with example values
	 * @remarks    id must be 0 if object instance is a specimen.
	 */
	function initAsSpecimen()
	{
		$this->id = 0;
		$this->siteid = '';
		$this->doli_soc = '';
		$this->ecom_customer = '';
		$this->site_cust_status = '';
		$this->site_cust_newsletter = '';
		$this->datem = '';

	}

}


