<?php
//Classe non utilisée
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2011-2012 Jean Heimburger      <jean@tiaris.fr>
 * Copyright (C) 2011-2013 Philippe Grand       <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2012 Juanjo Menent        <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       dev/skeletons/ecom_log.class.php
 *      \ingroup    mymodule othermodule1 othermodule2
 *      \brief      This file is an example for a CRUD class file (Create/Read/Update/Delete)
 *        \version    $Id: E_import.class.php,v 1.2.4.3 2011-10-19 18:01:53 tiaris Exp $
 *        \author        Put author name here
 *        \remarks    Initialy built by build_class_from_table on 2009-09-27 09:40
 */

//Classe actuellement inutilis
// Put here all includes required by your class file
require_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");
dol_include_once("/ecommerce/core/lib/ecommerce.lib.php");
dol_include_once("/ecommerce/class/E_product.class.php");

/**
 *      \class      E_import
 *      \brief      File import utility
 *      \remarks    Ecommerce module 2010-06-12
 */
class E_import
{

	var $db;
	var $error;
	var $errors = array();

	var $process_result;
	var $process_msg;
	var $filename;
	var $firstline;
	var $siteid;
	var $user;
	var $separator = ";";

	function E_import($db, $filename, $siteid, $user)
	{
		$this->db = $db;
		$this->error = '';
		$this->filename = $filename;
		$this->user = $user;
		$this->siteid = $siteid;
		$this->firstline = 0;
		return 1;
	}

   // fonction d'imports de fichiers'
	function validate_import()
	{

		$this->process_msg = '';
		$error = 0;
		if (!utf8_check($this->filename)) $$this->filename = utf8_encode($this->filename);
		$fp = @fopen($this->filename, "r");
		if ($fp) {
			$i = 0;
			while ($ligne = fgetcsv($fp, 1000, $separator)) {
				$i++;
				if ($this->firstline && $i == 1) continue;

				foreach ($ligne as $element) {
					$this->process_msg .= $element . " ";
				}
				$this->process_msg .= "\n";
				$this->process_msg .= convertCharset($ligne[0]) . ' ; ' . convertCharset($ligne[1]) . ' ; ' . utf8_decode($ligne[1]) . ' ; ' . convertCharset($ligne[3]) . "\n";
			}
			fclose($fp);
		}
		else {
			$this->error = "erreur ouverture fichier " . $nomfich;
			$error = -1;
		}
		return $error;
	}


	//Non utilisé
	// creation objet dans dolibarr $object = 'product' typeimport = Creation,  ou Modification ou Delete
	// structure fichier : référence, quantité, poids, fabricant, catégorie, tva_id, prix vente, description longue

	function ImportOnEcommerce($typeimport)
	{
		$this->process_msg = '';
		$error = 0;
		$doliprod = new Product($this->db);
		$eprod = new E_product($this->db, $this->siteid, $this - user);
		$fp = @fopen($this->filename, "r");
		if ($fp) {
			$i = 0;
			while ($ligne = fgetcsv($fp, 1000, ";")) {
				$i++;
				if ($this->firstline && $i == 1) continue;

				// création sur ecommerce
				if ($doliprod->fetch('', $ligne[0]) < 0) {
					$this->process_msg .= "Erreur ligne $i " . $ligne[0] . "  Article inconnu " . "\n";
					continue;
				}

				$eprod->doli_ref = $ligne[0];
				if ($ligne[6]) $eprod->price = $ligne[6];
				if ($ligne[1]) $eprod->site_stock = $ligne[1];
				if ($ligne[2]) $eprod->weight = $ligne[2];
				if ($ligne[3]) $eprod->fourn = $ligne[3];
				if ($ligne[4]) $eprod->catid = $ligne[4];
				$tva = 0;
				if ($ligne[5]) $tva = $ligne[5];
				//description longue
				if ($ligne[7]) $eprod->long_desc = $ligne[7];

				switch ($typeimport) {
					case 'C':
						// si le produit existe déjà en ligne on continue
						if ($row = $eprod->findrowid($doliprod->id) > 0) {
							$this->process_msg .= "Erreur ligne $i " . $ligne[0] . "  Article déjà en vente sur ce site $row " . "\n";
						}
						else {
							if ($eprod->sell_product($doliprod->id, $ligne[4], $tva) < 0) $this->process_msg .= "Erreur ligne $i " . $ligne[0] . "  " . $eprod->error . "\n";;
							// 	maj avec long desc A faire
						}
						break;
					case 'M':
						$eprod->doli_product = $doliprod->id;
						if ($eprod->modify($doliprod->id) < 0) $this->process_msg .= "Erreur ligne $i " . $ligne[0] . "  " . $eprod->error . "\n";
						if ($ligne[7] != '') {
							switch ($ligne[7]) {
								case 'A':
									if ($eprod->activate($doliprod->id, 1) < 0) $this->process_msg .= "Erreur ligne $i " . $ligne[0] . "  " . $eprod->error . "\n";
									break;
								case 'I':
									if ($eprod->activate($doliprod->id, 0) < 0) $this->process_msg .= "Erreur ligne $i " . $ligne[0] . "  " . $eprod->error . "\n";
									break;
								default:
									$this->process_msg .= "Erreur ligne $i " . $ligne[0] . " produit actif : valeurs possibles A = actif, I = Inactif" . "\n";
							}
						}
				}

			}
			fclose($fp);
		}
		else {
			$this->error = "erreur ouverture fichier " . $nomfich;
			$error = -1;
		}

		return $error;
	}

}


