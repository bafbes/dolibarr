<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2008      Jean Heimburger	    <jean@tiaris.fr>
 * Copyright (C) 2011-2013 Philippe Grand       <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2014 Juanjo Menent        <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *       \file       ecommerce/E_order.class.php
 *       \ingroup    ecommerce
 *       \brief      Class function for e-commerce order management
 *         \author     Jean Heimburger
 *         \remarks     http://www.tiaris.fr
 */

dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/ecom_params.class.php");
dol_include_once("/ecommerce/class/ecom_manufacturer.class.php");
dol_include_once("/ecommerce/class/ecom_customer_type.class.php");
dol_include_once("/ecommerce/class/webservice_ecom.class.php");

class E_params extends Ecom_params
{
	var $user;
	var $site;

	var $tx;

	function E_params($db, $siteid, $user)
	{
		$this->db = $db;
		$this->user = $user;
		$this->site = new Ecom_site($this->db);
		if ($this->site->fetch($siteid, $user) < 0) {
			dol_syslog("E_params::Constructeur $site->error", LOG_DEBUG);
			return -1;
		}
		$this->siteid = $siteid;
		return 1;
	}

// Vérification de l'unicité -
//Retourne le nombre d'enregistrements dans llx_ecom_params pour $this->partype, $this->doli_id et $this->ecom_id
	function verif_param()
	{
		if ($this->partype == 'ecomstat') {
			$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "ecom_params ";
			$sql .= "WHERE siteid = '" . $this->siteid . "' AND partype ='" . $this->partype . "' AND doli_id = '" . $this->doli_id . "'";

			dol_syslog("E_params.class.php::verif_param $sql", LOG_DEBUG);

			$resql = $this->db->query($sql);
			if ($resql) {
				$num = $this->db->num_rows($resql);
				if ($num > 0) {
					$obj = $this->db->fetch_object($resql);
					$num = $obj->rowid;
				}
			}
			else $num = 0;
		}
		elseif ($this->partype == 'manufacturer') {
			$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "ecom_manufacturer ";
			$sql .= "WHERE siteid = '" . $this->siteid . "' AND ecom_manufacturer = '" . $this->ecom_id . "' AND manutype = '0'";

			dol_syslog("E_params.class.php::verif_param $sql", LOG_DEBUG);

			$resql = $this->db->query($sql);
			if ($resql) $num = $this->db->num_rows($resql);
			else $num = 0;
		}
		elseif ($this->partype == 'supplier') {
			$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "ecom_manufacturer ";
			$sql .= "WHERE siteid = '" . $this->siteid . "' AND ecom_manufacturer = '" . $this->ecom_id . "' AND manutype = '1'";

			dol_syslog("E_params.class.php::verif_param $sql", LOG_DEBUG);

			$resql = $this->db->query($sql);
			if ($resql) $num = $this->db->num_rows($resql);
			else $num = 0;
		}
		elseif ($this->partype == "typecli") {
			// test en dehors de ecom_params
			$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "ecom_customer_type ";
			$sql .= " WHERE siteid = '" . $this->siteid . "' AND ecom_id = '" . $this->ecom_id . "'";
			dol_syslog("E_params.class.php::verif_param $sql", LOG_DEBUG);

			$resql = $this->db->query($sql);
			if ($resql) $num = $this->db->num_rows($resql);
			else $num = 0;
		}
		else {
			$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "ecom_params ";
			$sql .= "WHERE siteid = '" . $this->siteid . "' AND partype ='" . $this->partype . "' AND ecom_id = '" . $this->ecom_id . "'";

			dol_syslog("E_params.class.php::verif_param $sql", LOG_DEBUG);

			$resql = $this->db->query($sql);
			if ($resql) $num = $this->db->num_rows($resql);
			else $num = 0;
		}

		return $num;

	}

// Méthodes de gestion des paramètres
//Lit les taxes dans prestashop et les copie dans llx_ecom_params

	function get_taxrates()
	{
		global $conf, $langs;
		// appel du webservice
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		$client = new nusoap_client($this->site->site_ws_url . "/ws_params.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
		$parameters = array();

		$obj = $client->call("get_taxes", $parameters);

		if ($client->fault) {
			$this->error = 'Erreur Webservice ' . $client->getError();
			dol_syslog("E_params::get_taxrates " . $this->error, LOG_ERR);
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if (!is_array($obj)) {
				$this->error = 'pas de résultats taxes ';
				dol_syslog("E_params::get_taxrates " . $this->error, LOG_WARNING);
				return -1;
			}

			$this->tx = 'taxes ';
			$par = new Ecom_params($this->db);
			for ($i = 0; $i < sizeof($obj); $i++) {
				$this->tx .= $obj[$i]["partype"] . " " . $obj[$i]["tax_class_id"] . " " . $obj[$i]["tax_class_title"];
				$par->siteid = $this->siteid;
				$par->partype = mb_convert_encoding($obj[$i]["partype"], 'UTF-8', mb_detect_encoding($obj[$i]["partype"]));
				$par->ecom_id = $obj[$i]["tax_class_id"];
				$conv=mb_detect_encoding($obj[$i]["tax_class_title"]);
				$par->ecom_lib = !empty($conv)?mb_convert_encoding($obj[$i]["tax_class_title"], 'UTF-8', $conv):$obj[$i]["tax_class_title"];
				$par->doli_id = '0';

				$this->ecom_id = $par->ecom_id;
				$this->partype = $par->partype;
				if ($this->verif_param() == 0) {
					if ($par->create($this->user) < 0) {
                        $this->error .= "Erreur create params " . $obj[$i]["tax_class_title"];
                        setEventMessage($this->error , 'warnings');
                    }
					$this->tx .= "<br/>";
				}
			}
		}
		else {
			$this->error = 'Erreur ' . $err;
			return -1;
		}
		return 1;
	}

	//???????????????
	function get_orderstatus()
	{
		global $conf, $langs;
		// appel du webservice
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		$client = new nusoap_client($this->site->site_ws_url . "/ws_params.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
		$parameters = array("lg_id" => '4');

		$obj = $client->call("get_orderstatus", $parameters);

		if ($client->fault) {
			$this->error = "Fault detected " . $client->getError();
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if (!is_array($obj)) {
				$this->tx = 'pas de résultats order_status ';
				return -1;
			}

			$this->tx = 'order status ';
			$par = new Ecom_params($this->db);
			for ($i = 0; $i < sizeof($obj); $i++) {
				$this->tx .= $obj[$i]["partype"] . " " . $obj[$i]["orders_status_id"] . " " . $obj[$i]["orders_status_name"];
				$par->siteid = $this->siteid;
				$par->partype = mb_convert_encoding($obj[$i]["partype"], 'UTF-8', mb_detect_encoding($obj[$i]["partype"]));
				$par->ecom_id = $obj[$i]["orders_status_id"];
				$par->ecom_lib = mb_convert_encoding($obj[$i]["orders_status_name"], 'UTF-8', mb_detect_encoding($obj[$i]["orders_status_name"]));
				$par->doli_id = '0';

				$this->ecom_id = $par->ecom_id;
				$this->partype = $par->partype;
				if ($this->verif_param() == 0) {
					if ($par->create($this->user) < 0) {
                        $this->error .= "Erreur create params " . $obj[$i]["tax_class_title"];
                        setEventMessage($this->error , 'warnings');
                    }
					$this->tx .= "<br/>";
				}
			}
		}
		else {
			$this->error = 'Erreur ' . $err;
			return -1;
		}
		return 1;
	}

// manufacturers
	function get_manufacturers()
	{
		global $conf, $langs;
		// appel du webservice
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		$client = new nusoap_client($this->site->site_ws_url . "/ws_params.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
		$parameters = array();

		$obj = $client->call("get_manufacturers", $parameters);

		if ($client->fault) {
			$this->error = "Fault detected " . $client->getError();
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if (!is_array($obj)) {
				$this->tx = 'pas de résultats order_status ';
				return -1;
			}

			$this->tx = 'manufacturer ';
			$par = new Ecom_manufacturer($this->db);
			for ($i = 0; $i < count($obj); $i++) {
				$par->siteid = $this->siteid;
				$par->ecom_manufacturer = $obj[$i]["manufacturers_id"];
				$par->manutype = '0';
				$par->ecom_manuname = mb_convert_encoding($obj[$i]["manufacturers_name"], 'UTF-8', mb_detect_encoding($obj[$i]["manufacturers_name"]));
				$par->doli_manufacturer = '0';

				$this->ecom_id = $par->ecom_manufacturer;
				$this->partype = 'manufacturer';
				if ($this->verif_param() == 0) {
					if ($par->create($this->user) < 0) {
                        $this->error .= "Erreur create params " . $obj[$i]["manufacturers_name"];
                        setEventMessage($this->error , 'warnings');
                    }
					$this->tx .= "<br/>";
				}
			}
		}
		else {
			$this->error = 'Erreur ' . $err;
			return -1;
		}
		return 1;
	}

	function get_suppliers()
	{
		global $conf, $langs;
		// appel du webservice
		//set_magic_quotes_runtime(0);
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		$client = new nusoap_client($this->site->site_ws_url . "/ws_params.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
		$parameters = array();

		$obj = $client->call("get_suppliers", $parameters);

		if ($client->fault) {
			$this->error = "Fault detected " . $client->getError();
			$msg = $this->error;
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if (!is_array($obj)) {
				$this->tx = 'pas de résultats suppliers ';
				return -1;
			}

			$this->tx = 'supplier ';
			$par = new Ecom_manufacturer($this->db);
			for ($i = 0; $i < sizeof($obj); $i++) {
				$par->siteid = $this->siteid;
				$par->ecom_manufacturer = $obj[$i]["supplier_id"];
				$par->manutype = '1';
				$par->ecom_manuname = mb_convert_encoding($obj[$i]["supplier_name"], 'UTF-8', mb_detect_encoding($obj[$i]["supplier_name"]));
				$par->doli_manufacturer = '0';

				$this->ecom_id = $par->ecom_manufacturer;
				$this->partype = 'supplier';
				if ($this->verif_param() == 0) {
					if ($par->create($this->user) < 0) {
                        $this->error .= "Erreur create params " . $obj[$i]["supplier_name"];
                        setEventMessage($this->error , 'warnings');
                    }
					$this->tx .= "<br/>";
				}
			}
		}
		else {
			$this->error = 'Erreur ' . $err;
			return -1;
		}
		return 1;
	}


	function get_products_option()
	{
		global $conf, $langs;
		// appel du webservice
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		$client = new nusoap_client($this->site->site_ws_url . "/ws_params.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
		$parameters = array();

		$obj = $client->call("get_product_options", $parameters);

		if ($client->fault) {
			$this->error = "Fault detected " . $client->getError();
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if (!is_array($obj)) {
				$this->tx = 'pas de resultats product_options ';
				return -1;
			}
			$this->tx = 'products_options ';
			$par = new Ecom_params($this->db);
			for ($i = 0; $i < count($obj); $i++) {
				$this->tx .= $obj[$i]["partype"] . " " . $obj[$i]["products_options_id"] . " " . $obj[$i]["products_options_name"];
				$par->siteid = $this->siteid;
				$par->partype = mb_convert_encoding($obj[$i]["partype"], 'UTF-8', mb_detect_encoding($obj[$i]["partype"]));
				$par->ecom_id = $obj[$i]["products_options_id"];
				$par->ecom_lib = mb_convert_encoding($obj[$i]["products_options_name"], 'UTF-8', mb_detect_encoding($obj[$i]["products_options_name"]));
				$par->doli_id = '0';

				$this->ecom_id = $par->ecom_id;
				$this->partype = $par->partype;
				if ($this->verif_param() == 0) {
					if ($par->create($this->user) < 0) {
                        $this->error .= "Erreur create params " . $obj[$i]["tax_class_title"];
                        setEventMessage($this->error , 'warnings');
                    }
					$this->tx .= "<br/>";
				}
			}
		}
		else {
			$this->error = 'Erreur ' . $err;
			return -1;
		}
		return 1;
	}

	function get_products_optionvals()
	{
		global $conf, $langs;
		// appel du webservice
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		$client = new nusoap_client($this->site->site_ws_url . "/ws_params.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
		$parameters = array();

		$obj = $client->call("get_product_optionsvals", $parameters);

		if ($client->fault) {
			$this->error = "Fault detected " . $client->getError();
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if (!is_array($obj)) {
				$this->tx = 'pas de résultat option_values';
				return -1;
			}
			$this->tx = 'product options vals ';
			$par = new Ecom_params($this->db);
			for ($i = 0; $i < count($obj); $i++) {
				$this->tx .= $obj[$i]["partype"] . " " . $obj[$i]["products_options_values_id"] . " " . $obj[$i]["products_options_values_name"];
				$par->siteid = $this->siteid;
				$par->partype = mb_convert_encoding($obj[$i]["partype"], 'UTF-8', mb_detect_encoding($obj[$i]["partype"]));
				$par->ecom_id = $obj[$i]["products_options_values_id"];
				$par->ecom_lib = mb_convert_encoding($obj[$i]["products_options_values_name"], 'UTF-8', mb_detect_encoding($obj[$i]["products_options_values_name"]));
				$par->doli_id = '0';

				$this->ecom_id = $par->ecom_id;
				$this->partype = $par->partype;
				if ($this->verif_param() == 0) {
					if ($par->create($this->user) < 0) {
                        $this->error .= "Erreur create params " . $obj[$i]["tax_class_title"];
                        setEventMessage($this->error , 'warnings');

                    }
					$this->tx .= "<br/>";
				}
			}
		}
		else {
			$this->error = 'Erreur ' . $err;
			return -1;
		}
		return 1;
	}

	/**
	 *
	 * @return number
	 */
	function get_customers_type()
	{
		global $conf, $langs;
		// on se connecte pour récupérer les infos sur le site

		$soap_client = new webservice_ecom($this->site->site_ws_url, 'ws_params.php');
		$p = array();
		$soap_client->ws_call('get_customers_type', $p);

		//TODO test résultats
		if (!$soap_client->resko) {
			//traitement du résultat
			$typecli = new Ecom_customer_type($this->db);
			foreach ($soap_client->ws_data as $param) {
				$typecli->siteid = $this->siteid;
				$typecli->ecom_id = $param["id_group"];
				$typecli->ecom_lib = $param["name"];
				$typecli->datem = dol_now();
				$typecli->doli_cat_id = 0;
				$typecli->doli_tarif_id = 0;
				$typecli->doli_typent_id = 0;

				$this->ecom_id = $typecli->ecom_id;
				$this->partype = "typecli";
				if ($this->verif_param() == 0) {
					if ($typecli->create($this->user) < 0) {
                        $this->error .= "erreur création type client " . print_r($param, true);
                        setEventMessage($this->error , 'warnings');
                    }
					//	dol_syslog("E_params:get_customers_type ".print_r($typecli, true), LOG_DEBUG);
				}
			}
		}
		else {
			//erreur
			dol_syslog("E_params:get_customers_type " . $soap_client->error);
			$this->error = $soap_client->error;
			return -1;
		}

		return 1;
	}

	// la liste des methodes d'expedition
	function get_expedition_meths()
	{
		global $conf, $langs;
		// appel du webservice
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		$client = new nusoap_client($this->site->site_ws_url . "/ws_params.php". (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
		$parameters = array();

		$obj = $client->call("get_methodes_exped", $parameters);

		if ($client->fault) {
			$this->error = "Fault detected " . $client->getError();
			return -1;
		}
		elseif (!($err = $client->getError())) {
			if (!is_array($obj)) {
				$this->tx = 'pas de résultats expéditions ';
				return -1;
			}
			$this->tx = 'Expeditions ';
			dol_syslog("E_params::get_Expedition_meths " . $this->tx, LOG_DEBUG);
			$par = new Ecom_params($this->db);
			for ($i = 0; $i < count($obj); $i++) {
				$this->tx .= $obj[$i]["partype"] . " " . $obj[$i]["id_carrier"] . " " . $obj[$i]["name"];
				$par->siteid = $this->siteid;
				$par->partype = mb_convert_encoding($obj[$i]["partype"], 'UTF-8', mb_detect_encoding($obj[$i]["partype"]));
				$par->ecom_id = $obj[$i]["id_carrier"];
				$par->ecom_lib = mb_convert_encoding($obj[$i]["name"], 'UTF-8', mb_detect_encoding($obj[$i]["name"]));
				$par->doli_id = '0';

				$this->ecom_id = $par->ecom_id;
				$this->partype = $par->partype;
				if ($this->verif_param() == 0) {
					if ($par->create($this->user) < 0) {
                        $this->error .= "Erreur create params " . $obj[$i]["tax_class_title"];
                        setEventMessage($this->error , 'warnings');
                    }
					$this->tx .= "<br/>";
				}
			}
		}
		else {
			$this->error = 'Erreur ' . $err;
			return -1;
		}
		return 1;
	}

	/**
	 *
	 * get product features list
	 */
	function get_product_features()
	{
		global $conf, $langs;
		// on se connecte pour récupérer les infos sur le site

		$soap_client = new webservice_ecom($this->site->site_ws_url, 'ws_params.php');
		$p = array();
		$soap_client->ws_call('get_product_features', $p);

		//TODO test résultats
		if (!$soap_client->resko) {
			//traitement du résultat
			$par = new Ecom_params($this->db);
			foreach ($soap_client->ws_data as $param) {
				dol_syslog("E_params::get_product_features " . print_r($param, true), LOG_DEBUG);
				$par->siteid = $this->siteid;
				$par->partype = mb_convert_encoding($param["partype"], 'UTF-8', mb_detect_encoding($param["partype"]));
				$par->ecom_id = $param["id_feature"];
				$par->ecom_lib = mb_convert_encoding($param["name"], 'UTF-8', mb_detect_encoding($param["name"]));
				$par->doli_id = '0';

				$this->ecom_id = $par->ecom_id;
				$this->partype = $par->partype;
				if ($this->verif_param() == 0) {
					if ($par->create($this->user) < 0) {
                        $this->error .= "Erreur create params " . $param["name"];
                        setEventMessage($this->error , 'warnings');
                    }
					$this->tx .= "<br/>";
				}
			}
		}
		else {
			//erreur
			dol_syslog("E_params::get_product_features " . $soap_client->error);
			$this->error = $soap_client->error;
			return -1;
		}

		return 1;
	}

	// renvoie l'id dolibarr correspondant à un id ecommerce pour l'id du type donné
	function ecom2dolibarr($ecom_id, $type)
	{

		$sql = "SELECT doli_id FROM " . MAIN_DB_PREFIX . "ecom_params ";
		$sql .= "WHERE siteid = '" . $this->siteid . "' AND partype ='" . $type . "' AND ecom_id = '" . $ecom_id . "'";

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			if ($num > 0) {
				$obj = $this->db->fetch_object($resql);
				$doli_id = $obj->doli_id;
			}
			else $doli_id = 0;
		}
		else $doli_id = 0;

		return $doli_id;
	}


	/**
	 * get dolibarr supplier from ecom id
	 *
	 * @param int $ecom_id
	 * @return number
	 */
	function ecom2doli_supplier($ecom_id)
	{
		$sql = "SELECT doli_manufacturer FROM " . MAIN_DB_PREFIX . "ecom_manufacturer ";
		$sql .= "WHERE siteid = '" . $this->siteid . "' AND manutype ='1' AND ecom_manufacturer = '" . $ecom_id . "'";

		dol_syslog(basename(__FILE__) . "::" . __METHOD__ . " sql $sql", LOG_DEBUG);

		$resql = $this->db->query($sql);

		if ($resql) {
			$num = $this->db->num_rows($resql);
			if ($num > 0) {
				$obj = $this->db->fetch_object($resql);
				$doli_id = $obj->doli_manufacturer;
			}
			else $doli_id = 0;
		}
		else $doli_id = 0;

		return $doli_id;

	}

	// renvoie l'id ecom correspondant a un id dolibarr pour l'id du type donne
	function dolibarr2ecom($doli_id, $type)
	{

		$sql = "SELECT ecom_id FROM " . MAIN_DB_PREFIX . "ecom_params ";
		$sql .= "WHERE siteid = '" . $this->siteid . "' AND partype ='" . $type . "' AND doli_id = '" . $doli_id . "'";
		dol_syslog("E_params : dolibarr2ecom " . $sql, LOG_DEBUG);

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			if ($num > 0) {
				$obj = $this->db->fetch_object($resql);
				$ecom_id = $obj->ecom_id;
			}
			else $ecom_id = 0;
		}
		else $ecom_id = 0;

		return $ecom_id;
	}

	function set_localorderstatus($doli_ordstat)
	{
		$error = 0;
		$this->partype = 'ecomstat';
		dol_syslog(__FILE__ . "::" . __FUNCTION__ . "  " . print_r($doli_ordstat, true), LOG_DEBUG);
		foreach ($doli_ordstat as $key => $value) {
			dol_syslog(__FILE__ . "::" . __FUNCTION__ . "  " . "key= " . $key . " value= " . $value, LOG_DEBUG);
			$this->doli_id = $key;
			$this->ecom_lib = $value;
			$row = $this->verif_param();
			if ($row > 0) {
				$this->fetch($row);
				$this->ecom_lib = $value;
				$this->update($this->user);
				dol_syslog("E_params.class.php::update " . $this->ecom_lib, LOG_DEBUG);
			}
			else {
				$this->ecom_id = '';
				$this->create($this->user);
				dol_syslog("E_params.class.php::insert " . $this->ecom_lib, LOG_DEBUG);
			}

		}
		return ($error) ? -1 : 1;
	}


// delete a site and all its parameters
	function delete_site($siteid)
	{
		$error = 0;
		$this->db->begin();

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_params WHERE siteid ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_categories WHERE siteid ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_customer WHERE siteid ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_contact WHERE siteid ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		/*	$sql = "DELETE FROM ".MAIN_DB_PREFIX."ecom_customer_type WHERE siteid ='".$siteid."'";
			if ( ! $error) {
				$resql=$this->db->query($sql);
				if ( ! $resql)
				{
					$error ++;
					dol_syslog(get_class($this)."::delete error sql=".$sql, LOG_ERR);
				}
			}
		*/
		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_log WHERE site_id ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_manufacturer WHERE siteid ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_order WHERE siteid ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_product WHERE siteid ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_site WHERE rowid ='" . $siteid . "'";
		if (!$error) {
			$resql = $this->db->query($sql);
			if (!$resql) {
				$error++;
				dol_syslog(get_class($this) . "::delete error sql=" . $sql, LOG_ERR);
			}
		}

		if ($error) {
			$this->db->rollback();
			return -1;
		}

		$this->db->commit();
		return 1;

	}
}

