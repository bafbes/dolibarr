<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2011-2013 Jean Heimburger	<jean@tiaris.info>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       htdocs/ecommerce/class/webservice_ecom.class.php
 *      \ingroup    ecommerce
 *      \brief      general webservice client
 *        \version    $Id: webservice_ecom.class.php,v 1.3 2011-11-24 10:36:01 tiaris Exp $
 *        \author        Jean Heimburger
 *        \remarks    initial version on 2011-10-05 14:13
 */
class webservice_ecom
{
	var $ws_url; // base url of web services
	var $ws_file; // ws file
	var $ws_service; // service to call
	var $ws_parameters = array();

	var $ws_client;
	var $ws_type = ''; //''=simple soap client, 'MIME' for mime client
	var $ws_result = array();  // result of execution
	var $ws_data = array(); // datas from execution

	var $resko = 0; //0 = OK -1 = KO
	var $error;

	function webservice_ecom($url, $file, $mime = '')
	{
		global $conf, $langs;

		$this->ws_url = $url;
		$this->ws_file = $file;

		if (!isset($conf->global->ECOMMERCE_NUSOAPPATH)) {
			dol_syslog(basename(__FILE__) . " :: " . __FUNCTION__ . "Chemin vers nusoap non défini " . print_r($conf->global, true), LOG_ERR);
			return -1;
		}
		//WebService Client.

		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
		dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoapmime.php");

		// Set the WebService URL
		if ($mime == 'MIME') {
			$this->ws_client = new nusoap_client_mime($url . "/" . $file. (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
			dol_syslog(__FILE__ . " :: " . __FUNCTION__ . " nusoap mime", LOG_DEBUG);
			$this->ws_type = 'MIME';
		}
		else {
			$this->ws_client = new nusoap_client($url . "/" . $file. (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
			dol_syslog(__FILE__ . " :: " . __FUNCTION__ . " nusoap ", LOG_DEBUG);
		}

		if (!$this->ws_client) {
			dol_syslog(__FILE__ . " :: " . __FUNCTION__ . " : webservice not instantiated", LOG_ERR);
			return -1;
		}
		return 1;
	}

	function ws_call($service, $parameters)
	{
		$this->ws_parameters = $parameters;
		$this->ws_service = $service;
		$this->resko = 0;
		dol_syslog(__FILE__ . " : webservice call " . $this->ws_url . $this->ws_file . " method " . $this->ws_service . " with " . print_r($this->ws_parameters, true), LOG_DEBUG);
		$obj = $this->ws_client->call($this->ws_service, $this->ws_parameters);
		if ($this->ws_client->fault) {
			$this->error = "Fault detected " . $this->ws_client->getError();
			dol_syslog(__FILE__ . " :: " . __FUNCTION__ . " : webservice Soap Error " . $this->error, LOG_ERR);
			return -1;
		}
		else {
			$err = $this->ws_client->getError();
			if ($err) {
				$this->error = 'Web Service error ' . $err;
				dol_syslog(__FILE__ . " :: " . __FUNCTION__ . " : webservice error " . $err, LOG_ERR);
				return -1;
			}
			else {
				// execution result
				$this->ws_result = $obj["result"];
				$this->resko = $this->ws_result["code"];
				$this->ws_data = $obj["data"];
				if ($this->resko) $this->error .= (($this->error) ? ' - ' : '') . $this->ws_result["message"];
				dol_syslog(__FILE__ . " : webservice call " . $service . " result " . print_r($obj, true), LOG_DEBUG);
			}
		}
		return 1;
	}

	/*
	 * Adds attachemements to a soap client
	 * must be a mime client
	 * $type : ''
	 * $file : file to add
	 */
	function addAttachment($type, $file)
	{
		if ($this->ws_type != 'MIME') {
			$this->error = 'addAttachment only for mime type webservices';
			dol_syslog(__FILE__ . " :: " . __FUNCTION__ . " :  " . $this->error, LOG_ERR);
			return -1;
		}
		if (!file_exists($file)) {
			$this->error = 'file not found ' . $file;
			dol_syslog(__FILE__ . " :: " . __FUNCTION__ . " :  " . $this->error, LOG_ERR);
			return -1;
		}

		if (!$type) $type = '';

		$cid = $this->ws_client->addAttachment($type, $file);
		//TODO error test ?
		dol_syslog(__FILE__ . " :: " . __FUNCTION__ . " :  " . $cid, LOG_DEBUG);

		return 1;
	}
}


