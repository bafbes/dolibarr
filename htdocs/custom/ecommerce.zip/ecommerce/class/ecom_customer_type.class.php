<?php
/* Copyright (C) 2007-2011 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *      \file       dev/skeletons/ecom_customer_type.class.php
 *      \ingroup    mymodule othermodule1 othermodule2
 *      \brief      This file is an example for a CRUD class file (Create/Read/Update/Delete)
 *        \version    $Id: ecom_customer_type.class.php,v 1.32 2011/07/31 22:21:58 eldy Exp $
 *        \author        Put author name here
 *        \remarks    Initialy built by build_class_from_table on 2013-07-02 10:02
 */

// Put here all includes required by your class file
//require_once(DOL_DOCUMENT_ROOT."/core/class/commonobject.class.php");
//require_once(DOL_DOCUMENT_ROOT."/societe/class/societe.class.php");
//require_once(DOL_DOCUMENT_ROOT."/product/class/product.class.php");


/**
 *      \class      Ecom_customer_type
 *      \brief      Put here description of your class
 *        \remarks    Initialy built by build_class_from_table on 2013-07-02 10:02
 */
class Ecom_customer_type // extends CommonObject
{
	var $db;                            //!< To store db handler
	var $error;                            //!< To return error code (or message)
	var $errors = array();                //!< To return several error codes (or messages)
	//var $element='ecom_customer_type';			//!< Id that identify managed objects
	//var $table_element='ecom_customer_type';	//!< Name of table without prefix where object is stored

	var $id;

	var $siteid;
	var $ecom_id;
	var $ecom_lib;
	var $doli_cat_id;
	var $doli_typent_id;
	var $doli_tarif_id;
	var $datem = '';


	/**
	 *      Constructor
	 * @param DB      Database handler
	 */
	function Ecom_customer_type($DB)
	{
		$this->db = $DB;
		return 1;
	}


	/**
	 *      Create object into database
	 * @param user            User that create
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, Id of created object if OK
	 */
	function create($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->ecom_id)) $this->ecom_id = trim($this->ecom_id);
		if (isset($this->ecom_lib)) $this->ecom_lib = trim($this->ecom_lib);
		if (isset($this->doli_cat_id)) $this->doli_cat_id = trim($this->doli_cat_id);
		if (isset($this->doli_typent_id)) $this->doli_typent_id = trim($this->doli_typent_id);
		if (isset($this->doli_tarif_id)) $this->doli_tarif_id = trim($this->doli_tarif_id);


		// Check parameters
		// Put here code to add control on parameters values

		// Insert request
		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_customer_type(";

		$sql .= "siteid,";
		$sql .= "ecom_id,";
		$sql .= "ecom_lib,";
		$sql .= "doli_cat_id,";
		$sql .= "doli_typent_id,";
		$sql .= "doli_tarif_id,";
		$sql .= "datem";


		$sql .= ") VALUES (";

		$sql .= " " . (!isset($this->siteid) ? 'NULL' : "'" . $this->siteid . "'") . ",";
		$sql .= " " . (!isset($this->ecom_id) ? 'NULL' : "'" . $this->ecom_id . "'") . ",";
		$sql .= " " . (!isset($this->ecom_lib) ? 'NULL' : "'" . $this->db->escape($this->ecom_lib) . "'") . ",";
		$sql .= " " . (!isset($this->doli_cat_id) ? 'NULL' : "'" . $this->doli_cat_id . "'") . ",";
		$sql .= " " . (!isset($this->doli_typent_id) ? 'NULL' : "'" . $this->doli_typent_id . "'") . ",";
		$sql .= " " . (!isset($this->doli_tarif_id) ? 'NULL' : "'" . $this->doli_tarif_id . "'") . ",";
		$sql .= " " . (!isset($this->datem) || dol_strlen($this->datem) == 0 ? 'NULL' : "'".$this->db->idate($this->datem)) . "'";


		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_customer_type");

			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_CREATE',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}


	/**
	 *    Load object in memory from database
	 * @param id          id object
	 * @return     int         <0 if KO, >0 if OK
	 */
	function fetch($id)
	{
		global $langs;
		$sql = "SELECT";
		$sql .= " t.rowid,";

		$sql .= " t.siteid,";
		$sql .= " t.ecom_id,";
		$sql .= " t.ecom_lib,";
		$sql .= " t.doli_cat_id,";
		$sql .= " t.doli_typent_id,";
		$sql .= " t.doli_tarif_id,";
		$sql .= " t.datem";


		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_customer_type as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;

				$this->siteid = $obj->siteid;
				$this->ecom_id = $obj->ecom_id;
				$this->ecom_lib = $obj->ecom_lib;
				$this->doli_cat_id = $obj->doli_cat_id;
				$this->doli_typent_id = $obj->doli_typent_id;
				$this->doli_tarif_id = $obj->doli_tarif_id;
				$this->datem = $this->db->jdate($obj->datem);


			}
			$this->db->free($resql);

			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 *      Update object into database
	 * @param user            User that modify
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return     int            <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->ecom_id)) $this->ecom_id = trim($this->ecom_id);
		if (isset($this->ecom_lib)) $this->ecom_lib = trim($this->ecom_lib);
		if (isset($this->doli_cat_id)) $this->doli_cat_id = trim($this->doli_cat_id);
		if (isset($this->doli_typent_id)) $this->doli_typent_id = trim($this->doli_typent_id);
		if (isset($this->doli_tarif_id)) $this->doli_tarif_id = trim($this->doli_tarif_id);


		// Check parameters
		// Put here code to add control on parameters values

		// Update request
		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_customer_type SET";

		$sql .= " siteid=" . (isset($this->siteid) ? $this->siteid : "null") . ",";
		$sql .= " ecom_id=" . (isset($this->ecom_id) ? $this->ecom_id : "null") . ",";
		$sql .= " ecom_lib=" . (isset($this->ecom_lib) ? "'" . $this->db->escape($this->ecom_lib) . "'" : "null") . ",";
		$sql .= " doli_cat_id=" . (isset($this->doli_cat_id) ? $this->doli_cat_id : "null") . ",";
		$sql .= " doli_typent_id=" . (isset($this->doli_typent_id) ? $this->doli_typent_id : "null") . ",";
		$sql .= " doli_tarif_id=" . (isset($this->doli_tarif_id) ? $this->doli_tarif_id : "null") . ",";
		$sql .= " datem=" . (dol_strlen($this->datem) != 0 ? "'" . $this->db->idate($this->datem) . "'" : 'null') . "'";


		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_MODIFY',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *   Delete object in database
	 * @param user            User that delete
	 * @param notrigger        0=launch triggers after, 1=disable triggers
	 * @return    int                <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_customer_type";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::delete sql=" . $sql);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {
				// Uncomment this and change MYOBJECT to your own tag if you
				// want this action call a trigger.

				//// Call triggers
				//include_once(DOL_DOCUMENT_ROOT . "/core/class/interfaces.class.php");
				//$interface=new Interfaces($this->db);
				//$result=$interface->run_triggers('MYOBJECT_DELETE',$this,$user,$langs,$conf);
				//if ($result < 0) { $error++; $this->errors=$interface->errors; }
				//// End call triggers
			}
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *        Load an object from its id and create a new one in database
	 * @param fromid            Id of object to clone
	 * @return        int                New id of clone
	 */
	function createFromClone($fromid)
	{
		global $user, $langs;

		$error = 0;

		$object = new Ecom_customer_type($this->db);

		$this->db->begin();

		// Load source object
		$object->fetch($fromid);
		$object->id = 0;
		$object->statut = 0;

		// Clear fields
		// ...

		// Create clone
		$result = $object->create($user);

		// Other options
		if ($result < 0) {
			$this->error = $object->error;
			$error++;
		}

		if (!$error) {


		}

		// End
		if (!$error) {
			$this->db->commit();
			return $object->id;
		}
		else {
			$this->db->rollback();
			return -1;
		}
	}


	/**
	 *        Initialisz object with example values
	 *        Id must be 0 if object instance is a specimen.
	 */
	function initAsSpecimen()
	{
		$this->id = 0;

		$this->siteid = '';
		$this->ecom_id = '';
		$this->ecom_lib = '';
		$this->doli_cat_id = '';
		$this->doli_typent_id = '';
		$this->doli_tarif_id = '';
		$this->datem = '';


	}

}


