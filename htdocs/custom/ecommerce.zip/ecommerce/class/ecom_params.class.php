<?php
/* Copyright (C) 2007-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010      Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013 Philippe Grand  		<philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *      \file       htdocs/ecommerce/class/ecom_params.class.php
 *      \ingroup    products
 *        \author        Jean Heimburger - http://www.tiaris.fr
 */

/**
 *      \class      Ecom_params
 *      \brief      Params class for e-commerce site
 */
class Ecom_params extends CommonObject
{
	var $id;

	var $siteid;
	var $partype;
	var $ecom_id;
	var $ecom_lib;
	var $doli_id;


	/**
	 *  Constructor
	 *
	 * @param DoliDb $db Database handler
	 */
	function __construct($db)
	{
		$this->db = $db;
		return 1;
	}


	/**
	 *      Create in database
	 * @param user     User that create
	 * @return     int      <0 si ko, >0 si ok
	 */
	function create($user)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->partype)) $this->partype = trim($this->partype);
		if (isset($this->ecom_id)) $this->ecom_id = trim($this->ecom_id);
		if (isset($this->ecom_lib)) $this->ecom_lib = trim($this->ecom_lib);
		if (isset($this->doli_id)) $this->doli_id = trim($this->doli_id);


		// Insert request

		$sql = "INSERT INTO " . MAIN_DB_PREFIX . "ecom_params(";
		$sql .= " siteid,";
		$sql .= " partype,";
		$sql .= " ecom_id,";
		$sql .= " ecom_lib,";
		$sql .= " doli_id";


		$sql .= ") VALUES (";
		$sql .= " " . (!isset($this->siteid) ? 'NULL' : "'" . $this->siteid . "'") . ",";
		$sql .= " " . (!isset($this->partype) ? 'NULL' : "'" . $this->db->escape($this->partype) . "'") . ",";
		$sql .= " " . (!isset($this->ecom_id) ? 'NULL' : "'" . $this->ecom_id . "'") . ",";
		$sql .= " " . (!isset($this->ecom_lib) ? 'NULL' : "'" . $this->db->escape($this->ecom_lib) . "'") . ",";
		$sql .= " " . (!isset($this->doli_id) ? 'NULL' : "'" . $this->doli_id . "'") . "";
		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this) . "::create sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX . "ecom_params");

			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::create " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return $this->id;
		}
	}

	/**
	 *      Update database
	 * @param user            User that modify
	 * @param notrigger        0=no, 1=yes (no update trigger)
	 * @return     int            <0 if KO, >0 if OK
	 */
	function update($user = 0, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		// Clean parameters

		if (isset($this->siteid)) $this->siteid = trim($this->siteid);
		if (isset($this->partype)) $this->partype = trim($this->partype);
		if (isset($this->ecom_id)) $this->ecom_id = trim($this->ecom_id);
		if (isset($this->ecom_lib)) $this->ecom_lib = trim($this->ecom_lib);
		if (isset($this->doli_id)) $this->doli_id = trim($this->doli_id);


		// Update request

		$sql = "UPDATE " . MAIN_DB_PREFIX . "ecom_params SET";
		$sql .= " siteid='" . $this->siteid . "',";
		$sql .= " partype='" . $this->db->escape($this->partype) . "',";
		$sql .= " ecom_id='" . $this->ecom_id . "',";
		$sql .= " ecom_lib='" . $this->db->escape($this->ecom_lib) . "',";
		$sql .= " doli_id='" . $this->doli_id . "'";
		$sql .= " WHERE rowid=" . $this->id;

		dol_syslog(get_class($this) . "::update sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::update " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *    Load object in memory from database
	 * @param id          id object
	 * @param user        User that load
	 * @return     int         <0 if KO, >0 if OK
	 */
	function fetch($id, $user = 0)
	{
		global $langs;
		$sql = "SELECT";
		$sql .= " t.rowid,";
		$sql .= " t.siteid,";
		$sql .= " t.partype,";
		$sql .= " t.ecom_id,";
		$sql .= " t.ecom_lib,";
		$sql .= " t.doli_id";

		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_params as t";
		$sql .= " WHERE t.rowid = " . $id;

		dol_syslog(get_class($this) . "::fetch sql=" . $sql, LOG_DEBUG);
		$resql = $this->db->query($sql);
		if ($resql) {
			if ($this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);

				$this->id = $obj->rowid;
				$this->siteid = $obj->siteid;
				$this->partype = $obj->partype;
				$this->ecom_id = $obj->ecom_id;
				$this->ecom_lib = $obj->ecom_lib;
				$this->doli_id = $obj->doli_id;


			}
			$this->db->free($resql);

			return 1;
		}
		else {
			$this->error = "Error " . $this->db->lasterror();
			dol_syslog(get_class($this) . "::fetch " . $this->error, LOG_ERR);
			return -1;
		}
	}


	/**
	 *   Delete object in database
	 * @param user     User that delete
	 * @return        int         <0 if KO, >0 if OK
	 */
	function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM " . MAIN_DB_PREFIX . "ecom_params";
		$sql .= " WHERE rowid=" . $this->id;

		$this->db->begin();

		dol_syslog(get_class($this) . "::delete sql=" . $sql);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++;
			$this->errors[] = "Error " . $this->db->lasterror();
		}

		if (!$error) {
			if (!$notrigger) {

			}
		}

		// Commit or rollback

		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this) . "::delete " . $errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', ' . $errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		}
		else {
			$this->db->commit();
			return 1;
		}
	}


	/**
	 *        Initialise object with example values
	 * @remarks   id must be 0 if object instance is a specimen.
	 */
	function initAsSpecimen()
	{
		$this->id = 0;
		$this->siteid = '';
		$this->partype = '';
		$this->ecom_id = '';
		$this->ecom_lib = '';
		$this->doli_id = '';

	}

}


