<?php
/* Copyright (C) 2007    	Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010-2011	Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013  Philippe Grand       <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013 	Juanjo Menent	     <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       htdocs/ecommerce/index.php
 *        \ingroup    ecommerce
 *        \brief      index page of ecommerce module
 */

require("./pre.inc.php");

//compatibilité
dol_include_once("/ecommerce/core/lib/ecommerce.lib.php");

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("other");
$langs->load("ecommerce@ecommerce");

// Get parameters
$socid = GETPOST('socid', 'int');
$siteid = isset($_GET["siteid"]) ? $_GET["siteid"] : '';

// Protection if external user
if ($user->societe_id) $socid = $user->societe_id;
$result = restrictedArea($user, 'societe', $socid);

$user->getrights('Ecommerce');
if (!$user->rights->Ecommerce->user) accessforbidden();


/* Datas  TODO*/

// boutiques
$tabboutiques = array();
$sql = "SELECT s.rowid AS siteid, s.site_name FROM " . MAIN_DB_PREFIX . "ecom_site AS s";
$sql .= " WHERE s.entity = " . $conf->entity;

$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;

	if ($num) {
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				$tabboutiques[$i]["id"] = $obj->siteid;
				$tabboutiques[$i]["name"] = $obj->site_name;
			}
			$i++;
		}
	}
}
else dol_syslog("Ecommerce index::erreur sql=" . $sql, LOG_DEBUG);

// last orders
$sql = "SELECT ec.ecom_order, ec.site_client_name, ec.site_order_date, ec.site_order_total_ht, ec.site_order_status, ec.doli_order ";
$sql .= " , es.site_name, es.rowid AS siteid, ep.doli_id";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order AS ec ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_site AS es ON es.rowid = ec.siteid ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "ecom_params AS ep ON ep.ecom_id = ec.site_order_status AND ep.partype = 'ordstat' AND ep.siteid = ec.siteid ";
$sql .= " WHERE es.entity = " . $conf->entity;

$sql .= " ORDER BY ec.site_order_date DESC ";
$sql .= " LIMIT 0,10";

$taborders = array();
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;
	if ($num) {
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				$taborders[$i]["ecom_order"] = $obj->ecom_order;
				$taborders[$i]["site_client_name"] = $obj->site_client_name;
				$taborders[$i]["site_order_date"] = $obj->site_order_date;
				$taborders[$i]["site_order_total_ht"] = $obj->site_order_total_ht;
				$taborders[$i]["site_order_status"] = $obj->doli_id;//$obj->site_order_status;
				$taborders[$i]["doli_order"] = $obj->doli_order;
				$taborders[$i]["siteid"] = $obj->siteid;
				$taborders[$i]["site_name"] = $obj->site_name;
			}
			$i++;
		}
	}
}
else dol_syslog("Ecommerce index sql commandes sql=" . $sql, LOG_DEBUG);

// CA global
$sql = "SELECT sum(eo.site_order_total_HT) AS CA, MONTH(eo.site_order_date) AS mois , YEAR(eo.site_order_date) AS an ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_order AS eo";
$sql .= " JOIN " . MAIN_DB_PREFIX . "commande AS c ON eo.doli_order = c.rowid ";
$sql .= " WHERE c.fk_statut > 0 "; // on ne compte que les commandes validées pour le CA
$sql .= " AND c.entity = " . $conf->entity;
$sql .= " GROUP BY an, mois ";
$sql .= " ORDER BY an desc, mois desc ";
$sql .= " limit 12";

$tabCA = array();
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;
	if ($num) {
		$var = true;
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			$var = !$var;
			if ($obj) {
				$tabCA[$i]["an"] = $obj->an;
				$tabCA[$i]["mois"] = $obj->mois;
				$tabCA[$i]["CA"] = $obj->CA;
			}
			$i++;
		}
	}
}
else dol_syslog("site_index CA sql=" . $sql, LOG_DEBUG);

// Products out of local stock
$sql = "SELECT cd.fk_product, p.ref, p.label, sum(cd.qty) qte_cde, ps.reel, eo.siteid, es.site_name ";
$sql .= " FROM " . MAIN_DB_PREFIX . "commandedet AS cd ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "commande AS c on c.rowid = cd.fk_commande AND c.fk_statut IN (1,2) ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "product AS p on p.rowid = cd.fk_product ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_order AS eo ON eo.doli_order = cd.fk_commande ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_site AS es ON es.rowid = eo.siteid ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "product_stock AS ps ON ps.fk_product = cd.fk_product AND ps.fk_entrepot = es.site_entrepot ";
$sql .= " WHERE es.entity = " . $conf->entity;

$sql .= " GROUP BY   cd.fk_product having qte_cde > ps.reel";

$taboutstock = array();
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;
	if ($num) {
		while ($i < $num) {
			$obj = $db->fetch_object($resql);

			if ($obj) {
				$taboutstock[$i]["fk_product"] = $obj->fk_product;
				$taboutstock[$i]["ref"] = $obj->ref;
				$taboutstock[$i]["label"] = $obj->label;
				$taboutstock[$i]["qte_cde"] = $obj->qte_cde;
				$taboutstock[$i]["reel"] = $obj->reel;
				$taboutstock[$i]["siteid"] = $obj->siteid;
				$taboutstock[$i]["site_name"] = $obj->site_name;
			}
			$i++;
		}
	}
}
else dol_syslog("Ecommerce index out of local stock sql=" . $sql, LOG_DEBUG);

//Products on ecommerce sites
$sql = "SELECT ep.ecom_product, ep.site_stock, ";
$sql .= " es.site_name, es.rowid AS siteid, ";
$sql .= " p.ref, p.label ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product AS ep ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_site AS es ON es.rowid = ep.siteid ";
$sql .= " LEFT OUTER JOIN " . MAIN_DB_PREFIX . "product AS p ON p.rowid = ep.doli_product ";
$sql .= " WHERE ep.site_stock <='0'  AND ep.site_status = '1' ";
$sql .= " AND es.entity = " . $conf->entity;
$sql .= " LIMIT 10 ";

$tabproduct = array();
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;
	if ($num) {
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				$tabproduct[$i]["ecom_product"] = $obj->ecom_product;
				$tabproduct[$i]["ref"] = $obj->ref;
				$tabproduct[$i]["label"] = $obj->label;
				$tabproduct[$i]["site_stock"] = $obj->site_stock;
				$tabproduct[$i]["siteid"] = $obj->siteid;
				$tabproduct[$i]["site_name"] = $obj->site_name;
			}
			$i++;
		}
	}
}
else dol_syslog("Ecommerce index site stock sql=" . $sql, LOG_DEBUG);

// Prospects

// Display log
$sql = "SELECT l.log_date, l.site_id, l.log_message ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_log AS l ";
$sql .= " INNER JOIN " . MAIN_DB_PREFIX . "ecom_site AS es ON es.rowid = l.site_id ";
$sql .= " WHERE l.log_type = 'EXP'";
$sql .= " AND es.entity = " . $conf->entity;
$sql .= " ORDER BY l.log_date DESC ";
$sql .= " LIMIT 10";

$var = True;
$tablog = array();
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;
	if ($num) {
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			$var = !$var;
			if ($obj) {
				$tablog[$i]["log_date"] = $obj->log_date;
				$tablog[$i]["site_id"] = $obj->site_id;
				$tablog[$i]["log_message"] = $obj->log_message;
			}
			$i++;
		}
	}
}
else dol_syslog("Ecommerce index log sql=" . $sql, LOG_DEBUG);

/**
 * View
 */

llxHeader();

$form = new Form($db);

$text = $langs->trans("EcomSitesArea");

print_fiche_titre($text, '', 'ecommerce@ecommerce');
print '<br>';
$head = ecommerce_index_prepare_head();

dol_fiche_head($head, 'siterecap', $langs->trans("ECommerce"));

print '<table class="liste" width="100%">';


// boutiques
/*
print '<tr class="liste_titre"><td colspan="2">';
if (count($tabboutiques) > 0)
{
	print '<table class="notopnoleftnoright" width="100%">';
	print '<tr class="liste_titre"><td width="40%">'.$langs->trans("SiteName").'</td><td width="40%">'.$langs->trans("Administrer").'</td>';
	if (!$user->rights->Ecommerce->admin) print '<td width="20%"></td>';
	else
    {
		print '<td width="20%" align="center"><center><form action="'.dol_buildpath('/ecommerce/admin/site_admin.php',1).'"><input type="submit" class="button" value="'.$langs->trans("AddSite").'" >';
		print '</form></center></td>';
		}
		print '</tr>';
    $var=True;
    foreach ($tabboutiques as $elt)
    {
		print '<tr '.$bc[$var].'><td align="left"><a href="'.dol_buildpath('/ecommerce/site_index.php',1).'?siteid='.$elt["id"].'">'.$elt["name"].'</a></td>';
  		if (!$user->rights->Ecommerce->admin) print '<td></td>';
  		else print '<td align="left"><a href="'.dol_buildpath('/ecommerce/admin/site_admin.php',1).'?siteid='.$elt["id"].'">'.$langs->trans("Administration").'</a></td>';
  		print '<td>&nbsp;</td></tr>';
  		$var=!$var;
		}
		print '</table>';
}
else print '<p>'.$langs->trans("DefNewSite").' <a href="'.dol_buildpath('/ecommerce/admin/site_admin.php',1).'">'.$langs->trans("AddSite").'</a></p>';
print '</td></tr>';
print '<tr><td colspan="2">&nbsp;</td></tr>';
*/
// Orders and CA
print '<tr class="liste_titre">';
print '<td align="center">' . $langs->trans("SiteLastOrders") . '</td><td align="center">' . $langs->trans("SiteCA") . '</td>';
print '</tr>' . "\n";
print '<tr><td valign="top" align="center">';
if (count($taborders) > 0) {
	print '<table class="notopnoleftnoright" align="center" width="98%">';
	print '<tr class="liste_titre">';
	print '<td class="liste_titre">' . $langs->trans("SiteOrderId") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("SiteCustName") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("SiteOrderDate") . '</td>';
	print '<td align="right" class="liste_titre">' . $langs->trans("SiteOrderTotal") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("SiteOrderStatus") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("DoliOrder") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("SiteName") . '</td>';
	print "</tr>\n";
	$var = True;
	foreach ($taborders as $elt) {
		print '<tr ' . $bc[$var] . ' ><td>';
		print $elt["ecom_order"];
		print '</td><td>';
		print $elt["site_client_name"];
		print '</td><td>';
		print dol_print_date($db->jdate($elt["site_order_date"]), "day");
		print '</td><td align="right">';
		print price($elt["site_order_total_ht"]);
		print '</td><td>';
		switch ((int)$elt["site_order_status"]) {
			case 0:
				$lib = $langs->trans("OrderStatusDraft");
				break;
			case 1:
				$lib = $langs->trans("OrderStatusValid");
				break;
			case 2:
				$lib = $langs->trans("OrderStatusTrait");
				break;
			case 3:
				$lib = $langs->trans("OrderStatusCloture");
				break;
			case -1:
				$lib = $langs->trans("OrderStatusNull");
				break;
			default:
				$lib = $elt["site_order_status"];
		}
		print $lib;
		print '</td><td>';
		if ($elt["doli_order"] == 0) print ' ';
		else {
			print '<a href="' . dol_buildpath('/commande/card.php', 1) . '?id=' . $elt["doli_order"] . '">' . $elt["doli_order"] . '</a>';
		}
		print '</td><td><a href="' . dol_buildpath('/ecommerce/site_orders.php', 1) . '?siteid=' . $elt["siteid"] . '">' . $elt["site_name"] . '</a>';
		print '</td></tr>';
		$var = !$var;
	}
	print '</table>';
}
print '</td>';
print '<td valign="top" align="center">';

if (count($tabCA) > 0) {
	print '<table class="notopnoleftnoright" width="98%">';
	print '<tr class="liste_titre">';
	print '<td class="liste_titre" >' . $langs->trans("e-year") . '</td>';
	print '<td class="liste_titre" >' . $langs->trans("e-month") . '</td>';
	print '<td align="right" class="liste_titre" >' . $langs->trans("e-CA") . '</td>';
	print '</tr>';
	$var = True;
	foreach ($tabCA as $elt) {
		print '<tr ' . $bc[$var] . '><td>';
		print $elt["an"] . '</td>';
		print '<td >' . $elt["mois"] . '</td>';
		print '<td align="right">' . price($elt["CA"]) . '</td>';
		print'</td></tr>';
		$var = !$var;
	}
	print '</table>';
}
print '</td></tr>';
print '<tr><td colspan="2">&nbsp;</td></tr>';

//stadistics
include_once DOL_DOCUMENT_ROOT . '/core/class/dolgraph.class.php';
include_once './class/ecom_stadistics.class.php';

$WIDTH = DolGraph::getDefaultGraphSizeForStats('width');//ancho de la grafica
$HEIGHT = DolGraph::getDefaultGraphSizeForStats('height');//alto de la grafica

$endyear = strftime("%Y", dol_now());//años en los que se aplicara la grafica
$startyear = $endyear - 1;

//carpeta temporal
$dir = getcwd() . '/temp';
dol_mkdir($dir);
$filenamenb = $dir . '/ordersnbinyear-' . $year . '.png';

$stats = new ecom_stadistics($db);

print '<tr class="liste_titre">';
print '<td align="center">' . $langs->trans("NumberOfOrdersByMonth") . '</td>' . "\n";//grafica 1
print '<td align="center">' . $langs->trans("AmountOfOrdersByMonthHT") . '</td>' . "\n";//grafica 2
print '</tr>';

//grafica 1
$data = $stats->getNbByMonthWithPrevYear($endyear, $startyear, null, null);

$px1 = new DolGraph();
$mesg = $px1->isGraphKo();

if (!$mesg) {
	$px1->SetData($data);
	$px1->SetPrecisionY(0);
	$i = $startyear;
	$legend = array();
	while ($i <= $endyear) {
		$legend[] = $i;
		$i++;
	}
	$px1->SetLegend($legend);
	$px1->SetMaxValue($px1->GetCeilMaxValue());
	$px1->SetMinValue(min(0, $px1->GetFloorMinValue()));
	$px1->SetWidth($WIDTH);
	$px1->SetHeight($HEIGHT);
	$px1->SetYLabel($langs->trans("NbOfOrder"));
	$px1->SetShading(3);
	$px1->SetHorizTickIncrement(1);
	$px1->SetPrecisionY(0);
	$px1->mode = 'depth';
	//$px1->SetTitle($langs->trans("NumberOfOrdersByMonth"));

	$px1->draw($filenamenb, '');
}

//grafica 2
// Build graphic number of object
$data = $stats->getAmountByMonthWithPrevYear($endyear, $startyear, null, null);

$filenameamount = $dir . '/ordersamountinyear-' . $year . '.png';

$px2 = new DolGraph();
$mesg2 = $px2->isGraphKo();

if (!$mesg2) {
	$px2->SetData($data);
	$px2->SetPrecisionY(0);
	$i = $startyear;
	$legend = array();
	while ($i <= $endyear) {
		$legend[] = $i;
		$i++;
	}
	$px2->SetLegend($legend);
	$px2->SetMaxValue($px2->GetCeilMaxValue());
	$px2->SetMinValue(min(0, $px2->GetFloorMinValue()));
	$px2->SetWidth($WIDTH);
	$px2->SetHeight($HEIGHT);
	$px2->SetYLabel($langs->trans("AmountOfOrders"));
	$px2->SetShading(3);
	$px2->SetHorizTickIncrement(1);
	$px2->SetPrecisionY(0);
	$px2->mode = 'depth';
	//$px2->SetTitle($langs->trans("AmountOfOrdersByMonthHT"));

	$px2->draw($filenameamount, '');
}

//show graph
print '<tr valign="top"><td align="center">';

if ($mesg) {
	print $mesg;
}
else {
	print $px1->show();
}
print '</td><td align="center">';

if ($mesg2) {
	print $mesg2;
}
else {
	print $px2->show();
}
print '</tr>';


// Products
print '<tr class="liste_titre">';
print '<td colspan="2" align="center">' . $langs->trans("SiteArticle") . '</td>';
print '</tr>';
print '<tr><td align="center">' . $langs->trans("SiteProdOutStock") . '</td><td align="center">' . $langs->trans("SiteArticleStock") . '</td></tr>';
"\n";
print '<tr><td valign="top" align="center">';
if (count($tabproduct) > 0) {
	print '<table class="notopnoleftnoright" width="98%">';
	print '<tr class="liste_titre">';
	print '<td class="liste_titre">' . $langs->trans("SiteProdId") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("ArticleRef") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("ArticleLib") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("ArticleStock") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("SiteName") . '</td>';
	print "</tr>\n";
	$var = True;
	foreach ($tabproduct as $elt) {
		print '<tr ' . $bc[$var] . '><td>';
		print $elt["ecom_product"];
		print '</td><td>';
		print $elt["ref"];
		print '</td><td>';
		print $elt["label"];
		print '</td><td align="center">';
		print $elt["site_stock"];
		print '</td><td><a href="' . dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $elt["siteid"] . '">' . $elt["site_name"] . '</a>';
		print '</td></tr>';
		$var = !$var;
	}
	print '</table>';
}
print '</td>';
print '<td valign="top" align="center">';
if (count($taboutstock) > 0) {
	print '<table class="notopnoleftnoright" width="98%">';
	print '<tr class="liste_titre">';
	print '<td class="liste_titre">' . $langs->trans("SiteProdId") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("ArticleRef") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("ArticleLib") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("ArticleStock") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("SiteName") . '</td>';
	print "</tr>\n";
	$var = True;
	foreach ($taboutstock as $elt) {
		print '<tr ' . $bc[$var] . '><td>';
		print $elt["fk_product"];
		print '</td><td>';
		print '<a href="' . dol_buildpath('/product/card.php', 1) . '?id=' . $elt["fk_product"] . '">' . $elt["ref"] . '</a>';
		print '</td><td>';
		print $elt["label"];
		print '</td><td align="center">';
		print $elt["qte_cde"];
		print '</td><td><a href="' . dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $elt["siteid"] . '">' . $elt["site_name"] . '</a>';
		print '</td></tr>';
		$var = !$var;
	}
	print '</table>';
}
print '</td></tr>';
print '<tr><td colspan="2">&nbsp;</td></tr>';

// customer and log
print '<tr class="liste_titre">';
print '<td colspan="2" align="center">' . $langs->trans("SiteImportLog") . '</td>';
print '<tr>';
print '<tr class="liste_titre">';
print '<td align="center">' . $langs->trans("SiteClients") . '</td><td align="center">' . $langs->trans("SiteLog") . '</td>';
print '</tr>';
print '<tr><td valign="top" align="center">';
print '<p>' . $langs->trans("ImportProspects") . '</p><p>' . $langs->trans("OtherFunctions") . '</p>';
$tabcustomer = array();
if (count($tabcustomer) > 0) {
}
print '</td>';
print '<td valign="top" align="center">';
if (count($tablog) > 0) {
	print '<table class="notopnoleftnoright" width="98%">';
	print '<tr class="liste_titre">';
	print '<td class="liste_titre">' . $langs->trans("LogDate") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("LogSite") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("LogMessage") . '</td>';
	print "</tr>\n";
	$var = True;
	foreach ($tablog as $elt) {
		print '<tr ' . $bc[$var] . ' ><td>';
		print $elt["log_date"];
		print '</td><td >';
		print $elt["site_id"];
		print '</td><td >';
		print $elt["log_message"];
		print '</td></tr>';
		$var = !$var;
	}
	print '</table>';
}
print '</td></tr>';
print '</table>';
print '<tr><td>&nbsp;</td></tr>';

// End of page
llxFooter();

$db->close();

