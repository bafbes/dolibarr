<?php
/* Copyright (C) 2007 Laurent Destailleur  	<eldy@users.sourceforge.net>
 * Copyright (C) 2011-2012  Jean Heimburger <jean@tiaris.info>
 * Copyright (C) 2011-2013  Philippe Grand  <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013 	Juanjo Menent	<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       htdocs/ecommerce/producttab.php
 *        \ingroup    ecommerce
 *        \brief      producttab page of ecommerce module
 */

require("../pre.inc.php");
require_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");
require_once(DOL_DOCUMENT_ROOT . "/core/lib/product.lib.php");
require_once(DOL_DOCUMENT_ROOT . "/core/lib/functions.lib.php");
//require_once(DOL_DOCUMENT_ROOT."/html.formfile.class.php");
dol_include_once("/ecommerce/class/ecom_html.class.php");
dol_include_once("/ecommerce/class/E_product.class.php");
dol_include_once("/ecommerce/class/ecom_html.class.php");

$ecom_html = new Ecom_html($db);

$sql = "SELECT rowid as id, site_name as lib FROM " . MAIN_DB_PREFIX . "ecom_site";
$sql .= " WHERE entity=" . $conf->entity;
$listesite = $ecom_html->ecom_ddform('', $sql, "siteid", '');

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("ecommerce@ecommerce");

// Get parameters
$id=$prodid = GETPOST("id", "int");
$reference = GETPOST('ref', 'alpha');
$action = GETPOST("action", "alpha");

// Protection if external user
if ($user->societe_id > 0) {
	//accessforbidden();
}

// Chargement

$product = new Product($db);
if ($prodid > 0) $resultprod = $product->fetch($prodid);
if (!empty($reference)) {
	$resultprod = $product->fetch('', $reference);
	$prodid = $product->id;
}

//dol_syslog(__FILE__.":: produit chargé ".print_r($product, true). " default price ".get_product_defaultprice($product->id), LOG_DEBUG);

$pdir = get_exdir($product->id, 2, 0, 0, $product, '') . $product->id . "/photos/";
$dir = $conf->produit->dir_output . '/' . $pdir;
$pictureslist = $product->liste_photos($dir);

$ecom_html = new Ecom_html($db);

/*******************************************************************
 * ACTIONS
 *
 * Put here all code to do according to value of "action" parameter
 ********************************************************************/
if ($action == 'AddProduct') {
	$siteid = GETPOST("siteid", int);
	dol_syslog(basename(__FILE__) . ":: action " . $action . " siteid =" . $siteid, LOG_DEBUG);
	if (!empty($siteid)) {
		$sql = "SELECT ec.ecom_catid as id, ec.ecom_catname as lib ";
		$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_categories ec WHERE siteid = '" . $siteid . "' ORDER BY ec.ecom_catname";
		$liste_catsite = $ecom_html->ecom_ddform('', $sql, "catid", '');
		// charger les listes catégories
		// si équivalence catégorie dolibarr et ecommerce
		/*		$sql = "SELECT ec.ecom_catid as id, c.label as lib ";
				$sql.= " FROM ".MAIN_DB_PREFIX."categorie_product cp ";
				$sql.= " JOIN ".MAIN_DB_PREFIX."categorie c ON cp.fk_categorie = c.rowid ";
				$sql.= " LEFT JOIN ".MAIN_DB_PREFIX."ecom_categories ec ON c.rowid = ec.doli_catid AND siteid = '".$siteid."' " ;
				$sql.= " WHERE cp.fk_product = '".$prodid."'";
				dol_syslog(basename(__FILE__).":: action ".$action." sql =".$sql, LOG_DEBUG);
				$liste_catsite = $ecom_html->ecom_ddform('', $sql, "catid", '');
			//  si vide charger la liste des catégories par défaut
				if (empty($liste_catsite))
				{
					$sql = "SELECT ec.ecom_catid as id, ec.ecom_catname as lib ";
					$sql .= " FROM ".MAIN_DB_PREFIX."ecom_categories ec WHERE siteid = '".$siteid."'";
					$liste_catsite = $ecom_html->ecom_ddform('', $sql, "catid", '');
				}
		*/
		// fabricants
		$sql = "SELECT ecom_manufacturer as id, ecom_manuname as lib FROM " . MAIN_DB_PREFIX . "ecom_manufacturer WHERE manutype = '0' AND siteid ='" . $siteid . "' ORDER BY ecom_manuname";
		dol_syslog(basename(__FILE__) . ":: action " . $action . " sql =" . $sql, LOG_DEBUG);
		$liste_manufacturersite = $ecom_html->ecom_ddform('', $sql, "manufid", '');

		// Site name
		$sitename = $ecom_html->getsiteurl($siteid);
	}


}


if ($action == 'AddProductConfirm') {
	// contrôles cat par défaut, fabricant...
	$productid = GETPOST("productid", "int");
	$catid = GETPOST("catid", "int");
	$fourid = GETPOST("manufid", "int");
	$taxid = GETPOST("tva", "int");
	$quant = GETPOST("quantity", "int");
	$siteid = GETPOST("siteid", "int");
	$price = GETPOST("price", "int");

	if (empty($productid)) {
		$mesg = "product id empty ";
		setEventMessage($mesg, 'errors');
	}

	else {
		dol_syslog(basename(__FILE__) . ":: action " . $action . " prodid = $productid catid=$catid  fourid = $fourid, taxid = $taxid", LOG_DEBUG);
		$eprod = new E_product($db, $siteid, $user);
		$eprod->fourn = (empty($fourid) ? '' : $fourid);
		$eprod->catid = (empty($catid) ? '' : $catid);
		$eprod->site_stock = (empty($quant) ? '' : $quant);
		$eprod->price = (empty($price) ? '' : $price); //get_product_defaultprice($product->id):$price);
		$eprod->doli_ref = $product->ref;

		$res = $eprod->sell_product($productid, $catid, $taxid);
		if ($res < 0) {
			//$mesg = "Erreur mise en vente ";
			$mesg = $langs->trans("SellProductKO", $product->ref, $eprod->error);
			setEventMessage($mesg, 'errors');
		}
	}
}

/***************************************************
 * DATAS
 ****************************************************/
/*// Site lists
$sql = "SELECT es.rowid as id, es.site_name as lib FROM " . MAIN_DB_PREFIX . "ecom_site es ";
$sql .= " WHERE NOT EXISTS (SELECT * FROM " . MAIN_DB_PREFIX . "ecom_product ep WHERE ep.doli_product ='" . $prodid . "' AND ep.siteid = es.rowid)";
$sql .= " AND es.entity=" . $conf->entity;
$listesite = $ecom_html->ecom_ddform('', $sql, "siteid", '');
*/

// sites where present
$sql = "SELECT ep.rowid, ep.siteid , es.site_name, ep.ecom_product, ";
$sql .= " ep.ecom_ref,  ep.long_desc ";
$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_product AS ep ";
$sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_site AS es ON ep.siteid = es.rowid ";
$sql .= " WHERE doli_product='" . $prodid . "' AND ecom_product >= '0'";

// TODO ajouter une liste de produits en attente de mise en vente

$tabprodsite = array();

$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 0;
	if ($num) {
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				$tabprodsite[$i]['siteid'] = $obj->siteid;
				$tabprodsite[$i]['site_name'] = $obj->site_name;
				$tabprodsite[$i]['ecom_product'] = $obj->ecom_product;
				$tabprodsite[$i]['long_desc'] = $obj->long_desc;
				$tabprodsite[$i]['ecom_ref'] = $obj->ecom_ref;
			}
			$i++;
		}
	}
}
else {
	dol_syslog("producttab.php:: Erreur requête $sql " . $db->error, LOG_ERR);
}


/***************************************************
 * PAGE
 *
 * Put here all code to build page
 ****************************************************/

llxHeader('', '', '');


$form = new Form($db);

// onglets
if ($resultprod) {
    $object = new Product($db);
//$upload_dir
    if ($id > 0 || !empty($ref)) {
        $result = $object->fetch($id, $ref);

        $upload_dir = $conf->product->multidir_output[$object->entity] . '/etiquetage/' . dol_sanitizeFileName($object->ref);

        if (!empty($conf->global->PRODUCT_USE_OLD_PATH_FOR_PHOTO))    // For backward compatiblity, we scan also old dirs
        {
            if (!empty($conf->product->enabled)) $upload_dirold = $conf->product->multidir_output[$object->entity] . '/' . substr(substr("000" . $object->id, -2), 1, 1) . '/' . substr(substr("000" . $object->id, -2), 0, 1) . '/' . $object->id . "/photos";
            else $upload_dirold = $conf->service->multidir_output[$object->entity] . '/' . substr(substr("000" . $object->id, -2), 1, 1) . '/' . substr(substr("000" . $object->id, -2), 0, 1) . '/' . $object->id . "/photos";
        }
    }
    $head = product_prepare_head($product, $user);
    $titre = $langs->trans("CardProduct" . $object->type);
    $picto = ($object->type == Product::TYPE_SERVICE ? 'service' : 'product');
    dol_fiche_head($head, 'tabproducttab', $titre, 0, $picto);

    $linkback = '<a href="' . DOL_URL_ROOT . '/product/list.php?type=' . $object->type . '">' . $langs->trans("BackToList") . '</a>';
    $object->next_prev_filter = " fk_product_type = " . $object->type;

    dol_banner_tab($object, 'ref', $linkback, ($user->societe_id ? 0 : 1), 'ref');

    /*	$titre = $langs->trans("CardProduct" . $product->type);
        $picto = ($product->type == 1 ? 'service' : 'product');
        dol_fiche_head($head, 'tabproducttab', $titre, 0, $picto);*/

    //product infos
    print "<div>";
    print '<table class="border" width="100%">';

    // Reference
	print '<tr>';
	print '<td width="15%">' . $langs->trans("Ref") . '</td><td colspan="2">';
	print $form->showrefnav($product, 'ref', '', 1, 'ref', '');
	print '</td>';
	print '</tr>';

	// Libelle
	print '<tr><td>' . $langs->trans("Label") . '</td><td colspan="2">' . $product->label . '</td>';
	print '</tr>';

	// Prix
	print '<tr><td>' . $langs->trans("SellingPrice") . '</td><td colspan="2">';
	if ($product->price_base_type == 'TTC') {
		print price($product->price_ttc) . ' ' . $langs->trans($product->price_base_type);
	}
	else {
		print price($product->price) . ' ' . $langs->trans($product->price_base_type);
	}
	print '</td></tr>';
	/*
		// Statut
		print '<tr><td>'.$langs->trans("Status").'</td><td colspan="2">';
		print $product->getLibStatut(2);
		print '</td></tr><tr>';
		if (sizeof($tabprodsite) > 0) print '<td>'.$langs->trans("ProdOnSell").'</td>';
		else print '<td>'.$langs->trans("ProdNotOnSell").'</td>';
		print "</tr></table>\n";
	*/
	print "</table>\n";
	print "</div>\n";
	dol_fiche_end();
	print "<br /><div>";

	if (sizeof($tabprodsite) > 0) {
		print_fiche_titre($langs->trans("ProductOnEcom"), '', '');

		print '<table class="noborder" width="100%">';
		print '<tr class="liste_titre">';
		print '<td>' . $langs->trans("Site") . '</td>';
		print '<td>' . $langs->trans("SiteProdRef") . '</td>';
		print '<td>' . $langs->trans("SiteLongDesc") . '</td>';
		print '</tr>';
		$var = true;
		foreach ($tabprodsite as $elt) {
			$var = !$var;
			print '<tr ' . $bc[$var] . '>';

			print '<td width="10%">' . $elt["site_name"] . '</td>';
			print '<td width="10%">' . (empty($elt["ecom_product"]) ? $langs->trans("ProdComingSoon") : $elt["ecom_ref"]) . '</td>';
			print '<td colspan="2">' . $elt["long_desc"] . '</td>';
			print '</tr>';
		}
		print '</table>';
	}
	else {
		print "<p>" . $langs->trans("ErrNotOnWeb") . "</p>";
	}
	print '</div><br />';

	if ($listesite[1] > 0) {
		print '<div>';
		print_fiche_titre($langs->trans("ProductNotOnEcom"), '', '');
		print '<table> ';
		print '<tr><form action="" method="POST">';
		print '<td>' . $product->getNomUrl(1) . '</td>';
		if ($action == "AddProduct") {
			print '<td>' . html_entity_decode($langs->trans("EcomValueChoose", $sitename)) . '</td></tr>';
			print '<tr>';
			print '<td>' . $langs->trans("Ecomcat") . '</td><td>' . $liste_catsite[0] . '</td>';
			//print '<td>'.$langs->trans("Ecomfour").'</td><td>'.$liste_manufacturersite.'</td>';
			print '<td>' . $langs->trans("Ecomqty") . '</td><td><input type="TEXT" size="6" name="quantity" value="' . $product->stock_reel . '" /></td>';
			print '<td>' . $langs->trans("Ecomvat") . '</td><td><input type="text" size="6" name="tva" value="' . $product->tva_tx . '" /></td>';
			print '<td>' . $langs->trans("Ecomprice") . '</td><td><input type="text" size="6" name="price" value="' .
                price($product->price) . '" /></td>';
			print '<input type="hidden" name="siteid" value="' . $siteid . '" />';
			print '<input type="hidden" name="action" value="AddProductConfirm" />';
            $actionlib = $langs->trans("Send");
		}
		else {
			print '<input type="hidden" name="action" value="AddProduct" />';
			print '<td>' . $listesite[0] . '</td>';
            $actionlib = $langs->trans("SelectOne");
		}
		print '<input type="hidden" name="productid" value="' . $product->id . '" />';

		print '<td><input class="button" type="submit" value="' . $actionlib . '"></td>';
		print "</form></tr>";
		print '</table>';
		print '</div>';
	}

}

// End of page
llxFooter();

$db->close();

