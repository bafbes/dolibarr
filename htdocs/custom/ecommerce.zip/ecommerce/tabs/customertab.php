<?php
/* Copyright (C) 2007 Laurent Destailleur  	<eldy@users.sourceforge.net>
 * Copyright (C) 2011-2012 Jean Heimburger      	<jean@tiaris.info>
 * Copyright (C) 2011 Philippe Grand       	<philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2012 	Juanjo Menent	<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       htdocs/ecommerce/producttab.php
 *        \ingroup    ecommerce
 *        \brief      producttab page of ecommerce module
 *        \version    $Id: producttab.php,v 1.2.4.2 2011-11-21 11:33:39 atoonet Exp $
 */

require("../pre.inc.php");
require_once DOL_DOCUMENT_ROOT . "/societe/class/societe.class.php";
require_once DOL_DOCUMENT_ROOT . "/contact/class/contact.class.php";
require_once DOL_DOCUMENT_ROOT . "/core/lib/company.lib.php";
dol_include_once("/ecommerce/class/ecom_html.class.php");
dol_include_once("/ecommerce/class/E_customer.class.php");

//require_once(DOL_DOCUMENT_ROOT."/html.formfile.class.php");

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("ecommerce@ecommerce");

// Get parameters
$id = GETPOST('id', 'int');
$client = new Societe($db);
$client->fetch($id);

// Protection if external user
if ($user->societe_id > 0) {
	//accessforbidden();
}
$object = new Societe($db);

$object->fetch($id);
/*******************************************************************
 * ACTIONS
 *
 * Put here all code to do according to value of "action" parameter
 ********************************************************************/

if ($_REQUEST["action"] == 'AddCustomer') {
	$siteid = GETPOST('siteid', 'int');
	$custid = GETPOST('custid', 'int');
	$Ecomcust = new E_customer($db, $siteid, $user);
	if ($Ecomcust->send_customertosite($custid) < 0) {
		$mesg = $Ecomcust->error;
		setEventMessage($mesg, 'errors');
	}

}

if ($_REQUEST["action"] == 'AddContact') {
	$siteid = GETPOST('siteid', 'int');
	$custid = GETPOST('custid', 'int');
	$Ecomcust = new E_customer($db, $siteid, $user);
	if ($Ecomcust->send_customertosite($custid) < 0) {
		$mesg = $Ecomcust->error;
		setEventMessage($mesg, 'errors');
	}

}

/***************************************************
 * DATAS
 ****************************************************/

//sites where customer is pesent
/*
$sql = "SELECT ec.siteid, ec.site_cust_status, es.site_name, es.site_url ";
$sql .= " FROM ".MAIN_DB_PREFIX."ecom_customer ec ";
$sql .= " JOIN ".MAIN_DB_PREFIX."ecom_site es ON ec.siteid = es.rowid ";
$sql .= " WHERE ec.doli_soc = '".$id."'";

$resql=$db->query($sql);
$tabpresent = array();
if ($resql)
{
	while ($obj = $db->fetch_object($resql))
	{
		$tabpresent[] = $obj;
	}
}
*/

$ecom_html = new Ecom_html($db);

$sql = "SELECT rowid as id, site_name as lib FROM " . MAIN_DB_PREFIX . "ecom_site es";
$sql .= " WHERE NOT EXISTS (SELECT * FROM " . MAIN_DB_PREFIX . "ecom_customer ep WHERE ep.doli_soc ='" . $id . "' AND ep.siteid = es.rowid)";
$sql .= " AND entity=" . $conf->entity;
$listesite = $ecom_html->ecom_ddform('', $sql, "siteid", '');

$sql = "SELECT sp.rowid as id, sp.lastname, sp.firstname, ec.siteid, es.site_name ";
$sql .= " FROM " . MAIN_DB_PREFIX . "socpeople sp ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "ecom_contact ec on sp.rowid = ec.doli_contact_id ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "ecom_site es ON ec.siteid = es.rowid ";
$sql .= " WHERE sp.fk_soc = '" . $id . "'";

$resql = $db->query($sql);
$tabcontact = array();
if ($resql) {
	while ($obj = $db->fetch_object($resql)) {
		$tabcontact[] = $obj;
	}
}

/***************************************************
 * PAGE
 *
 * Put here all code to build page
 ****************************************************/

llxHeader('', '', '');

$form = new Form($db);

$head = societe_prepare_head($client);
print dol_get_fiche_head($head, 'tabthirdtab', $langs->trans("ThirdParty"), -1, 'company');
$linkback = '<a href="'.DOL_URL_ROOT.'/societe/list.php?restore_lastsearch_values=1">'.$langs->trans("BackToList").'</a>';

dol_banner_tab($object, 'socid', $linkback, ($user->socid ? 0 : 1), 'rowid', 'nom');

// infos société
print "<div>";
print '<table class="border" width="100%">';
print '<tr><td width="20%">' . $langs->trans('ThirdPartyName') . '</td>';
print '<td colspan="3">';
print $form->showrefnav($client, 'socid', '', ($user->societe_id ? 0 : 1), 'rowid', 'nom');
print '</td></tr>';
if ($client->client) {
	print '<tr><td>';
	print $langs->trans('CustomerCode') . '</td><td colspan="3">';
	print $client->code_client;
	if ($client->check_codeclient() <> 0) print ' <font class="error">(' . $langs->trans("WrongCustomerCode") . ')</font>';
	print '</td></tr>';
}

if ($client->fournisseur) {
	print '<tr><td>';
	print $langs->trans('SupplierCode') . '</td><td colspan="3">';
	print $client->code_fournisseur;
	if ($client->check_codefournisseur() <> 0) print ' <font class="error">(' . $langs->trans("WrongSupplierCode") . ')</font>';
	print '</td></tr>';
}
print "</table>";
print "</div>";

dol_fiche_end();
print "<br /><div>";

$cont = new Contact($db);

// présent sur
print_fiche_titre($langs->trans("CustomerEcom"), '', '');

if (count($tabcontact) > 0) {
	print '<table class="noborder" width="100%">';
	print '<tr class="liste_titre">';
	print '<td>' . $langs->trans("ThirdParty") . '</td>';
	print '<td>' . $langs->trans("Site") . '</td>';
	print '<td>' . $langs->trans("Status") . '</td>';
	print '</tr>';
	$var = true;


	foreach ($tabcontact as $contact) {
		if ($contact->siteid) {
			$var = !$var;
			print '<tr ' . $bc[$var] . '>';

			$cont->id = $contact->id;

			$cont->name = $contact->lastname;

			$cont->firstname = $contact->firstname;

			$cont->fetch($contact->id);

			print "<td>" . $cont->getNomUrl(1) . ": " . $cont->address . ", " . $cont->town . "</td>";
			print "<td>" . $contact->site_name . "</td><td>" . $line->site_cust_status . "</td>";
			print "</tr>";
		}
	}
	print "</table>";
}

print "</div>";
print "<br />";

if ($listesite[1] > count($tabcontact)) {
	print "<div>";
	print_fiche_titre($langs->trans("CustomerEcomContacts"), '', '');
	print '<table> ';
	foreach ($tabcontact as $contact) {
		print '<tr><form action="" method="POST">';
		$cont->id = $contact->id;
		$cont->name = $contact->lastname;
		$cont->firstname = $contact->firstname;

		$cont->fetch($contact->id);
		print "<td>" . $cont->getNomUrl(1) . ": " . $cont->address . ", " . $cont->town . "</td>";

		print '<td>' . $listesite[0] . '</td>';
		print '<input type="hidden" name="custid" value="' . $contact->id . '" />';
		print '<input type="hidden" name="action" value="AddContact" />';
		print '<td><input class="button" type="submit" value="' . $langs->trans("Send") . '"></td>';

		print "</form></tr>";
	}

	print '</table>';
	print "</div>";
}


// End of page
llxFooter();

$db->close();


