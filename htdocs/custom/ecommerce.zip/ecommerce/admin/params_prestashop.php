<?php
/* Copyright (C) 2007  		Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2010-2012  Jean Heimburger     <jean@tiaris.info>
 * Copyright (C) 2011-2013  Philippe Grand      <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013 	Juanjo Menent		<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *        \file       htdocs/ecommerce/admin/site_admin.php
 *        \ingroup    ecommerce
 *        \brief      admin page of ecommerce module
 */

require("../pre.inc.php");
dol_include_once('/ecommerce/core/lib/ecommerce.lib.php');

// Load traductions files requiredby by page
$langs->load("admin");
$langs->load("companies");
$langs->load("other");
$langs->load("ecommerce@ecommerce");

$user->getrights('Ecommerce');

if (!$user->rights->Ecommerce->admin) accessforbidden();

$conn = new mysqli($presta_main_db_host, $presta_main_db_user, $presta_main_db_pass, $presta_main_db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

llxHeader();
// sql to delete a record

//page
$linkback = '<a href="' . DOL_URL_ROOT . '/admin/modules.php">' . $langs->trans("BackToModuleList") . '</a>';
print load_fiche_titre($langs->trans("ECommerceSetup"), $linkback, 'ecommerce@ecommerce');

$head = ecommerce_prepare_head();

print dol_get_fiche_head($head, 'paramsprestashop', $langs->trans("ECommerce"),-1,'bookmark');
if (isset($_GET['deleteattributeswithoutproducts'])) {
    $sql = "delete from ps_product_attribute where id_product=0";

    if ($conn->query($sql) === TRUE) {
        $sql = "SELECT ROW_COUNT() nb AS DELETED";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {$row = $result->fetch_assoc();}
        $response= (empty($row["nb"])||$row["nb"]<1? 0 : $row["nb"]) . " records deleted successfully";
    }
    else {
        $response= "Error deleting record: " . $conn->error;
    }
}
if (isset($_GET['fixattributereferencesindouble'])) {
    $sql = "select reference,count(*) c from ps_product_attribute group by reference HAVING c > 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        $response= '';
        while ($row = $result->fetch_assoc()) {
            $response.=  "Reference: " . $row["reference"] . " - repetitions: " . $row["c"] . "<br>";
            $rows[$row["reference"]] = $row["c"];
        }
    }
    else {
        $response= "0 results";

    }
    foreach ($rows as $ref => $value) {
        $sql = "select id_product_attribute from ps_product_attribute where reference='$ref'";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $ids[] = $row["id_product_attribute"];
        }
        $i = 1;
        foreach ($ids as $id) {
            $sql = "update ps_product_attribute set reference=concat(reference,'-',$i) where id_product_attribute=$id";
            $result = $conn->query($sql);
            $i++;
        }
    }
    $response=  '<br>Fixed';
}
if($response)echo "Réponse de mysql : $response";
$var = true;
print '<table class="noborder" width="100%">';
print '<tr class="liste_titre">';
print '<td width="40%"><h3>' . $langs->trans("Parameter") . '</td>';
print '<td><h3>' . $langs->trans("Value") . '</td>';
print '</tr>';

$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("UrlWs") . '</td>';
print '<td>';
print 'http://' . $_SERVER['HTTP_HOST'] . dirname(dirname($_SERVER['REQUEST_URI'])) . '/';
print '</td>';
print '</tr>';

print '</table>';

print '<table class="noborder" width="100%">';
print '<tr class="liste_titre">';
print '<td width="40%"><h3>' . $langs->trans("Function") . '</td>';
print '<td><h3>' . $langs->trans("Link") . '</td>';
print '</tr>';

$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("deleteattributeswithoutproducts") . '</td>';
print '<td>';
print "<a href='". $_SERVER["PHP_SELF"]."?deleteattributeswithoutproducts=1'>".$langs->trans("Exécuter")."</a>";
print '</td>';
print '</tr>';
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("fixattributereferencesindouble") . '</td>';
print '<td>';
print "<a href='". $_SERVER["PHP_SELF"]."?fixattributereferencesindouble=1'>".$langs->trans("Exécuter")."</a>";
print '</td>';
print '</tr>';

print '</table>';

llxFooter();

