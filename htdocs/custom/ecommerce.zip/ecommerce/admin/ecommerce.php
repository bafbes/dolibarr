<?php
/* Copyright (C) 2010 	   Jean Heimburger  <jean@tiaris.fr>
 * Copyright (C) 2011-2013 Philippe Grand   <philippe.grand@atoo-net.com>
 * Copyright (C) 2012-2013 Juanjo Menent    <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

/**
 *    \file        htdocs/admin/ecommerce.php
 *    \ingroup    ecommerce
 *    \brief      Page d'administration/configuration du module E-Commerce
 */

require("../pre.inc.php");

require_once(DOL_DOCUMENT_ROOT . "/core/lib/admin.lib.php");
require_once DOL_DOCUMENT_ROOT . '/core/class/html.formother.class.php';
dol_include_once('/ecommerce/core/lib/ecommerce.lib.php');

$langs->load("admin");
$langs->load("ecommerce@ecommerce");
$langs->load('bills');


if (!$user->admin)
	accessforbidden();

/*
 * Actions
 */
if (isset($_POST["save"])) {
	dolibarr_set_const($db, 'ECOM_CREATE_FACTURE', trim($_POST["Ecomfact"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_IMP_CATPROD',trim($_POST["EcomImpCat"]),'chaine',0,'',$conf->entity);
	dolibarr_set_const($db, 'ECOM_IMP_PRODIMPORT', trim($_POST["EcomImpProd"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_FRSPORT_TVA', trim($_POST["EcomPortTva"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_BATCH_USER', trim($_POST["EcomBatchUser"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_CB_PAYE', trim($_POST["EcomCB"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_CB_ACCOUNT', trim($_POST["EcomCBAccount"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_PAYPAL', trim($_POST["EcomPaypal"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_PAYPAL_ACCOUNT', trim($_POST["EcomPaypalAccount"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_PAYPAL_COM', trim($_POST["EcomPaypalCom"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_PAYBOX', trim($_POST["EcomPaybox"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_PAYBOX_ACCOUNT', trim($_POST["EcomPayboxAccount"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_PAYBOX_COM', trim($_POST["EcomPayboxCom"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_ONLINE_SEND_INVOICE', trim($_POST["EcomOnlineInvoice"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_PRODUCT_MUST_EXIST', trim($_POST["EcomProductMustExist"]), 'chaine', 0, '', $conf->entity);
    dolibarr_set_const($db, 'ECOM_DOLICAT',trim(GETPOST("EcomDoliCat2Ecom")),'chaine',0,'',$conf->entity);
	dolibarr_set_const($db, 'ECOM_PRODUCT_WITH_IMAGE', trim($_POST["EcomProductWithImage"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_SHOW_TOTAL_STOCK_COLUMN', trim($_POST["EcomShowTotalStockColumn"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_ORDER_PRESTA2DOLI', trim($_POST["EcomOrderPresta2doli"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_PRODUCT_PRESTA2DOLI', trim($_POST["EcomProductPresta2doli"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_ONLINE_PRODUCT_QTY_UPDATE', trim($_POST["EcomOnlineStock"]), 'chaine', 0, '', $conf->entity);
	dolibarr_set_const($db, 'ECOM_ONLINE_SYNCRO_PRODUCTS', trim($_POST["EcomOnlineSyncro"]), 'chaine', 0, '', $conf->entity);
}


/*
 * Affichage page
 */

llxHeader('', '', '', '',  0,  0, '', array("/ecommerce/css/ecommerce.css",1));
$html = new Form($db);
$htmlother = new FormOther($db);

// lecture
//$ecompayboxcom = dolibarr_get_const($db, "ECOM_PAYBOX_COM", $conf->entity);

//page
$linkback = '<a href="' . DOL_URL_ROOT . '/admin/modules.php">' . $langs->trans("BackToModuleList") . '</a>';
print load_fiche_titre($langs->trans("ECommerceSetup"), $linkback, 'ecommerce@ecommerce');

$head = ecommerce_prepare_head();

print dol_get_fiche_head($head, 'miscellaneous', $langs->trans("ECommerce"),-1, 'technic');

$var = true;
print '<form name="agilioconfig" action="' . $_SERVER["PHP_SELF"] . '" method="post">';

print '<input type="hidden" name="token" value="' . $_SESSION['newtoken'] . '">';
print '<table class="noborder centpercent">';
print '<tr class="noborder liste_titre">';
print '<th width="40%">' . $langs->trans("Parameter") . '</th>';
print '<th>' . $langs->trans("Value") . '</th>';
print '<th>' . $langs->trans("Examples") . '</th>';
print '</tr>';

//Invoicing Payed Orders
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParFactAuto") . '</td>';
print '<td>';
print $html->selectyesno("Ecomfact", $conf->global->ECOM_CREATE_FACTURE, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';

//Categories
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParImpCat") . '</td>';
print '<td>';
print $htmlother->select_categories(0, $conf->global->ECOM_IMP_CATPROD, 'EcomImpCat');
print '</td>';
print '<td>' . $langs->trans("ParEcomIdent");
print '</td>';
print '</tr>';

//CSV for products
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParImpProd") . '</td>';
print '<td>';
print $html->selectyesno("EcomImpProd", $conf->global->ECOM_IMP_PRODIMPORT, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';

//VAT portes
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParPortTva") . '</td>';
print '<td><input type="text" class="flat" name="EcomPortTva" value="' . $conf->global->ECOM_FRSPORT_TVA . '" size="10"></td>';
print '<td>' . $langs->trans("ParEcomTVA");
print '</td>';
print '</tr>';

//User batchs
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParBatchUser") . '</td>';
$sql = "SELECT login FROM " . MAIN_DB_PREFIX . "user where statut=1";
$resql = $db->query($sql);
if ($resql) {
	$login = array();
	$num = $db->num_rows($resql);
	$i = 0;

	while ($i < $num) {
		$objp = $db->fetch_object($resql);
		$login[$objp->login] = $objp->login;
		$i++;
	}
}
print '<td>' . $html->selectarray("EcomBatchUser", $login, $conf->global->ECOM_BATCH_USER, 1) . '</td>';
print '<td>' . $langs->trans("ParEcomLogin");
print '</td>';
print '</tr>';

//Credit Card paypment
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParCB") . '</td>';
print '<td>';
$html->select_types_paiements($conf->global->ECOM_CB_PAYE, 'EcomCB');
print '</td>';
print '<td>' . $langs->trans("ParEcomIdent");
print '</td>';
print '</tr>';
//++++
//Bank for credit card
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParCBAccount") . '</td>';
print '<td>';
$html->select_comptes($conf->global->ECOM_CB_ACCOUNT, 'EcomCBAccount', 0, "courant=1", 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomIdent");
print '</td>';
print '</tr>';
//---
//++
///+++
//Sending Dolibarr invoice to Prestashop
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParEcomSendInvoice") . '</td>';
print '<td>';
print $html->selectyesno("EcomOnlineInvoice", $conf->global->ECOM_ONLINE_SEND_INVOICE, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';
///---
//Verify ordered products
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParEcomProductMustExist") . '</td>';
print '<td>';
print $html->selectyesno("EcomProductMustExist", $conf->global->ECOM_PRODUCT_MUST_EXIST, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';
///++++
//---
//Sales products without image
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParProductWithImage") . '</td>';
print '<td>';
print $html->selectyesno("EcomProductWithImage", $conf->global->ECOM_PRODUCT_WITH_IMAGE, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';

// Show Stock total in site products page
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParEcomShowTotalStockColumn") . '</td>';
print '<td>';
print $html->selectyesno("EcomShowTotalStockColumn", $conf->global->ECOM_SHOW_TOTAL_STOCK_COLUMN, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';

// Use neworder event on prestashop
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParEcomOrderPresta2doli") . '</td>';
print '<td>';
print $html->selectyesno("EcomOrderPresta2doli", $conf->global->ECOM_ORDER_PRESTA2DOLI, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';

// Use neworder event on prestashop
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParEcomProductPresta2doli") . '</td>';
print '<td>';
print $html->selectyesno("EcomProductPresta2doli", $conf->global->ECOM_PRODUCT_PRESTA2DOLI, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';

//Update stock
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParEcomStockUpdate") . '</td>';
print '<td>';
print $html->selectyesno("EcomOnlineStock", $conf->global->ECOM_ONLINE_PRODUCT_QTY_UPDATE, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';

//Syncro data
$var = !$var;
print '<tr ' . $bc[$var] . '>';
print '<td>' . $langs->trans("ParEcomSyncroData") . '</td>';
print '<td>';
print $html->selectyesno("EcomOnlineSyncro", $conf->global->ECOM_ONLINE_SYNCRO_PRODUCTS, 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomYesNo");
print '</td>';
print '</tr>';
print '<tr ' . $bc[$var] . '>';
print '<td>&nbsp;</td>';
print '</tr>';

//Mass products export Dolibarr to Prestashop
if (!empty($conf->global->ECOMMERCE_EXPORT_DOLI2ECOM)) {
    $var = !$var;
    require_once(DOL_DOCUMENT_ROOT . "/categories/class/categorie.class.php");
    print '<tr class="disabled-row">';
    print '<td>' . $langs->trans("ParEcomCategoryUploads") . '</td>';
    print '<td>';
    print $html->select_all_categories(0, $conf->global->ECOM_DOLICAT, "EcomDoliCat2Ecom");
    print '</td>';
    print '<td>' . $langs->trans("ParEcomIdent");
    print '</td>';
    print '</tr>';
}
//Paypal payment
$var = !$var;
print '<tr class="disabled-row">';
print '<td>' . $langs->trans("ParPaypal") . '</td>';
print '<td>';
$html->select_types_paiements($conf->global->ECOM_PAYPAL, 'EcomPaypal');
print '</td>';
print '<td>' . $langs->trans("ParEcomIdent");
print '</td>';
print '</tr>';

//Bank for paypal
$var = !$var;
print '<tr class="disabled-row">';
print '<td>' . $langs->trans("ParPaypalAccount") . '</td>';
print '<td>';
$html->select_comptes($conf->global->ECOM_PAYPAL_ACCOUNT, 'EcomPaypalAccount', 0, "courant=1", 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomIdent");
print '</td>';
print '</tr>';

//Paypal commision
$var = !$var;
print '<tr class="disabled-row">';
print '<td>' . $langs->trans("ParPaypalCom") . '</td>';
print '<td><input type="text" class="flat" name="EcomPaypalCom" value="' . $conf->global->ECOM_PAYPAL_COM. '" size="10"></td>';
print '<td>' . $langs->trans("ParEcomVal") . ' %';
print '</td>';
print '</tr>';

//Paybox payment
$var = !$var;
print '<tr class="disabled-row">';
print '<td>' . $langs->trans("ParPaybox") . '</td>';
print '<td>';
$html->select_types_paiements($conf->global->ECOM_PAYBOX, 'EcomPaybox');
print '</td>';
print '<td>' . $langs->trans("ParEcomIdent");
print '</td>';
print '</tr>';

//Bank for paybox
$var = !$var;
print '<tr class="disabled-row">';
print '<td>' . $langs->trans("ParPayboxAccount") . '</td>';
print '<td>';
$html->select_comptes($conf->global->ECOM_PAYBOX_ACCOUNT, 'EcomPayboxAccount', 0, "courant=1", 1);
print '</td>';
print '<td>' . $langs->trans("ParEcomIdent");
print '</td>';
print '</tr>';

//Paybox commision
$var = !$var;
print '<tr class="disabled-row">';
print '<td>' . $langs->trans("ParPayboxCom") . '</td>';
print '<td><input type="text" class="flat" name="EcomPayboxCom" value="' . $conf->global->ECOM_PAYBOX_COM. '" size="10"></td>';
print '<td>' . $langs->trans("ParEcomVal") . ' %';
print '</td>';
print '</tr>';
///---
print '</table>';

print '<br><center>';
print '<input type="submit" name="save" class="button" value="' . $langs->trans("Save") . '">';
print '</center>';
print "</form>\n";

print '<br>';

clearstatcache();

// Footer
llxFooter();
// Close database handler
$db->close();

