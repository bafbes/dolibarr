<?php
/* Copyright (C) 2007  		Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2010-2012  Jean Heimburger     <jean@tiaris.info>
 * Copyright (C) 2011-2013  Philippe Grand      <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013 	Juanjo Menent		<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *        \file       htdocs/ecommerce/admin/site_admin.php
 *        \ingroup    ecommerce
 *        \brief      admin page of ecommerce module
 */

$res = @include("../main.inc.php");                        // For root directory
if (!$res) $res = @include("../../main.inc.php");
if (!$res) $res = @include("../../../main.inc.php");        // For "custom" directory
if (!$res) die;

require_once(DOL_DOCUMENT_ROOT . "/product/stock/class/entrepot.class.php");
dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/E_categorie.class.php");
dol_include_once("/ecommerce/class/ecom_manufacturer.class.php");
dol_include_once("/ecommerce/class/ecom_product.class.php");
dol_include_once("/ecommerce/class/ecom_params.class.php");
dol_include_once("/ecommerce/class/E_params.class.php");
dol_include_once("/ecommerce/class/ecom_html.class.php");
//dol_include_once("/ecommerce/class/ecom_customer_type.class.php");
dol_include_once("/ecommerce/class/webservice_ecom.class.php");
require_once(DOL_DOCUMENT_ROOT . "/product/class/html.formproduct.class.php");
require_once(DOL_DOCUMENT_ROOT . "/core/class/html.formfile.class.php");
require_once DOL_DOCUMENT_ROOT . '/core/class/html.formcompany.class.php';
dol_include_once('/ecommerce/core/lib/ecommerce.lib.php');

// Load traductions files requiredby by page
$langs->load("admin");
$langs->load("companies");
$langs->load("other");
$langs->load("sendings");
$langs->load("ecommerce@ecommerce");

$user->getrights('Ecommerce');
//print_r($user->rights);
if (!$user->rights->Ecommerce->admin) accessforbidden();


// Get parameters
$action = GETPOST('action', 'alpha');
$confirm = GETPOST('confirm', 'alpha');
$siteid = GETPOST('siteid', 'int');
$importtype = GETPOST('importtype', 'alpha');

// define dolibarr' order statuses
$doli_ordstat = array(0 => $langs->trans('DoliDraft'),
	1 => $langs->trans('DoliValid'),
	2 => $langs->trans('DoliProcess'),
	3 => $langs->trans('DoliClose'),
	-1 => $langs->trans('DoliCancel'),
	4 => $langs->trans('DoliBilled'),
	5 => $langs->trans('DoliPayed'));

//define prestashop order status in dolibar
$presta_ordstat = array(
//    0 => $langs->trans('DoliDraft'),
	-1 => $langs->trans('OrderStatusNull'),
	0 => $langs->trans('OrderStatusDraft'),
	1 => $langs->trans('OrderStatusValid'),
	2 => $langs->trans('OrderStatusTrait'),
	3 => $langs->trans('OrderStatusCloture'));

//hacemos consulta para seleccionar el iva
$sql = "SELECT t.rowid, c.code, t.taux";
$sql .= " FROM " . MAIN_DB_PREFIX . "c_tva t," . MAIN_DB_PREFIX . "c_country c ";
$sql .= " WHERE c.rowid = t.fk_pays AND t.taux!=0 AND t.fk_pays=" . $mysoc->country_id;
$sql .= " ORDER BY c.code, t.taux";

$resql = $db->query($sql);
if ($resql) {
	$tax = array();
	$num = $db->num_rows($resql);
	$i = 0;
	while ($i < $num) {
		$objp = $db->fetch_object($resql);
		$tax[$objp->rowid] = $objp->taux . '% - ' . $langs->transcountry("Country", $mysoc->country_code);
		$i++;
	}
}

//metodos de envio
$sql = "SELECT rowid, code,libelle FROM " . MAIN_DB_PREFIX . "c_shipment_mode WHERE active=1";

$resql = $db->query($sql);
if ($resql) {
	$shipment = array();
	$num = $db->num_rows($resql);
	$i = 0;
    while ($i < $num) {
        $objp = $db->fetch_object($resql);
        $key = "SendingMethod" . strtoupper($objp->code);
        $translated = $langs->trans($key);
        if($objp->code=='TRANS') $shipment[0] = $translated == $key ? $objp->libelle : $translated;
        $shipment[$objp->rowid] = $translated == $key ? $objp->libelle : $translated;
        $i++;
    }
}

// Protection if external user
if ($user->societe_id > 0) {
    //accessforbidden();
}

if (!$siteid) {
	$nexsiteid = 1;
	// recherche siteid suivant
	$sql = " SELECT max(rowid) AS maxrowid FROM " . MAIN_DB_PREFIX . "ecom_site";
	$result = $db->query($sql);
	if ($result) {
		$obj = $db->fetch_object($result);
		$nextsiteid = $obj->maxrowid + 1;
	}
	dol_syslog("creation ecom_site $sql  $langs->trans('Result')  " . $nextsiteid, LOG_DEBUG);
}
else {
	// get site_parameters
	$site_params = new Ecom_site($db);
	if ($site_params->fetch($siteid, $user) < 0) {
		$mesg = $site_params->error;
	}
}


/*
* Actions
*/

if ($action == 'create') {
	if (GETPOST("SiteName", 'alpha') != '') {
		$myobject = new Ecom_Site($db);
		$errors = 0;
		$myobject->fetch(GETPOST("SiteId", 'int'));
		// tester si le siteid n'est pas deja pris
		if ($myobject->id > 0) {
			$errors++;
			$mesg = $langs->trans("msgCreateSiteExist", $_POST["SiteId"], $myobject->site_url);
			setEventMessage($mesg, 'warnings');//"Le site identifie par ".$_POST["SiteId"]." existe deja : ".$myobject->site_url;
		}
		// tester existence de l'entrepot
		$entrepot = new Entrepot($db);
		$entrepot->fetch(GETPOST("SiteEntrepot", 'int'));
		if (!$entrepot->id) {
			$entrepot->ref = GETPOST("SiteName", 'alpha');
			$entrepot->libelle = GETPOST("SiteName", 'alpha');
			$entrepot->statut = 1;
			$result = $entrepot->create($user);

			if ($result > 0) {
				$mesg = "creation entrepot reussie $result " . GETPOST("SiteName", 'alpha');
				setEventMessage($mesg, 'mesgs');
				dol_syslog($mesg, LOG_DEBUG);
			}
			else {
				setEventMessage($langs->trans("msgCreateEntrepotKO"), 'warnings'); //"Impossible de creer un entrepot";
				$error++;
			}
		}
		if ($errors == 0) {
			$sitedate = dol_mktime(12, 0, 0, GETPOST('remonth'), GETPOST('reday'), GETPOST('reyear'));
			$myobject->id = GETPOST("SiteId", 'int');
			$myobject->site_name = GETPOST("SiteName", 'alpha');
			$myobject->site_url = GETPOST("SiteUrl", 'alpha');
			$myobject->site_ws_url = GETPOST("SiteWsUrl", 'alpha');
			$myobject->site_entrepot = GETPOST("SiteEntrepot", 'int');

			$myobject->site_startdate = $sitedate;
			$myobject->site_maxcategory = GETPOST("SiteMaxCategory", 'int');
			$myobject->site_maxorder = GETPOST("SiteMaxOrder", 'int');
			$myobject->site_maxproduct = GETPOST("SiteMaxProds", 'int');
			$myobject->site_maxclient = GETPOST("SiteMaxCustomers", 'int');
			$myobject->site_invoicetemplate = GETPOST("SiteInvoiceTemplate", 'int');
			$myobject->site_commercial = (GETPOST("SiteCommercial", 'int')) ? GETPOST("SiteCommercial", 'int') : 0;
			$myobject->site_customercategory = (GETPOST("SiteCustomerCategory", 'int')) ? GETPOST("SiteCustomerCategory", 'int') : 0;
			$myobject->site_prospectcategory = (GETPOST("SiteProspectCategory", 'int')) ? GETPOST("SiteProspectCategory", 'int') : 0;

			// on se connecte pour recuperer les infos sur le site
			dol_include_once('/ecommerce/class/webservice_ecom.class.php');
			$soap_client = new webservice_ecom($myobject->site_ws_url, 'ws_test.php');
			$p = array();
			$soap_client->ws_call('get_module_info', $p);

			//TODO test resultats
			if (!$soap_client->resko) {
				$myobject->site_ecom_system = $soap_client->ws_data["ecommerce"];
				$myobject->site_ecom_system_version = $soap_client->ws_data["ecom_version"];
				$myobject->site_ecom_module_version = $soap_client->ws_data["module_version"];
			}
			else {
				setEventMessage($langs->trans("ErrWSConnect"), 'warnings');
			}

			// Creation
			$result = $myobject->create($user);
			dol_syslog("creation ecom_site $result", LOG_DEBUG);
			if ($result > 0) {
				// Creation OK
				setEventMessage($langs->trans("msgCreateSiteOK", GETPOST("SiteName", 'alpha'), GETPOST("SiteUrl", 'alpha')), 'mesgs');//"Creation du site ".$_POST["SiteName"]." ".$_POST["SiteUrl"];
				Header('Location: site_admin.php?siteid=' . $myobject->id);
			}
			else {
				// Creation KO
				setEventMessage($langs->trans("msgCreateSiteKO", $myobject->error), 'warnings');//"Erreur creation site ".$myobject->error;
			}

		}
	}
}

if ($confirm == 'no') {
	$siteid = 0;
}

if ($action == 'confirm_delete' && $confirm == 'yes') {
	//$mesg = "Suppresion du site ".$siteid;
	if ($siteid) {
		$e_par = new E_params($db, $siteid, $user);
		if ($e_par->delete_site($siteid) > 0) Header('Location: site_admin.php');
	}
}

// modification des parametres d'un site
if ($action == 'modifSite') {
	$sitedate = dol_mktime(12, 0, 0, GETPOST('remonth', 'int'), GETPOST('reday', 'int'), GETPOST('reyear', 'int'));
	$ecomsite = new Ecom_Site($db);
	$ecomsite->id = $siteid;
	$ecomsite->site_name = GETPOST("SiteName", 'alpha');
	$ecomsite->site_url = GETPOST("SiteUrl", 'alpha');
	$ecomsite->site_ws_url = GETPOST("SiteWsUrl", 'alpha');
	$ecomsite->site_entrepot = GETPOST("SiteEntrepot", 'int');
	$ecomsite->site_startdate = $sitedate;
	$ecomsite->site_maxcategory = GETPOST("SiteMaxCategory", 'int');
	$ecomsite->site_maxorder = GETPOST("SiteMaxOrder", 'int');
	$ecomsite->site_maxproduct = GETPOST("SiteMaxProds", 'int');
	$ecomsite->site_maxclient = GETPOST("SiteMaxCustomers", 'int');
	$ecomsite->site_invoicetemplate = GETPOST("SiteInvoiceTemplate", 'int');
	$ecomsite->site_commercial = (GETPOST("SiteCommercial", 'int')) ? GETPOST("SiteCommercial", 'int') : 0;
	$ecomsite->site_customercategory = (GETPOST("SiteCustomerCategory", 'int')) ? GETPOST("SiteCustomerCategory", 'int') : 0;
	$ecomsite->site_prospectcategory = (GETPOST("SiteProspectCategory", 'int')) ? GETPOST("SiteProspectCategory", 'int') : 0;

	dol_syslog("mise a jour ecom_site webservice Entrepot " . print_r($_POST, true), LOG_DEBUG);
	// on se connecte pour recuperer les infos sur le site
	dol_include_once("/ecommerce/class/webservice_ecom.class.php");
	$soap_client = new webservice_ecom($ecomsite->site_ws_url, 'ws_test.php');
	$p = array();
	$soap_client->ws_call('get_module_info', $p);

	//TODO test resultats
	if (!$soap_client->resko) {
		$ecomsite->site_ecom_system = $soap_client->ws_data["ecommerce"];
		$ecomsite->site_ecom_system_version = $soap_client->ws_data["ecom_version"];
		$ecomsite->site_ecom_module_version = $soap_client->ws_data["module_version"];
	}
	else {
		$mesg = $langs->trans("connexion impossible aux webservices");
		setEventMessage($mesg, 'warnings');
	}

	$result = $ecomsite->update($user);
	dol_syslog("mise a jour ecom_site $result", LOG_DEBUG);
	if ($result > 0) {
		// Creation OK
//		$mesg = "modification du site ".$_POST["SiteName"]." ".$_POST["SiteUrl"];
	}
	else {
		// Creation KO
		$mesg = $langs->trans("msgModifSiteKO", $ecomsite->error);
		setEventMessage($mesg, 'warnings');    //"Erreur modification site ".$ecomsite->error;
	}
}

if ($siteid) {
	// get site_parameters
	$site_params = new Ecom_site($db);
	if ($site_params->fetch($siteid, $user) < 0) {
		$mesg = $site_params->error;
		setEventMessage($mesg, 'warnings');
	}
	else {

	}
}

// import all
if ($action == 'ImportAll') {
	$error = 0;
	$mesg = '';

	$e_par = new E_params($db, $siteid, $user);

	// supplier
	$res = $e_par->get_suppliers();
	if ($res != 1) {
		$errorr++;
		$mesg .= " supplier ko <br/>";
		setEventMessage($mesg, 'warnings');
	}

	//Taxe rates
	$res = $e_par->get_taxrates();
	if ($res != 1) {
		$error++;
		setEventMessage($langs->trans("ErrImportNewTaxes", $e_par->error), 'warnings');
	}
	// Order status
	$res = $e_par->get_orderstatus();
	if ($res != 1) {
		$error++;
		setEventMessage($langs->trans("ErrImportNewOrdersStatus", $e_par->error), 'warnings');
	}

	// Local Status
	$res = $e_par->set_localorderstatus($doli_ordstat);
	if ($res != 1) {
		$errorr++;
		setEventMessage($langs->trans("ErrImportLocalOrdersStatus", $e_par->error), 'warnings');
	}

	// product_options
	$res = $e_par->get_products_option();
	if ($res != 1) {
		$error++;
		setEventMessage($langs->trans("ErrImportNewProductOptions", $e_par->error), 'warnings');
	}
	// product options values
	$res = $e_par->get_products_optionvals();
	if ($res != 1) {
		$error++;
		setEventMessage($langs->trans("ErrImportNewProductOptionsVals", $e_par->error), 'warnings');
	}
	// shipping methods
	$res = $e_par->get_expedition_meths();
	if ($res != 1) {
		$error++;
		setEventMessage($langs->trans("ErrImportNewExpeditions", $e_par->error), 'warnings');
	}

	// manufacturers
	$res = $e_par->get_manufacturers();
	if ($res != 1) {
		$error++;
		setEventMessage($langs->trans("ErrImportNewManofacturers", $e_par->error), 'warnings');
	}
	// Categories
	$ecat = new E_categorie($db, $siteid, $user);
	if ($ecat->import_new_cats($limit) < 0) {
		$error++;
		setEventMessage($langs->trans("ErrImportNewCat", $ecat->error), 'warnings');
	}

	// client types
	$res = $e_par->get_customers_type();
	if ($res != 1) {
		$errorr++;
		setEventMessage($langs->trans("ErrImportClientTypes", $epar->error), 'warnings');
	}
	// Product features
	$res = $e_par->get_product_features();
	if ($res != 1) {
		$errorr++;
		setEventMessage($langs->trans("ErrImportProductFeatures", $epar->error), 'warnings');
	}

	if (!$error) {
		setEventMessage($langs->trans("msgSiteImportAll", 'ok'), 'mesgs');
	}
	else {
		setEventMessage($langs->trans("msgSiteImportAll", $error . ' ' . $langs->trans("ErrError")), 'warnings');
	}

}

// modification d'un parametre
if ($action == 'ParModify') {

	$parrowid = GETPOST('parrowid', 'int');
	$dolid = GETPOST('dolid', 'int');
	$ecomlib = GETPOST('ecomlib');
	$ecomid = GETPOST('ecomid');

	$mesg = $parrowid . " - " . $ecomlib . " - " . $dolid;
	setEventMessage($mesg, 'mesgs');
	$e_par = new Ecom_params($db);
	$e_par->fetch($parrowid);
	if ($ecomlib) $e_par->ecom_lib = $ecomlib;
	$e_par->doli_id = $dolid;
	if ($ecomid) $e_par->ecom_id = $ecomid;
	if ($e_par->update($user) < 0) $mesg = $langs->trans("MajKo") . $_POST["ecomlib"];
	else $mesg = '';
	setEventMessage($mesg, 'warnings');

	header("Location: " . $_SERVER['PHP_SELF'] . "?siteid=" . $siteid . "&action=edit");
	exit;

}

// gestion des fournisseurs
if ($action == 'SupplierModify') {
	$parrowid = GETPOST('parrowid', 'int');
	$dolid = GETPOST('dolid', 'int');

	$e_manu = new Ecom_manufacturer($db);
	if ($e_manu->fetch($parrowid) < 0) {
		$mesg = "Error getting ecom_manufacturer";
		setEventMessage($mesg, 'warnings');
	}
	else {
		$e_manu->doli_manufacturer = $dolid;
		if ($e_manu->update($user) < 0) $mesg = $langs->trans("MajKo") . " supplier " . $e_manu->doli_manufacturer;
		setEventMessage($mesg, 'warnings');
	}

	header("Location: " . $_SERVER['PHP_SELF'] . "?siteid=" . $siteid . "&action=edit");
	exit;

}

// parametrage types clients
if ($action == "CliTypeModify") {
	$cat_id = GETPOST("doli_cat_id", "int");
	$typent_id = GETPOST("doli_typent_id", "int");
	$tarif_id = GETPOST("doli_tarif_id", "int");
	$parrowid = GETPOST('parrowid', 'int');

	$mesg = " ecom_lib " . $_POST["ecom_lib"] . " - categorie " . $cat_id . " : " . $_POST["doli_cat_id"] . " - tarif " . $tarif_id . " : " . $_POST["toli_tarif_id"] . " - typent " . $typent_id . " : " . $_POST["doli_typent_id"];
	setEventMessage($mesg, 'warnings');
	dol_syslog(basename(__FILE__) . $mesg, LOG_DEBUG);
	$e_custtype = new Ecom_customer_type($db);
	$e_custtype->fetch($parrowid);

	if (!empty($catid)) {
		$e_custtype->doli_cat_id = ($cat_id < 0) ? 0 : $cat_id;
		dol_syslog(basename(__FILE__) . ":: on passe dans cat " . $cat_id, LOG_DEBUG);
	}
	if (!empty($typent_id)) {
		$e_custtype->doli_typent_id = ($typent_id < 0) ? 0 : $typent_id;
		dol_syslog(basename(__FILE__) . ":: on passe dans typent " . $typent_id, LOG_DEBUG);
	}
	if (!empty($tarif_id)) {
		$e_custtype->doli_tarif_id = ($tarif_id < 0) ? 0 : $tarif_id;
		dol_syslog(basename(__FILE__) . ":: on passe dans tarif " . $tarif_id, LOG_DEBUG);
	}

	if ($e_custtype->update($user) < 0) {
		$mesg .= $langs->trans("MajKo");
		setEventMessage($mesg, 'warnings');
		dol_syslog(basename(__FILE__) . 'Action ' . $_REQUEST["action"] . "  " . $mesg . "  " . $e_custtype->error, LOG_DEBUG);
	}
	else $mesg = '';
	header("Location: " . $_SERVER['PHP_SELF'] . "?siteid=" . $siteid . "&action=edit");
	exit;
}

/*
 * DB requests
 *
 */

// get user list
$sql = "SELECT u.rowid, u.login, u.lastname, u.firstname, u.admin";
$sql .= " FROM " . MAIN_DB_PREFIX . "user AS u";
$sql .= " WHERE u.entity IN (0," . $conf->entity . ")";
$sql .= " ORDER BY u.lastname";

$result = $db->query($sql);
if ($result) {
	$num = $db->num_rows($result);
	$i = 0;
	while ($i < $num) {
		$obj = $db->fetch_object($result);
		$username = $obj->lastname;
		$uss[$obj->rowid] = ucfirst(stripslashes($username)) . ' ' . ucfirst(stripslashes($obj->firstname));
		if ($obj->login) $uss[$obj->rowid] .= ' (' . $obj->login . ')';
		$i++;
	}
}

// Ecome orderstatuses
$ecom_ordstat = array();
$sql = "SELECT ecom_id as id, ecom_lib as lib FROM " . MAIN_DB_PREFIX . "ecom_params WHERE siteid = '" . $siteid . "' AND partype ='ordstat' ";
$result = $db->query($sql);
if ($result) {
	while ($obj = $db->fetch_object($result)) {
		$ecom_ordstat[$obj->id] = $obj->lib;
	}
}

// get supplier list
$sql = "SELECT rowid, ecom_manufacturer, ecom_manuname, doli_manufacturer FROM " . MAIN_DB_PREFIX . "ecom_manufacturer WHERE siteid = '" . $siteid . "' AND manutype = '1' ";
dol_syslog("requête $sql", LOG_DEBUG);
$result = $db->query($sql);

$ecom_suppliers = array();

if ($result) {
	while ($obj = $db->fetch_object($result)) {
		$ecom_suppliers[] = $obj;
	}
}
else {
	$msg .= " Error reading suppliers $sql";
}

//TODO Type clients
/*
$sql = "SELECT c.rowid, c.siteid, c.ecom_id, c.ecom_lib, c.doli_cat_id, c.doli_typent_id, c.doli_tarif_id";
$sql.= " FROM ".MAIN_DB_PREFIX."ecom_customer_type AS c";
$sql.= " WHERE c.siteid ='".$siteid."'";
$sql.= " ORDER BY c.rowid";

$result = $db->query($sql);
if ($result)
{
	while ($obj = $db->fetch_object($result))
	{
		$tab_clitype[] = $obj;
	}
}
else dol_syslog(__FILE__." Error sql client types ".$sql. LOG_ERR);
*/


// get product features
$ecom_html = new Ecom_html($db);

$sql = "SELECT ep.rowid, ep.ecom_id, ep.ecom_lib, ep.doli_id ";
$sql .= "FROM " . MAIN_DB_PREFIX . "ecom_params ep ";
$sql .= "WHERE ep.partype = 'prdfeat' AND ep.siteid = '" . $siteid . "'";

$result = $db->query($sql);
if ($result) {
	while ($obj = $db->fetch_object($result)) {
		$tab_prodfeatures[] = $obj;
	}
}
else dol_syslog(__FILE__ . " Error sql client types " . $sql . LOG_ERR);

// dolibarr product extrafileds list
$sql = "SELECT rowid as id, label as lib  FROM " . MAIN_DB_PREFIX . "extrafields where elementtype = 'product'";
$result = $db->query($sql);
if ($result) {
	while ($obj = $db->fetch_object($result)) {
		$tab_extrafields[$obj->id] = $langs->trans($obj->lib);
	}
}
else dol_syslog(__FILE__ . " Error sql extrafields types " . $sql . LOG_ERR);

$liste_extrafield = $ecom_html->ecom_ddform($siteid, $sql, "dolid");

/*
 * View
 */

$morejs = array();
$morecss = array("/admin/dolistore/css/dolistore.css");


$help_url = 'EN:First_setup|FR:Premiers_paramétrages|ES:Primeras_configuraciones';
llxHeader('', $langs->trans("Setup"), $help_url, '', '', '', $morejs, $morecss, 0, 'mod-admin page-modules');

$form = new Form($db);
$formproduct = new FormProduct($db);
$formfile = new FormFile($db);
$formcompany = new FormCompany($db);
$ecom_html = new Ecom_html($db);

//page
$linkback = '<a href="' . DOL_URL_ROOT . '/admin/modules.php">' . $langs->trans("BackToModuleList") . '</a>';
print load_fiche_titre($langs->trans("ECommerceSetup"), $linkback, 'ecommerce@ecommerce');

print $formconfirm;
$head = ecommerce_prepare_head();
print dol_get_fiche_head($head, 'newsite', $langs->trans("ECommerce"),-1,'building');

// Début Paramètres du site
/*// Requete SQL récupérant les modeles de facture activés
$sql = 'SELECT dm.nom, dm.rowid';
$sql .= ' FROM ' . MAIN_DB_PREFIX . 'document_model as dm';
$sql .= ' WHERE dm.type = "invoice"';

dol_syslog("site_admin select_modeles sql=" . $sql, LOG_DEBUG);

$resqlinvoice = $db->query($sql);

// Stock le nombre de modèles de facture activés
$numinvoice = $db->num_rows($resqlinvoice);
*/

if ($siteid && $action != 'delete') {
    print '<table class="noborder centpercent">';
    print '<tr class="noborder liste_titre">';
	print '<td colspan="2" align="center">' . $site_params->site_name . '</td>';
	print '<td colspan="2"><a href="' . $site_params->site_url . '" target="_blank">' . $site_params->site_url . '</a></td>';
	print "</tr>\n";
	// affichage donnees du site
	print '<tr><td colspan="4">';
    print '<tr class="liste_titre"><td >'.$langs->trans("SiteEcomType").'</td><td >'.$langs->trans("SiteEcomVersion").'</td><td>';
    print $langs->trans("SiteEcomModuleVersion").'</td><td></td></tr>';
	print '<tr><td >' . $langs->trans("SiteEcomType") . " : " . $site_params->site_ecom_system . '</td>';
	print '<td>' . $langs->trans("SiteEcomVersion") . " : " . $site_params->site_ecom_system_version . '</td>';
	print '<td>' . $langs->trans("SiteEcomModuleVersion") . " : " . $site_params->site_ecom_module_version . '</td></tr>';

    print '</td></tr>' . "\n";

//	print '<tr><td>&nbsp;</td></tr>';
	print '<form action="" name="modifSite" >';
	print '<input type="hidden" name="action" value="modifSite">';
	print '<input type="hidden" name="siteid" value="' . $siteid . '">';

	print '<tr class="liste_titre">';
	print '<td class="liste_titre"><h4>' . $langs->trans("Parameters") . '</td>';
	print '<td class="liste_titre" colspan="2"><h4>' . $langs->trans("Value") . '</td>';
	print '<td class="liste_titre"><h4>' . $langs->trans("Examples") . '</td>';
	print '</tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteId") . '</td>';
	print '<td colspan="2">' . $siteid . '</td>';
	print '<td>' . $langs->trans("AutoIncrement") . '</td>';
	print '</tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteName") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteName" value="' . $site_params->site_name . '" size="40"></td>';
	print '<td>My Ecommerce';
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteUrl") . "</td>";
	print '<td colspan="2"><input type="text" class="flat" name="SiteUrl" value="' . $site_params->site_url . '" size="40"></td>';
	print '<td>http://www.ecommerce.com/';
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteWsUrl") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteWsUrl" value="' . $site_params->site_ws_url . '" size="40"></td>';
	print '<td>http://www.ecommerce.com/modules/dolipresta/';
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteEntrepot") . '</td>';
	if ($conf->stock->enabled) {
		print '<td colspan="2">';
		print $formproduct->selectWarehouses($site_params->site_entrepot, 'SiteEntrepot', '', 1);
		/* TODO		if ($result <= 0)
				{
					print ' &nbsp; No warehouse defined, <a href="'.DOL_URL_ROOT.'/product/stock/fiche.php?action=create">add one</a>';
				}*/
		print '</td>';
	}
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteDate") . '</td>';
	print '<td colspan="2">';
	print $form->select_date($site_params->site_startdate, '', '', '', '', "add", 1, 1);
	print '<td>01/01/2011';
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteMaxCategory") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteMaxCategory" value="' . $site_params->site_maxcategory . '" size="40"></td>';
	print '<td>' . $langs->trans("ANumber");
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteMaxOrder") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteMaxOrder" value="' . $site_params->site_maxorder . '" size="40"></td>';
	print '<td>' . $langs->trans("ANumber");
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteMaxProds") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteMaxProds" value="' . $site_params->site_maxproduct . '" size="40"></td>';
	print '<td>' . $langs->trans("ANumber");
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteMaxCustomers") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteMaxCustomers" value="' . $site_params->site_maxclient . '" size="40"></td>';
	print '<td>' . $langs->trans("ANumber");
	print '</td></tr>';
/*
	// Liste permettant de choisir le modele de facture a activer
	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteInvoiceTemplate") . '</td>';

	if ($conf->facture->enabled) {
		print '<td colspan="2">';
		print '<select class="flat" name="SiteInvoiceTemplate">';
		while ($row = $db->fetch_array($resqlinvoice)) {
			print '<option value="' . $row["nom"] . '"';
			if ($site_params->site_invoicetemplate == $row["nom"]) print ' selected="selected"';
			print '>';
			print $row["nom"];
			print '</option>';
		};
		print '</select>';
		print '</td>';
	}

	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';
    */
    //TODO tester si gestion des categories
	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteCustomersCat") . '</td>';
	print '<td colspan="2">';
	print $form->select_all_categories(2, $site_params->site_customercategory, 'SiteCustomerCategory');
	print '</td>';
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteProspectsCat") . '</td>';
	print '<td colspan="2">';
	print $form->select_all_categories(2, $site_params->site_prospectcategory, 'SiteProspectCategory');
	print '</td>';
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteCommercial") . '</td>';
	print '<td colspan="2">';
	print $form->selectarray("SiteCommercial", $uss, $site_params->site_commercial, 1);
	print '</td>';
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';
	print '</table>';

	print '<div class="tabsAction">';
	print '<input type="submit" name="save" class="button" value="' . $langs->trans("Save") . '">';
	print '</div><br>';

	print '</form>';
// Fin Paramètres du site

// Début Section import des paramètres
	print '<table class="liste" width="100%">';
	print '<tr class="liste_titre">';
	print '<td colspan="3" align="center"><h3>' . $langs->trans("Configurations") . '</td></tr>';
	print '<tr><td colspan="3" align="center"><form action="" name="ImportAll">';
	print '<input type="hidden" name="action" value="ImportAll">';
	print '<input type="hidden" name="siteid" value="' . $siteid . '">';

	print '<input type="submit" class="button" value="' . $langs->trans("Import") . '">';

	print '</form>';
	print '</td></tr>';
	print '</table>';

	print '<br>';
// Fin Section import des paramètres

// taxes
	print '<table class="liste" width="100%">';
	print '<tr class="liste_titre">';
	print '<td colspan="6" align="center"><h3>' . $langs->trans('ParamsTaxes') . '</td></tr>';

	$sql = "SELECT ep.rowid, ep.ecom_id, ep.ecom_lib, ep.doli_id ";
	$sql .= "FROM " . MAIN_DB_PREFIX . "ecom_params ep ";
	$sql .= "WHERE ep.partype = 'taxrate' AND ep.siteid = '" . $siteid . "'";

	dol_syslog("site_admin modif_params sql=" . $sql, LOG_DEBUG);

	$resql = $db->query($sql);
	if ($resql) {
		$num = $db->num_rows($resql);
		print '<tr class="liste_titre"><td class="liste_titre"><h4>' . $langs->trans('ParEcomId') . '</td><td class="liste_titre"><h4>' . $langs->trans('ParEcomLib') . '</td>';
		print '<td class="liste_titre" colspan="2"><h4>' . $langs->trans('ParDoliId') . '</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
		$i = 0;
		if ($num) {
			$var = True;
			while ($i < $num) {
				$obj = $db->fetch_object($resql);

				$var = !$var;

				if ($obj) {
					print '<tr ' . $bc[$var] . '><form action="">';
					print '<td>' . $obj->ecom_id . '</td>';
					print '<td><input type="text" size="20" name="ecomlib" value="' . $obj->ecom_lib . '"/></td>';
					print '<td>' . $form->selectarray("dolid", $tax, $obj->doli_id, 1) . '</td>';
					print '<input type="hidden" name="parrowid" value="' . $obj->rowid . '"/>';
					print '<input type="hidden" name="siteid" value="' . $siteid . '"/>';
					print '<input type="hidden" name="action" value="ParModify"/>';
					print '<td>&nbsp;</td>';
					print '<td>&nbsp;</td>';
					print '<td><input class="button" type="submit" value="' . $langs->trans("Modify") . '"></td>';
					print '</form></tr>';
				}
				$i++;

			}
		}
	}

// Début Order status
//	print '<tr><td>&nbsp;</td></tr>';
	print '<tr class="liste_titre"><td colspan="6" align="center"><h3>' . $langs->trans('ParamsOrderstatus') . '</td></tr>';

	$sql = "SELECT ep.rowid, ep.ecom_id, ep.ecom_lib, ep.doli_id ";
	$sql .= "FROM " . MAIN_DB_PREFIX . "ecom_params ep ";
	$sql .= "WHERE ep.partype = 'ordstat' AND ep.siteid = '" . $siteid . "'";

	dol_syslog("site_admin modif_params sql=" . $sql, LOG_DEBUG);

	$resql = $db->query($sql);
	if ($resql) {
		$num = $db->num_rows($resql);
		print '<tr class="liste_titre"><td class="liste_titre"><h4>' . $langs->trans('ParEcomId') . '</td><td class="liste_titre"><h4>' . $langs->trans('ParEcomLib') . '</td>';
		print '<td class="liste_titre" colspan="2"><h4>' . $langs->trans('ParDoliId') . '</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
		$i = 0;
		if ($num) {
			$var = True;
			while ($i < $num) {
				$obj = $db->fetch_object($resql);

				$var = !$var;

				if ($obj) {
					print '<tr ' . $bc[$var] . '><form action="">';
					print '<td>' . $obj->ecom_id . '</td>';
					print '<td><input type="text" size="40" name="ecomlib" value="' . $obj->ecom_lib . '"/></td>';
					print '<td>' . $form->selectarray("dolid", $presta_ordstat, $obj->doli_id, 1) . '</td>';
					//print '<td><input type="text" size="3" name="dolid" value="'.$obj->doli_id.'"/></td>';
					print '<input type="hidden" name="parrowid" value="' . $obj->rowid . '"/>';
					print '<input type="hidden" name="siteid" value="' . $siteid . '"/>';
					print '<input type="hidden" name="action" value="ParModify"/>';
					print '<td>&nbsp;</td>';
					print '<td>&nbsp;</td>';
					print '<td><input class="button" type="submit" value="' . $langs->trans("Modify") . '"></td>';
					print '</form></tr>';
				}
				$i++;

			}
		}
	}

// Fin Order status
/*
    //	print '<tr><td>&nbsp;</td></tr>';
        print '<tr class="liste_titre"><td colspan="6" align="center"><h3>' . $langs->trans('ParamsOrderstatusMAJ') . '</td></tr>';

        $sql = "SELECT ep.rowid, ep.ecom_id, ep.ecom_lib, ep.doli_id ";
        $sql .= "FROM " . MAIN_DB_PREFIX . "ecom_params ep ";
        $sql .= "WHERE ep.partype = 'ecomstat' AND ep.siteid = '" . $siteid . "'";

        dol_syslog("site_admin Local order status sql=" . $sql, LOG_DEBUG);

        $resql = $db->query($sql);
        if ($resql) {
            $num = $db->num_rows($resql);
            print '<tr class="liste_titre"><td><h4>' . $langs->trans('ParDoliOrderStatus') . '</td><td><h4>' . $langs->trans('EcomOrderStatus') . '</td>';
            print '<td colspan="4">&nbsp;</td></tr>';
            $i = 0;
            if ($num) {
                $var = True;
                while ($i < $num) {
                    $obj = $db->fetch_object($resql);

                    $var = !$var;

                    if ($obj) {
                        print '<tr ' . $bc[$var] . '><form action="">';
                        print '<td>' . $obj->ecom_id . '</td>';
                        print '<td><input type="text" size="40" name="ecomlib" value="' . $obj->ecom_lib . '"/></td>';
                        print '<td>' . $form->selectarray("ecomid", $ecom_ordstat, $obj->ecom_id, 1) . '</td>';
                        print '<td>&nbsp;</td>';
                        print '<input type="hidden" name="dolid" value="' . $obj->doli_id . '"/>';
                        print '<input type="hidden" name="parrowid" value="' . $obj->rowid . '"/>';
                        print '<input type="hidden" name="action" value="ParModify"/>';
                        print '<input type="hidden" name="siteid" value="' . $siteid . '"/>';
                        print '<td>&nbsp;</td>';
                        print '<td><input class="button" type="submit" value="' . $langs->trans("Modify") . '"></td>';
                        print '</form></tr>';

                    }
                    $i++;

                }
            }
        }
        print '</td>';
*/
// Début Shipping methods
    //	print '<tr><td>&nbsp;</td></tr>';
        print '<tr class="liste_titre"><td colspan="6" align="center"><h3>' . $langs->trans('ParamsExpMeths') . '</td></tr>';

        $sql = "SELECT ep.rowid, ep.ecom_id, ep.ecom_lib, ep.doli_id ";
        $sql .= "FROM " . MAIN_DB_PREFIX . "ecom_params ep ";
        $sql .= "WHERE ep.partype = 'expmeth' AND ep.siteid = '" . $siteid . "'";

        dol_syslog("site_admin modif_params sql=" . $sql, LOG_DEBUG);

        $resql = $db->query($sql);
        if ($resql) {
            $num = $db->num_rows($resql);
            print '<tr class="liste_titre"><td class="liste_titre"><h4>' . $langs->trans('ParEcomId') . '</td><td class="liste_titre"><h4>' . $langs->trans('ParEcomLib') . '</td>';
            print '<td class="liste_titre" colspan="2"><h4>' . $langs->trans('ParDoliId') . '</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
            $i = 0;
            if ($num) {
                $var = True;
                while ($i < $num) {
                    $obj = $db->fetch_object($resql);

                    $var = !$var;

                    if ($obj) {
                        print '<tr ' . $bc[$var] . '><form action="">';
                        print '<td>' . $obj->ecom_id . '</td>';
                        print '<td><input type="text" size="20" name="ecomlib" value="' . $obj->ecom_lib . '"/></td>';
                        //print '<td><input type="text" size="3" name="dolid" value="'.$obj->doli_id.'"/></td>';
                        print '<td>' . $form->selectarray("dolid", $shipment, $obj->doli_id, 1) . '</td>';
                        print '<input type="hidden" name="parrowid" value="' . $obj->rowid . '"/>';
                        print '<input type="hidden" name="action" value="ParModify"/>';
                        print '<input type="hidden" name="siteid" value="' . $siteid . '"/>';
                        print '<td>&nbsp;</td>';
                        print '<td>&nbsp;</td>';
                        print '<td><input class="button" type="submit" value="' . $langs->trans("Modify") . '"></td>';
                        print '</form></tr>';
                    }
                    $i++;
                }
            }
        }
// Fin Shipping methods

//TODO Suppliers

    if (count($ecom_suppliers) > 0) {
    //	print '<tr><td>&nbsp;</td></tr>';
        print '<tr class="liste_titre"><td colspan="5" align="center"><h3>' . $langs->trans('ParamsSupplier') . '</td></tr>';

        print '<tr class="liste_titre"><td class="liste_titre"><h4>' . $langs->trans('ParEcomId') . '</td><td class="liste_titre"><h4>' . $langs->trans('ParSupplierLib') . '</td><td class="liste_titre" colspan="2"><h4>' . $langs->trans('ParDoliId') . '</td><td>&nbsp;</td></tr>';
            $var = True;
            foreach ($ecom_suppliers as $obj) {
                print '<tr ' . $bc[$var] . '><form action="">';
                print '<td>' . $obj->ecom_manufacturer . '</td>';
                print '<td>' . $obj->ecom_manuname . '</td>';
                print '<td>' . $form->select_company($obj->doli_manufacturer, 'dolid', 's.fournisseur = 1', 1) . '</td>';


                //print '<td><input type="text" size="3" name="dolid" value="'.$obj->doli_manufacturer.'"/></td>';
                print '<input type="hidden" name="parrowid" value="' . $obj->rowid . '"/>';
                print '<input type="hidden" name="siteid" value="' . $siteid . '"/>';
                print '<input type="hidden" name="action" value="SupplierModify"/>';
                print '<td>&nbsp;</td>';
                print '<td><input class="button" type="submit" value="' . $langs->trans("Modify") . '"></td>';
                print '</form></tr>';
            }

        }

//TODO Type clients
/*    //	print '<tr><td>&nbsp;</td></tr>';
        print '<tr class="liste_titre"><td colspan="5" align="center"><h3>' . $langs->trans('ParamsClientType') . '</td></tr>';

        print '<tr class="liste_titre"><td class="liste_titre"><h4>' . $langs->trans('ParEcomId') . '</td><td class="liste_titre"><h4>' . $langs->trans('ParEcomLib') . '</td><td class="liste_titre" ><h4>' . $langs->trans('ParDoliCustCatId') . '</td>';
        print '<td class="liste_titre">';

        if (!empty($conf->global->PRODUIT_MULTIPRICES))
            print '<td class="liste_titre" >' . $langs->trans('ParDoliTarifId');
        else
            print '&nbsp;';

        print '</td><td>&nbsp;</td></tr>';

        if (count($tab_clitype) > 0) {
            $var = True;
            $tab_typent = $formcompany->typent_array(0);
            foreach ($tab_clitype as $elt) {
                print '<form action="">';
                print '<tr ' . $bc[$var] . '>';
                print '<td>' . $elt->ecom_id . '</td><td>' . $elt->ecom_lib . '</td>';
    //			print '<td>'.$form->select_all_categories(2, $elt->doli_cat_id, 'doli_cat_id' ).'</td>';
                print '<td>';
                print $form->selectarray("doli_typent_id", $tab_typent, $elt->doli_typent_id, 1);
                print '</td>';
                print '<td>';
                if (!empty($conf->global->PRODUIT_MULTIPRICES)) {

                    print '<select name="doli_tarif_id" class="flat">';
                    print '<option value="-1"></option>';
                    for ($i = 1; $i <= $conf->global->PRODUIT_MULTIPRICES_LIMIT; $i++) {
                        print '<option value="' . $i . '"';
                        if ($i == $elt->doli_tarif_id)
                            print 'selected';
                        print '>' . $i . '</option>';
                    }
                }
                else {
                    print '&nbsp;';
                }
                print '</td>';
                print '<input type="hidden" name="action" value="CliTypeModify"/>';
                print '<input type="hidden" name="siteid" value="' . $siteid . '"/>';
                print '<input type="hidden" name="parrowid" value="' . $elt->rowid . '"/>';
                print '<td><input class="button" type="submit" value="' . $langs->trans("Modify") . '"></td>';
                print '</tr></form>';
                $var = !$var;
            }
            //print '</table></td>'."\n";
        }
    //	}
        print '</tr>';
*/
//TODO  product features
/*//	print '<tr><td>&nbsp;</td></tr>';
	print '<tr class="liste_titre"><td colspan="6" align="center"><h3>'.$langs->trans('ParamsProductFeatures').'</td></tr>';

	if (count($tab_prodfeatures) > 0)
	{
		$var=True;
		dol_syslog("extrafield ".print_r($tab_extrafields,true));
		foreach ($tab_prodfeatures as $feature)
		{
			print '<tr '.$bc[$var].'><form action="">';
			print '<td>'.$feature->ecom_id.'</td>';
			print '<td><input type="text" size="20" name="ecomlib" value="'.$feature->ecom_lib.'"/></td>';
			//print '<td><input type="text" size="3" name="dolid" value="'.$feature->doli_id.'"/></td>';
			//print '<td>'.$liste_extrafield.'</td>';
			print '<td>'.$form->selectarray("dolid",$tab_extrafields, $feature->doli_id ,1 ).'</td>';
			print '<input type="hidden" name="parrowid" value="'.$feature->rowid.'"/>';
			print '<input type="hidden" name="action" value="ParModify"/>';
			print '<input type="hidden" name="siteid" value="'.$siteid.'"/>';
			print '<td>&nbsp;</td>';
			print '<td>&nbsp;</td>';
			print '<td><input class="button" type="submit" value="'.$langs->trans("Modify").'"></td>';
			print '</form></tr>';
			$var=!$var;
		}
	}*/
/*
	print '</td></tr>';
	print '</table>';
	print '<div class="tabsAction">';
	print '<input type="submit" class="button" value="'.$langs->trans("Import").'">';
	print '</div>';

	print '</form>';
*/

}
elseif ($action == 'addSite') {
	//mode création
    print '<table class="noborder centpercent">';
    print '<tr class="noborder liste_titre">';
	print '<td class="liste_titre">' . $langs->trans("CreateSite") . '</td>';
	print '<td class="liste_titre" colspan="2">' . $langs->trans("Value") . '</td>';
	print '<td class="liste_titre">' . $langs->trans("Examples") . '</td>';
	print '</tr>';
	print '<form action="site_admin.php" name="create">';
	print '<input type="hidden" name="token" value="' . $_SESSION['newtoken'] . '">';
	print '<input type="hidden" name="action" value="create"';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteId") . "</td>";
	print '<td colspan="2"><input type="hidden" name="SiteId" value="' . $nextsiteid . '"></td>';
	print '<td>' . $langs->trans("AutoIncrement");
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteName") . '</td>';
	print '<td colspan="2"><input type="text" autofocus="" required="" placeholder=' . $langs->trans("SiteName") . ' class="flat" name="SiteName" value="' . $site_params->site_name . '" size="40"></td>';
	print '<td>My Ecommerce';
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteUrl") . "</td>";
	print '<td colspan="2"><input type="text" class="flat" required="" placeholder="http://www.ecommerce.com/" name="SiteUrl" value="' . $site_params->site_url . '" size="40"></td>';
	print '<td>http://www.ecommerce.com/';
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteWsUrl") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" required="" placeholder="http://www.ecommerce.com/modules/dolipresta/" name="SiteWsUrl" value="' . $site_params->site_ws_url . '" size="40"></td>';
	print '<td>http://www.ecommerce.com/modules/dolipresta/';
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteEntrepot") . '</td>';
	if ($conf->stock->enabled) {
		print '<td colspan="2">';
		print $formproduct->selectWarehouses($site_params->site_entrepot, 'SiteEntrepot', '', 1);
		/* TODO		if ($result <= 0)
				{
					print ' &nbsp; No warehouse defined, <a href="'.DOL_URL_ROOT.'/product/stock/fiche.php?action=create">add one</a>';
				}
		*/
		print '</td>';
	}
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteDate") . '</td>';
	print '<td colspan="2">';
	print $form->select_date($site_params->site_startdate, '', '', '', '', "add", 1, 1);
	print '<td>01/01/2010';
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteMaxCategory") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteMaxCategory" value="' . $site_params->site_maxcategory . '" size="40"></td>';
	print '<td>' . $langs->trans("ANumber");
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteMaxOrder") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteMaxOrder" value="' . $site_params->site_maxorder . '" size="40"></td>';
	print '<td>' . $langs->trans("ANumber");
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteMaxProds") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteMaxProds" value="' . $site_params->site_maxproduct . '" size="40"></td>';
	print '<td>' . $langs->trans("ANumber");
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteMaxCustomers") . '</td>';
	print '<td colspan="2"><input type="text" class="flat" name="SiteMaxCustomers" value="' . $site_params->site_maxclient . '" size="40"></td>';
	print '<td>' . $langs->trans("ANumber");
	print '</td></tr>';

/*	// Liste permettant de choisir le modele de facture a activer
	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteInvoiceTemplate") . '</td>';

	if ($conf->facture->enabled) {
		print '<td colspan="2">';
		print '<select class="flat" name="site_invoicetemplate">';
		while ($row = $db->fetch_array($resqlinvoice)) {
			print '<option value="' . $row["rowid"] . '"';
			if ($site_params->site_invoicetemplate == $row["nom"]) print ' selected="selected"';
			print '>';
			print $row["nom"];
			print '</option>';
		}
		print '</select>';
		print '</td>';
	}
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';
*/
	//TODO tester si gestion des categories
	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteCustomersCat") . '</td>';
	print '<td colspan="2">';
	print $form->select_all_categories(2, $site_params->site_customercategory, 'SiteCustomerCategory');
	print '</td>';
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';

	print '<tr class="impair">';
	print '<td>' . $langs->trans("SiteProspectsCat") . '</td>';
	print '<td colspan="2">';
	print $form->select_all_categories(2, $site_params->site_prospectcategory, 'SiteProspectCategory');
	print '</td>';
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';

	print '<tr class="pair">';
	print '<td>' . $langs->trans("SiteCommercial") . '</td>';
	print '<td colspan="2">';
	print $form->selectarray("SiteCommercial", $uss, $site_params->site_commercial, 1);
	print '</td>';
	print '<td>' . $langs->trans("SelectOne");
	print '</td></tr>';
	/*print '<td colspan="5" align="center"><input class="button" type="submit" name="save" value="'.$langs->trans("Save").'"></td>';
	print '</tr>';
	print '</form>';
	print '<tr><td>&nbsp;</td></tr>';*/
	print '</table>';
	print '<div class="tabsAction">';
	print '<input type="submit" name="save" class="button" value="' . $langs->trans("Add") . '">';
	print '</<div>';
	print "</form>";

}
else {
	print '<form action="' . $_SERVER["PHP_SELF"] . '">';
	print '<input type="hidden" name="token" value="' . $_SESSION['newtoken'] . '">';
	print '<input type="hidden" name="action" value="addSite">';
    print '<table class="noborder centpercent">';
    print '<tr class="noborder liste_titre">';
	print '<td class="liste_titre">' . $langs->trans('SiteOrderId') . '</td>';
	print '<td class="liste_titre">' . $langs->trans('SiteName') . '</td>';
	print '<td class="liste_titre">' . $langs->trans('SiteUrl') . '</td>';
	print '<td class="liste_titre">' . $langs->trans('SiteEcomVersion') . '</td>';
	print '<td class="liste_titre">' . $langs->trans('Warehouse') . '</td>';
	print '<td class="liste_titre">&nbsp;</td>';
	print '<td class="liste_titre">&nbsp;</td>';
	print '</tr>';

	$sql = "SELECT s.rowid, site_url, site_name, site_ecom_system_version, CONCAT_WS('-',e.ref,e.lieu) as description";
	$sql .= " FROM " . MAIN_DB_PREFIX . "ecom_site s";
	//con LEFT JOIN sale seguro todos los sitios configurados, aunque no tengan almacen configurado
	$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "entrepot e on e.rowid = s.site_entrepot";
	$sql .= " WHERE s.entity=" . $conf->entity;

	dol_syslog("site_admin select sites sql=" . $sql, LOG_DEBUG);


	$resql = $db->query($sql);
	if ($resql) {
		$num = $db->num_rows($resql);
		$i = 0;
		if ($num) {
			$var = True;
			while ($i < $num) {
				$obj = $db->fetch_object($resql);
				if ($obj) {
					$var = !$var;
					print '<tr ' . $bc[$var] . '>';
					print '<td>' . $obj->rowid . '</td>';
					print '<td>' . $obj->site_name . '</td>';
					print '<td><a href="' . $obj->site_url . '" target="_blank">' . $obj->site_url . '</a></td>';
					print '<td>' . $obj->site_ecom_system_version . '</td>';
					//Si el almacen no esta correctamente configurado sale un mensaje al respecto
					if (empty($obj->description)) {
						print '<td>' . $langs->trans("ErrorWarehouseNoConf") . '</td>';
					}
					else {
						print '<td>' . $obj->description . '</td>';
					}

					print '<td align="center"><a href="' . $_SERVER["PHP_SELF"] . '?siteid=' . $obj->rowid . '&amp;action=edit">' . img_edit() . '</a></td>';
					print '<td align="center"><a href="' . $_SERVER["PHP_SELF"] . '?siteid=' . $obj->rowid . '&amp;action=delete">' . img_delete() . '</a></td>';
					print '</tr>' . "\n";
				}
				$i++;
			}
		}
	}
	print '</table>';
	print '<div class="tabsAction">';
	print '<input type="submit" name="save" class="button" value="' . $langs->trans("Add") . '">';
	print '</<div>';
	print "</form>";

	//Delete a site
	if ($action == 'delete') {
		print $form->form_confirm("site_admin.php?siteid=" . $siteid, $langs->trans('deleteSiteShort', $site_params->site_name), $langs->trans("deleteSite"), "confirm_delete", '', 0, 2);

	}

}

$db->close();
llxFooter();