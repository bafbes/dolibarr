<?php
$res = @include("../../../main.inc.php");                                // For "custom" directory
if (!$res) $res = @include("../../main.inc.php");
if (!$res) $res = @include("../main.inc.php");                        // For root directory
dol_include_once('/ecommerce/core/lib/ecommerce.lib.php');

$user->getrights('Ecommerce');

if (!$user->rights->Ecommerce->admin) accessforbidden();

llxHeader();
//page
$linkback = '<a href="' . DOL_URL_ROOT . '/admin/modules.php">' . $langs->trans("BackToModuleList") . '</a>';
print load_fiche_titre($langs->trans("ECommerceSetup"), $linkback, 'ecommerce@ecommerce');
print $formconfirm;
$head = ecommerce_prepare_head();
print dol_get_fiche_head($head, 'consistency', $langs->trans("ECommerce"),-1,'task');
// Create connection
$conn = new mysqli($presta_main_db_host, $presta_main_db_user, $presta_main_db_pass, $presta_main_db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully<br>";
// sql to delete a record
if (isset($_GET['deleteattributeswithoutproducts'])) {
    $sql = "delete from ps_product_attribute where id_product=0";

    if ($conn->query($sql) === TRUE) {
        $sql = "SELECT ROW_COUNT() nb AS DELETED";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {$row = $result->fetch_assoc();}
        echo (empty($row["nb"])||$row["nb"]<1? 0 : $row["nb"]) . " records deleted successfully";
    }
    else {
        echo "Error deleting record: " . $conn->error;
    }
}
if (isset($_GET['fixattributereferencesindouble'])) {
    $sql = "select reference,count(*) c from ps_product_attribute group by reference HAVING c > 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "Reference: " . $row["reference"] . " - repetitions: " . $row["c"] . "<br>";
            $rows[$row["reference"]] = $row["c"];
        }
    }
    else {
        echo "0 results";

    }
    var_dump($rows);
    foreach ($rows as $ref => $value) {
        $sql = "select id_product_attribute from ps_product_attribute where reference='$ref'";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $ids[] = $row["id_product_attribute"];
        }
        $i = 1;
        foreach ($ids as $id) {
            $sql = "update ps_product_attribute set reference=concat(reference,'-',$i) where id_product_attribute=$id";
            $result = $conn->query($sql);
            $i++;
        }
    }
    echo '<br>Fixed';
}

$conn->close();
