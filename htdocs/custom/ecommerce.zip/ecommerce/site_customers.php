<?php
/* Copyright (C) 2007 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2008 Jean Heimburger	   <jean@tiaris.fr>
 * Copyright (C) 2011-2013 Philippe Grand  <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2013 Juanjo Menent	<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *    \file       ecommerce/site_customers.php
 *    \ingroup    ecommerce
 *        \brief      Customers Management for e-commerce site
 *        \author        Jean Heimburger www.tiaris.fr
 */

require_once("./pre.inc.php");

dol_include_once("/ecommerce/class/ecom_site.class.php");
dol_include_once("/ecommerce/class/E_product.class.php");
require_once(DOL_DOCUMENT_ROOT . "/product/class/product.class.php");

// Load traductions files requiredby by page
$langs->load("companies");
$langs->load("other");
$langs->load("ecommerce@ecommerce");


// Protection if external user
$socid = GETPOST('socid', 'int');
if ($user->societe_id) $socid = $user->societe_id;
$result = restrictedArea($user, 'societe', $socid);

// Get parameters
$siteid = isset($_GET["siteid"]) ? $_GET["siteid"] : '';

if ($siteid) {
// get site_parameters
	$site_params = new Ecom_site($db);
	if ($site_params->fetch($siteid, $user) < 0) {
		$mesg = '<div class="error">' . "Erreur lecture site" . '</div>';
	}
	else {
	}
}

// Pagination
$sortfield = GETPOST("sortfield", 'alpha');
$sortorder = GETPOST("sortorder", 'alpha');
if (!$sortfield) $sortfield = "ec.ecom_customer";
if (!$sortorder) $sortorder = "ASC";

$page = GETPOST("page", 'int');
$limit = GETPOST("limit", 'int') ? GETPOST("limit", 'int') : $conf->liste_limit;
$offset = GETPOST("offset", 'int') ? GETPOST("offset", 'int') : 0;

/*
* Actions
*/

if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'import') {
// import a customer
	/*
		$mesg = "traitement de l'import de ".$_POST['ecomid'];
		$e_prod = new E_product($db, $siteid, $user);
		if ($e_prod->wsfetch($_POST['ecomid'],'') < 0) print "erreur ".$e_prod->error."\n";
		else
		{
			$prod = new Product($db);
			$prod = $e_prod->ecom2dolibarr($_POST['ecomid']);
			if (!$prod) $mesg = $mesg . "\nErreur ecom2dolibarr \n";

			  else
			  {
				  $id = $prod->create($user);
				  if ($id > 0)
				  {
					$mesg = $mesg . "\n produit cr�� ".$id."\n";
					  $ecom_prod = new Ecom_product($db);
					  $res = $ecom_prod->fetchprodid($_POST['ecomid'], $user);
					  if ($res == 1)
					  {
						  $ecom_prod->doli_product = $id;
						  if ($ecom_prod->update($user) == -1) $mesg = $mesg . "\nErreur update ".$ecom_prod->error."\n";
					  }
					  else $mesg = $mesg . "\n ecom_product non trouv� ".$id."\n";
				}
				else $mesg = $mesg . "\n erreur cr�ation produit ".$prod->error."\n";
			}
		}
	*/
}

if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'modif') {
// Modify a customer
	$mesg = '<div class="error">' . $langs->trans("NoDispo") . ' ' . $_POST['ecomid'] . '</div>';
}


/*
 * View
 */

llxHeader();

$form = new Form($db);

//if ($mesg) print '<p><div class="warning">'.$mesg.'</div></p>';

$text = $langs->trans("SiteArea");

print_fiche_titre($text, '', 'ecommerce@ecommerce');
$h = 0;
$head = array();

$head[$h][0] = dol_buildpath('/ecommerce/site_customers.php?siteid=' . $siteid, 1);
$head[$h][1] = $site_params->site_name;
$head[$h][2] = 'ecommerce';
$h++;

dol_fiche_head($head, 'ecommerce', $langs->trans("SiteCustomerAdmin"));

print '<form action="' . $_SERVER['PHP_SELF'] . '?siteid=' . $siteid . '" method="POST">';
print '<input type="hidden" name="siteid" value="' . $siteid . '">';
print '<input type="hidden" name="action" value="resetlimitoffset">';
print 'Nombre d\'enregistrements : ';
print '<input type="text" id="limit" name="limit" value="'.$limit.'">';
print 'Décalage depuis la fin : ';
print '<input type="text" id="offset" name="offset" value="'.$offset.'">';
print '<input class="button" type="submit" value="' . $langs->trans("Update") . '">';
print '</form>';


$sql = "SELECT ec.ecom_customer,  ec.doli_soc, s.nom, s.town, s.fk_pays, p.code ";
$sql .= "FROM " . MAIN_DB_PREFIX . "ecom_customer ec ";
$sql .= "LEFT OUTER JOIN " . MAIN_DB_PREFIX . "societe s ON s.rowid = ec.doli_soc ";
$sql .= " LEFT JOIN " . MAIN_DB_PREFIX . "c_country p ON p.rowid = s.fk_pays ";
$sql .= " WHERE ec.siteid = '" . $siteid . "' AND ec.site_cust_status = 'C'";
$sql .= "ORDER BY ec.ecom_customer DESC ";
$sql .= $db->plimit($limit + 1, $offset);

dol_syslog("site_customers:: sql=" . $sql, LOG_DEBUG);

$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	//entete
	$param = '&siteid=' . $siteid;
	$texte = '';
//	print_barre_liste($texte, $page, "site_customers.php", $param, $sortfield, $sortorder, '', $num);
	print '<table class="notopnoleftnoright" width="100%">';
	print '<tr class="liste_titre">';
	print '<td colspan="6" align="center"><h3>' . $langs->trans("SiteCustomerAdmin") . '</td>';
	print '</tr>';
	print '<tr><td width="8%"><b>' . $langs->trans("SiteCustId") . '</td>';
	print '<td width="26%"><b>' . $langs->trans("SiteCustName") . '</td>';
	print '<td width="20%"><b>' . $langs->trans("SiteCustTown") . '</td>';
	print '<td width="18%"><b>' . $langs->trans("SiteCustCountry") . '</td>';
	print '<td width="18%"><b>' . $langs->trans("DoliCustId") . '</td>';
	//the button does nothing now, edit the other widths
	//print '<td width="15%">'.$langs->trans("ImportModify").'</td>';
	print '</tr>';

	$i = 0;
	if ($num) {
		$var = True;
		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			if ($obj) {
				print '<tr ' . $bc[$var] . '>';
				print '<td>' . $obj->ecom_customer . '</td>';
				print '<td><a href="' . DOL_URL_ROOT . '/societe/card.php?socid=' . $obj->doli_soc . '" target=_blank>' . $obj->nom . '</a></td>';

				print '<td>' . $obj->town . '</td>';

				print '<td>' . $langs->trans("Country" . $obj->code) . '</td>';

				print '<td><a href="' . DOL_URL_ROOT . '/societe/card.php?socid=' . $obj->doli_soc . '" target=_blank>' . $obj->doli_soc . '</a></td>';

				//the button does nothing now
				/*print '<td><form action="site_customers.php?siteid='.$siteid.'"method="POST">';
				if ($obj->doli_soc)
				{
					$lib = $langs->trans("Modify") ;
					print '<input type="hidden" name="action" value="modif">';
					print '<input type="hidden" name="ecomid" value="'.$obj->ecom_customer.'">'	;

				}
				else
				{
					$lib=	$langs->trans("Import")	;
					print '<input type="hidden" name="action" value="import">';
					print '<input type="hidden" name="ecomid" value="'.$obj->ecom_customer.'">'	;
				}
				print '<input class="button" type="submit" value="'.$lib.'">';
				print '</form></td>'; //bouton import*/
				print '</tr>';
			}
			$i++;
			$var = !$var;
		}
		if ($num > $conf->liste_limit) {
			print '<input type="hidden" name="siteid" value="' . $siteid . '" />';
			print_barre_liste($texte, $page, "site_customers.php", '&siteid=' . $siteid, '', '', '', $num);
		}
	}
	print '</table>';
}


//print '<br/><br/>';
/*
// les prospects
	if (version_compare(DOL_VERSION, "3.4.0") >= 0) $sql = "SELECT ec.ecom_customer,  ec.doli_soc, s.nom, s.town, s.fk_pays, p.libelle ";
	else $sql = "SELECT ec.ecom_customer,  ec.doli_soc, s.nom, s.ville, s.fk_pays, p.libelle ";
	$sql .= "FROM ".MAIN_DB_PREFIX."ecom_customer ec ";
	$sql .= "LEFT OUTER JOIN ".MAIN_DB_PREFIX."societe s ON s.rowid = ec.doli_soc ";
	$sql .= " JOIN ".MAIN_DB_PREFIX."c_pays p ON p.rowid = s.fk_pays ";
	$sql .= " WHERE ec.siteid = '".$siteid."' AND ec.site_cust_status = 'P'";
	$sql .= "ORDER BY ec.rowid DESC ";
	$sql .= $db->plimit($limit + 1 ,$offset);

	$resql=$db->query($sql);
	if ($resql)
	{
		$num = $db->num_rows($resql);
		$texte= '';
		$param = '&siteid='.$siteid;
		print_barre_liste($texte, $page, "site_customers.php", $param, $sortfield, $sortorder,'',$num);

		print '<table class="notopnoleftnoright" width="100%">';
		print '<tr class="liste_titre">';
		print '<td colspan="6" align="center">'.$langs->trans("SiteProspectAdmin").'</td>';
		print '</tr>';
		print '<tr><td width="15%">'.$langs->trans("SiteCustId").'</td>';
		print '<td width="15%">'.$langs->trans("SiteCustName").'</td>';
		print '<td width="15%">'.$langs->trans("SiteCustTown").'</td>';
		print '<td width="15%">'.$langs->trans("SiteCustCountry").'</td>';
		print '<td width="15%">'.$langs->trans("DoliCustId").'</td>';
		print '<td width="15%">'.$langs->trans("ImportModify").'</td></tr>';

		$i = 0;
		if ($num)
		{
			$var=True;
			while ($i < $num)
			{
				$obj = $db->fetch_object($resql);
				if ($obj)
				{
					print '<tr '.$bc[$var].'>';
					print '<td>'.$obj->ecom_customer.'</td>';
					print '<td>'.$obj->nom.'</td>'; //Nom
					print '<td>'.$obj->ville.'</td>';
					print '<td>'.$obj->libelle.'</td>';

					if (version_compare(DOL_VERSION, '3.7.0') >= 0){
						print '<td><a href="'.DOL_URL_ROOT.'/societe/soc.php?socid='.$obj->doli_soc.'">'.$obj->doli_soc.'</a></td>';
					} else {
						print '<td><a href="'.DOL_URL_ROOT.'/comm/fiche.php?socid='.$obj->doli_soc.'">'.$obj->doli_soc.'</a></td>';
					}

					print '<td align="center"><form action="site_customers.php?siteid='.$siteid.'"method="POST">';
					if ($obj->doli_soc)
					{
						$lib = "modifier";
						print '<input type="hidden" name="action" value="modif">';
						print '<input type="hidden" name="ecomid" value="'.$obj->ecom_customer.'">'	;

					}
    				else
    				{
						$lib=	$langs->trans("Import")	;
						print '<input type="hidden" name="action" value="import">';
						print '<input type="hidden" name="ecomid" value="'.$obj->ecom_customer.'">'	;
					}
					print '<input class="button" type="submit" value="'.$lib.'">';
					print '</form></td>'; //bouton import
					print '</tr>';
				}
				$i++;
				$var=!$var;
			}
			if ($num > $conf->liste_limit)
			{
				print '<input type="hidden" name="siteid" value="'.$siteid.'" />';
				print_barre_liste($texte, $page, "site_customers.php",'&siteid='.$siteid,'','','',$num);
			}
		print '</table>';
		}
	}
*/
// End of page
if ($mesg) dol_htmloutput_mesg($mesg);

llxFooter();

$db->close();


