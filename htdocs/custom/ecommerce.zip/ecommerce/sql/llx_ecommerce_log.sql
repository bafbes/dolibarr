-- ===================================================================
-- Copyright (C) 2005 Laurent Destailleur  <eldy@users.sourceforge.net>
-- Copyright (C) 2008-2009 Jean Heimburger <jean@tiaris.info>
-- Copyright (C) 2011-2013 	Philippe Grand <philippe.grand@atoo-net.com>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--
-- ===================================================================

CREATE TABLE llx_ecom_log
(
    rowid        int(11) unsigned NOT NULL auto_increment,
    site_id      int(2)           NOT NULL,
    log_date     datetime,
    log_fct      varchar(3),
    log_type     varchar(10),
    log_fonction varchar(255),
    log_message  text,
    PRIMARY KEY (rowid)
) ENGINE = InnoDB COMMENT ='Table de log des fonctions du module dolibarr';
