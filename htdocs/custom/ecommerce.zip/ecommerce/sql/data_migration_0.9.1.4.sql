-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--
-- $Id: migration_01.sql,v 1.1 2011-10-17 14:46:43 tiaris Exp $
-- ===================================================================

-- migration from 0.9.1.3 
ALTER TABLE llx_ecom_site
    ADD COLUMN site_commercial INT(11) NULL AFTER site_maxclient;
ALTER TABLE llx_ecom_site
    ADD COLUMN site_customercategory INT(11) NULL AFTER site_commercial;
ALTER TABLE llx_ecom_site
    ADD COLUMN site_prospectcategory INT(11) NULL AFTER site_customercategory;
ALTER TABLE llx_ecom_site
    ADD COLUMN site_ecom_system VARCHAR(50) NULL AFTER site_prospectcategory;
ALTER TABLE llx_ecom_site
    ADD COLUMN site_ecom_system_version VARCHAR(20) NULL AFTER site_ecom_system;
ALTER TABLE llx_ecom_site
    ADD COLUMN site_ecom_module_version VARCHAR(20) NULL AFTER site_ecom_system_version;
ALTER TABLE llx_ecom_site
    ADD COLUMN site_maxcategory INT(2) DEFAULT 1 AFTER site_startdate;
--migration for order table
ALTER TABLE llx_ecom_order
    ADD COLUMN exp_meth varchar(50) default null;
ALTER TABLE llx_ecom_order
    ADD COLUMN exp_meth_id int(11) default 0;
-- migration ajout modele de facture par site
ALTER TABLE llx_ecom_site
    ADD COLUMN site_invoicetemplate varchar(50) default null;
-- correction for columns
ALTER TABLE llx_ecom_site
    MODIFY COLUMN site_ecom_system VARCHAR(50) DEFAULT NULL;
ALTER TABLE llx_ecom_site
    MODIFY COLUMN site_ecom_system_version VARCHAR(20) DEFAULT NULL;
ALTER TABLE llx_ecom_site
    MODIFY COLUMN site_ecom_module_version VARCHAR(20) DEFAULT NULL;
-- le statut de commande est un entier
ALTER TABLE llx_ecom_order
    MODIFY COLUMN site_order_status INTEGER NOT NULL DEFAULT 0;
-- add parentid to categories table
ALTER TABLE llx_ecom_categories
    ADD COLUMN ecom_parentid integer NOT NULL AFTER doli_catid;
-- references sur 32 car
ALTER TABLE llx_ecom_product
    MODIFY COLUMN doli_ref VARCHAR(32) DEFAULT NULL;
ALTER TABLE llx_ecom_product
    MODIFY COLUMN ecom_ref VARCHAR(32) DEFAULT NULL;
ALTER TABLE llx_ecom_product
    MODIFY COLUMN ecom_attribut VARCHAR(72) NOT NULL default '';
