ALTER TABLE llx_ecom_order
    MODIFY COLUMN site_order_status INTEGER DEFAULT 0;
-- gestion fabricants manutype = 0 et furnisseurs manutype = 1
ALTER TABLE llx_ecom_manufacturer
    ADD COLUMN manutype int not null default '0' AFTER siteid;
-- modif gestion type client
ALTER TABLE llx_ecom_customer_type
    ADD COLUMN doli_typent_id INTEGER NOT NULL DEFAULT 0 AFTER doli_cat_id;
-- add parentid to categories table
ALTER TABLE llx_ecom_categories
    ADD COLUMN ecom_parentid integer NOT NULL AFTER doli_catid;
-- add end date to product
ALTER TABLE llx_ecom_product
    ADD COLUMN date_send datetime default NULL AFTER datem;
ALTER TABLE llx_ecom_product
    ADD COLUMN date_modif DATETIME default NULL AFTER date_send;
ALTER TABLE llx_ecom_product
    ADD COLUMN ecom_manuf integer DEFAULT NULL AFTER long_desc;
ALTER TABLE llx_ecom_product
    ADD COLUMN ecom_category integer DEFAULT NULL AFTER ecom_manuf;
ALTER TABLE llx_ecom_product
    ADD COLUMN ecom_price decimal(12, 5) NOT NULL DEFAULT 0.0 AFTER ecom_category;
ALTER TABLE llx_ecommerce_log
    MODIFY COLUMN log_message TEXT DEFAULT 0;

--MultiCompany
ALTER TABLE llx_ecom_site
    ADD COLUMN entity integer DEFAULT 1 AFTER rowid;
