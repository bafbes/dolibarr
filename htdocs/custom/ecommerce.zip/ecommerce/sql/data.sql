INSERT INTO `llx_c_paiement` (`id`, `entity`, `code`, `libelle`, `type`, `active`, `accountancy_code`, `module`, `position`) VALUES
(6,	1,	'CB',	'Credit card',	2,	1,	NULL,	NULL,	0),
(105,	1,	'PPL',	'Paiement par ligne',	2,	1,	NULL,	NULL,	0);


INSERT INTO `llx_ecom_params` (`rowid`, `siteid`, `partype`, `ecom_id`, `ecom_lib`, `doli_id`) VALUES
(1,	1,	'taxrate',	1,	'TVA FR 20%',	2462),
(2,	1,	'taxrate',	2,	'TVA FR 10%',	2463),
(3,	1,	'taxrate',	3,	'TVA FR 5.5%',	2464),
(4,	1,	'taxrate',	4,	'TVA FR 2.1%',	2465);

INSERT INTO `llx_ecom_params` (`rowid`, `siteid`, `partype`, `ecom_id`, `ecom_lib`, `doli_id`) VALUES
(37,	1,	'ordstat',	6,	'Annulé',	-1),
(48,	1,	'ordstat',	17,	'Autorisation. A capturer par le marchand',	1),
(58,	1,	'ordstat',	27,	'Disponible en boutique',	1),
(50,	1,	'ordstat',	19,	'En attente de capture',	1),
(53,	1,	'ordstat',	22,	'En attente de capture Stripe',	1),
(44,	1,	'ordstat',	13,	'En attente de paiement à la livraison',	1),
(46,	1,	'ordstat',	15,	'En attente de paiement par Carte de Créd',	1),
(47,	1,	'ordstat',	16,	'En attente de paiement par moyen de paie',	1),
(45,	1,	'ordstat',	14,	'En attente de paiement par PayPal',	1),
(57,	1,	'ordstat',	26,	'En attente de paiement PayPal',	1),
(51,	1,	'ordstat',	20,	'En attente de paiement Sofort',	1),
(43,	1,	'ordstat',	12,	'En attente de réapprovisionnement (non p',	1),
(40,	1,	'ordstat',	9,	'En attente de réapprovisionnement (payé)',	1),
(41,	1,	'ordstat',	10,	'En attente de virement bancaire',	1),
(32,	1,	'ordstat',	1,	'En attente du paiement par chèque',	1),
(59,	1,	'ordstat',	28,	'En cours d’expédition',	2),
(34,	1,	'ordstat',	3,	'En cours de préparation',	2),
(39,	1,	'ordstat',	8,	'Erreur de paiement',	1),
(35,	1,	'ordstat',	4,	'Expédié',	2),
(36,	1,	'ordstat',	5,	'Livré',	3),
(42,	1,	'ordstat',	11,	'Paiement à distance accepté',	1),
(33,	1,	'ordstat',	2,	'Paiement accepté',	2),
(38,	1,	'ordstat',	7,	'Remboursé',	-1),
(49,	1,	'ordstat',	18,	'Remboursement partiel',	-1),
(52,	1,	'ordstat',	21,	'Remboursement partiel Stripe',	-1),
(60,	1,	'ordstat',	29,	'Remis au transporteur',	2),
(55,	1,	'ordstat',	24,	'SEPA dispute',	1),
(56,	1,	'ordstat',	25,	'Waiting for OXXO payment confirmation',	1),
(54,	1,	'ordstat',	23,	'Waiting for SEPA payment',	1);
