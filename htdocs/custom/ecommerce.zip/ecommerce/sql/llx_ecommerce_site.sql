-- ===================================================================
-- Copyright (C) 2005 Laurent Destailleur  <eldy@users.sourceforge.net>
-- Copyright (C) 2008-2009 Jean Heimburger <jean@tiaris.info>
-- Copyright (C) 2013      Philippe Grand  <philippe.grand@atoo-net.com>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--
-- ===================================================================

CREATE TABLE llx_ecom_site
(
    rowid                    int(11) unsigned NOT NULL auto_increment,
    site_url                 varchar(100)     NOT NULL,
    site_name                varchar(100)     NOT NULL,
    site_ws_url              varchar(100)     NOT NULL,
    site_ws_user             varchar(50),
    site_ws_pwd              varchar(20),
    site_entrepot            int(2)           NOT NULL,
    site_startdate           datetime,
    site_maxcategory         int(2)      DEFAULT 1 COMMENT 'nombre de cat�gories � importer � la fois',
    site_maxorder            int(2)      DEFAULT 1 COMMENT 'nombre de commandes � importer � la fois',
    site_maxproduct          int(2)      DEFAULT 1 COMMENT 'nombre de produits � importer � la fois',
    site_maxclient           int(2)      DEFAULT 1 COMMENT 'nombre de clients � importer � la fois',
    site_commercial          int(11)          null,
    site_customercategory    int(11)          null,
    site_prospectcategory    int(11)          null,
    site_ecom_system         varchar(50)      null,
    site_ecom_system_version varchar(20)      null,
    site_ecom_module_version varchar(20)      null,
    site_invoicetemplate     varchar(50) default null,
    PRIMARY KEY (rowid)
) ENGINE = InnoDB COMMENT ='Table de d�finition des sites e-com';
