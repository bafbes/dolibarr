-- ===================================================================
-- Copyright (C) 2005 Laurent Destailleur  <eldy@users.sourceforge.net>
-- Copyright (C) 2010-2012 Jean Heimburger <jean@tiaris.info>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--
-- ===================================================================

CREATE TABLE llx_ecom_contact
(
    rowid           int(11) unsigned NOT NULL auto_increment,
    siteid          int(2)           NOT null default '0',
    ecom_cust_id    int(11)          NOT NULL default '0',
    ecom_address_id int(11)          NOT NULL default '0',
    doli_contact_id int(11)          NOT NULL default '0',
    datem           datetime                  default NULL,
    PRIMARY KEY (rowid)
) ENGINE = InnoDB COMMENT ='Table de correspondance contacts et adresses sites e-com';
