-- ===================================================================
-- Copyright (C) 2005 Laurent Destailleur  <eldy@users.sourceforge.net>
-- Copyright (C) 2008-2009 Jean Heimburger <jean@tiaris.info>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--
-- $Id: llx_ecommerce_customer.sql,v 1.1 2011-06-13 12:04:39 tiaris Exp $
-- ===================================================================

CREATE TABLE llx_ecom_customer
(
    rowid                int(11) unsigned NOT NULL auto_increment,
    siteid               int(2)           NOT null default '0',
    doli_soc             int(11)              NULL default '0',
    ecom_customer        int(11)          NOT NULL default '0',
    site_cust_status     char(1)          NOT NULL default 'C',
    site_cust_newsletter char(1)          NOT NULL default 'Y',
    datem                datetime                  default NULL,
    PRIMARY KEY (rowid)
) ENGINE = InnoDB COMMENT ='Table transition client OSC - societe Dolibarr';
