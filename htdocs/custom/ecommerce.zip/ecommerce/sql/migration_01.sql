-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--
-- $Id: migration_01.sql,v 1.1 2011-10-17 14:46:43 tiaris Exp $
-- ===================================================================

-- migration from 0.9.1.3 
ALTER TABLE llx_ecom_site
    ADD COLUMN site_commercial          INT(11)     NOT NULL DEFAULT 0 AFTER site_maxclient,
    ADD COLUMN site_customercategory    INT(11)     NOT NULL DEFAULT 0 AFTER site_commercial,
    ADD COLUMN site_prospectcategory    INT(11)     NOT NULL DEFAULT 0 AFTER site_customercategory,
    ADD COLUMN site_ecom_system         VARCHAR(50) NOT NULL DEFAULT '' AFTER site_prospectcategory,
    ADD COLUMN site_ecom_system_version VARCHAR(20) NOT NULL AFTER site_ecom_system,
    ADD COLUMN site_ecom_module_version VARCHAR(20) NOT NULL AFTER site_ecom_system_version;
--migration for order table
ALTER TABLE llx_ecom_order
    ADD COLUMN exp_meth    varchar(50) default null,
    ADD COLUMN exp_meth_id int(11)     default 0;
-- migration ajout modele de facture par site
ALTER TABLE llx_ecom_site
    ADD COLUMN site_invoicetemplate varchar(50) default null;

ALTER TABLE llx_ecom_product
    MODIFY COLUMN doli_ref varchar(32);
ALTER TABLE llx_ecom_product
    MODIFY COLUMN ecom_ref varchar(32) NULL default NULL;
