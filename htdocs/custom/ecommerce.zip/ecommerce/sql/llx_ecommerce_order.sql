-- ===================================================================
-- Copyright (C) 2005 Laurent Destailleur  <eldy@users.sourceforge.net>
-- Copyright (C) 2008-2009 Jean Heimburger <jean@tiaris.info>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--
-- ===================================================================

CREATE TABLE llx_ecom_order
(
    rowid               int(11) unsigned NOT NULL auto_increment,
    siteid              int(2)           NOT null default '0',
    doli_order          int(11)          NOT NULL default '0',
    ecom_order          int(11)          NOT NULL default '0',
    datem               datetime                  default NULL,
    site_order_status   integer          not null default '0',
    site_order_date     datetime                  default NULL,
    site_order_total_ht decimal(10, 2)            default '0.00',
    site_total_vat      decimal(10, 2)            default '0.00',
    site_total_port     decimal(10, 2)            default '0.00',
    site_client_name    varchar(250)               default null,
    exp_meth            varchar(250)               default null,
    exp_meth_id         int(11)                   default 0,
    PRIMARY KEY (rowid)
) ENGINE = InnoDB COMMENT ='Table transition commande ecommerce - commande Dolibarr';
