-- ===================================================================
-- Copyright (C) 2005 Laurent Destailleur  <eldy@users.sourceforge.net>
-- Copyright (C) 2008-2009 Jean Heimburger <jean@tiaris.info>
-- Copyright (C) 2012 Juanjo Menent 	   <jmenent@2byte.es>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
--
-- $Id: llx_ecommerce_product.sql,v 1.1.8.1 2012-06-23 09:41:59 tiaris Exp $
-- ===================================================================

CREATE TABLE llx_ecom_product
(
    rowid         int(11) unsigned NOT NULL auto_increment,
    siteid        int(2)           NOT null default '0',
    doli_product  int(11)          NOT NULL default '0',
    doli_ref      varchar(128),
    ecom_product  int(11)          NOT NULL default '0',
    ecom_attribut varchar(128)     NULL     default '',
    ecom_ref      varchar(128)     NULL     default NULL,
    site_status   char(1)          NULL     default ' ',
    site_stock    int(5)           NULL     default '0',
    datem         datetime                  default NULL,
    long_desc     text             NULL,
    PRIMARY KEY (rowid)
) ENGINE = InnoDB COMMENT ='Table transition produit ecommerce - produit Dolibarr';


ALTER TABLE `llx_ecom_product` ADD `declinaison` varchar(50) NULL;