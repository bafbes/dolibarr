<?php
/* Copyright (C) 2010-2011	Jean Heimburger   <jean@tiaris.info>
 * Copyright (C) 2012-2013  Philippe Grand    <philippe.grand@atoo-net.com>
 * Copyright (C) 2011    	Juanjo Menent	  <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * or see http://www.gnu.org/
 */

/**
 *        \file       /ecommerce/core/lib/ecommerce.lib.php
 *        \brief      Ensemble de fonctions de base pour le module ecommerce
 *      \ingroup    ecommerce
 */


function ecommerce_prepare_head()
{
	global $langs, $conf;
	$langs->load('ecommerce@ecommerce');

	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath("/ecommerce/admin/ecommerce.php", 1);
	$head[$h][1] = $langs->trans("Miscellaneous");
	$head[$h][2] = 'miscellaneous';
	$h++;

	$head[$h][0] = dol_buildpath("/ecommerce/admin/site_admin.php", 1);
	$head[$h][1] = $langs->trans("Sites");
	$head[$h][2] = 'newsite';
	$h++;

	$head[$h][0] = dol_buildpath("/ecommerce/admin/params_prestashop.php", 1);
	$head[$h][1] = $langs->trans("Prestashop");
	$head[$h][2] = 'paramsprestashop';
	$h++;

	$head[$h][0] = dol_buildpath("/ecommerce/webservices/admin/index.php", 1);
	$head[$h][1] = $langs->trans("webservices");
	$head[$h][2] = 'webservices';
	$h++;

	complete_head_from_modules($conf, $langs, null, $head, $h, 'ecommerce');

	return $head;
}

function ecommerce_index_prepare_head()
{
	global $langs, $conf;
	$langs->load('ecommerce@ecommerce');

	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath("/ecommerce/index.php", 1);
	$head[$h][1] = $langs->trans("SiteRecap");
	$head[$h][2] = 'siterecap';
	$h++;

	complete_head_from_modules($conf, $langs, null, $head, $h, 'ecommerce');

	return $head;
}

/**
 *
 * Prepare onglets pour page produits
 * @param int $siteid
 */
function ecom_prepare_head_product($siteid,$limit,$offset)
{
	global $langs, $conf, $user;
	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&select=onSale";
	$head[$h][1] = $langs->trans("ProductsOnSale");
	$head[$h][2] = 'onSale';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&select=Waiting";
	$head[$h][1] = $langs->trans("ProductsWaiting");
	$head[$h][2] = 'Waiting';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&select=unAvail";
	$head[$h][1] = $langs->trans("ProductsUnavailable");
	$head[$h][2] = 'unAvail';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&select=All";
	$head[$h][1] = $langs->trans("Allproducts");
	$head[$h][2] = 'All';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_products.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&select=Different";
	$head[$h][1] = $langs->trans("Different");
	$head[$h][2] = 'Different';
	$h++;

	return $head;

}

/**
 *
 * Prepare onglets pour page produits
 * @param int $siteid
 */
function ecom_prepare_head_order($siteid,$limit,$offset)
{
	global $langs, $conf, $user;
	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath('/ecommerce/site_orders.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&state=Waiting";
	$head[$h][1] = $langs->trans("OrdersWaiting");
	$head[$h][2] = 'Waiting';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_orders.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&state=Process";
	$head[$h][1] = $langs->trans("OrdersInProcess");
	$head[$h][2] = 'Process';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_orders.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&state=ToBill";
	$head[$h][1] = $langs->trans("OrdersToSend");
	$head[$h][2] = 'ToBill';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_orders.php', 1) . '?siteid=' . $siteid . "&limit=$limit&offset=$offset&state=All";
	$head[$h][1] = $langs->trans("Allorders");
	$head[$h][2] = 'All';
	$h++;

	return $head;

}

function ecom_prepare_head_masstreatments($siteid)
{
	global $langs, $conf, $user;
	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath('/ecommerce/site_prodimport.php', 1) . '?siteid=' . $siteid . '&state=Batch';
	$head[$h][1] = $langs->trans("BatchTreatment");
	$head[$h][2] = 'Batch';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_prodimport.php', 1) . '?siteid=' . $siteid . '&state=Createfile';
	$head[$h][1] = $langs->trans("CreateFile");
	$head[$h][2] = 'CreateFile';
	$h++;

	$head[$h][0] = dol_buildpath('/ecommerce/site_prodimport.php', 1) . '?siteid=' . $siteid . '&state=Sendfile';
	$head[$h][1] = $langs->trans("SendFile");
	$head[$h][2] = 'SendFile';
	$h++;

	return $head;
}


// common functions

function convertCharset($string)
{
	$charset_in = mb_detect_encoding($string, "auto");

	if ($charset_in != "UTF-8") $string = mb_convert_encoding($string, 'UTF-8', $charset_in);
//	print $string. ' '.$charset_in.' '.mb_detect_encoding($string, "auto");
	return $string;
}

// compatibility with dolibarr 2.9
if (!function_exists('dol_buildpath')) {
	function dol_buildpath($page, $id)
	{
		return DOL_URL_ROOT . $page;
	}
}

function get_vat_rate_id($vat_rate)
{
	global $mysoc, $db;

	$vatid = 0;
	$code_pays = $mysoc->country_code;

	$sql = "SELECT ps.ecom_id";
	$sql .= " FROM " . MAIN_DB_PREFIX . "c_tva as t, " . MAIN_DB_PREFIX . "c_country as p, " . MAIN_DB_PREFIX . "ecom_params as ps";
	$sql .= " WHERE t.active=1 AND t.fk_pays = p.rowid AND p.code='" . $code_pays . "'";
	$sql .= " AND t.taux = " . $vat_rate;
	$sql .= " AND ps.partype='taxrate' AND ps.doli_id=t.rowid";
	$sql .= " ORDER BY t.taux DESC, t.recuperableonly ASC";

	dol_syslog(__FILE__ . "::" . __FUNCTION__ . " sql  $sql", LOG_DEBUG);

	$resql = $db->query($sql);
	if ($resql) {
		$obj = $db->fetch_object($resql);
		if ($obj) {
			$vatid = $obj->ecom_id;
		}
	}
	else dol_syslog(__FILE__ . "::" . __FUNCTION__ . " sql error $sql", LOG_ERR);

	return $vatid;
}

/**
 *
 * gets group id for a price level
 * @param integer $level
 * @param integer $siteid
 */
function get_groupforlevel($level, $siteid)
{
	global $db;
	if (empty($level)) {
		dol_syslog("get_groupforlevel level is empty", LOG_ERR);
		return 0;
	}

	$sql = "SELECT ecom_id FROM " . MAIN_DB_PREFIX . "ecom_customer_type WHERE doli_tarif_id = '" . $level . "' AND siteid = '" . $siteid . "'";

	$id_ecom = 0;
	dol_syslog("get_groupforlevel sql=" . $sql, LOG_DEBUG);
	$resql = $db->query($sql);
	if ($resql) {
		if ($db->num_rows($resql)) {
			$obj = $db->fetch_object($resql);
			$id_ecom = $obj->ecom_id;
		}
	}
	else {
		dol_syslog("E_product::get_groupforlevel sql=" . $sql, LOG_ERR);
		return -1;
	}

	return $id_ecom;
}


function get_groupfortypent($typent_id, $siteid)
{
	global $db;
	if (empty($typent_id)) {
		dol_syslog("get_groupforlevel level is empty", LOG_ERR);
		return 0;
	}

	$sql = "SELECT ecom_id FROM " . MAIN_DB_PREFIX . "ecom_customer_type WHERE doli_typent_id = '" . $typent_id . "' AND siteid = '" . $siteid . "'";

	$id_ecom = 0;
	dol_syslog("get_groupfortypent sql=" . $sql, LOG_DEBUG);
	$resql = $db->query($sql);
	if ($resql) {
		if ($db->num_rows($resql)) {
			$obj = $db->fetch_object($resql);
			$id_ecom = $obj->ecom_id;
		}
	}
	else {
		dol_syslog("E_product::get_groupfortypent sql=" . $sql, LOG_ERR);
		return -1;
	}

	return $id_ecom;
}


