<?php
/* Copyright (C) 2005-2008 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2010-2012 Jean Heimburger      <jean@tiaris.info>
 * Copyright (C) 2011-2013 Philippe Grand       <philippe.grand@atoo-net.com>
 * Copyright (C) 2011-2012 Juanjo Menent	    <jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 *   \file       htdocs/ecommerce/core/triggers/interface_01_modEcommerce_Ecommerce.class.php
 *   \ingroup    ecommerce
 *   \brief      Trigger file for ecommerce module
 */


/**
 *    \class      InterfaceEcommerce
 *    \brief      Class of triggered functions for ecommerce module
 */

dol_include_once("/ecommerce/core/lib/ecommerce.lib.php");
dol_include_once("/ecommerce/class/E_order.class.php");
dol_include_once("/ecommerce/includes/products.inc.php");
dol_include_once("/ecommerce/class/ecom_product.class.php");
dol_include_once($conf->global->ECOMMERCE_NUSOAPPATH . "/nusoap.php");
dol_include_once('/ecommerce/class/ecom_site.class.php');


class InterfaceEcommerce
{
	var $db;

	/**
	 *   Constructor
	 *
	 * @param DB      Handler d'acces base
	 */
	function __construct($db)
	{
		$this->db = $db;

		$this->name = preg_replace('/^Interface/i', '', get_class($this));
		$this->family = "Ecommerce";
		$this->description = "Triggers of this module add actions in Ecommerce site according to setup made in ecommerce setup.";
		$this->version = 'dolibarr';
		$this->picto = 'ecommerce@ecommerce';
	}

	/**
	 *   Renvoie nom du lot de triggers
	 *
	 * @return     string      Nom du lot de triggers
	 */
	function getName()
	{
		return $this->name;
	}

	/**
	 *   Renvoie descriptif du lot de triggers
	 *
	 * @return     string  Descriptif du lot de triggers
	 */
	function getDesc()
	{
		return $this->description;
	}

	/**
	 *   Renvoie version du lot de triggers
	 *
	 * @return     string  Version du lot de triggers
	 */
	function getVersion()
	{
		global $langs;
		$langs->load("admin");

		if ($this->version == 'development') return $langs->trans("Development");
		elseif ($this->version == 'experimental') return $langs->trans("Experimental");
		elseif ($this->version == 'dolibarr') return DOL_VERSION;
		elseif ($this->version) return $this->version;
		else return $langs->trans("Unknown");
	}

	/**
	 *      Function called when a Dolibarrr business event is done.
	 *      All functions run_trigger are triggered if file is inside directory core/triggers
	 *
	 *
	 * @param action      Event code (COMPANY_CREATE, PROPAL_VALIDATE, ...)
	 * @param object      Object action is done on
	 * @param user        Object user
	 * @param langs       Object langs
	 * @param conf        Object conf
	 * @return     int         <0 if KO, 0 if no action are done, >0 if OK
	 */
	function run_trigger($action, $object, $user, $langs, $conf)
	{
        global $db;
		// Actions
		// il s'agit d'une expédition
		if (($action == 'EXPED_CREATE') || ($action == 'ORDER_SHIPPING') || ($action == 'SHIPPING_VALIDATE')) {
			// trouver la commande correspondante
			dol_syslog("Trigger '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->origin_id . " origine= " . $object->origin, LOG_DEBUG);
			if ($object->origin == 'commande') $comid = $object->origin_id;
			else {
				dol_syslog("Erreur id=" . $object->origin_id . " origine= " . $object->origin . " <> commande", LOG_DEBUG);
			}
			//dol_syslog("Trigger '".$this->name."' for action '$action' launched by ".__FILE__.". id=".$object->id." sql= ".$sql, LOG_DEBUG);
		}

		// il s'agit d'une commande
		if (($action == 'ORDER_VALIDATE') || ($action == 'ORDER_DELETE') || ($action == 'ORDER_CANCEL') || ($action == 'ORDER_CLOSE')) {
			$comid = $object->id;
		}

		if (($action == 'ORDER_VALIDATE') || ($action == 'ORDER_DELETE') || ($action == 'ORDER_CANCEL') || ($action == 'ORDER_CLOSE') || ($action == 'SHIPPING_VALIDATE')) {
			// recherche commande

			$sql = "SELECT siteid, ecom_order FROM " . MAIN_DB_PREFIX . "ecom_order o";
			$sql .= " WHERE o.doli_order = '" . $comid . "'";

			dol_syslog("Trigger '" . $this->name . " sql= " . $sql, LOG_DEBUG);
			$resql = $this->db->query($sql);
			if ($resql) {
				if ($this->db->num_rows($resql)) {
					$obj = $this->db->fetch_object($resql);
					$siteid = $obj->siteid;
					$ecom_order = $obj->ecom_order;
				}
				else return 0; //la commande ne provient pas d'un site ecom
				$this->db->free($resql);
			}
			else {
				dol_syslog("Trigger '" . $this->name . " erreur " . $this->db->lasterror(), LOG_ERR);
				return -1;
			}
			$ecomorder = new E_order($this->db, $siteid, $user);
		}

		// les actions
        //A la suppression d'un produit, supprimer son enregistrement dans ecom_product
		if ($action == 'PRODUCT_DELETE') {
			$res = product_isdeleted($object->id);
			dol_syslog("Trigger '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id);
		}
		//A la modification d'un produit ou de son prix, propager l'action sur Prestashop
		elseif ($action == 'PRODUCT_PRICE_MODIFY' || $action == 'PRODUCT_MODIFY') {
            //Ne pas synchroniser si c'est une modification d'un prix autre que le premier en multiprix
			if (!empty($conf->global->PRODUIT_MULTIPRICES) && $action == 'PRODUCT_PRICE_MODIFY') {
				$price = GETPOST("price_1");
				if ($price) {
					$res = syncro_ecom_prod($this->db, $object->id, $user);
				}
			}
			else {

				$res = syncro_ecom_prod($this->db, $object->id, $user);
            }
            dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '$action' launched by " . __FILE__ . ". product_id=" . $object->product_id . " entrepot =" . $object->entrepot_id . " qty =" . $object->qty . " res = " . $res, LOG_DEBUG);
        }
        //Au mouvement de stock d'un produit mettre à jour l'article sur Prestashop si ECOM_ONLINE_PRODUCT_QTY_UPDATE est actif
        elseif ($action == 'STOCK_MOVEMENT') {
//            $res = update_ecom_prod($this->db, $object->product_id, $object->entrepot_id, $object->qty, $user);

            if (!$conf->global->ECOM_ONLINE_PRODUCT_QTY_UPDATE) {
                dol_syslog("products.inc.php:: update_ecom_prod est désactivé ", LOG_DEBUG);
                return 0;
            }

            $product = new Product($db);
            $result = $product->fetch($object->product_id);
            if ($result < 0) {
                dol_syslog("products.inc.php:: update_ecom_prod error reading product " . $product->error, LOG_ERR);
                return 0;
            }
            if ($product->load_stock() < 0) {
                dol_syslog("products.inc.php:: update_ecom_prod error loading product product_stock" . $product->error, LOG_ERR);
                return 0;
            }
            // en vente sur sites internet liés au stock indiqué !!
            $sql = "SELECT ep.rowid, ep.siteid, ep.ecom_product ,ep.ecom_attribut FROM " . MAIN_DB_PREFIX . "ecom_product ep ";
            $sql .= " JOIN " . MAIN_DB_PREFIX . "ecom_site es ON es.rowid = ep.siteid AND es.site_entrepot='" . $object->entrepot_id . "' ";
            $sql .= " WHERE doli_product ='" . $object->product_id . "' ";
            dol_syslog("products.inc.php:: update_ecom_prod sql= $sql", LOG_DEBUG);

            $resql = $db->query($sql);
            if ($resql) {
                $num = $db->num_rows($resql);
                $i = 0;
                if ($num) {
                    while ($i < $num) {
                        $obj = $db->fetch_object($resql);
                        if ($obj) {
                            $ecom_prod = new Ecom_product($db);
                            $ecom_prod->fetch($obj->rowid);
                            $modifs['id_product_attribute'] = $obj->ecom_attribut;
                            $modifs['quantity'] = $ecom_prod->site_stock =$product->stock_warehouse[$object->entrepot_id]->real;
                            $parameters = array("tabmod" => $modifs, "prodid" => $obj->ecom_product);
                            $site=new Ecom_site($db);
                            $site->fetch($ecom_prod->siteid);
                            // Set the WebService URL
                            $client = new nusoap_client($site->site_ws_url . "/ws_articles.php" . (!empty($conf->global->DEBUG_URL) ? '?XDEBUG_SESSION_START=PhpStorm' : ''));
                            // Call the WebService and store its result in $obj
                            $client->call("setQuantity", $parameters);
                            if ($client->fault) {
                                $error = $langs->trans("ErrWSFault") . " " . $client->getError();
                                dol_syslog("E_product::modify " . $error, LOG_DEBUG);
                                return -1;
                            }
                            elseif (!($err = $client->getError())) {
                                $ecom_prod->update();
                                dol_syslog("E_product::modify réussi", LOG_DEBUG);
                            }
                            else {
                                dol_syslog("E_product::modify raté " . $err . " " . print_r($client, true), LOG_DEBUG);
                                return -1;
                            }
                        }
                        else {
                            // on ne fait rien
                        }
                        $i++;
                    }
                }
            }
            else {
                dol_syslog("products.inc.php:: update_ecom_prod erreur sql= $sql", LOG_ERR);
            }
            dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '$action' launched by " . __FILE__ . ". product_id=" . $object->product_id . " entrepot =" . $object->entrepot_id . " qty =" . $object->qty . " res = " . $res, LOG_DEBUG);
        }
        //A l'assignation d'un produit à une catégorie, reproduire l'action sur la catégorie correspondante dans presta
        elseif ($action == 'CATEGORY_LINK') {
            if ($object->type == 'product' && $object->id != $conf->global->ECOM_DOLICAT) {
                $res = add_categorie_ecom_prod($this->db, $object->id, $object->context['linkto']->id, $user);
            }
			dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '$action' launched by " . __FILE__ . ". product_id=" . $object->product_id . " entrepot =" . $object->entrepot_id . " qty =" . $object->qty . " res = " . $res, LOG_DEBUG);
		}
		//A la déassignation d'un produit à une catégorie, reproduire l'action sur la catégorie correspondante dans presta
		elseif ($action == 'CATEGORY_UNLINK') {
			if ($object->type == 'product' && $object->id != $conf->global->ECOM_DOLICAT) {
				$res = delete_categorie_ecom_prod($this->db, $object->id, $object->context['unlinkoff']->id, $user);
			}
			dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '$action' launched by " . __FILE__ . ". product_id=" . $object->product_id . " entrepot =" . $object->entrepot_id . " qty =" . $object->qty . " res = " . $res, LOG_DEBUG);
		}
		//A la validation de commande, changer le statut sur ecom_order et sur Presta
		elseif ($action == 'ORDER_VALIDATE') {
			$res = $ecomorder->change_status($ecom_order, 1);
			dol_syslog("Trigger ORDER VALIDATE '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id . " " . $res);
		}
		//A la suppression d'une commande, la supprimer sur ecom_order pour le site d'ou elle provient
		elseif ($action == 'ORDER_DELETE') {
			$res = $ecomorder->order_isdeleted($comid);
			dol_syslog("Trigger '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id . " result = " . $res);
		}
		//A la cloture d'une commande, le faire également sur Prestashop
		elseif ($action == 'ORDER_CLOSE') {
			$res = $ecomorder->change_status($ecom_order, 3);
			dol_syslog("Trigger ORDER_CLOSE '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id . " res : " . $res);
		}
		//A l'annulation' d'une commande, le faire également sur Prestashop
		elseif ($action == 'ORDER_CANCEL') {
			$res = $ecomorder->change_status($ecom_order, -1);
			dol_syslog("Trigger '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id . " result = " . $res);
		}
		//à la validation d'une expédition, on enregistre le numéro de suivi et on change le statut de la commande dans Prestashop
		elseif ($action == 'SHIPPING_VALIDATE') {
			$eorder = new E_order($this->db, $siteid, $user);
			// d'abord maj du tracking n°
			$res = $eorder->set_tracking_num($comid, $object->id);
			dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id . "tracknum=" . $object->tracking_number . "commande =" . $comid, LOG_DEBUG);
			// maj statut
			$res = $eorder->change_status($ecom_order, 2);
			dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '$action' launched by " . __FILE__ . "expédition commande =" . $ecom_order, LOG_DEBUG);
		}
        elseif ($action == 'CATEGORY_DELETE') {
                $sql = "UPDATE ".MAIN_DB_PREFIX."ecom_categories";
                $sql .= " SET doli_catid = 0";
                $sql .= " WHERE doli_catid =".$object->id;
                if (!$this->db->query($sql)) {
                    $this->error = $this->db->lasterror();
                    return -1;
                }
            }
		// Si ECOM_ONLINE_SEND_INVOICE ...
		elseif ($conf->global->ECOM_ONLINE_SEND_INVOICE && ($action == 'BILL_VALIDATE' || $action == 'BILL_PAYED')) {
            dol_syslog("Trigger Ecommerce controle '", LOG_DEBUG);
            $object->fetch("", $object->newref);

            // compatibilité
            $object->fetchObjectLinked('', '', $object->id, 'facture');
            $object->commande_id = array_values($object->linkedObjectsIds["commande"])[0];

            if ($object->commande_id) {
                $eorder = new E_order($this->db, '', $user);
				$res = $eorder->send_invoice($object->commande_id, $object->ref);
				dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '$action' launched by " . __FILE__ . " ECOM_ONLINE_SEND_INVOICE=" . $conf->global->ECOM_ONLINE_SEND_INVOICE . " validation facture " . $object->ref . " commande =" . $object->commande_id . '  res=' . $res, LOG_DEBUG);
			}
			else dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '$action' launched by " . __FILE__ . " ECOM_ONLINE_SEND_INVOICE=" . $conf->global->ECOM_ONLINE_SEND_INVOICE . " validation facture " . $object->ref . " commandeid est vide", LOG_WARN);
			dol_syslog("Trigger Ecommerce'" . $this->name . "' for action '" . $action . "' launched by " . __FILE__ . " ECOM_ONLINE_SEND_INVOICE=" . $conf->global->ECOM_ONLINE_SEND_INVOICE . " action = " . $action . " commande " . isset($object->commande_id) ? $object->commande_id : 'null', LOG_DEBUG);
		}

		return 0;
	}

}


