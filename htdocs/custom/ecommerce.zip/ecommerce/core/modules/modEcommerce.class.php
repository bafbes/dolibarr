<?php
/* Copyright (C) 2003      Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2012 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2005-2012 Regis Houssin        <regis@dolibarr.fr>
 * Copyright (C) 2013      Philippe Grand       <philippe.grand@atoo-net.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *    \defgroup   ecommerce     Module Ecommerce
 *  \brief      Module to manage ecommerce shops.
 *
 *  \file       htdocs/ecommerce/core/modules/modEcommerce.class.php
 *  \ingroup    ecommerce
 *  \brief      Description and activation file for module Ecommerce
 */
include_once(DOL_DOCUMENT_ROOT . "/core/modules/DolibarrModules.class.php");
include_once(DOL_DOCUMENT_ROOT . "/core/lib/admin.lib.php");


/**
 *  Description and activation class for module Ecommerce
 */
class modEcommerce extends DolibarrModules
{
	/**
	 *   Constructor. Define names, constants, directories, boxes, permissions
	 *
	 * @param DoliDB $db Database handler
	 */
	function __construct($db)
	{
		global $langs, $conf, $menumanager;

		$this->db = $db;

		// Id for module (must be unique).
		$this->numero = 102010;
		// Key text used to identify module (for permissions, menus, etc...)
		$this->rights_class = 'ecommerce';
		// Family
		$this->family = "products";
		// Module label
		$this->name = preg_replace('/^mod/i', '', get_class($this));
		// Module description,
		$this->description = "E-commerce site interface";
		// Module version
		$this->version = '1.15';
		// Key used in llx_const table to save module status enabled/disabled (where MYMODULE is value of property name of module in uppercase)
		$this->const_name = 'MAIN_MODULE_' . strtoupper($this->name);
		// Where to store the module in setup page (0=common,1=interface,2=others,3=very specific)
		$this->special = 1;
		// Name of image file used for this module.
		$this->picto = 'ecommerce@ecommerce';

		// Data directories to create when module is enabled.
		$this->dirs = array("/ecommerce/temp");

		// Config pages. Put here list of php page, stored into mymodule/admin directory, to use to setup module.
		$this->config_page_url = array("ecommerce.php@ecommerce");

		// Defined all module parts (triggers, login, substitutions, menus, css, etc...)
		$this->module_parts = array('triggers' => 1);

		// Dependencies
		$this->depends = array("modStock", "modCommande", "modComptabilite", "modBarcode");        // List of modules id that must be enabled if this module is enabled
		$this->requiredby = array();    // List of modules id to disable if this one is disabled
		$this->phpmin = array(5, 0);                    // Minimum version of PHP required by module
		$this->need_dolibarr_version = array(3, 2);    // Minimum version of Dolibarr required by module
		$this->langfiles = array("ecommerce@ecommerce");

		// Constants
		// List of particular constants to add when module is enabled (key, 'chaine', value, desc, visible, 'current' or 'allentities', deleteonunactive)
		// Example: $this->const=array(0=>array('MYMODULE_MYNEWCONST1','chaine','myvalue','This is a constant to add',1),
		//                             1=>array('MYMODULE_MYNEWCONST2','chaine','myvalue','This is another constant to add',0)
		// );
		$this->const = array(0 => array('ECOMMERCE_NUSOAPPATH', 'chaine', '/ecommerce/includes/nusoap/lib', 'Path to nusoap', 0, 'allentities', 1));

		// Array to add new pages in new tabs
        $this->tabs = array('product:+tabproducttab:E-commerce:ecommerce@ecommerce:1:/ecommerce/tabs/producttab.php?id=__ID__'
            /*,'thirdparty:+tabthirdtab:E-commerce:ecommerce@ecommerce:1:/ecommerce/tabs/customertab.php?id=__ID__'*/
        );

		// Dictionnaries
//		if (!empty($conf->mymodule->enabled) && isset($conf->mymodule->enabled)) $conf->mymodule->enabled = 0;
		$this->dictionnaries = array();

		// Boxes
		// Add here list of php file(s) stored in core/boxes that contains class to show a box.
		$this->boxes = array();            // List of boxes
		$r = 0;

		// Permissions
		$this->rights = array();        // Permission array used by this module
		$r = 0;

		$this->rights_class = 'Ecommerce';

		// Add here list of permission defined by an id, a label, a boolean and two constant strings.
		$this->rights[$r][0] = 8555;
		$this->rights[$r][1] = 'Utilisation du module';
		$this->rights[$r][3] = 0;
		$this->rights[$r][4] = 'user';
		$r++;

		$this->rights[$r][0] = 8556;
		$this->rights[$r][1] = 'Definir les sites ecommerce';
		$this->rights[$r][3] = 0;
		$this->rights[$r][4] = 'admin';
		$r++;

		$this->rights[$r][0] = 8557;
		$this->rights[$r][1] = 'Importer les donnees';
		$this->rights[$r][3] = 0;
		$this->rights[$r][4] = 'import';
		$r++;

		$this->rights[$r][0] = 8558;
		$this->rights[$r][1] = 'Accéder à l\'élement de menu de configuration';
		$this->rights[$r][3] = 0;
		$this->rights[$r][4] = 'config';
		$r++;


		// Main menu entries
		$this->menus = array();            // List of menus to add
		$r = 0;

		// Top menu
		$this->menu[$r] = array('fk_menu' => '',
			'type' => 'top',
			'titre' => 'Ecommerce',
			'mainmenu' => 'ecommerce',
			'leftmenu' => '',
			'url' => '/ecommerce/index.php',
			'langs' => 'ecommerce@ecommerce',
			'position' => 1000 + $r,
			'enabled' => '$conf->ecommerce->enabled', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
			'perms' => '1',
			'target' => '',
			'user' => 2);
		$r++;
/*		$this->menu[$r] = array('fk_menu' => "fk_mainmenu=ecommerce",
			'type' => 'left',
			'titre' => $langs->trans("Administration"),
			'mainmenu' => 'ecommerce',
			'leftmenu' => '',
			'url' => "/ecommerce/admin/ecommerce.php",
			'langs' => 'ecommerce@ecommerce',
			'position' => 1000 + $r,
			'enabled' => '$conf->ecommerce->enabled', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
			'perms' => '1',
			'target' => '',
			'user' => 2);
		$r++;*/
        if ($menumanager->name == 'abbes') {
            // afficher tous les sites
            $sql = "SELECT rowid, site_name FROM " . MAIN_DB_PREFIX . "ecom_site";
            $sql .= " WHERE entity = " . $conf->entity;
            $resql = $db->query($sql);
            if ($resql) {
                $numr = $db->num_rows($resql);
                $i = 0;
                $this->menu[$r] = array('fk_menu' => 'fk_mainmenu=ecommerce',
                    'type' => 'left',
                    'titre' => "Tous les sites",
                    'mainmenu' => 'ecommerce',
                    'leftmenu' => '',
                    'url' => "/ecommerce/index.php",
                    'langs' => 'ecommerce@ecommerce',
                    'position' => 1000 + $r,
                    'enabled' => '$conf->ecommerce->enabled', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
                    'perms' => '1',
                    'target' => '',
                    'user' => 2);
                $r++;
                while ($i < $numr) {
					$objp = $db->fetch_object($resql);
					$site_name=ucfirst(str_replace(' ','_',$objp->site_name));
					$this->menu[$r] = array('fk_menu' => 'fk_mainmenu=ecommerce',
						'type' => 'left',
						'titre' => "Administration $site_name",
						'mainmenu' => 'ecommerce',
						'leftmenu' => $site_name,
                        'url' => "/ecommerce/admin/site_admin.php?action=edit&siteid=$objp->rowid&hidetabs=1",
						'langs' => 'ecommerce@ecommerce',
						'position' => 1000 + $r,
						'enabled' => '$conf->ecommerce->enabled', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
                        'perms' => '$user->rights->Ecommerce->config',
						'target' => '',
						'user' => 2);
					$r++;
                    $this->menu[$r] = array('fk_menu' => "fk_mainmenu=ecommerce,fk_leftmenu=$site_name",
						'type' => 'left',
						'titre' => $site_name,
						'mainmenu' => '',
						'leftmenu' => '',
						'url' => "/ecommerce/site_index.php?action=edit&siteid=$objp->rowid&hidetabs=1",
						'langs' => 'ecommerce@ecommerce',
						'position' => 1000 + $r,
						'enabled' => '$conf->ecommerce->enabled', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
						'perms' => '$user->rights->Ecommerce->config',
						'target' => '',
						'user' => 2);
					$r++;
                    $this->menu[$r] = array('fk_menu' => "fk_mainmenu=ecommerce,fk_leftmenu=$site_name",
							'type' => 'left',
							'titre' => $langs->trans("Categories"),
							'mainmenu' => '',
							'leftmenu' => '',
							'url' => "/ecommerce/site_categories.php?siteid=" . $objp->rowid,
							'langs' => 'ecommerce@ecommerce',
							'position' => 1000 + $r,
							'enabled' => '$conf->ecommerce->enabled', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
							'perms' => '$user->rights->Ecommerce->config',
							'target' => '',
							'user' => 2);
						$r++;
					$this->menu[$r] = array('fk_menu' => "fk_mainmenu=ecommerce,fk_leftmenu=$site_name",
						'type' => 'left',
						'titre' => $langs->trans("Commandes"),
						'mainmenu' => '',
						'leftmenu' => '',
						'url' => "/ecommerce/site_orders.php?siteid=" . $objp->rowid,
						'langs' => 'ecommerce@ecommerce',
						'position' => 1000 + $r,
						'enabled' => '$conf->ecommerce->enabled', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
						'perms' => '1',
						'target' => '',
						'user' => 2);
					$r++;
					$this->menu[$r] = array('fk_menu' => "fk_mainmenu=ecommerce,fk_leftmenu=$site_name",
						'type' => 'left',
						'titre' => $langs->trans("Products"),
						'mainmenu' => '',
						'leftmenu' => '',
						'url' => "/ecommerce/site_products.php?siteid=" . $objp->rowid,
						'langs' => 'ecommerce@ecommerce',
						'position' => 1000 + $r,
						'enabled' => '$conf->ecommerce->enabled', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
						'perms' => '1',
						'target' => '',
						'user' => 2);
					$r++;
                    $this->menu[$r] = array('fk_menu' => "fk_mainmenu=ecommerce,fk_leftmenu=$site_name",
                        'type' => 'left',
                        'titre' => $langs->trans("Logs"),
                        'mainmenu' => '',
                        'leftmenu' => '',
                        'url' => "/ecommerce/site_logs.php?siteid=" . $objp->rowid,
                        'langs' => 'ecommerce@ecommerce',
                        'position' => 1000 + $r,
                        'enabled' => '$conf->ecommerce->enabled && $user->admin', // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
                        'perms' => '1',
                        'target' => '',
                        'user' => 2);
                    $r++;
                    $this->menu[$r] = array('fk_menu' => "fk_mainmenu=ecommerce,fk_leftmenu=$site_name",
                        'type' => 'left',
                        'titre' => $langs->trans("SiteProdImport"),
                        'mainmenu' => '',
                        'leftmenu' => '',
                        'url' => "/ecommerce/site_prodimport.php?siteid=" . $objp->rowid,
                        'langs' => 'ecommerce@ecommerce',
                        'position' => 1000 + $r,
                        'enabled' => '$conf->ecommerce->enabled && $conf->global->ECOM_IMP_PRODIMPORT', //
                        // Define condition to show or hide menu entry. Use '$conf->odqc->enabled' if entry must be visible if module is enabled.
                        'perms' => '1',
                        'target' => '',
                        'user' => 2);
                    $r++;
                    $i++;
                }
            }
        }


        // Exports
        $r = 1;

    }

	/**
	 *        Function called when module is enabled.
	 *        The init function add constants, boxes, permissions and menus (defined in constructor) into Dolibarr database.
	 *        It also creates data directories
	 *
	 * @param string $options Options when enabling module ('', 'noboxes')
	 * @return     int                1 if OK, 0 if KO
	 */
	function init($options = '')
	{
		$sql = array();
        $extrafields = new ExtraFields($this->db);
        $extrafields->addExtraField('prodref', 'Prestareference', 'varchar', 1, 40, 'product', 0, 0,'', 0,0,'',1,'prodrefextrafield','','','ecommerce@ecommerce',1,0,1);
        $extrafields->addExtraField('declinaison', 'Declinaison', 'varchar', 10, 50, 'product', 0, 0,'', 0,0,'',1,'prodrefextrafield','','','ecommerce@ecommerce',1,0,1);
//		dolibarr_set_const($this->db, 'ECOMMERCE_EXPORT_DOLI2ECOM', 1);
		dolibarr_set_const($this->db, 'MAIN_MODULE_WEBSERVICES', 1);
		dolibarr_set_const($this->db, 'ECOM_CREATE_FACTURE', 0);
		dolibarr_set_const($this->db, 'ECOM_IMP_PRODIMPORT', 0);
		dolibarr_set_const($this->db, 'ECOM_FRSPORT_TVA', 20);
		dolibarr_set_const($this->db, 'ECOM_BATCH_USER', 'admin');
        dolibarr_set_const($this->db, 'ECOM_CB_PAYE', 6);
	    dolibarr_set_const($this->db, 'ECOM_CB_ACCOUNT', 0);
	    dolibarr_set_const($this->db, 'ECOM_PAYPAL', 0);
	    dolibarr_set_const($this->db, 'ECOM_PAYPAL_ACCOUNT', 0);
	    dolibarr_set_const($this->db, 'ECOM_PAYPAL_COM', 0);
	    dolibarr_set_const($this->db, 'ECOM_PAYBOX', 0);
	    dolibarr_set_const($this->db, 'ECOM_PAYBOX_ACCOUNT', 0);
	    dolibarr_set_const($this->db, 'ECOM_PAYBOX_COM', 0);
	    dolibarr_set_const($this->db, 'ECOM_ONLINE_PRODUCT_QTY_UPDATE',0);
	    dolibarr_set_const($this->db, 'ECOM_ONLINE_SYNCRO_PRODUCTS', 1);
	    dolibarr_set_const($this->db, 'ECOM_ONLINE_SEND_INVOICE', 0);
	    dolibarr_set_const($this->db, 'ECOM_PRODUCT_MUST_EXIST', 1);
	    dolibarr_set_const($this->db, 'ECOM_DOLICAT',1);
	    dolibarr_set_const($this->db, 'ECOM_PRODUCT_WITH_IMAGE',1);
	    dolibarr_set_const($this->db, 'ECOM_ORDER_PRESTA2DOLI',0);
	    dolibarr_set_const($this->db, 'ECOMMERCE_EXPORT_DOLI2ECOM',1);

		$result = $this->load_tables();

		return $this->_init($sql, $options);
	}

	/**
	 *        Function called when module is disabled.
	 *      Remove from database constants, boxes and permissions from Dolibarr database.
	 *        Data directories are not deleted
	 *
	 * @param string $options Options when enabling module ('', 'noboxes')
	 * @return     int                1 if OK, 0 if KO
	 */
	function remove($options = '')
	{
        dolibarr_set_const($this->db, 'MAIN_MODULE_WEBSERVICES', 0);
		$sql = array();

		return $this->_remove($sql, $options);
	}


	/**
	 *        Create tables, keys and data required by module
	 *        Files llx_table1.sql, llx_table1.key.sql llx_data.sql with create table, create keys
	 *        and create data commands must be stored in directory /mymodule/sql/
	 *        This function is called by this->init
	 *
	 * @return        int        <=0 if KO, >0 if OK
	 */
	function load_tables()
	{
		return $this->_load_tables('/ecommerce/sql/');
	}
}


