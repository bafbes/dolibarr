<?php
/* Copyright (C) 2016 Abbes Bahfir  <dolipar@dolipar.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *  \defgroup   projet Module rapports
 *	\brief      Module to print reports
 *  \file       htdocs/core/modules/modrapports.class.php
 *	\ingroup    rapports
 *	\brief      Fichier de description et activation du module rapports
 */

include_once(DOL_DOCUMENT_ROOT ."/core/modules/DolibarrModules.class.php");


/**
 *	Classe de description et activation du module Projet
 */
class modrapports extends DolibarrModules
{
	/**
	 *   Constructor. Define names, constants, directories, boxes, permissions
	 *
	 *   @param      DoliDB		$db      Database handler
	 */
	function __construct($db)
	{
		global $conf, $langs;
		
		$langs->load('rapports@rapports');
		
		$this->db = $db;
		$this->numero = 170000;

		$this->family = "technic";
		
		// Module label (no space allowed), used if translation string 'ModuleXXXName' not found (where XXX is value of numeric property 'numero' of module)
		$this->name = preg_replace('/^mod/i','',get_class($this));
		$this->description = $langs->trans("InfoModules");
		// Possible values for version are: 'development', 'experimental', 'dolibarr' or version
		$this->version = '3.5.+1.3.0';

		$this->const_name = 'MAIN_MODULE_'.strtoupper($this->name);
		$this->special = 0;
		//$this->config_page_url = array("rapports.php@rapports");
//		$this->picto='rapports.png@rapports';
        $this->picto='bill';

		// Config pages. Put here list of php page, stored into webmail/admin directory, to use to setup module.
//		$this->config_page_url = array("admin.php@rapports");

		// Dependancies
		$this->depends = array();
		$this->requiredby = array();

		// Constants
		$this->const = array();		
		
		// Left-Menu of Equipement module
		$r=0;
		
		$topmenu='rapports';
        $this->menu[$r] = array('fk_menu' => 0,
            'type' => 'top',
            'titre' => 'rapports',
            'mainmenu' => $topmenu,
            'leftmenu' => '1',
            'url' => '/rapports/rapports.php',
            'langs' => '',
            'position' => 100,
            'enabled' => '1',
            'perms' => '$user->admin',
            'target' => '',
            'user' => 2);
		$r++;
		$this->menu[$r]=array(	'fk_menu'=>'fk_mainmenu='.$topmenu,
					'type'=>'left',	
					'titre'=>'rapports',
					'mainmenu'=>$topmenu,
					'leftmenu'=>'rapports',
					'url'=>'/rapports/rapports.php',
					'langs'=>'rapports@rapports',
					'position'=>110,
					'enabled'=>'1',
					'perms'=>'1',
					'target'=>'',
					'user'=>2);
		$r++;
		$this->menu[$r]=array(	'fk_menu'=>'fk_mainmenu='.$topmenu.',fk_leftmenu=rapports',
					'type'=>'left',	
					'titre'=>'creances clients',
					'mainmenu'=>'',
					'leftmenu'=>'',
					'url'=>'/rapports/creances_clients.php',
					'langs'=>'rapports@rapports',
					'position'=>110,
					'enabled'=>'1',
					'perms'=>'1',
					'target'=>'',
					'user'=>2);
		$r++;
		$this->menu[$r]=array(	'fk_menu'=>'fk_mainmenu='.$topmenu.',fk_leftmenu=rapports',
					'type'=>'left',	
					'titre'=>'creances clients consolides',
					'mainmenu'=>'',
					'leftmenu'=>'',
					'url'=>'/rapports/creances_clients_consolides.php',
					'langs'=>'rapports@rapports',
					'position'=>110,
					'enabled'=>'1',
					'perms'=>'1',
					'target'=>'',
					'user'=>2);
		$r++;
		$this->menu[$r]=array(	'fk_menu'=>'fk_mainmenu='.$topmenu.',fk_leftmenu=rapports',
					'type'=>'left',
					'titre'=>'chiffre d\'affaires par produit',
					'mainmenu'=>'',
					'leftmenu'=>'',
					'url'=>'/rapports/ca_produits.php',
					'langs'=>'rapports@rapports',
					'position'=>110,
					'enabled'=>'1',
					'perms'=>'1',
					'target'=>'',
					'user'=>2);	
		$r++;
		$this->menu[$r]=array(	'fk_menu'=>'fk_mainmenu='.$topmenu.',fk_leftmenu=rapports',
					'type'=>'left',
					'titre'=>'etat des stocks',
					'mainmenu'=>'',
					'leftmenu'=>'',
					'url'=>'/rapports/stocks.php',
					'langs'=>'rapports@rapports',
					'position'=>110,
					'enabled'=>'1',
					'perms'=>'1',
					'target'=>'',
					'user'=>2);	
		$r++;
		$this->menu[$r]=array(	'fk_menu'=>'fk_mainmenu='.$topmenu.',fk_leftmenu=rapports',
					'type'=>'left',
					'titre'=>'chiffre d\'affaires par client',
					'mainmenu'=>'',
					'leftmenu'=>'',
					'url'=>'/rapports/ca_clients.php',
					'langs'=>'rapports@rapports',
					'position'=>110,
					'enabled'=>'1',
					'perms'=>'1',
					'target'=>'',
					'user'=>2);	
		$r++;
		$this->menu[$r]=array(	'fk_menu'=>'fk_mainmenu='.$topmenu.',fk_leftmenu=rapports',
					'type'=>'left',
					'titre'=>'chiffre d\'affaires par fourniseur',
					'mainmenu'=>'',
					'leftmenu'=>'',
					'url'=>'/rapports/ca_fournisseurs.php',
					'langs'=>'rapports@rapports',
					'position'=>110,
					'enabled'=>'1',
					'perms'=>'1',
					'target'=>'',
					'user'=>2);	

	}


	/**
	 *		Function called when module is enabled.
	 *		The init function add constants, boxes, permissions and menus (defined in constructor) into Dolibarr database.
	 *		It also creates data directories
	 *
     *      @param      string	$options    Options when enabling module ('', 'noboxes')
	 *      @return     int             	1 if OK, 0 if KO
	 */
	function init($options='')
	{
		global $conf;

		// Permissions
		$this->remove($options);

		$sql = array();

		$result=$this->load_tables();
		
		return $this->_init($sql,$options);
	}

    /**
	 *		Function called when module is disabled.
	 *      Remove from database constants, boxes and permissions from Dolibarr database.
	 *		Data directories are not deleted
	 *
     *      @param      string	$options    Options when enabling module ('', 'noboxes')
	 *      @return     int             	1 if OK, 0 if KO
     */
    function remove($options='')
    {
		$sql = array();

		return $this->_remove($sql,$options);
    }

	/**
	 *		Create tables, keys and data required by module
	 * 		Files llx_table1.sql, llx_table1.key.sql llx_data.sql with create table, create keys
	 * 		and create data commands must be stored in directory /mymodule/sql/
	 *		This function is called by this->init.
	 *
	 * 		@return		int		<=0 if KO, >0 if OK
	 */
	function load_tables()
	{
		return $this->_load_tables('/rapports/sql/');
	}

}
?>
