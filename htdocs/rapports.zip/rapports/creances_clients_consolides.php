<?php

/* Copyright (C) 2001-2006 Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2016 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2016 Abbes Bahfir  <dolipar@dolipar.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *  \file       htdocs/rapports/creances_clients_consolides.php
 * 	\ingroup    rapports
 *  \brief      Page de fiche recap Créances clients consolidés
 */
require '../main.inc.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/functions.lib.php';
require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT . '/compta/paiement/class/paiement.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/pdf.lib.php';


$langs->load("companies");
if (!empty($conf->facture->enabled))
    $langs->load("bills");

if ($_REQUEST["date_startmonth"])
    $date_start = dol_mktime(0, 0, 0, $_REQUEST["date_startmonth"], $_REQUEST["date_startday"], $_REQUEST["date_startyear"]);
else
    $date_start = GETPOST('date_start');

if (!$date_start)
    $date_start = -1;

if ($_REQUEST["date_endmonth"])
    $date_end = dol_mktime(23, 59, 59, $_REQUEST["date_endmonth"], $_REQUEST["date_endday"], $_REQUEST["date_endyear"]);
else
    $date_end = GETPOST('date_end');

if (!$date_end)
    $date_end = time();

// checks:if date_start>date_end  then date_end=date_start + 24 hours
if ($date_start > 0 && $date_end > 0 && $date_start > $date_end)
    $date_end = $date_start + 86400;

$socid = GETPOST('socid');
if ($socid == -1)
    $socid = 0;
if ($socid)
    $societe = array($socid);
else {
    $sql = "select rowid FROM " . MAIN_DB_PREFIX . "societe";
    $sql.= " WHERE client=1 or client=3";
    $result = $db->query($sql);
    if ($result) {
        while ($obj = $db->fetch_object($result))
            $societe[] = $obj->rowid;
    }
}
// Purge search criteria
if (GETPOST("button_removefilter_x") || GETPOST("button_removefilter.x") || GETPOST("button_removefilter")) { // Both test are required to be compatible with all browsers
    $date_start = -1;
    $date_end = -1;
    $societe = '';
    $socid = '';
}

$output2pdf = false;
if (GETPOST("button_print_x") || GETPOST("button_print.x") || GETPOST("button_print"))
    $output2pdf = true;

$pagelen = GETPOST("pagelen");
if (!$pagelen)
    $pagelen = 40;

$userstatic = new User($db);

$categ = GETPOST("categ");


if (!$output2pdf) {

    /*
     * 	View
     */

    $form = new Form($db);
    llxHeader();

// Invoice list
    print load_fiche_titre('Créances clients consolidés');

    print '<form method="GET" action="' . $_SERVER["PHP_SELF"] . '">';
    print '<table class="liste" width="100%">';
    print '<tr class="liste_titre">';
    print '<th>' . $langs->trans("Customer") . '</th>';
    print '<th>' . $langs->trans('Categorie') . '</th>';
    print '<th>' . $langs->trans("Date initale") . '' . '</th>';
    print '<th>' . $langs->trans("Date finale") . '' . '</th>';
    print '<th>' . $langs->trans("Hauteur page PDF") . '</th>';
    print '<th></th>';
    print "</tr>\n";
// Lignes des champs de filtres
    print '<tr class="liste_titre">';

    print '<td align="left" class="liste_titre">' . $form->select_company($socid, 'socid', 'client=1 or client=3', 1) . '</td>';
    if (!empty($conf->categorie->enabled)) {
        require_once DOL_DOCUMENT_ROOT . '/core/class/html.formother.class.php';
        require_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';
        $formother = new FormOther($db);
        print '<td align="left" class="liste_titre">' . $formother->select_categories('customer', $categ, 'categ') . '</td>';
    }
    print '<td class="liste_titre" width="15%">' . $form->select_date($date_start, 'date_start', 0, 0, 0, '', 1, 0, 1) . '</td>';
    print '<td class="liste_titre" width="15%">' . $form->select_date($date_end, 'date_end', 0, 0, 0, '', 1, 0, 1) . '</td>';
    print '<td class="liste_titre" width="15%"><input type="text" name="pagelen" id="pagelen" value="' . $pagelen . '"size="5"></td>';

    print '<td align="right" class="liste_titre">';
    $searchpitco = $form->showFilterAndCheckAddButtons(0);
    print $searchpitco;
    print '<input type="image" class="liste_titre" name="button_print" src="' . img_picto($langs->trans("Printer"), 'printer.png', '', '', 1) . '" value="' . dol_escape_htmltag($langs->trans("Imprimer PDF")) . '" title="' . dol_escape_htmltag($langs->trans("Imprimer PDF")) . '" onclick="window.open(\'' . $_SERVER['PHP_SELF'] . '?button_print=1&categ=' . $categ . '&socid=' . $socid . '&date_start=' . $date_start . '&date_end=' . $date_end . '&pagelen=\'+document.getElementById(\'pagelen\').value,\'_blank\');return false;">';
    print '</td>';

    print "</tr>\n";
    print '</table>';
    print '</form>';
}
else {

    $formatarray = pdf_getFormat();
    $page_largeur = $formatarray['width'];
    $page_hauteur = $formatarray['height'];
    $format = array($page_largeur, $page_hauteur);
    $marge_gauche = isset($conf->global->MAIN_PDF_MARGIN_LEFT) ? $conf->global->MAIN_PDF_MARGIN_LEFT : 10;
    $marge_droite = isset($conf->global->MAIN_PDF_MARGIN_RIGHT) ? $conf->global->MAIN_PDF_MARGIN_RIGHT : 10;
    $marge_haute = isset($conf->global->MAIN_PDF_MARGIN_TOP) ? $conf->global->MAIN_PDF_MARGIN_TOP : 10;
    $marge_basse = isset($conf->global->MAIN_PDF_MARGIN_BOTTOM) ? $conf->global->MAIN_PDF_MARGIN_BOTTOM : 10;

    $pdf = pdf_getInstance($format);
    $pdf->setPageOrientation('P');
    $pdf->SetAutoPageBreak(1, 0);
    if (class_exists('TCPDF')) {
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
    }
    $pdf->SetFont(pdf_getPDFFont($langs));

    $pdf->Open();

    $pdf->SetMargins($marge_gauche, $marge_haute, $marge_droite);   // Left, Top, Right
    $pdf->AddPage();

    $xcli = 5;
    $xcode = $xcli + 40;
    $xnumdoc = $xcode + 18; //50;
    $xdate = $xnumdoc + 30; //80;
    $xdes = $xdate + 25; //100;
    $xdeb = $xdes + 10; //130;
    $xcred = $xdeb + 30; // 150;
    $xsolde = $xcred + 30; //170
    $droite = $xsolde + 30; //200
    // Logo
    $logo = $conf->mycompany->dir_output . '/logos/' . $mysoc->logo;
    if ($mysoc->logo) {
        if (is_readable($logo)) {
            $height = pdf_getHeightForLogo($logo);
            $pdf->Image($logo, 0, 10, 0, $height); // width=0 (auto)
            $pdf->setxy(0, $pdf->gety() + $height);
        }
        else {
            $pdf->SetFont('', 'B', $default_font_size - 2);
            Multicell($pdf, 100, 3, $outputlangs->transnoentities("ErrorLogoFileNotFound", $logo), 0, 'L');
            Multicell($pdf, 100, 3, $outputlangs->transnoentities("ErrorGoToGlobalSetup"), 0, 'L');
        }
    }
    else {
        $text = $mysoc->name;
        Multicell($pdf, 100, 4, $langs->convToOutputCharset($text), 0, 'L');
        $pdf->setxy(0, $pdf->gety() + 4);
    }
    $posy = $pdf->getY();
    $pdf->SetxY(145, 10);
    multiCell($pdf, 80, 4, 'Créances clients consolidés', 0, 'L');
    $pdf->SetXY($xcli, $posy);
    multicell($pdf, 200, 4, 'Date initiale: ' . date("j/n/Y", $date_start) . '      Date finale: ' . date("j/n/Y", $date_end), 0, 'L');
}

if (!$output2pdf) {
    foreach ($societe as $socid) {
        $soc = new Societe($db);
        $soc->fetch($socid);

        if (!empty($conf->facture->enabled) && $user->rights->facture->lire) {

            $TData = array();
            $TDataSort = array();

            $sql = "SELECT s.nom, s.rowid as socid, f.facnumber, f.amount, f.datef as df,";
            $sql.= " f.paye as paye, f.fk_statut as statut, f.rowid as facid,";
            $sql.= " u.login, u.rowid as userid";
            $sql.= " FROM " . MAIN_DB_PREFIX . "societe as s," . MAIN_DB_PREFIX . "facture as f," . MAIN_DB_PREFIX . "user as u";
            if ($categ)
                $sql.= " ," . MAIN_DB_PREFIX . "categorie_societe as cs";
            $sql.= " WHERE f.fk_soc = s.rowid AND s.rowid = " . $soc->id;
            $sql.= " AND UNIX_TIMESTAMP(CONVERT_TZ(f.datef, '+00:00', @@session.time_zone)) >= $date_start"; //Convert UTC to time zone
            $sql.= " AND UNIX_TIMESTAMP(CONVERT_TZ(f.datef, '+00:00', @@session.time_zone)) <= $date_end";
            $sql.= " AND f.entity = " . $conf->entity;
            if ($categ) {
                $sql.= " AND cs.fk_soc = s.rowid";
                $sql.= " AND cs.fk_categorie = $categ";
            }
            $sql.= " AND f.fk_user_valid = u.rowid";
            $sql.= " ORDER BY f.datef ASC";

            $resql = $db->query($sql);
            if ($resql) {
                $var = true;
                $num = $db->num_rows($resql);
                if ($num) {

                    print '<table class="noborder" width="100%">';
                    print '<tr class="liste_titre">';
                    print '<td align="left" >' . $soc->getNomUrl(1) . '</td>';
                    print '</tr>';
                    print '</table>';
                    print '<table class="noborder" width="100%">';
                    print '<tr class="liste_titre">';
                    print '<td width="100" align="center">' . $langs->trans("Date") . '</td>';
                    print '<td>' . $langs->trans("Element") . '</td>';
                    print '<td>' . $langs->trans("Status") . '</td>';
                    print '<td align="right">' . $langs->trans("Debit") . '</td>';
                    print '<td align="right">' . $langs->trans("Credit") . '</td>';
                    print '<td align="right">' . $langs->trans("Balance") . '</td>';
                    print '<td align="right">' . $langs->trans("Author") . '</td>';
                    print '</tr>';
                }

                // Boucle sur chaque facture
                for ($i = 0; $i < $num; $i++) {
                    $objf = $db->fetch_object($resql);

                    $fac = new Facture($db);
                    $ret = $fac->fetch($objf->facid);
                    if ($ret < 0) {
                        print $fac->error . "<br>";
                        continue;
                    }
                    $totalpaye = $fac->getSommePaiement();

                    $userstatic->id = $objf->userid;
                    $userstatic->login = $objf->login;

                    $TData[] = array(
                        'date' => $fac->date,
                        'link' => $fac->getNomUrl(1),
                        'status' => $fac->getLibStatut(2, $totalpaye),
                        'amount' => $fac->total_ttc,
                        'author' => $userstatic->getLoginUrl(1)
                    );
                    $TDataSort[] = $fac->date;

                    // Paiements
                    $sql = "SELECT p.rowid, p.datep as dp, pf.amount, p.statut,";
                    $sql.= " p.fk_user_creat, u.login, u.rowid as userid";
                    $sql.= " FROM " . MAIN_DB_PREFIX . "paiement_facture as pf,";
                    $sql.= " " . MAIN_DB_PREFIX . "paiement as p";
                    $sql.= " LEFT JOIN " . MAIN_DB_PREFIX . "user as u ON p.fk_user_creat = u.rowid";
                    $sql.= " WHERE pf.fk_paiement = p.rowid";
                    $sql.= " AND p.entity = " . $conf->entity;
                    $sql.= " AND pf.fk_facture = " . $fac->id;
                    $sql.= " ORDER BY p.datep ASC";

                    $resqlp = $db->query($sql);
                    if ($resqlp) {
                        $nump = $db->num_rows($resqlp);
                        $j = 0;

                        while ($j < $nump) {
                            $objp = $db->fetch_object($resqlp);

                            $paymentstatic = new Paiement($db);
                            $paymentstatic->id = $objp->rowid;

                            $userstatic->id = $objp->userid;
                            $userstatic->login = $objp->login;

                            $TData[] = array(
                                'date' => $db->jdate($objp->dp),
                                'link' => $langs->trans("Payment") . ' ' . $paymentstatic->getNomUrl(1),
                                'status' => '',
                                'amount' => -$objp->amount,
                                'author' => $userstatic->getLoginUrl(1)
                            );
                            $TDataSort[] = $db->jdate($objp->dp);

                            $j++;
                        }

                        $db->free($resqlp);
                    }
                    else {
                        dol_print_error($db);
                    }
                }
            }
            else {
                dol_print_error($db);
            }

            if (!empty($TData)) {

                // Sort array by date
                asort($TDataSort);
                array_multisort($TData, $TDataSort);

                // Balance calculation
                $balance = 0;
                foreach ($TData as &$data1) {
                    $balance += $data1['amount'];
                    $data1['balance'] += $balance;
                }

                // Reverse array to have last elements on top
//                $TData = array_reverse($TData);

                $totalDebit = 0;
                $totalCredit = 0;

                // Display array
                foreach ($TData as $data) {
                    $var = !$var;
                    print "<tr " . $bc[$var] . ">";

                    print "<td align=\"center\">" . dol_print_date($data['date'], 'day') . "</td>\n";
                    print '<td>' . $data['link'] . "</td>\n";

                    print '<td aling="left">' . $data['status'] . '</td>';
                    print '<td align="right">' . (($data['amount'] > 0) ? price(abs($data['amount'])) : '') . "</td>\n";
                    $totalDebit += ($data['amount'] > 0) ? abs($data['amount']) : 0;
                    print '<td align="right">' . (($data['amount'] > 0) ? '' : price(abs($data['amount']))) . "</td>\n";
                    $totalCredit += ($data['amount'] > 0) ? 0 : abs($data['amount']);
                    print '<td align="right">' . price($data['balance']) . "</td>\n";

                    // Author
                    print '<td class="nowrap" align="right">';
                    print $data['author'];
                    print '</td>';

                    print "</tr>\n";
                }

                print '<tr class="liste_total">';
                print '<td colspan="3">&nbsp;</td>';
                print '<td align="right">' . price($totalDebit) . '</td>';
                print '<td align="right">' . price($totalCredit) . '</td>';
                print '<td colspan="2">&nbsp;</td>';
                print "</tr>\n";
            }

            print "</table>";
        }
    }
    llxFooter();
    $db->close();
}
else {
    $TotGendebit = 0;
    $TotGencredit = 0;
    $TotGenBalance = 0;
    foreach ($societe as $socid) {
        if (!empty($conf->facture->enabled) && $user->rights->facture->lire) {
            $TData = array();
            $TDataSort = array();

            $sql = "SELECT s.nom, s.rowid as socid, f.facnumber, f.amount, f.datef as df,";
            $sql.= " f.paye as paye, f.fk_statut as statut, f.rowid as facid,";
            $sql.= " u.login, u.rowid as userid";
            $sql.= " FROM " . MAIN_DB_PREFIX . "societe as s," . MAIN_DB_PREFIX . "facture as f," . MAIN_DB_PREFIX . "user as u";
            if ($categ)
                $sql.= " ," . MAIN_DB_PREFIX . "categorie_societe as cs";
            $sql.= " WHERE f.fk_soc = s.rowid AND s.rowid = " . $socid;
            $sql.= " AND UNIX_TIMESTAMP(CONVERT_TZ(f.datef, '+00:00', @@session.time_zone)) >= $date_start"; //Convert UTC to time zone
            $sql.= " AND UNIX_TIMESTAMP(CONVERT_TZ(f.datef, '+00:00', @@session.time_zone)) <= $date_end";
            $sql.= " AND f.entity = " . $conf->entity;
            if ($categ) {
                $sql.= " AND cs.fk_soc = s.rowid";
                $sql.= " AND cs.fk_categorie = $categ";
            }
            $sql.= " AND f.fk_user_valid = u.rowid";
            $sql.= " ORDER BY f.datef ASC";

            $resql = $db->query($sql);
            $soc = new Societe($db);
            $soc->fetch($socid);
            if ($resql) {
                $var = true;
                $num = $db->num_rows($resql);
                if ($num)
                    $pdfdata[] = array($soc->nom, $soc->code_client, '', '', '', '', '', '');

                // Boucle sur chaque facture
                for ($i = 0; $i < $num; $i++) {
                    $objf = $db->fetch_object($resql);

                    $fac = new Facture($db);
                    $ret = $fac->fetch($objf->facid);
                    if ($ret < 0) {
//                        print $fac->error . "<br>";
                        continue;
                    }
                    $totalpaye = $fac->getSommePaiement();

                    $userstatic->id = $objf->userid;
                    $userstatic->login = $objf->login;

                    $TData[] = array(
                        'date' => $fac->date,
                        'link' => $fac->ref,
                        'status' => $fac->getLibStatut(2, $totalpaye),
                        'amount' => $fac->total_ttc,
                        'author' => $userstatic->getLoginUrl(1)
                    );
                    $TDataSort[] = $fac->date;

                    // Paiements

                    $sql = "SELECT p.rowid, p.datep as dp, pf.amount, p.statut,";
                    $sql.= " p.fk_user_creat, u.login, u.rowid as userid";
                    $sql.= " FROM " . MAIN_DB_PREFIX . "paiement_facture as pf,";
                    $sql.= " " . MAIN_DB_PREFIX . "paiement as p";
                    $sql.= " LEFT JOIN " . MAIN_DB_PREFIX . "user as u ON p.fk_user_creat = u.rowid";
                    $sql.= " WHERE pf.fk_paiement = p.rowid";
                    $sql.= " AND p.entity = " . $conf->entity;
                    $sql.= " AND pf.fk_facture = " . $fac->id;
                    $sql.= " ORDER BY p.datep ASC";

                    $resqlp = $db->query($sql);
                    if ($resqlp) {
                        $nump = $db->num_rows($resqlp);
                        $j = 0;

                        while ($j < $nump) {
                            $objp = $db->fetch_object($resqlp);

                            $paymentstatic = new Paiement($db);
                            $paymentstatic->id = $objp->rowid;

                            $userstatic->id = $objp->userid;
                            $userstatic->login = $objp->login;

                            $TData[] = array(
                                'date' => $db->jdate($objp->dp),
                                'link' => $paymentstatic->id,
                                'status' => '',
                                'amount' => -$objp->amount,
                                'author' => $userstatic->getLoginUrl(1)
                            );
                            $TDataSort[] = $db->jdate($objp->dp);

                            $j++;
                        }

                        $db->free($resqlp);
                    }
                }
            }

            if (!empty($TData)) {

                // Sort array by date
                asort($TDataSort);
                array_multisort($TData, $TDataSort);

                // Balance calculation
                $balance = 0;
                foreach ($TData as &$data1) {
                    $balance += $data1['amount'];
                    $data1['balance'] += $balance;
                }

                // Reverse array to have last elements on top
                // $TData = array_reverse($TData);

                $totalDebit = 0;
                $totalCredit = 0;

                // Display array
                foreach ($TData as $data) {
                    $totalDebit += ($data['amount'] > 0) ? abs($data['amount']) : 0;
                    $totalCredit += ($data['amount'] > 0) ? 0 : abs($data['amount']);
                    $pdfdata[] = array('', '', $data['link'], dol_print_date($data['date'], 'day'),
                        (($data['amount'] > 0) ? price(abs($data['amount'])) : ''),
                        (($data['amount'] > 0) ? '' : price(abs($data['amount']))),
                        price($data['balance']));
                }

                if ($pdf->gety() > $pagelen) {
                    $pdf->addpage();
                }
                $pdfdata[] = array('', '', '',  '', price($totalDebit), price($totalCredit), price($balance));
        $TotGendebit+=$totalDebit;
        $TotGencredit+=$totalCredit;
        $TotGenBalance+=$balance;
            }
        }
    }
    $y = $pdf->gety();
    $pdfdata[] = array('TOTAUX', '', '', '',
        price($TotGendebit),
        price($TotGencredit),
        price($TotGenBalance));
    $w = array($xcode - $xcli, $xnumdoc - $xcode, $xdate - $xnumdoc, $xdes - $xdate, $xcred - $xdeb, $xsolde - $xcred, $droite - $xsolde);
    $align = array('L', 'L', 'L', 'C', 'R', 'R', 'R');
    $header = array($langs->trans("Customer"), $langs->trans("Code"), $langs->trans("Numéro doc"), $langs->trans("Date"), $langs->trans("Débit"), $langs->trans("Crédit"), $langs->trans("Solde"));
    Table($pdf, $w, $align, $header, $pdfdata, $pagelen);
    $pdf->Close();
    $pdf->Output();
}
/*
 * Multicell avec troncature de la chaine $s à la longueur de $w
 */

function Multicell(&$pdf, $w, $h, $s, $b, $f) {
    //Dépend de la taille de police utilisée et le style
    $pdf->Multicell($w, $h, substr($s, 0, $w / 2.5), $b, $f);
}

function Table(&$pdf, $w, $align, $header, $data, $offset = 0) {
    // En-tête
    $pdf->SetFont('', 'B', 12);
    $pdf->setx(5);
    for ($i = 0; $i < count($header); $i++)
        $pdf->Cell($w[$i], 7, $header[$i], 1, 0, 'C');
    $pdf->Ln();
    // Données
    $pdf->SetFont('', '');
    foreach ($data as $ind => $row) {
        if ($offset && $ind && $ind % $offset == 0) {
            $pdf->addpage();
        }
        $pdf->setx(5);
        for ($i = 0; $i < count($w); $i++)
            $pdf->Cell($w[$i], 6, substr($row[$i], 0, $w[$i] / 2.5), 1, 0, $align[$i]);
        $pdf->Ln();
    }
}
