<?php

/* Copyright (C) 2001-2006 Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2016 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2016 Abbes Bahfir  <dolipar@dolipar.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *  \file       htdocs/rapports/ca_clients.php
 * 	\ingroup    rapports
 *  \brief      Page de fiche Chiffre d'affaires par produit et par client
 */
require '../main.inc.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/functions.lib.php';
require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT . '/compta/paiement/class/paiement.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/pdf.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/class/html.formother.class.php';
require_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

$langs->load("companies");
if (!empty($conf->facture->enabled))
    $langs->load("bills");

if ($_REQUEST["date_startmonth"])
    $date_start = dol_mktime(0, 0, 0, $_REQUEST["date_startmonth"], $_REQUEST["date_startday"], $_REQUEST["date_startyear"]);
else
    $date_start = GETPOST('date_start');

if (!$date_start)
    $date_start = -1;

if ($_REQUEST["date_endmonth"])
    $date_end = dol_mktime(23, 59, 59, $_REQUEST["date_endmonth"], $_REQUEST["date_endday"], $_REQUEST["date_endyear"]);
else
    $date_end = GETPOST('date_end');

if (!$date_end)
    $date_end = time();

// checks:if date_start>date_end  then date_end=date_start + 24 hours
if ($date_start > 0 && $date_end > 0 && $date_start > $date_end)
    $date_end = $date_start + 86400;

// Purge search criteria
if (GETPOST("button_removefilter_x") || GETPOST("button_removefilter.x") || GETPOST("button_removefilter")) { // Both test are required to be compatible with all browsers
    $date_start = -1;
    $date_end = -1;
}
$output2pdf = false;
if (GETPOST("button_print_x") || GETPOST("button_print.x") || GETPOST("button_print"))
    $output2pdf = true;

$pagelen = GETPOST("pagelen");
if (!$pagelen)
    $pagelen = 40;

$userstatic = new User($db);

if (!$output2pdf) {

    /*
     * 	View
     */

    $form = new Form($db);
    $formother = new FormOther($db);
    llxHeader();

// Invoice list
    print load_fiche_titre('Chiffre d\'affaires par produit et par client');

    print '<form method="GET" action="' . $_SERVER["PHP_SELF"] . '">';
    print '<table class="liste" width="100%">';
    print '<tr class="liste_titre">';
    print '<th>' . $langs->trans("Date initale") . '' . '</th>';
    print '<th>' . $langs->trans("Date finale") . '' . '</th>';
    print '<th>' . $langs->trans("Hauteur page PDF") . '</th>';
    print '<th></th>';
    print '<th></th>';
    print "</tr>\n";
// Lignes des champs de filtres
    print '<tr class="liste_titre">';
    print '<td class="liste_titre" width="15%">' . $form->select_date($date_start, 'date_start', 0, 0, 0, '', 1, 0, 1) . '</td>';
    print '<td class="liste_titre" width="15%">' . $form->select_date($date_end, 'date_end', 0, 0, 0, '', 1, 0, 1) . '</td>';
    print '<td class="liste_titre" width="15%"><input type="text" name="pagelen" id="pagelen" value="' . $pagelen . '"size="5"></td>';
    print '<td class="liste_titre" width="15%"></td>';

    print '<td align="right" class="liste_titre">';
    $searchpitco = $form->showFilterAndCheckAddButtons(0);
    print $searchpitco;
    print '<input type="image" class="liste_titre" name="button_print" src="' . img_picto($langs->trans("Printer"), 'printer.png', '', '', 1) . '" value="' . dol_escape_htmltag($langs->trans("Imprimer PDF")) . '" title="' . dol_escape_htmltag($langs->trans("Imprimer PDF")) . '" onclick="window.open(\'' . $_SERVER['PHP_SELF'] . '?button_print=1&date_start=' . $date_start . '&date_end=' . $date_end . '&pagelen=\'+document.getElementById(\'pagelen\').value,\'_blank\');return false;">';
    print '</td>';

    print "</tr>\n";
    print '</table>';
    print '</form>';
}
else {

    $formatarray = pdf_getFormat();
    $page_largeur = $formatarray['width'];
    $page_hauteur = $formatarray['height'];
    $format = array($page_largeur, $page_hauteur);
    $marge_gauche = isset($conf->global->MAIN_PDF_MARGIN_LEFT) ? $conf->global->MAIN_PDF_MARGIN_LEFT : 10;
    $marge_droite = isset($conf->global->MAIN_PDF_MARGIN_RIGHT) ? $conf->global->MAIN_PDF_MARGIN_RIGHT : 10;
    $marge_haute = isset($conf->global->MAIN_PDF_MARGIN_TOP) ? $conf->global->MAIN_PDF_MARGIN_TOP : 10;
    $marge_basse = isset($conf->global->MAIN_PDF_MARGIN_BOTTOM) ? $conf->global->MAIN_PDF_MARGIN_BOTTOM : 10;

    $pdf = pdf_getInstance($format);
    $pdf->setPageOrientation('P');
    $pdf->SetAutoPageBreak(1, 0);
    if (class_exists('TCPDF')) {
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
    }
    $pdf->SetFont(pdf_getPDFFont($langs));

    $pdf->Open();

    $pdf->SetMargins($marge_gauche, $marge_haute, $marge_droite);   // Left, Top, Right
    $pdf->AddPage();

    // Logo
    $logo = $conf->mycompany->dir_output . '/logos/' . $mysoc->logo;
    if ($mysoc->logo) {
        if (is_readable($logo)) {
            $height = pdf_getHeightForLogo($logo);
            $pdf->Image($logo, 0, 10, 0, $height); // width=0 (auto)
            $pdf->setxy(0, $pdf->gety() + $height);
        }
        else {
            $pdf->SetFont('', 'B', $default_font_size - 2);
            Multicell($pdf, 100, 3, $outputlangs->transnoentities("ErrorLogoFileNotFound", $logo), 0, 'L');
            Multicell($pdf, 100, 3, $outputlangs->transnoentities("ErrorGoToGlobalSetup"), 0, 'L');
        }
    }
    else {
        $text = $mysoc->name;
        Multicell($pdf, 100, 4, $langs->convToOutputCharset($text), 0, 'L');
        $pdf->setxy(0, $pdf->gety() + 4);
    }
    $posy = $pdf->getY();
    $pdf->SetxY(130, 10);
    multiCell($pdf, 110, 4, 'Chiffre d\'affaires par produit et par client', 0, 'L');
    $pdf->SetXY($xcli, $posy);
    multicell($pdf, 200, 4, 'Date initiale: ' . date("j/n/Y", $date_start) . '      Date finale: ' . date("j/n/Y", $date_end), 0, 'L');
}

if (!$output2pdf) {

    print '<table class="noborder" width="100%">';
    print '<tr class="liste_titre">';
    print '<td width="100" align="left">' . $langs->trans("Ref") . '</td>';
    print '<td>' . $langs->trans("Designation") . '</td>';
    print '<td>' . $langs->trans("Customer") . '</td>';
    print '<td>' . $langs->trans("Code") . '</td>';
    print '<td align="center">' . $langs->trans("Quantité") . '</td>';
    print '<td align="right">' . $langs->trans("Prix de vente") . '</td>';
    print '<td align="right">' . $langs->trans("CA HT") . '</td>';
    print '</tr>';

    $TData = array();

    $sql = "SELECT p.rowid,p.ref,p.label,sum(fd.qty) as quantite,fd.subprice,sum(fd.total_ht) as total,s.rowid as soc";
    $sql.= " FROM " . MAIN_DB_PREFIX . "product p," . MAIN_DB_PREFIX . "facture f," . MAIN_DB_PREFIX . "facturedet fd," . MAIN_DB_PREFIX . "societe s";
    $sql.= " WHERE f.rowid=fd.fk_facture AND p.rowid = fd.fk_product AND s.rowid=f.fk_soc";
    $sql.= " AND p.fk_product_type = 0";
    $sql.= " AND UNIX_TIMESTAMP(CONVERT_TZ(f.datef, '+00:00', @@session.time_zone)) >= $date_start"; //Convert UTC to time zone
    $sql.= " AND UNIX_TIMESTAMP(CONVERT_TZ(f.datef, '+00:00', @@session.time_zone)) <= $date_end";
    $sql.= " AND f.entity = " . $conf->entity;
    $sql.= " GROUP BY p.ref,fd.subprice,s.rowid";
    $sql.= " ORDER BY ref ASC";

    $resql = $db->query($sql);
    if ($resql) {
        $var = true;
        $num = $db->num_rows($resql);

        // Boucle sur chaque facture
        for ($i = 0; $i < $num; $i++) {
            $objf = $db->fetch_object($resql);
            $TData[] = array(
                'rowid' => $objf->rowid,
                'ref' => $objf->ref,
                'label' => $objf->label,
                'client' => $objf->soc,
                'quantite' => $objf->quantite,
                'subprice' => $objf->subprice,
                'total' => $objf->total,
            );
        }
    }
    else {
        dol_print_error($db);
    }
    if (empty($TData)) {
        print '<tr ' . $bc[false] . '><td colspan="5">' . $langs->trans("NoInvoice") . '</td></tr>';
    }
    else {

        $quantite = 0;
        $total = 0;

        // Display array
        foreach ($TData as $data) {
            $p = new product($db);
            $p->fetch($data['rowid']);
            $var = !$var;
            print "<tr " . $bc[$var] . ">";
            $soc = new societe($db);
            $soc->fetch($data['client']);

            print "<td align=\"left\" nowrap>" . $p->getnomurl(1) . "</td>\n";
            print '<td>' . $data['label'] . "</td>\n";
            print '<td>' . $soc->getnomurl(1) . "</td>\n";
            print '<td>' . $soc->code_client . "</td>\n";
            print '<td align="center">' . $data['quantite'] . "</td>\n";
            print '<td align="right">' . price($data['subprice']) . "</td>\n";
            print '<td align="right">' . price($data['total']) . "</td>\n";

            print "</tr>\n";
            $quantite+=$data['quantite'];
            $total+=$data['total'];
        }

        print '<tr class="liste_total">';
        print '<td colspan="4">&nbsp;</td>';
        print '<td align="center" >' . $quantite . '</td>';
        print '<td =">&nbsp;</td>';
        print '<td align="right">' . price($total) . '</td>';
        print "</tr>\n";
    }

    print "</table>";


    llxFooter();
    $db->close();
}
else {
    $sql = "SELECT p.rowid,p.ref,p.label,sum(fd.qty) as quantite,fd.subprice,sum(fd.total_ht) as total,s.rowid as soc";
    $sql.= " FROM " . MAIN_DB_PREFIX . "product p," . MAIN_DB_PREFIX . "facture f," . MAIN_DB_PREFIX . "facturedet fd," . MAIN_DB_PREFIX . "societe s";
    $sql.= " WHERE f.rowid=fd.fk_facture AND p.rowid = fd.fk_product AND s.rowid=f.fk_soc";
    $sql.= " AND p.fk_product_type = 0";
    $sql.= " AND UNIX_TIMESTAMP(CONVERT_TZ(f.datef, '+00:00', @@session.time_zone)) >= $date_start"; //Convert UTC to time zone
    $sql.= " AND UNIX_TIMESTAMP(CONVERT_TZ(f.datef, '+00:00', @@session.time_zone)) <= $date_end";
    $sql.= " AND f.entity = " . $conf->entity;
    $sql.= " GROUP BY p.ref,fd.subprice,s.rowid";
    $sql.= " ORDER BY ref ASC";

    $resql = $db->query($sql);
    if ($resql) {
        $var = true;
        $num = $db->num_rows($resql);

        $quantite = 0;
        $total = 0;
        // Boucle sur chaque facture
        for ($i = 0; $i < $num; $i++) {
            $objf = $db->fetch_object($resql);
            $TData[] = array(
                'rowid' => $objf->rowid,
                'ref' => $objf->ref,
                'label' => $objf->label,
                'client' => $objf->soc,
                'quantite' => $objf->quantite,
                'subprice' => $objf->subprice,
                'total' => $objf->total,
            );
            $quantite+=$objf->quantite;
            $total+=$objf->total;
        }
       // Display array
        foreach ($TData as $data) {
            $soc = new societe($db);
            $soc->fetch($data['client']);
            $pdfdata[] = array($data['ref'], $data['label'],$soc->nom,$soc->code_client, $data['quantite'],
                price($data['subprice']), price($data['total']));
        }

        $pdfdata[] = array('TOTAUX', '','','',
            $quantite,
            '',
            price($total));
        $w = array(30, 50,20,20, 20, 35, 30);
        $align = array('L', 'L', 'L', 'L', 'C', 'R', 'R');
        $header = array("Ref.", "Désignation",'client','code', "Quantité", "Prix de vente", "CA HT");
        Table($pdf, $w, $align, $header, $pdfdata, $pagelen);
        $pdf->Close();
        $pdf->Output();
    }
}

/*
 * Multicell avec troncature de la chaine $s à la longueur de $w
 */

function Multicell(&$pdf, $w, $h, $s, $b, $f) {
    //Dépend de la taille de police utilisée et le style
    $pdf->Multicell($w, $h, substr($s, 0, $w / 2.5), $b, $f);
}

function Table(&$pdf, $w, $align, $header, $data, $offset = 0) {
    // En-tête
    $pdf->SetFont('', 'B', 12);
    $pdf->setx(5);
    for ($i = 0; $i < count($header); $i++)
        $pdf->Cell($w[$i], 7, $header[$i], 1,0,'C');
    $pdf->Ln();
    // Données
    $pdf->SetFont('', '');
    foreach ($data as $ind => $row) {
        if ($offset && $ind && $ind % $offset == 0) {
            $pdf->addpage();
        }
        $pdf->setx(5);
        for ($i = 0; $i < count($w); $i++)
            $pdf->Cell($w[$i], 6, substr($row[$i], 0, $w[$i] / 2.5), 1, 0, $align[$i]);
        $pdf->Ln();
    }
}
