<?php

/* Copyright (C) 2001-2006 Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2016 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2016 Abbes Bahfir  <dolipar@dolipar.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *  \file       htdocs/rapports/stocks.php
 * 	\ingroup    rapports
 *  \brief      Page de fiche recap Chiffre d'affaires par produit et par fournisseur
 */
require '../main.inc.php';
require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT . '/compta/paiement/class/paiement.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/functions.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/pdf.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/class/html.formother.class.php';
require_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/stock/class/entrepot.class.php';

$langs->load("companies");
if (!empty($conf->facture->enabled))
    $langs->load("bills");

if ($_REQUEST["date_startmonth"])
    $date_start = dol_mktime(0, 0, 0, $_REQUEST["date_startmonth"], $_REQUEST["date_startday"], $_REQUEST["date_startyear"]);
else
    $date_start = GETPOST('date_start');

if (!$date_start)
    $date_start = -1;

if ($_REQUEST["date_endmonth"])
    $date_end = dol_mktime(23, 59, 59, $_REQUEST["date_endmonth"], $_REQUEST["date_endday"], $_REQUEST["date_endyear"]);
else
    $date_end = GETPOST('date_end');

if (!$date_end)
    $date_end = time();

// checks:if date_start>date_end  then date_end=date_start + 24 hours
if ($date_start > 0 && $date_end > 0 && $date_start > $date_end)
    $date_end = $date_start + 86400;

// Purge search criteria
if (GETPOST("button_removefilter_x") || GETPOST("button_removefilter.x") || GETPOST("button_removefilter")) { // Both test are required to be compatible with all browsers
    $date_start = -1;
    $date_end = -1;
}
$output2pdf = false;
if (GETPOST("button_print_x") || GETPOST("button_print.x") || GETPOST("button_print"))
    $output2pdf = true;

$pagelen = GETPOST("pagelen");
if (!$pagelen)
    $pagelen = 25;

$userstatic = new User($db);

if (!$output2pdf) {

    /*
     * 	View
     */

    $form = new Form($db);
    $formother = new FormOther($db);
    llxHeader();

// Invoice list
    print load_fiche_titre('Etat des stocks');

    print '<form method="GET" action="' . $_SERVER["PHP_SELF"] . '">';
    print '<table class="liste" width="100%">';
    print '<tr class="liste_titre">';
    print '<th>' . $langs->trans("Date initale") . '' . '</th>';
    print '<th>' . $langs->trans("Date finale") . '' . '</th>';
    print '<th>' . $langs->trans("Hauteur page PDF") . '</th>';
    print '<th></th>';
    print '<th></th>';
    print "</tr>\n";
// Lignes des champs de filtres
    print '<tr class="liste_titre">';
    print '<td class="liste_titre" width="15%">' . $form->select_date($date_start, 'date_start', 0, 0, 0, '', 1, 0, 1) . '</td>';
    print '<td class="liste_titre" width="15%">' . $form->select_date($date_end, 'date_end', 0, 0, 0, '', 1, 0, 1) . '</td>';
    print '<td class="liste_titre" width="15%"><input type="text" name="pagelen" id="pagelen" value="' . $pagelen . '"size="5"></td>';
    print '<td class="liste_titre" width="15%"></td>';

    print '<td align="right" class="liste_titre">';
    $searchpitco = $form->showFilterAndCheckAddButtons(0);
    print $searchpitco;
    print '<input type="image" class="liste_titre" name="button_print" src="' . img_picto($langs->trans("Printer"), 'printer.png', '', '', 1) . '" value="' . dol_escape_htmltag($langs->trans("Imprimer PDF")) . '" title="' . dol_escape_htmltag($langs->trans("Imprimer PDF")) . '" onclick="window.open(\'' . $_SERVER['PHP_SELF'] . '?button_print=1&date_start=' . $date_start . '&date_end=' . $date_end . '&pagelen=\'+document.getElementById(\'pagelen\').value,\'_blank\');return false;">';
    print '</td>';

    print "</tr>\n";
    print '</table>';
    print '</form>';
}
else {

    $formatarray = pdf_getFormat();
    $page_largeur = $formatarray['width'];
    $page_hauteur = $formatarray['height'];
    $format = array($page_largeur, $page_hauteur);
    $marge_gauche = isset($conf->global->MAIN_PDF_MARGIN_LEFT) ? $conf->global->MAIN_PDF_MARGIN_LEFT : 10;
    $marge_droite = isset($conf->global->MAIN_PDF_MARGIN_RIGHT) ? $conf->global->MAIN_PDF_MARGIN_RIGHT : 10;
    $marge_haute = isset($conf->global->MAIN_PDF_MARGIN_TOP) ? $conf->global->MAIN_PDF_MARGIN_TOP : 10;
    $marge_basse = isset($conf->global->MAIN_PDF_MARGIN_BOTTOM) ? $conf->global->MAIN_PDF_MARGIN_BOTTOM : 10;

    $pdf = pdf_getInstance($format);
    $pdf->setPageOrientation('L');
    $pdf->SetAutoPageBreak(1, 0);
    if (class_exists('TCPDF')) {
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
    }
    $pdf->SetFont(pdf_getPDFFont($langs));

    $pdf->Open();

    $pdf->SetMargins($marge_gauche, $marge_haute, $marge_droite);   // Left, Top, Right
    $pdf->AddPage();

    // Logo
    $logo = $conf->mycompany->dir_output . '/logos/' . $mysoc->logo;
    if ($mysoc->logo) {
        if (is_readable($logo)) {
            $height = pdf_getHeightForLogo($logo);
            $pdf->Image($logo, 0, 10, 0, $height); // width=0 (auto)
            $pdf->setxy(0, $pdf->gety() + $height);
        }
        else {
            $pdf->SetFont('', 'B', $default_font_size - 2);
            Multicell($pdf, 100, 3, $outputlangs->transnoentities("ErrorLogoFileNotFound", $logo), 0, 'L');
            Multicell($pdf, 100, 3, $outputlangs->transnoentities("ErrorGoToGlobalSetup"), 0, 'L');
        }
    }
    else {
        $text = $mysoc->name;
        Multicell($pdf, 100, 4, $langs->convToOutputCharset($text), 0, 'L');
        $pdf->setxy(0, $pdf->gety() + 4);
    }
    $posy = $pdf->getY();
    $pdf->SetxY(240, 10);
    multiCell($pdf, 130, 4, 'Etat des stocks', 0, 'L');
    $pdf->SetXY($xcli, $posy);
    multicell($pdf, 200, 4, 'Date initiale: ' . date("j/n/Y", $date_start) . '      Date finale: ' . date("j/n/Y", $date_end), 0, 'L');
}

$sql = 'SELECT p.rowid,p.ref,p.label,ifnull(sm.si,0) as si,ifnull(sm.price,0) as price FROM llx_product p'
        . ' LEFT JOIN (SELECT fk_product, SUM( value ) AS si,AVG(price) as price FROM llx_stock_mouvement sm WHERE datem<=' 
        . $db->idate($date_start). ' GROUP BY fk_product) sm on sm.fk_product = p.rowid';
$TData = array();
$resql = $db->query($sql);
if ($resql) {
    $num = $db->num_rows($resql);
    for ($i = 0; $i < $num; $i++) {
        $objp = $db->fetch_object($resql);
        $p = new product($db);
        $p->fetch($objp->rowid);
        $sql2 = 'SELECT datem,value ,price FROM llx_stock_mouvement WHERE fk_product=' . $objp->rowid 
                . ' and datem<=' . $db->idate($date_end).' order by datem asc';
        $resql2 = $db->query($sql2);
        $num2 = $db->num_rows($resql2);
        $si = $objp->si; //stock initial
        $sipmp = $si * $objp->price; //stock initial en valeur        
        for ($j = 0; $j < $num2; $j++) {
            $objsm = $db->fetch_object($resql2);
            $entrepot = new Entrepot($db);
            $entrepot->fetch($objsm->fk_entrepot);
            $value=$objsm->value;
            $sf = $si +$value ;
            $valuepmp=$value * $objsm->price;
            $sfpmp = $sipmp + $valuepmp;
            $TData[] = array(
            'date' => dol_print_date($objsm->datem,"%d/%m/%Y"),
            'rowid' => ($j!=0)?'':$objp->rowid,
            'url' => ($j!=0)?'':$p->getnomurl(1),
            'ref' => ($j!=0)?'':$objp->ref,
            'label' => ($j!=0)?'':$objp->label,
            'ent_exp' => $objsm->value>0?'':$entrepot->libelle,
            'ent_dest' => $objsm->value<0?'':$entrepot->libelle,
            'price'=>price($objsm->price),
            'si' => $si,
            'sipmp' => price($sipmp),
            'sf' => $sf,
            'sfpmp' => price($sfpmp),
            'entrees' => $value>0?$value:'',
            'entreespmp' => $value>0?price($valuepmp):'',
            'sorties' =>  $value<0?-$value:'',
            'sortiespmp' => $value<0?price(-$valuepmp):''
            );
        }
    }
}
else {
    dol_print_error($db);
}
if (!$output2pdf) {

    print '<table class="liste" width="100%">';

    // Lignes des titres
    print "<tr class=\"liste_titre\">";
    print '<td>' . $langs->trans("Ref") . '</td>';
    print '<td>' . $langs->trans("Label") . '</td>';
    print '<td align="center">' . $langs->trans("Stock initial") . '</td>';
    print '<td align="right">' . $langs->trans("valeur") . '</td>';
    print '<td align="center">' . $langs->trans("Entrees") . '</td>';
    print '<td align="right">' . $langs->trans("valeur") . '</td>';
    print '<td align="center">' . $langs->trans("Sorties") . '</td>';
    print '<td align="right">' . $langs->trans("valeur") . '</td>';
    print '<td align="center">' . $langs->trans("Stock Final") . '</td>';
    print '<td align="right">' . $langs->trans("valeur") . '</td>';
    print '</tr>';

    if (empty($TData)) {
        print '<tr ' . $bc[false] . '><td colspan="5">' . $langs->trans('NoInvoice') . '</td></tr>';
    }
    else {

        // Display array
        foreach ($TData as $data) {
            $var = !$var;
            print "<tr " . $bc[$var] . ">";
            print "<td align=\"left\" nowrap>" . $data['url'] . "</td>\n";
            print '<td>' . $data['label'] . "</td>\n";
            print '<td align="center">' . $data['si'] . "</td>\n";
            print '<td align="right">' . $data['sipmp'] . "</td>\n";
            print '<td align="center">' . $data['entrees'] . "</td>\n";
            print '<td align="right">' . $data['entreespmp'] . "</td>\n";
            print '<td align="center">' . $data['sorties'] . "</td>\n";
            print '<td align="right">' . $data['sortiespmp'] . "</td>\n";
            print '<td align="center">' . $data['sf'] . "</td>\n";
            print '<td align="right">' . $data['sfpmp'] . "</td>\n";
            print "</tr>\n";
        }
    }
    print '</table>';

    llxFooter();
    $db->close();
}
else {
    foreach ($TData as $data) {
        $pdfdata[] = array($data['date'], $data['ref'], $data['label'], $data['ent_exp'], $data['ent_dest'],
            $data['si'], $data['price'], $data['sipmp'], 
            $data['entrees'],$data['entrees']>0?$data['price']:'',$data['entreespmp'], 
            $data['sorties'],$data['sorties']>0? $data['price']:'', $data['sortiespmp'],
            $data['sf'], $data['price'], $data['sfpmp'],
        );
    }

    $w = array(24, 20, 30, 20, 20, 45, 45, 45, 45);
    $w2 = array(24, 20, 30, 20, 20, 15, 15, 15, 10, 20, 15, 15, 15, 15, 15, 15, 15);
    $align = array('L', 'L', 'L', 'L', 'L', 'C', 'R', 'R', 'C', 'R', 'R', 'C', 'R', 'R', 'C', 'R', 'R');
    $header = array("Date", "Ref.", "Désignation", 'Ent. exp.', 'Ent. dest.',
        "Stock initial", "Entrées", "Sorties", "Stock final");
    $header2 = array('', '', '', '', '', 'Q', 'PMP', 'V', 'Q', 'PU/PMP', 'V', 'Q', 'PMP', 'V', 'Q', 'PMP', 'V');
    Table2($pdf, $w, $w2, $align, $header, $header2, $pdfdata, $pagelen);
    $pdf->Close();
    $pdf->Output();
}

/*
 * Multicell avec troncature de la chaine $s à la longueur de $w
 */

function Multicell(&$pdf, $w, $h, $s, $b, $f) {
    //Dépend de la taille de police utilisée et le style
    $pdf->Multicell($w, $h, substr($s, 0, $w / 2.5), $b, $f);
}

function Table2(&$pdf, $w, $w2, $align, $header, $header2, $data, $offset = 0) {
    // En-tête
    $pdf->SetFont('', 'B', 12);
    $pdf->setx(1);
    for ($i = 0; $i < count($header); $i++)
        $pdf->Cell($w[$i], 7, $header[$i], 1, 0, 'C');
    $pdf->Ln();
    $pdf->setx(1);
    for ($i = 0; $i < count($header2); $i++)
        $pdf->Cell($w2[$i], 7, $header2[$i], 1, 0, 'C');
    $pdf->Ln();
    // Données
    $pdf->SetFont('', '');
    foreach ($data as $ind => $row) {
        if ($offset && $ind && $ind % $offset == 0) {
            $pdf->addpage();
        }
        $pdf->setx(1);
        for ($i = 0; $i < count($w2); $i++)
            $pdf->Cell($w2[$i], 6, substr($row[$i], 0, $w2[$i] / 2.4), 1, 0, $align[$i]);
        $pdf->Ln();
    }
}
